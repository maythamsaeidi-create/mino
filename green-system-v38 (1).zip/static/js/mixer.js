/* ============================================================
   mixer.js — Final Mixer: locked until Final Mix, then the
   timeline deck + per-track rows (timeline player / M / S /
   volume / WAV / MP3). Multi-track playback with M/S + gain.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;

let nodes={},gains={},mute={},solo={},vol={};   // multi-track graph
let mixPlayer=null;

function tracks(){return[...(S.state.stems||[]),...(S.state.spkTrk||[])];}

/* ---------- raw state (after separation, before final mix) ---------- */
S.onSeparationDone=function(){
  S.state.finalMode=false;
  const st=S.state;
  $('mixWait').classList.remove('hidden');
  $('mixCard').classList.add('hidden');
  $('mixRows').innerHTML='';
  const ws=$('mixWaitStats');
  if(ws)ws.textContent=((st.stems||[]).length+' stems · '+(st.spkTrk||[]).length+' speakers')+' — next: Scan & Fix in Stem Studio, then Final Mix';
  renderMixRows(tracks(),false);
  S.switchTab('main');
  setTimeout(()=>{$('wshSection').scrollIntoView({behavior:'smooth',block:'center'});},400);
};

/* ---------- final state (after Final Mix on the server) ---------- */
S.onFinalMixDone=async function(res){
  const mix_id=res&&res.out_id;
  if(!mix_id){S.err(S.richErr('Final Mix finished but no output id',{hint:'Run Final Mix again.'}));return;}
  const tracksOut=[{id:mix_id,name:'Final Mix',spk:false}]
    .concat(((res&&res.stems)||[]).map(()=>null).filter(Boolean)); /* placeholder — real list below */
  /* fetch the final files: mix + every ticked stem's final file from workshop result */
  const list=[{id:mix_id,name:'Final Mix',spk:false}];
  if(S.wshRows)S.wshRows().forEach(r=>{
    if(!r.final)return;
    const id=(r.outId&&!r.passthrough)?r.outId:(r.serverId||null);
    if(id)list.push({id,name:r.name,spk:r.isSpk});
  });
  S.setStat('Fetching final files…');
  try{
    const tks=[];
    for(let i=0;i<list.length;i++){
      S.setStat('Fetching "'+list[i].name+'" ('+(i+1)+'/'+list.length+')…');
      const blob=await fetch('/api/dsp/file/'+encodeURIComponent(list[i].id))
        .then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.blob();});
      const buf=await S.decode(blob);
      const t={id:'fin_'+list[i].id,name:list[i].name,buffer:buf,blob,
               duration:buf.duration,spk:!!list[i].spk};
      if(t.spk)t.mp3Blob=S.ab2mp3(t.buffer,192);
      tks.push(t);
    }
    S.state.stems=tks.filter(t=>!t.spk);
    S.state.spkTrk=tks.filter(t=>t.spk);
    S.state.finalMode=true;
    /* mixer UI */
    $('mixWait').classList.add('hidden');
    $('mixCard').classList.remove('hidden');
    renderMixRows(tracks(),true);
    S.setStat('Final mixer ready — Final Mix first');
    $('mixCard').scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){
    S.err(S.richErr('Could not load the final files: '+(e.message||e),{hint:'Run Final Mix again in Stem Studio.'}));
  }
};

/* ---------- rows ---------- */
function renderMixRows(list,finalMode){
  const box=$('mixRows');
  box.innerHTML='';
  nodes={};gains={};mute={};solo={};vol={};
  let mdur=0;
  list.forEach(t=>{if(t.duration>mdur)mdur=t.duration;});
  $('trackCount').textContent=list.length;
  list.forEach((t,i)=>{
    const row=S.el('div','row');
    const head=S.el('div','rhead');
    head.innerHTML='<div class="rid">'
      +'<span class="tag '+(t.spk?'spk':'voc')+'">'+(finalMode&&i===0?'FINAL':(t.spk?'SPK':'STEM'))+'</span>'
      +'<div style="min-width:0"><div class="rname">'+S.esc(t.name)+'</div>'
      +'<div class="rmeta">'+S.fd(t.duration)+' · '+S.fb(t.blob.size)+'</div></div></div>'
      +'<div class="rbtns">'
      +'<button class="btn sm" data-a="m">M</button>'
      +'<button class="btn sm" data-a="s">S</button>'
      +'<input type="range" min="0" max="1" step="0.01" value="1" data-a="v" style="width:90px;accent-color:var(--acc)">'
      +'<button class="btn sm" data-a="w">WAV</button>'
      +(t.mp3Blob?'<button class="btn sm" data-a="mp">MP3</button>':'')
      +'</div>';
    const tid=t.id;
    mute[tid]=false;solo[tid]=false;vol[tid]=1;
    head.querySelector('[data-a=m]').onclick=e=>{e.stopPropagation();
      mute[tid]=!mute[tid];e.target.style.color=mute[tid]?'var(--err)':'';updGain();};
    head.querySelector('[data-a=s]').onclick=e=>{e.stopPropagation();
      solo[tid]=!solo[tid];e.target.style.color=solo[tid]?'var(--warn)':'';updGain();};
    head.querySelector('[data-a=v]').oninput=e=>{vol[tid]=parseFloat(e.target.value);updGain();};
    head.querySelector('[data-a=w]').onclick=e=>{e.stopPropagation();
      const a=S.el('a');a.href=URL.createObjectURL(t.blob);
      a.download=String(t.name).replace(/[\s()]+/g,'_')+'.wav';a.click();};
    const mpb=head.querySelector('[data-a=mp]');
    if(mpb)mpb.onclick=e=>{e.stopPropagation();
      const a=S.el('a');a.href=URL.createObjectURL(t.mp3Blob);
      a.download=String(t.name).replace(/[\s()]+/g,'_')+'.mp3';a.click();};
    row.appendChild(head);
    /* per-track TIMELINE PLAYER (single-side; plays just this track) */
    const body=S.el('div');body.style.cssText='padding:0 11px 11px';
    const ph=S.el('div');
    body.appendChild(ph);row.appendChild(body);
    const p=S.Player(ph,{});
    p.setBuffer('A',t.buffer);
    p._mixTrack=t;      // used by the mix graph start
    box.appendChild(row);
  });
  /* the master mix deck player */
  const deck=$('mixDeck');
  if(deck){
    deck.innerHTML='';
    mixPlayer=S.Player(deck,{});
    $('mixPlayAll').onclick=()=>{startMix(mixPlayer.pos());};
    $('mixStopAll').onclick=()=>{mixPlayer.stop();stopMix();};
  }
}

/* ---------- multi-track mix playback (M/S/gain) ---------- */
function stopMix(){
  Object.values(nodes).forEach(n=>{try{n.stop();n.disconnect();}catch(e){}});
  nodes={};gains={};
}
function startMix(off){
  stopMix();S.stopAllPlayers();
  const list=tracks();
  if(!list.length)return;
  const c=S.ctx();
  const anySolo=Object.values(solo).some(Boolean);
  list.forEach(t=>{
    const n=c.createBufferSource();n.buffer=t.buffer;
    const g=c.createGain();
    let eg=vol[t.id]!=null?vol[t.id]:1;
    if(mute[t.id])eg=0;
    if(anySolo&&!solo[t.id])eg=0;
    g.gain.value=eg;
    n.connect(g);g.connect(c.destination);
    n.start(0,Math.min(off,Math.max(0,t.buffer.duration-0.05)));
    nodes[t.id]=n;gains[t.id]=g;
  });
}
function updGain(){
  const anySolo=Object.values(solo).some(Boolean);
  Object.keys(gains).forEach(tid=>{
    const g=gains[tid];if(!g)return;
    let eg=vol[tid]!=null?vol[tid]:1;
    if(mute[tid])eg=0;
    if(anySolo&&!solo[tid])eg=0;
    g.gain.setValueAtTime(eg,S.ctx().currentTime);
  });
}

/* ---------- ZIPs ---------- */
async function dlZip(items,name,extra){
  if(!window.JSZip){S.err('ZIP library not loaded');return;}
  const zip=new JSZip();
  const f=zip.folder(name);
  items.forEach(i=>{
    f.file(String(i.name).replace(/[\s()]+/g,'_')+'.wav',i.blob);
    if(i.mp3Blob)f.file(String(i.name).replace(/[\s()]+/g,'_')+'.mp3',i.mp3Blob);
  });
  if(extra)f.file(extra.name,extra.blob);
  const b=await zip.generateAsync({type:'blob'});
  const a=S.el('a');a.href=URL.createObjectURL(b);a.download=name+'.zip';a.click();
}
const base=()=> (S.pn||'audio').replace(/\.[^/.]+$/,'');
$('dlAll').onclick=()=>dlZip(tracks(),base()+(S.state.finalMode?'_Final':'_All'));
$('dlStems').onclick=()=>dlZip(S.state.stems||[],base()+(S.state.finalMode?'_Final_Stems':'_Stems_Raw'));
$('dlSpk').onclick=()=>dlZip(S.state.spkTrk||[],base()+(S.state.finalMode?'_Final_Speakers':'_Speakers_Raw'));
})();
