/* ============================================================
   player.js — THE TIMELINE PLAYER
   Professional waveform timeline for every audio file:
     · canvas waveform (peaks, DPR-aware, redraw on resize)
     · moving playhead + progress region + click-to-seek
     · SMPTE timecode HH:MM:SS:FF
     · dual mode: A/B sources decoded as buffers — flipping sides
       keeps the EXACT playback position (sample-accurate compare)
   Built on Web Audio (AudioBufferSourceNode), single ctx.
   ============================================================ */
(function(){
'use strict';
const S=window.S;

const PLAYERS=[];              // registry — only one plays at a time
let rafId=0;

function stopAllExcept(me){
  PLAYERS.forEach(p=>{if(p!==me&&p.playing())p.stop();});
}
S.stopAllPlayers=function(){PLAYERS.forEach(p=>p.stop());};

/* ---------- peaks (min/max per column) ---------- */
function computePeaks(buf,cols){
  const ch=Math.min(2,buf.numberOfChannels);
  const step=Math.max(1,Math.floor(buf.length/cols));
  const a=buf.getChannelData(0);
  const b=ch>1?buf.getChannelData(1):null;
  const peaks=new Float32Array(cols*2);   // [min,max] interleaved
  for(let c=0;c<cols;c++){
    let mn=1,mx=-1;
    const s0=c*step,s1=Math.min(buf.length,s0+step);
    for(let i=s0;i<s1;i+=1){              // stride adapts to keep it fast
      let v=a[i];if(b)v=(v+b[i])*0.5;
      if(v<mn)mn=v;if(v>mx)mx=v;
    }
    peaks[c*2]=mn;peaks[c*2+1]=mx;
  }
  return peaks;
}

/* ---------- create ---------- */
S.Player=function(container,opts){
  opts=opts||{};
  const dual=!!opts.dual;
  const mini=!!opts.mini;              /* v28: compact stage player */
  const P={_side:'A',_bufs:{A:null,B:null},_peaks:{A:null,B:null},
           _node:null,_t0:0,_off:0,_pos:0,_playing:false,
           _markers:[],
           _onTick:opts.onTick||null,_labels:opts.labels||{A:'Original',B:'Fixed'}};

  /* ---- DOM ---- */
  const root=S.el('div','tl'+(dual?' dual':'')+(mini?' mini':''));
  const cv=document.createElement('canvas');cv.className='tlcanvas';
  if(opts.height)cv.style.height=opts.height+'px';
  if(mini)cv.style.height='26px';
  root.appendChild(cv);
  const foot=S.el('div','tlfoot');
  const pb=S.el('button','btn sm'+(mini?' pbtn':''));
  pb.title=mini?'Play / Pause':'Play / Stop (Space when focused)';
  const time=S.el('span','tltime');
  if(mini)time.innerHTML='<span class="cur">0:00</span><span class="tot"> / 0:00</span>';
  else time.innerHTML='<span class="cur">00:00:00:00</span><span class="tot"> / 00:00:00:00</span>';
  const sideB=S.el('span','tlside');
  let flipB=null;
  foot.appendChild(pb);
  if(!mini)foot.appendChild(sideB);
  foot.appendChild(time);
  if(mini){const sp=document.createElement('span');sp.style.flex='1';foot.appendChild(sp);}
  if(dual){
    flipB=S.el('button','abbtn tlflip');
    flipB.title='A/B compare — flip between '+P._labels.A+' (A) and '+P._labels.B+' (B) at the exact same position';
    flipB.innerHTML='<span class="sa">A</span><span class="sw">⇄</span><span class="sb">B</span>';
    foot.appendChild(flipB);
  }
  root.appendChild(foot);
  container.appendChild(root);
  /* marker tooltip host (markers drawn on the canvas) */
  const tip=S.el('div','tlmark-tip');tip.style.display='none';root.appendChild(tip);
  PLAYERS.push(P);

  const ctx2=cv.getContext('2d');

  /* ---- sizing ---- */
  function fit(){
    const r=cv.getBoundingClientRect();
    const dpr=window.devicePixelRatio||1;
    if(r.width<2)return;
    cv.width=Math.round(r.width*dpr);
    cv.height=Math.round(r.height*dpr);
    ctx2.setTransform(dpr,0,0,dpr,0,0);
    if(P._peaks[P._side])P._peaks[P._side]=null; // recompute at new resolution
    draw();
  }
  if(window.ResizeObserver)new ResizeObserver(()=>fit()).observe(cv);
  window.addEventListener('resize',fit);

  /* ---- draw ---- */
  function buf(){return P._bufs[P._side];}
  function peaks(){
    const b=buf();if(!b)return null;
    const cols=Math.max(50,Math.round(cv.width/(window.devicePixelRatio||1)));
    if(!P._peaks[P._side]||P._peaks[P._side]._cols!==cols){
      const pk=computePeaks(b,cols);pk._cols=cols;P._peaks[P._side]=pk;
    }
    return P._peaks[P._side];
  }
  function draw(){
    const w=cv.width/(window.devicePixelRatio||1),h=cv.height/(window.devicePixelRatio||1);
    ctx2.clearRect(0,0,w,h);
    ctx2.fillStyle=getComputedStyle(cv).backgroundColor||'#0d0d10';
    ctx2.fillRect(0,0,w,h);
    const pk=peaks();const d=dur();
    if(!pk||!d){ // empty state
      ctx2.fillStyle='rgba(113,113,122,.25)';
      ctx2.fillRect(0,h/2-1,w,2);
      return;
    }
    const cols=pk._cols;
    const px=P._playing?pos():P._pos;
    const pxX=px/d*w;
    const css=getComputedStyle(document.documentElement);
    const accA=css.getPropertyValue('--accent-ab-a').trim()||'#34d399';
    const accB=css.getPropertyValue('--accent-ab-b').trim()||'#2dd4bf';
    const col=(P._side==='A')?accA:accB;
    const dim='rgba(161,161,170,.28)';
    const mid=h/2,amp=h*0.44;
    for(let c=0;c<cols;c++){
      const mn=pk[c*2],mx=pk[c*2+1];
      const x=(c/cols)*w;
      const y0=mid-mx*amp,y1=mid-mn*amp;
      ctx2.fillStyle=(x<=pxX)?col:dim;
      ctx2.fillRect(x,y0,Math.max(1,w/cols),Math.max(1,y1-y0));
    }
    /* playhead */
    ctx2.fillStyle=col;
    ctx2.fillRect(Math.max(0,Math.min(w-1.5,pxX)),2,1.5,h-4);

    /* markers — analysis segments on top of the waveform */
    if(P._markers&&P._markers.length&&d){
      const MK={silence:'rgba(113,113,122,',quiet:'rgba(56,189,248,',
                loud:'rgba(251,146,60,',clip:'rgba(251,113,133,'};
      P._markers.forEach(m=>{
        const c=MK[m.kind]||'rgba(161,161,170,';
        const x0=Math.max(0,(m.t0/d)*w),x1=Math.min(w,(m.t1/d)*w);
        if(x1-x0<1)return;
        ctx2.fillStyle=c+'0.14)';          // translucent band
        ctx2.fillRect(x0,2,x1-x0,h-4);
        ctx2.fillStyle=c+'0.95)';          // solid start tick
        ctx2.fillRect(x0,2,1.5,h-4);
        if(x1-x0>7){                       // end tick on long segments
          ctx2.fillStyle=c+'0.55)';
          ctx2.fillRect(x1-1.2,2,1.2,h-4);
        }
      });
      /* re-draw playhead over the bands so it stays visible */
      ctx2.fillStyle=col;
      ctx2.fillRect(Math.max(0,Math.min(w-1.5,pxX)),2,1.5,h-4);
    }
  }

  /* ---- timekeeping (sample-accurate) ---- */
  function dur(){const b=buf();return b?b.duration:0;}
  function pos(){
    if(!P._playing)return Math.min(P._pos,dur());
    return Math.min(P._off+(S.ctx().currentTime-P._t0),dur());
  }

  /* ---- transport ---- */
  function killNode(){
    if(P._node){try{P._node.onended=null;P._node.stop();}catch(e){}
      P._node.disconnect();P._node=null;}
  }
  function startNode(off){
    const b=buf();if(!b)return;
    const c=S.ctx();
    if(c.state==='suspended')c.resume();
    const n=c.createBufferSource();
    n.buffer=b;
    n.connect(S.anTap?S.anTap():c.destination);   /* v27: taps the shared analyser (passthrough) */
    n.onended=()=>{ // natural end only (killNode nulls handler first)
      P._playing=false;P._pos=dur();killNode();ui();draw();
      if(P._onTick)P._onTick(P._side,P._pos,true);
    };
    off=Math.max(0,Math.min(off,b.duration-0.005));
    n.start(0,off);
    P._node=n;P._t0=c.currentTime;P._off=off;P._playing=true;
    loop();
  }
  P.play=async function(){
    if(P._playing)return;
    if(!buf()){S.toast('Load audio first',true);return;}
    stopAllExcept(P);
    const c=S.ctx();
    if(c.state==='suspended'){try{await c.resume();}catch(e){}}
    if(!P._playing)startNode(Math.min(P._pos,Math.max(0,dur()-0.005)));
    ui();
  };
  P.stop=function(){
    if(!P._playing){P._pos=0;draw();ui();return;}
    P._pos=pos();P._playing=false;killNode();ui();draw();
  };
  P.toggle=function(){P._playing?P.stop():P.play();};
  P.seek=function(t){
    const was=P._playing;
    if(was){P._pos=Math.max(0,Math.min(t,dur()));killNode();P._playing=false;startNode(P._pos);}
    else{P._pos=Math.max(0,Math.min(t,dur()));draw();ui();}
  };
  P.pos=pos;P.dur=dur;
  P.playing=function(){return P._playing;};
  P.destroy=function(){P.stop();const i=PLAYERS.indexOf(P);if(i>=0)PLAYERS.splice(i,1);root.remove();};

  /* ---- A/B (the whole point) ---- */
  P.hasSide=function(sd){return !!P._bufs[sd];};
  P.setSide=function(sd,keepPos){
    if(!dual||sd===P._side)return;
    if(!P._bufs[sd]){S.toast('No '+(sd==='A'?'A':'B')+' file yet',true);return;}
    const t=keepPos?pos():0;
    const was=P._playing;
    if(was)killNode();
    P._side=sd;P._pos=Math.min(t,dur());P._playing=false;
    if(was)startNode(P._pos);else{ui();draw();}
    ui();
  };
  P.flip=function(){P.setSide(P._side==='A'?'B':'A',true);};

  /* ---- markers (analysis segments) ---- */
  P.setMarkers=function(list){
    P._markers=(list||[]).filter(m=>typeof m.t0==='number'
      &&typeof m.t1==='number'&&m.kind).slice(0,400);
    draw();
  };
  P.getMarkers=function(){return P._markers.slice();};

  /* ---- loading ---- */
  function setBuf(sd,b){
    if(!b)return;
    if(P._side===sd){killNode();P._playing=false;P._pos=Math.min(P._pos,b.duration);}
    P._bufs[sd]=b;P._peaks[sd]=null;
    if(!P._bufs[P._side])P._side=sd;
    ui();draw();
  }
  P.setBuffer=function(sd,b){setBuf(sd,b);return Promise.resolve();};
  P.setUrl=function(sd,url){
    return fetch(url)
      .then(r=>{if(!r.ok)throw S.richErr('file missing on the server (HTTP '+r.status+')',{url:String(url)});return r.arrayBuffer();})
      .then(ab=>S.decode(ab))
      .then(b=>{setBuf(sd,b);})
      .catch(e=>{S.toast('Could not load this file: '+(e.message||e),true);});
  };
  P.setBlob=function(sd,blob){
    return S.decode(blob).then(b=>setBuf(sd,b)).catch(e=>{S.err(S.richErr('Cannot decode this audio file',{hint:'The file may be corrupt or in an unsupported codec.'}));});
  };

  /* ---- UI state ---- */
  const mmfmt=t=>{t=Math.max(0,t||0);const m=Math.floor(t/60),s=Math.floor(t%60);
    return m+':'+(s<10?'0':'')+s;};
  function ui(){
    if(mini){
      const IC_PL='<svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path d="M6.3 2.84A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.27l9.34-5.89a1.5 1.5 0 000-2.54L6.3 2.84z"/></svg>';
      const IC_PA='<svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path d="M5.75 3h2.6a.9.9 0 01.9.9v12.2a.9.9 0 01-.9.9h-2.6a.9.9 0 01-.9-.9V3.9a.9.9 0 01.9-.9zm5.9 0h2.6a.9.9 0 01.9.9v12.2a.9.9 0 01-.9.9h-2.6a.9.9 0 01-.9-.9V3.9a.9.9 0 01.9-.9z"/></svg>';
      pb.innerHTML=P._playing?IC_PA:IC_PL;
      if(P._playing){pb.style.background='var(--acc)';pb.style.color='#052e1c';}
      else{pb.style.background='';pb.style.color='';}
      const cur=time.querySelector('.cur'),tot=time.querySelector('.tot');
      if(cur)cur.textContent=mmfmt(P._playing?pos():P._pos);
      if(tot)tot.textContent=' / '+mmfmt(dur());
      return;
    }
    const IC_PLAY='<svg width="11" height="11" viewBox="0 0 20 20" fill="currentColor"><path d="M6.3 2.84A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.27l9.34-5.89a1.5 1.5 0 000-2.54L6.3 2.84z"/></svg>';
    const IC_STOP='<svg width="11" height="11" viewBox="0 0 20 20" fill="currentColor"><path d="M5 4a1 1 0 00-1 1v10a1 1 0 001 1h10a1 1 0 001-1V5a1 1 0 00-1-1H5z"/></svg>';
    pb.innerHTML=(P._playing?IC_STOP+'<span>Stop</span>':IC_PLAY+'<span>Play</span>');
    if(P._playing){pb.style.background='var(--acc)';pb.style.color='#052e1c';}
    else{pb.style.background='';pb.style.color='';}
    const cur=time.querySelector('.cur'),tot=time.querySelector('.tot');
    if(cur)cur.textContent=S.tcSMPTE(P._playing?pos():P._pos);
    if(tot)tot.textContent=' / '+S.tcSMPTE(dur());
    sideB.textContent=dual?P._side:'';
    sideB.className='tlside '+(dual?P._side:'');
    if(dual&&flipB){
      const sa=flipB.querySelector('.sa'),sb=flipB.querySelector('.sb');
      if(sa)sa.className='sa'+(P._side==='A'?' live':'');
      if(sb)sb.className='sb'+(P._side==='B'?' live':'');
      flipB.disabled=!P._bufs.A||!P._bufs.B;
      flipB.title='A/B compare — '+P._labels.A+' (A) ⇄ '+P._labels.B+' (B) at the exact same position';
    }
  }

  /* ---- rAF loop ---- */
  function loop(){
    cancelAnimationFrame(rafId);
    (function tick(){
      if(!P._playing)return;
      const cur=time.querySelector('.cur');
      if(cur)cur.textContent=mini?mmfmt(pos()):S.tcSMPTE(pos());
      draw();
      if(P._onTick)P._onTick(P._side,pos(),false);
      rafId=requestAnimationFrame(tick);
    })();
  }

  /* ---- events ---- */
  pb.onclick=e=>{e.stopPropagation();P.toggle();};
  if(flipB)flipB.onclick=e=>{e.stopPropagation();P.flip();};
  cv.onclick=e=>{
    const r=cv.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width;
    P.seek(x*dur());
  };
  cv.addEventListener('mousemove',e=>{
    if(!P._markers.length||!dur()){tip.style.display='none';return;}
    const r=cv.getBoundingClientRect();
    const t=(e.clientX-r.left)/r.width*dur();
    const hit=P._markers.find(m=>t>=m.t0-0.3&&t<=m.t1+0.3);
    if(hit){
      tip.textContent=(hit.label||hit.kind)+' · '+S.tcSMPTE(hit.t0)
        +' – '+S.tcSMPTE(hit.t1);
      tip.style.display='block';
      const rw=root.getBoundingClientRect();
      const tx=Math.max(2,Math.min(rw.width-170,e.clientX-rw.left-80));
      tip.style.left=tx+'px';
    }else tip.style.display='none';
  });
  cv.addEventListener('mouseleave',()=>{tip.style.display='none';});

  setTimeout(fit,0);   // initial size after layout
  ui();
  return P;
};
})();
