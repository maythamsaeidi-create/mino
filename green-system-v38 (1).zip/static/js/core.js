/* ============================================================
   core.js — foundation: state, utils, timecode, API (JSON contract),
   error system, diagnostic log, server heartbeat.
   Every module hangs off window.S (Studio namespace).
   ============================================================ */
(function(){
'use strict';
const S=window.S=window.S||{};

/* ---------- dom ---------- */
S.$=function(id){return document.getElementById(id);};
S.el=function(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;};

/* ---------- state ---------- */
S.state={
  lf:null,          // source file (File)
  sab:null,         // decoded source AudioBuffer
  stems:[],         // [{id,name,blob,duration,kind}]
  spkTrk:[],        // [{id,name,blob,duration}]
  finalMode:false,  // mixer unlocked
  serverUp:null,
};

/* ---------- utils ---------- */
S.esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));};
S.fb=function(b){if(!b)return'0B';const k=1024,si=['B','KB','MB','GB'],i=Math.max(0,Math.min(3,Math.floor(Math.log(b)/Math.log(k))));return(b/Math.pow(k,i)).toFixed(1)+' '+si[i];};

/* ---------- TIMECODE (broadcast standard) ----------
   tcSMPTE : HH:MM:SS:FF  (25 fps — player + everywhere professional)
   tcSRT   : HH:MM:SS,mmm (cue lists / export)                        */
S.fps=25;
function p2(n){return (n<10?'0':'')+n;}
S.tcSMPTE=function(t){
  t=Math.max(0,t||0);
  const h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=Math.floor(t%60);
  const f=Math.floor((t-Math.floor(t))*S.fps);
  return p2(h)+':'+p2(m)+':'+p2(s)+':'+p2(f);
};
S.tcSRT=function(t){
  t=Math.max(0,t||0);
  const h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=Math.floor(t%60);
  const ms=Math.round((t-Math.floor(t))*1000);
  return p2(h)+':'+p2(m)+':'+p2(s)+','+(ms<100?(ms<10?'00':'0'):'')+ms;
};
S.fd=function(t){ // compact HH:MM:SS for meta lines
  t=Math.max(0,t||0);
  return p2(Math.floor(t/3600))+':'+p2(Math.floor(t%3600/60))+':'+p2(Math.floor(t%60));
};

/* ---------- audio context (shared, lazily resumed) ---------- */
let _ac=null;
S.ctx=function(){
  if(!_ac)_ac=new (window.AudioContext||window.webkitAudioContext)();
  if(_ac.state==='suspended')_ac.resume();
  return _ac;
};
/* decode any blob/arraybuffer into an AudioBuffer (PCM via ctx) */
S.decode=async function(data){
  const ab=(data instanceof ArrayBuffer)?data:await data.arrayBuffer();
  return await S.ctx().decodeAudioData(ab);
};

/* ---------- API: strict JSON contract ----------
   Every response is parsed as JSON; a non-JSON body (HTML error page etc.)
   becomes a precise structured error instead of "Unexpected token '<'". */
S.api=async function(url,opts){
  const t0=performance.now();
  let r=null,text='';
  try{
    r=await fetch(url,opts);
  }catch(e){
    throw S.richErr('Network unreachable — server is down or offline',
      {url:String(url),hint:'The browser could not reach the server. If it repeats, restart the server (start.sh) and reload the page.'});
  }
  text=await r.text();
  const ms=Math.round(performance.now()-t0);
  S.diag({m:(opts&&opts.method)||'GET',u:String(url),s:r.status,d:ms+'ms',b:text.slice(0,220)});
  let j=null;
  try{j=JSON.parse(text);}catch(e){
    throw S.richErr('Server returned '+(r.status||'?')+' — not JSON',
      {url:String(url),httpStatus:r.status,respBody:text.slice(0,400),
       hint:'The server answered with an error page instead of data. This is a server bug — the exact response is shown below.'});
  }
  return j;
};
S.jpost=function(url,body){return S.api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});};
S.jget=function(url){return S.api(url);};
/* upload with progress (name: filename for nameless Blobs) */
S.upl=function(url,file,onpct,name){
  return new Promise((res,rej)=>{
    const x=new XMLHttpRequest();
    x.open('POST',url);
    x.upload.onprogress=e=>{if(e.lengthComputable&&onpct)onpct(Math.round(e.loaded/e.total*100));};
    x.onload=()=>{S.diag({m:'POST',u:url,s:x.status,b:(x.responseText||'').slice(0,220)});
      let j=null;try{j=JSON.parse(x.responseText);}catch(e){}
      if(j&&j.ok!==false)res(j);else rej(S.richErr((j&&j.reason)||('upload failed ('+x.status+')'),{url:url,httpStatus:x.status,respBody:x.responseText.slice(0,400)}));};
    x.onerror=()=>rej(S.richErr('Upload failed — network error',{url:url}));
    const fd=new FormData();
    fd.append('file',file,name||file.name||'audio.wav');
    x.send(fd);
  });
};

/* ---------- structured error system (lean but precise) ---------- */
S.richErr=function(msg,det){const e=new Error(msg);e.det=det||{};return e;};
let _lastErr=null;
S.err=function(mOrE){
  const isE=mOrE instanceof Error;
  const msg=isE?mOrE.message:String(mOrE||'-');
  const d=(isE&&mOrE.det)||{};
  _lastErr={msg,d};
  const box=S.$('errBox');
  if(box){
    box.classList.remove('hidden');
    S.$('errTitle').textContent='Error';
    S.$('errMsg').textContent=msg;
    const h=S.$('errHint');
    if(d.hint){h.textContent=d.hint;h.classList.remove('hidden');}else h.classList.add('hidden');
    box.scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  S.diag({m:'ERROR',d:msg.slice(0,180)});
  console.error('[studio]',mOrE);
};
S.closeErr=function(){const b=S.$('errBox');if(b)b.classList.add('hidden');};
S.$('errClose').onclick=S.closeErr;

/* ---------- diagnostic log ---------- */
const _dl=[];
S.diag=function(e){_dl.push(Object.assign({t:new Date().toISOString()},e));if(_dl.length>300)_dl.shift();S._rDiag();};
S._rDiag=function(){
  const n=S.$('diagCount'),b=S.$('diagBody');
  if(n)n.textContent=_dl.length;
  if(!b)return;
  b.innerHTML=_dl.slice().reverse().map(e=>{
    let c='var(--err)';if(e.s>=200&&e.s<300)c='var(--acc)';else if(e.s>=400&&e.s<500)c='var(--warn)';
    return '<div style="padding:3px 0;border-bottom:1px solid var(--line)"><span style="color:var(--fg3)">'+e.t.slice(11,19)+'</span> <b style="color:var(--info)">'+S.esc(e.m||'')+'</b> <b style="color:'+c+'">'+S.esc(String(e.s==null?'-':e.s))+'</b> '+(e.d?'<span style="color:var(--fg3)">'+S.esc(String(e.d))+'</span>':'')+(e.u?'<div style="color:var(--fg3);padding-left:14px;word-break:break-all">'+S.esc(String(e.u).slice(0,110))+'</div>':'')+'</div>';
  }).join('');
};
S.$('diagBtn').onclick=()=>S.$('diagPanel').classList.toggle('hidden');
S.$('diagClear').onclick=()=>{_dl.length=0;S._rDiag();};
S.$('diagClose').onclick=()=>S.$('diagPanel').classList.add('hidden');

/* window-level safety nets */
window.addEventListener('error',ev=>{S.err(ev.error||ev.message);});
window.addEventListener('unhandledrejection',ev=>{S.err(ev.reason||'Unhandled background failure');});

/* ---------- server heartbeat (visible, honest) ---------- */
async function beat(){
  const hb=S.$('hb');
  try{
    const j=await S.jget('/healthz');
    const up=!!(j&&j.status);
    if(S.state.serverUp!==up){S.state.serverUp=up;
      hb.classList.toggle('on',up);hb.classList.toggle('off',!up);
      S.$('hbTxt').textContent=up?'server online':'server offline';}
  }catch(e){
    if(S.state.serverUp!==false){S.state.serverUp=false;
      hb.classList.add('off');hb.classList.remove('on');
      S.$('hbTxt').textContent='server offline';}
  }
}
beat();setInterval(beat,7000);

/* ---------- tiny toast (status line helper) ---------- */
S.toast=function(msg,warn){
  const t=S.$('toast');
  if(!t){return;}
  t.textContent=msg||'';
  t.style.color=warn?'var(--warn)':'var(--fg2)';
  t.style.opacity='1';                    /* v27: a toast fades — it is not a status bar */
  if(S._toastT)clearTimeout(S._toastT);
  S._toastT=setTimeout(function(){t.style.opacity='0';},3200);
};
})();
