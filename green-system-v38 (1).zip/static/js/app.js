/* ============================================================
   app.js — boot: tabs, bridges, engine lab. Wires everything.
   Load order: core → player → options → msep → studio → subs →
   mixer → app.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;

/* ---------- tabs ---------- */
const TABS=['main','subs'];
S.switchTab=function(name){
  TABS.forEach(t=>{
    $('tab'+(t==='main'?'Main':'Subs')).classList.toggle('hidden',t!==name);
    const b=$('tabBtn'+(t==='main'?'Main':'Subs'));
    if(b)b.classList.toggle('on',t===name);
  });
};
$('tabBtnMain').onclick=()=>S.switchTab('main');
$('tabBtnSubs').onclick=()=>S.switchTab('subs');

/* ---------- engine outputs registry (for the subtitles source menu) ---------- */
const OUTS=[];
S.dspOutputs=function(){return OUTS.slice();};

/* ---------- ENGINE LAB (single file — NOT the scan; clearly secondary) ---------- */
const LAB_ENGINES={
  studiomic:'Mic Studio — AI studio voice',
  dolby_off:'Dolby One — 7-stage · full settings',clean:'Clean (full mix)',voice:'Voice Enhance',
  music:'Music Enhance',fx:'FX Enhance',spatial:'3D Spatial',master:'Master'
};
const labSel=$('labEngine');
if(labSel){
  Object.keys(LAB_ENGINES).forEach(k=>{
    const o=document.createElement('option');o.value=k;o.textContent=LAB_ENGINES[k];labSel.appendChild(o);
  });
  labSel.value='studiomic';
  const srcSel=$('labSource');
  const refreshSrc=()=>{
    const keep=srcSel.value;
    srcSel.innerHTML='';
    OUTS.forEach(o=>{const op=document.createElement('option');op.value=o.id;op.textContent=o.label;srcSel.appendChild(op);});
    const first=document.createElement('option');first.value='';first.textContent='— pick a file —';
    srcSel.prepend(first);
    if([...srcSel.options].some(o=>o.value===keep))srcSel.value=keep;
  };
  S._labRefresh=refreshSrc;refreshSrc();

  /* source-name chip + engine-dependent run label */
  const syncMicBar=()=>{
    const sel=srcSel.selectedOptions[0];
    const name=(sel&&sel.value)?sel.textContent.replace(/ · source$/,''):'pick an audio file — the AI makes it sound close-mic studio';
    if($('micSrcName'))$('micSrcName').textContent=name;
    if($('labRunBtn'))$('labRunBtn').textContent=(labSel.value==='studiomic')?'Enhance ▶':'Run Engine ▶';
    if($('micSetBtn')){
      $('micSetBtn').style.display=(labSel.value==='studiomic'||labSel.value==='dolby_off')?'':'none';
      $('micSetBtn').textContent=(labSel.value==='studiomic')?'⚙ Settings':'⚙ Dolby Settings';
    }
  };
  srcSel.addEventListener('change',syncMicBar);
  labSel.addEventListener('change',syncMicBar);
  S._labSyncMicBar=syncMicBar;syncMicBar();

  /* ===== Dolby One — settings MODAL (every param drives the engine) ===== */
  const labParams=()=>({
    noise_strength:parseInt($('labNoise').value||'20',10),
    profile:$('labProfile').value==='voice'?'voice':'music',
    spatial:$('labSpatial').checked,
    declick:$('labDeclick').checked,
    dehum:$('labDehum').checked});
  S._labParams=labParams;

  /* ===== MIC STUDIO — settings modal + params (v32) ===== */
  const MIC_IDS=['micAI','micProx','micPres','micAir','micWarm','micComp'];
  const MIC_VALS={micAI:'micAIV',micProx:'micProxV',micPres:'micPresV',micAir:'micAirV',micWarm:'micWarmV',micComp:'micCompV'};
  const micParams=()=>({
    ai_clean:parseInt($('micAI').value||'70',10),
    max_quality:$('micMaxQ').checked,
    mic_profile:$('micProfiles').querySelector('button.on')?.dataset.v||'studio',
    proximity:parseInt($('micProx').value||'60',10),
    presence:parseInt($('micPres').value||'60',10),
    air:parseInt($('micAir').value||'60',10),
    warmth:parseInt($('micWarm').value||'60',10),
    compression:parseInt($('micComp').value||'60',10),
    target_lufs:$('micLufs').value,
    declick:$('micDeclick').checked,
    dehum:$('micDehum').checked});
  S._micParams=micParams;

  const micSum=()=>{
    const p=micParams();
    const txt=p.mic_profile+' · AI '+p.ai_clean+'%'+(p.max_quality?' max':'')
      +' · prox '+p.proximity+' · pres '+p.presence+' · air '+p.air
      +' · warm '+p.warmth+' · comp '+p.compression
      +' · '+(p.target_lufs==='auto'?'auto LUFS':p.target_lufs+' LUFS');
    if($('micSetLive'))$('micSetLive').textContent=txt;
    return txt;
  };
  const MIC_PROFILE_HINTS={
    studio:'large-diaphragm condenser (U87-like) — silky, airy, detailed',
    broadcast:'dynamic broadcast mic (SM7B-like) — thick, punchy, controlled',
    podcast:'warm intimate close-up — podcast golden voice',
    vintage:'tube / ribbon — rounded, even-harmonic warmth',
    natural:'minimal color — barely-there polish'};
  const micUpdVals=()=>{
    Object.keys(MIC_VALS).forEach(id=>{
      const el=$(id),vl=$(MIC_VALS[id]);
      if(el&&vl)vl.textContent=el.value;
    });
    micSum();
  };
  /* open / close / Esc / backdrop — same pattern as Dolby One */
  const openMicModal=()=>{$('micSetModal').classList.remove('hidden');micUpdVals();};
  const closeMicModal=()=>{$('micSetModal').classList.add('hidden');micSum();S.toast('Mic settings applied — '+micSum());};
  if($('micSetBtn'))$('micSetBtn').onclick=()=>{
    if(labSel.value==='studiomic')openMicModal();
    else if(labSel.value==='dolby_off')openModal();   /* Dolby One settings modal */
  };
  if($('micSetClose'))$('micSetClose').onclick=closeMicModal;
  if($('micSetApply'))$('micSetApply').onclick=closeMicModal;
  if($('micSetReset'))$('micSetReset').onclick=()=>{micApplyPreset(MIC_DEFAULTS);S.toast('Mic settings reset to defaults');};
  if($('micSetModal')){
    $('micSetModal').addEventListener('click',e=>{
      if(e.target===$('micSetModal')||e.target.classList.contains('modal-bg'))closeMicModal();});
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape'&&!$('micSetModal').classList.contains('hidden'))closeMicModal();});
  }
  /* profile chips (segmented) */
  if($('micProfiles')){
    $('micProfiles').querySelectorAll('button').forEach(b=>{
      b.onclick=()=>{
        $('micProfiles').querySelectorAll('button').forEach(x=>x.classList.remove('on'));
        b.classList.add('on');
        S.toast('Mic profile: '+b.textContent+' — '+MIC_PROFILE_HINTS[b.dataset.v]);
        micSum();
      };
    });
  }
  /* live values + persistence on every control */
  [...MIC_IDS,'micMaxQ','micLufs','micDeclick','micDehum'].forEach(id=>{
    const el=$(id);if(!el)return;
    el.addEventListener('input',()=>{micUpdVals();micSave();});
    el.addEventListener('change',()=>{micUpdVals();micSave();});
  });
  const MIC_DEFAULTS={ai_clean:70,max_quality:false,mic_profile:'studio',
    proximity:60,presence:60,air:60,warmth:60,compression:60,
    target_lufs:'auto',declick:true,dehum:true};
  const MIC_PRESETS={
    podcast:{ai_clean:80,max_quality:false,mic_profile:'podcast',proximity:75,presence:55,air:50,warmth:70,compression:70,target_lufs:'-16'},
    broadcast:{ai_clean:75,max_quality:false,mic_profile:'broadcast',proximity:80,presence:75,air:35,warmth:60,compression:80,target_lufs:'-16'},
    intimate:{ai_clean:65,max_quality:false,mic_profile:'podcast',proximity:90,presence:40,air:30,warmth:75,compression:55,target_lufs:'-19'},
    natural:{ai_clean:55,max_quality:false,mic_profile:'natural',proximity:40,presence:40,air:40,warmth:25,compression:35,target_lufs:'auto'},
    maxclean:{ai_clean:100,max_quality:true,mic_profile:'studio',proximity:60,presence:60,air:60,warmth:40,compression:60,target_lufs:'auto'}};
  function micApplyPreset(p){
    $('micAI').value=p.ai_clean;$('micMaxQ').checked=!!p.max_quality;
    $('micProx').value=p.proximity;$('micPres').value=p.presence;
    $('micAir').value=p.air;$('micWarm').value=p.warmth;$('micComp').value=p.compression;
    $('micLufs').value=String(p.target_lufs);
    if(p.declick!==undefined)$('micDeclick').checked=!!p.declick;
    if(p.dehum!==undefined)$('micDehum').checked=!!p.dehum;
    if(p.mic_profile){
      const b=$('micProfiles').querySelector('button[data-v="'+p.mic_profile+'"]');
      if(b){$('micProfiles').querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');}
    }
    micUpdVals();micSave();
  }
  document.querySelectorAll('#micPresets button[data-preset]').forEach(b=>{
    b.onclick=()=>{
      const p=MIC_PRESETS[b.dataset.preset];if(!p)return;
      micApplyPreset(p);
      S.toast('preset: '+b.textContent.trim());
    };
  });
  function micSave(){
    try{localStorage.setItem('studio32_mic',JSON.stringify(micParams()));}catch(e){}
  }
  (function micLoad(){
    let o=null;
    try{o=JSON.parse(localStorage.getItem('studio32_mic')||'null');}catch(e){}
    if(o)micApplyPreset(Object.assign({},MIC_DEFAULTS,o));
    else micUpdVals();
  })();

  /* ===== v37: AI MODEL AUTO-DOWNLOAD (lightweight package) =====
     When the 713 MB Resemble weights are missing, one click pulls them
     from HuggingFace server-side (job + live progress) — no git/lfs,
     no restart: ai_status flips true and Mic Studio reaches full power. */
  (function modelDl(){
    const btn=$('modelDlBtn'),stat=$('modelDlStat');
    if(!btn||!stat)return;
    let timer=null;
    async function check(){
      try{
        const st=await S.jget('/api/model/status');
        if(st&&st.present===false){
          btn.classList.remove('hidden');
          const chip=$('micAiChip');
          if(chip){chip.classList.remove('good');chip.classList.add('bad');
            chip.title='AI weights missing — click "AI model" to download (713 MB)';}
        }else if(st&&st.present){
          btn.classList.add('hidden');
          const chip=$('micAiChip');
          if(chip){chip.classList.add('good');chip.classList.remove('bad');
            chip.title='AI backend: resemble-enhance (deep denoise + generative restore)';}
        }
      }catch(e){}
    }
    check();
    function done(present){
      if(timer)clearInterval(timer);timer=null;
      stat.textContent=present?'AI model ready — Mic Studio at full power':'model still missing — retry the button';
      if(!present)btn.disabled=false;
      check();
      if(present)S.toast('AI model installed — Mic Studio / ENHANCE AI now at full power');
    }
    btn.onclick=async()=>{
      btn.disabled=true;stat.classList.remove('hidden');
      stat.textContent='asking the server…';
      try{
        const j=await S.jpost('/api/model/ensure',{});
        if(j&&j.already&&j.present){done(true);return;}
        if(!j||!j.ok||!j.job_id)throw new Error((j&&j.reason)||'could not start the download');
        const jid=j.job_id;
        stat.textContent='downloading 713 MB from huggingface…';
        let last='';
        timer=setInterval(async()=>{
          try{
            const s=await S.jget('/api/dsp/job/'+jid);
            const job=s&&s.job;
            if(!job)return;
            if(job.stage!==last){last=job.stage;
              stat.textContent=job.stage+' · '+Math.round(job.progress||0)+'%';}
            if(job.state==='done'){done((job.result||{}).present!==false);}
            else if(job.state==='error'){
              if(timer)clearInterval(timer);timer=null;
              stat.textContent='download failed — '+(String((job.result||{}).reason||'').slice(0,90));
              btn.disabled=false;
            }
          }catch(e){/* transient poll error — keep waiting */}
        },2000);
      }catch(e){
        stat.textContent='download failed — '+(e.message||e);
        btn.disabled=false;
      }
    };
  })();

  /* ===== v38: AI MODEL PANEL — every auto-downloadable model =====
     Studio Max (engine #3) composes three AI specialists; each weights
     file auto-downloads from HuggingFace with one click + live job
     progress, and the engine picks them up WITHOUT a restart. */
  (function modelPanel(){
    const row=$('aiModelsRow'),stat=$('mdlStat'),ready=$('mdlReady');
    if(!row)return;
    const CORE=['resemble','apollo','demucs'];   // Studio Max trio
    const btn=k=>$('mdlBtn-'+k);
    let busy=false,timer=null;
    async function paint(){
      try{
        const st=await S.jget('/api/model/status');
        const ms=(st&&st.models)||{};
        let missing=0;
        Object.keys(ms).forEach(k=>{
          const b=btn(k);if(!b)return;
          if(ms[k].present)b.classList.add('hidden');
          else{b.classList.remove('hidden');missing++;}
        });
        if(ready){
          const all=CORE.every(k=>ms[k]&&ms[k].present);
          ready.classList.toggle('hidden',!all);
        }
        return ms;
      }catch(e){return null;}
    }
    paint();
    function reenable(){
      busy=false;
      row.querySelectorAll('button').forEach(x=>x.disabled=false);
    }
    function done(k){
      if(timer)clearInterval(timer);timer=null;
      reenable();
      (async()=>{
        const ms=await paint();
        const okk=ms&&ms[k]&&ms[k].present;
        stat.textContent=okk?('✓ '+(ms[k].label||k)+' installed'):(k+' still missing — retry');
        if(okk)S.toast((ms[k].label||k)+' installed — Studio Max picks it up instantly');
      })();
    }
    ['resemble','apollo','demucs','demucs_ft'].forEach(k=>{
      const b=btn(k);if(!b)return;
      b.onclick=async()=>{
        if(busy){S.toast('Another model download is running — wait for it',true);return;}
        busy=true;
        row.querySelectorAll('button').forEach(x=>x.disabled=true);
        stat.classList.remove('hidden');
        stat.textContent='asking the server…';
        try{
          const j=await S.jpost('/api/model/ensure',{model:k});
          if(j&&j.already&&j.present){renable();
            stat.textContent='already installed';paint();return;}
          if(!j||!j.ok||!j.job_id)throw new Error((j&&j.reason)||'could not start the download');
          const jid=j.job_id;
          stat.textContent='downloading from huggingface…';
          let last='';
          timer=setInterval(async()=>{
            try{
              const s=await S.jget('/api/dsp/job/'+jid);
              const job=s&&s.job;
              if(!job)return;
              if(job.stage!==last){last=job.stage;
                stat.textContent=job.stage+' · '+Math.round(job.progress||0)+'%';}
              if(job.state==='done')done(k);
              else if(job.state==='error'){
                if(timer)clearInterval(timer);timer=null;
                reenable();
                stat.textContent='download failed — '+(String((job.result||{}).reason||'').slice(0,90));
              }
            }catch(e){/* transient poll error — keep waiting */}
          },2000);
        }catch(e){
          reenable();
          stat.textContent='download failed — '+(e.message||e);
        }
      };
    });
  })();

  const setSum=()=>{
    const p=labParams();
    const txt=p.profile+' · NR '+p.noise_strength+'/45 dB · '
      +(p.declick?'declick ✓':'declick ✗')+' · '
      +(p.dehum?'dehum ✓':'dehum ✗')+' · '
      +(p.spatial?'3D ✓':'3D ✗');
    if($('labSetSum'))$('labSetSum').textContent=txt;
    if($('setLive'))$('setLive').textContent='current: '+txt;
    return txt;
  };
  const PROFILE_HINTS={
    music:'sub-bass body · warmth · presence · sheen — harshness dip',
    voice:'mud cut 240Hz · presence 2.8k · de-harsh 6.8k · air 10.5k · LPF 14k'};
  const updHints=()=>{
    if($('labProfileHint'))$('labProfileHint').textContent=PROFILE_HINTS[$('labProfile').value]||PROFILE_HINTS.music;
    if($('labNoiseVal'))$('labNoiseVal').textContent=$('labNoise').value;
  };
  /* open / close / Esc / backdrop */
  const openModal=()=>{$('setModal').classList.remove('hidden');updHints();setSum();};
  const closeModal=()=>{$('setModal').classList.add('hidden');setSum();};
  if($('labSetBtn'))$('labSetBtn').onclick=openModal;
  if($('setClose'))$('setClose').onclick=closeModal;
  if($('setApply'))$('setApply').onclick=()=>{closeModal();S.toast('Settings applied — '+setSum());};
  if($('setReset'))$('setReset').onclick=()=>{
    $('labProfile').value='music';$('labNoise').value=20;
    $('labSpatial').checked=true;$('labDeclick').checked=true;$('labDehum').checked=true;
    updHints();setSum();S.toast('Settings reset to defaults');};
  if($('setModal')){
    $('setModal').addEventListener('click',e=>{
      if(e.target===$('setModal')||e.target.classList.contains('modal-bg'))closeModal();});
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape'&&!$('setModal').classList.contains('hidden'))closeModal();});
  }
  /* live updates from every control */
  ['labNoise','labProfile','labSpatial','labDeclick','labDehum'].forEach(id=>{
    const el=$(id);if(!el)return;
    el.addEventListener('input',()=>{updHints();setSum();});
    el.addEventListener('change',()=>{updHints();setSum();});
  });
  /* one-click presets */
  const PRESETS={
    music:{profile:'music',noise_strength:20,spatial:true,declick:true,dehum:true},
    voice:{profile:'voice',noise_strength:26,spatial:false,declick:true,dehum:true},
    rescue:{profile:'voice',noise_strength:38,spatial:false,declick:true,dehum:true},
    maxclean:{profile:'music',noise_strength:45,spatial:true,declick:true,dehum:true},
    raw:{profile:'music',noise_strength:0,spatial:false,declick:false,dehum:false}};
  document.querySelectorAll('#setPresets button[data-preset]').forEach(b=>{
    b.onclick=()=>{
      const p=PRESETS[b.dataset.preset];if(!p)return;
      $('labProfile').value=p.profile;$('labNoise').value=p.noise_strength;
      $('labSpatial').checked=p.spatial;$('labDeclick').checked=p.declick;$('labDehum').checked=p.dehum;
      updHints();setSum();S.toast('preset: '+b.textContent.trim());
    };
  });
  updHints();setSum();

  $('labUpBtn').onclick=()=>$('labFile').click();

  /* ===== ENHANCE — intelligent adaptive agent (v33) =====
     Own card + own settings modal; shares the OUTS source registry.
     Dolby One + Mic Studio wiring above stays untouched. */
  const enhSel=$('enhSource');
  const enhRefresh=()=>{
    if(!enhSel)return;
    const keep=enhSel.value;
    enhSel.innerHTML='';
    OUTS.forEach(o=>{const op=document.createElement('option');op.value=o.id;op.textContent=o.label;enhSel.appendChild(op);});
    const first=document.createElement('option');first.value='';first.textContent='— pick a file —';
    enhSel.prepend(first);
    if([...enhSel.options].some(o=>o.value===keep))enhSel.value=keep;
    const sel=enhSel.selectedOptions[0];
    if($('enhSrcName'))$('enhSrcName').textContent=(sel&&sel.value)?sel.textContent.replace(/ · source$/,''):'pick an audio file — the agent diagnoses it, then applies only what it needs';
  };
  S._enhRefresh=enhRefresh;enhRefresh();
  const _origLabRefresh=S._labRefresh;
  S._labRefresh=()=>{_origLabRefresh();enhRefresh();};
  enhSel.addEventListener('change',()=>{
    const sel=enhSel.selectedOptions[0];
    if($('enhSrcName'))$('enhSrcName').textContent=(sel&&sel.value)?sel.textContent.replace(/ · source$/,''):'pick an audio file — the agent diagnoses it, then applies only what it needs';
  });

  /* ---- settings modal (same pattern as Mic Studio) ---- */
  const enhParams=()=>({
    mode:$('enhModes').querySelector('button.on')?.dataset.v||'balanced',
    profile:$('enhProfiles').querySelector('button.on')?.dataset.v||'auto',
    ai_assist:parseInt($('enhAI').value||'55',10),
    max_quality:$('enhMaxQ').checked,
    intensity:parseInt($('enhInt').value||'70',10),
    preserve_dynamics:$('enhPd').checked,
    keep_natural:$('enhKn').checked,
    target_lufs:$('enhLufs').value,
    declick:$('enhDeclick').value,
    dehum:$('enhDehum').value});
  S._enhParams=enhParams;

  const ENH_DEFAULTS={mode:'balanced',profile:'auto',ai_assist:55,max_quality:false,
    intensity:70,preserve_dynamics:false,keep_natural:false,
    target_lufs:'auto',declick:'auto',dehum:'auto'};
  const ENH_PRESETS={
    adaptive:{mode:'balanced',profile:'auto',ai_assist:55,max_quality:false,intensity:70,target_lufs:'auto'},
    deep:{mode:'aggressive',profile:'auto',ai_assist:85,max_quality:true,intensity:92,target_lufs:'auto'},
    gentle:{mode:'safe',profile:'natural',ai_assist:30,max_quality:false,intensity:40,target_lufs:'auto'},
    bcast:{mode:'balanced',profile:'broadcast',ai_assist:60,max_quality:false,intensity:75,target_lufs:'-16'},
    music:{mode:'balanced',profile:'music',ai_assist:40,max_quality:false,intensity:60,target_lufs:'-14'},
    dry:{mode:'safe',profile:'auto',ai_assist:0,max_quality:false,intensity:0,target_lufs:'auto'}};
  const enhSum=()=>{
    const p=enhParams();
    const txt=p.mode+' · '+p.profile+' · AI '+p.ai_assist+'% · budget '+p.intensity+'%'
      +(p.intensity===0?' (dry-run)':'')+(p.max_quality?' max':'')
      +(p.preserve_dynamics?' · dynamics-locked':'')
      +(p.keep_natural?' · keep-natural':'')
      +' · '+(p.target_lufs==='auto'?'auto LUFS':p.target_lufs+' LUFS')
      +' · declick '+p.declick+' · dehum '+p.dehum;
    if($('enhSetLive'))$('enhSetLive').textContent=txt;
    return txt;
  };
  const enhUpdVals=()=>{
    if($('enhAIV'))$('enhAIV').textContent=$('enhAI').value;
    if($('enhIntV'))$('enhIntV').textContent=$('enhInt').value;
    enhSum();
  };
  function enhApplyPreset(p){
    $('enhAI').value=p.ai_assist!=null?p.ai_assist:55;
    $('enhMaxQ').checked=!!p.max_quality;
    $('enhInt').value=p.intensity!=null?p.intensity:70;
    $('enhLufs').value=String(p.target_lufs||'auto');
    $('enhDeclick').value=p.declick||'auto';
    $('enhDehum').value=p.dehum||'auto';
    $('enhPd').checked=!!p.preserve_dynamics;
    $('enhKn').checked=!!p.keep_natural;
    [['enhModes',p.mode||'balanced'],['enhProfiles',p.profile||'auto']].forEach(([id,v])=>{
      const b=$(id).querySelector('button[data-v="'+v+'"]');
      if(b){$(id).querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');}
    });
    enhUpdVals();enhSave();
  }
  const openEnhModal=()=>{$('enhSetModal').classList.remove('hidden');enhUpdVals();};
  const closeEnhModal=()=>{$('enhSetModal').classList.add('hidden');enhSum();S.toast('Enhance settings applied — '+enhSum());};
  if($('enhSetBtn'))$('enhSetBtn').onclick=openEnhModal;
  if($('enhSetClose'))$('enhSetClose').onclick=closeEnhModal;
  if($('enhSetApply'))$('enhSetApply').onclick=closeEnhModal;
  if($('enhSetReset'))$('enhSetReset').onclick=()=>{enhApplyPreset(ENH_DEFAULTS);S.toast('Enhance settings reset to defaults');};
  if($('enhSetModal')){
    $('enhSetModal').addEventListener('click',e=>{
      if(e.target===$('enhSetModal')||e.target.classList.contains('modal-bg'))closeEnhModal();});
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape'&&!$('enhSetModal').classList.contains('hidden'))closeEnhModal();});
  }
  /* segmented chips: mode + profile */
  [['enhModes','mode'],['enhProfiles','profile']].forEach(([id])=>{
    if($(id))$(id).querySelectorAll('button').forEach(b=>{
      b.onclick=()=>{
        $(id).querySelectorAll('button').forEach(x=>x.classList.remove('on'));
        b.classList.add('on');enhSum();
      };
    });
  });
  document.querySelectorAll('#enhPresets button[data-preset]').forEach(b=>{
    b.onclick=()=>{const p=ENH_PRESETS[b.dataset.preset];if(!p)return;
      enhApplyPreset(p);S.toast('preset: '+b.textContent.trim());};
  });
  ['enhAI','enhInt','enhMaxQ','enhLufs','enhDeclick','enhDehum','enhPd','enhKn'].forEach(id=>{
    const el=$(id);if(!el)return;
    el.addEventListener('input',()=>{enhUpdVals();enhSave();});
    el.addEventListener('change',()=>{enhUpdVals();enhSave();});
  });
  function enhSave(){try{localStorage.setItem('studio33_enh',JSON.stringify(enhParams()));}catch(e){}}
  (function enhLoad(){
    let o=null;
    try{o=JSON.parse(localStorage.getItem('studio33_enh')||'null');}catch(e){}
    if(o)enhApplyPreset(Object.assign({},ENH_DEFAULTS,o));
    else enhUpdVals();
  })();
  if($('enhUpBtn'))$('enhUpBtn').onclick=()=>$('enhFile').click();
  if($('enhFile'))$('enhFile').onchange=async e=>{
    const f=e.target.files[0];e.target.value='';
    if(!f)return;
    S.toast('Uploading '+f.name+'…');
    try{
      const j=await S.upl('/api/dsp/upload',f);
      OUTS.push({id:j.id,label:f.name+' · source'});
      enhRefresh();enhSel.value=j.id;
      S.toast('Uploaded — '+f.name);
    }catch(x){S.err(x);}
  };

  /* ---- Enhance result card: diagnosis · decisions · scores · report ---- */
  const RESULT_CLS={'kept':'good','kept-reduced':'warn','rolled-back':'bad','no-problem':'','dry-run':'warn'};
  function problemsTable(problems){
    const t=S.el('table','dtable dx-table');
    const rows=(problems||[]).map(p=>{
      const sev=Math.round((p.severity||0)*100);
      const conf=Math.round((p.confidence||0)*100);
      const risk=Math.round((p.risk||0)*100);
      return '<tr><td>'+S.esc(p.label||p.problem)+'</td>'
        +'<td><div class="sevbar"><i style="width:'+sev+'%" class="'+(sev>66?'hi':(sev>33?'md':'lo'))+'"></i></div><span class="lp-sub">'+sev+'% · conf '+conf+'% · risk '+risk+'%</span></td>'
        +'<td><b>'+S.esc(String(p.value||'—'))+'</b><span class="lp-sub">target '+S.esc(String(p.window||'—'))+' · fix: '+S.esc(String(p.action||'—'))+'</span></td>'
        +'<td class="dx-freq">'+S.esc(String(p.freq||'—'))+((p.time_str)?'<span class="lp-sub">at '+S.esc(String(p.time_str))+'</span>':'')+'</td></tr>';
    });
    t.innerHTML='<thead><tr><th>problem</th><th>severity × confidence</th><th>measured</th><th>region</th></tr></thead><tbody>'
      +(rows.length?rows.join(''):'<tr><td colspan="4">clean source — nothing detected</td></tr>')+'</tbody>';
    return t;
  }
  function gatesTable(gates){
    const t=S.el('table','dtable dx-table');
    const CLS={pass:'good',warn:'warn',fail:'bad'};
    const rows=(gates||[]).map(g=>'<tr><td>'+S.esc(g.gate)+'</td>'
      +'<td><span class="chip '+(CLS[g.status]||'')+'">'+S.esc(String(g.status||'—').toUpperCase())+'</span></td>'
      +'<td>'+S.esc(String(g.detail||'—'))+'</td></tr>');
    t.innerHTML='<thead><tr><th>gate</th><th>status</th><th>detail</th></tr></thead><tbody>'
      +(rows.length?rows.join(''):'<tr><td colspan="3">no gate data</td></tr>')+'</tbody>';
    return t;
  }
  function actionsTable(actions){
    const t=S.el('table','dtable dx-table');
    const rows=(actions||[]).map(a=>{
      const rc=RESULT_CLS[a.result]??'';
      return '<tr><td>'+S.esc(a.label||a.problem)+'</td>'
        +'<td><b>'+S.esc(String(a.what||'—'))+'</b><span class="lp-sub">'+S.esc(String(a.why||''))+'</span></td>'
        +'<td>'+S.esc(String(a.how_much||'—'))+'</td>'
        +'<td><span class="chip '+(rc||'')+'">'+S.esc(String(a.result||'—'))+'</span></td></tr>'
        +((a.detail&&a.result!=='no-problem')?'<tr class="dx-detail"><td></td><td colspan="3">'+S.esc(a.detail)+'</td></tr>':'');
    });
    t.innerHTML='<thead><tr><th>issue</th><th>action · why</th><th>how much</th><th>result</th></tr></thead><tbody>'
      +(rows.length?rows.join(''):'')+'</tbody>';
    return t;
  }
  function scoresPanel(scores){
    const wrap=S.el('div','sc-grid');
    const NAMES={technical:'Technical',restoration:'Restoration',tonal:'Tonal balance',
      dynamics:'Dynamics',naturalness:'Naturalness',artifacts:'Artifacts',
      stereo:'Stereo · Phase',delivery:'Delivery'};
    Object.keys(NAMES).forEach(k=>{
      const v=scores&&scores[k];
      const el=S.el('div','sc-item'+(v==null?'':' '+(v>=85?'good':(v>=70?'ok':(v>=50?'warn':'bad')))));
      el.innerHTML='<span class="sc-n">'+NAMES[k]+'</span>'
        +'<div class="sc-bar"><i style="width:'+(v||0)+'%"></i></div>'
        +'<b class="sc-v">'+(v==null?'—':v)+'</b>';
      wrap.appendChild(el);
    });
    return wrap;
  }
  function buildEnhanceCard(res,srcSid){
    const host=S.el('div','labcard enhcard');
    $('enhOuts').prepend(host);
    const v=String(res.verdict||'?').toUpperCase();
    const rep=res.report||{};
    const cap=S.el('div','labcaph');
    cap.innerHTML='<b>Enhance — agent report</b>'
      +'<span class="chip '+(res.verdict==='pass'?'good':(res.verdict==='warn'?'warn':'bad'))+'">QA '+S.esc(v)+'</span>'
      +'<span class="chip">detected '+S.esc(String(rep.detected??'—'))+'</span>'
      +'<span class="chip good">corrected '+S.esc(String(rep.corrected??'—'))+'</span>'
      +'<span class="chip">ignored '+S.esc(String(rep.ignored??'—'))+'</span>'
      +'<span class="chip warn">rolled back '+S.esc(String(rep.rolled_back??'—'))+'</span>'
      +'<span class="sub">'+S.esc(String(rep.profile_desc||''))+'</span>'
      +'<span style="flex:1"></span>';
    const dl=S.el('button','btn sm');dl.textContent='Download WAV';
    dl.onclick=()=>{const a=S.el('a');a.href='/api/dsp/download/'+res.out_id;
      a.download='enhance-output.wav';a.click();};
    cap.appendChild(dl);
    host.appendChild(cap);

    /* A/B player + markers — same as the other engine cards */
    const ph=S.el('div');host.appendChild(ph);
    const p=S.Player(ph,{dual:true,labels:{A:'Original',B:'Enhance'}});
    p.setUrl('A','/api/dsp/file/'+srcSid);
    p.setUrl('B','/api/dsp/file/'+res.out_id);
    const mkHost=S.el('div');host.appendChild(mkHost);
    S.jget('/api/dsp/analyze/'+srcSid).then(markerBar(mkHost,p)).catch(()=>{});

    const pn=S.el('div','labpanel');
    pn.appendChild(S.el('div','lp-h','Diagnosis — '+S.esc(String(rep.profile||''))+' profile · what the agent measured'));
    pn.appendChild(problemsTable(res.problems));
    pn.appendChild(S.el('div','lp-h2','Decisions — WHY · WHAT · HOW MUCH · RISK · RESULT'));
    pn.appendChild(actionsTable(res.actions));
    pn.appendChild(S.el('div','lp-h2','Quality scores — 8 dimensions (not one number)'));
    pn.appendChild(scoresPanel(res.scores));
    pn.appendChild(S.el('div','lp-h2','Quality gates — 10 checks · PASS / WARN / REPROCESS'));
    pn.appendChild(gatesTable(res.gates));
    pn.appendChild(S.el('div','lp-h2','Pipeline — the adaptive graph actually executed'));
    pn.appendChild(stageList(res.stages));
    const grid=S.el('div','lp-grid');
    grid.appendChild(statBox('Input — before',res.stats_before||{}));
    grid.appendChild(statBox('Output — after',res.stats||{},'acc'));
    grid.appendChild(qaBox(res.qa));
    grid.appendChild(beforeAfter(res.stats_before,res.stats));
    pn.appendChild(grid);
    host.appendChild(pn);
  }

  if($('enhRunBtn'))$('enhRunBtn').onclick=async()=>{
    const sid=enhSel.value;
    if(!sid){S.err('Pick a source file in the Enhance agent first.');return;}
    const btn=$('enhRunBtn');btn.disabled=true;
    $('enhBar').style.width='4%';
    if($('enhStatus'))$('enhStatus').textContent='agent starting — forensic analysis…';
    try{
      const j=await S.jpost('/api/dsp/run',{src_id:sid,engine:'enhance',params:S._enhParams()});
      if(!j.ok)throw S.richErr(j.reason||'engine start failed');
      await new Promise((res,rej)=>{
        const t=setInterval(async()=>{
          let jj=null;
          try{jj=await S.jget('/api/dsp/job/'+j.job_id);}catch(e){return;}
          if(!jj.ok){clearInterval(t);rej(S.richErr('job lost'));return;}
          const job=jj.job;
          if($('enhStatus'))$('enhStatus').textContent=(job.stage||job.state)+' · '+job.elapsed+'s';
          $('enhBar').style.width=Math.max(4,job.progress)+'%';
          if(job.state==='done'||job.state==='error'){
            clearInterval(t);
            if(job.state==='error')rej(S.richErr((job.result&&job.result.reason)||'engine failed'));
            else res(job.result);
          }
        },1500);
      }).then(res=>{
        if(res&&res.out_id){
          OUTS.push({id:res.out_id,label:'Enhance agent → '+String(res.stats&&res.stats.duration||'')});
          enhRefresh();enhSel.value=res.out_id;
          buildEnhanceCard(res,sid);
          const rep=res.report||{};
          if($('enhStatus'))$('enhStatus').textContent='done — detected '+rep.detected+' · corrected '+rep.corrected+' · rolled back '+rep.rolled_back+' · QA '+(res.verdict||'?')+' · report below';
        }
        S.toast('Enhance agent done — full report below');
        $('enhBar').style.width='100%';
      });
    }catch(e){S.err(e);if($('enhStatus'))$('enhStatus').textContent='failed — see the error box';}
    finally{btn.disabled=false;setTimeout(()=>{$('enhBar').style.width='0%';},1500);}
  };

  $('labFile').onchange=async e=>{
    const f=e.target.files[0];e.target.value='';
    if(!f)return;
    S.toast('Uploading '+f.name+'…');
    try{
      const j=await S.upl('/api/dsp/upload',f);
      OUTS.push({id:j.id,label:f.name+' · source'});
      refreshSrc();srcSel.value=j.id;
      S.toast('Uploaded — '+f.name);
    }catch(x){S.err(x);}
  };

  /* ---- analysis & decision panel builders (Dolby One) ---- */
  const fdb=v=>(v==null||isNaN(v))?'—':((v>0?'+':'')+ (+v).toFixed(1));
  function statBox(title,st,cls){
    const row=(k,v)=>'<div class="lp-r"><span>'+k+'</span><b>'+v+'</b></div>';
    const b=S.el('div','lp-box'+(cls?' '+cls:''));
    b.innerHTML='<div class="lp-bt">'+title+'</div>'
      +row('Duration',S.fd(st&&st.duration||0))
      +row('Sample rate',((st&&st.sample_rate)||0)+' Hz')
      +row('Channels',((st&&st.channels)||0)+' ch')
      +row('Loudness',fdb(st&&st.lufs)+' LUFS')
      +row('True peak',fdb(st&&st.true_peak)+' dBTP')
      +row('LRA',fdb(st&&st.lra)+' LU')
      +row('RMS',fdb(st&&st.rms_db)+' dB')
      +row('Clipped samples',(st&&st.clipped_samples)!=null?st.clipped_samples:'—');
    return b;
  }
  function decisionTable(d){
    d=d||{};
    const rows=[
      ['Profile',(d.profile==='voice'?'VOICE — speech':'MUSIC — full mix'),(d.profile_desc||'')],
      ['Noise reduction','requested '+(d.noise_requested!=null?d.noise_requested:'—')+' dB → applied '+(d.noise_applied!=null?d.noise_applied:'—')+' dB · cap '+(d.noise_cap||45),'spectral afftdn, mixed-content safe'],
      ['Repair','declick '+(d.declick?'on':'off')+' · dehum '+(d.dehum?'on':'off'),'notch −10dB 50/60/100Hz + rumble HPF 35Hz'],
      ['Dynamics',d.dynamics||'—',''],
      ['EQ contour',d.eq||'—',''],
      ['Spatial',(d.spatial_applied?'APPLIED':'SKIPPED'),(d.spatial_reason||'')],
      ['Loudness target',(d.loudness_target!=null?fdb(d.loudness_target)+' LUFS':'—'),(d.loudness_rule||'')],
      ['True-peak ceiling',fdb(d.true_peak_ceiling)+' dBTP','safety limiter 0.97'],
      ['Output format',d.output_format||'48 kHz · 24-bit WAV','']
    ];
    const t=S.el('table','dtable');
    t.innerHTML='<tbody>'+rows.map(r=>
      '<tr><td>'+S.esc(r[0])+'</td><td><b>'+S.esc(String(r[1]))+'</b>'
      +(r[2]?'<span class="lp-sub">'+S.esc(r[2])+'</span>':'')+'</td></tr>').join('')+'</tbody>';
    return t;
  }
  function stageList(stages){
    const box=S.el('div','stglist');
    (stages||[]).forEach(s=>{
      const ic=s.status==='done'?'✓':(s.status==='skipped'?'—':'!');
      const cl=s.status==='done'?'ok':(s.status==='skipped'?'sk':'bad');
      const row=S.el('div','stg '+cl);
      row.innerHTML='<span class="stg-n">'+ic+'</span>'
        +'<span class="stg-name">'+S.esc(s.n+'. '+s.name)+'</span>'
        +'<span class="stg-d">'+S.esc(s.detail||'')+'</span>';
      box.appendChild(row);
    });
    return box;
  }
  function qaBox(qa){
    qa=qa||{};
    const v=qa.verdict||'?';
    const m=qa.metrics||{};
    const b=S.el('div','lp-box');
    b.innerHTML='<div class="lp-bt">QA gate</div>'
      +'<div style="margin:4px 0"><span class="chip '+(v==='pass'?'good':(v==='warn'?'warn':'bad'))+'">VERDICT '+S.esc(String(v).toUpperCase())+'</span></div>'
      +'<div class="lp-r"><span>duration Δ</span><b>'+(m.duration_delta!=null?m.duration_delta+'s':'—')+'</b></div>'
      +'<div class="lp-r"><span>loudness Δ</span><b>'+(m.lufs_delta!=null?((m.lufs_delta>0?'+':'')+m.lufs_delta+' LU'):'—')+'</b></div>'
      +'<div class="lp-r"><span>out RMS</span><b>'+fdb(m.out_rms_db)+' dB</b></div>'
      +'<div class="lp-issues">'+((qa.issues&&qa.issues.length)
        ?qa.issues.map(x=>S.esc(String(x))).join('<br>')
        :'all gates passed — duration · aliveness · DC · level · clip')+'</div>';
    return b;
  }
  function beforeAfter(sb,sa){
    const b=S.el('div','lp-box acc');
    b.innerHTML='<div class="lp-bt">Before → After</div>'
      +'<div class="lp-r"><span>Loudness</span><b>'+fdb(sb&&sb.lufs)+' → '+fdb(sa&&sa.lufs)+' LUFS</b></div>'
      +'<div class="lp-r"><span>True peak</span><b>'+fdb(sb&&sb.true_peak)+' → '+fdb(sa&&sa.true_peak)+' dBTP</b></div>'
      +'<div class="lp-r"><span>Duration</span><b>'+S.fd(sb&&sb.duration||0)+' → '+S.fd(sa&&sa.duration||0)+'</b></div>'
      +'<div class="lp-r"><span>Clipped</span><b>'+((sb&&sb.clipped_samples)!=null?sb.clipped_samples:'—')+' → '+((sa&&sa.clipped_samples)!=null?sa.clipped_samples:'—')+'</b></div>';
    return b;
  }
  function markerBar(host,p){
    return function(j){
      if(!j||!j.ok)return;
      const mks=j.markers||[];
      const bar=S.el('div','mkbar');
      if(!mks.length){
        bar.innerHTML='<span class="sub">markers: none — signal steady (no silence / clip / loud anomalies)</span>';
        host.appendChild(bar);return;
      }
      const KD={silence:['#71717a','Silence'],quiet:['#38bdf8','Quiet'],
                loud:['#fb923c','Loud'],clip:['#fb7185','Clipping']};
      const legend=S.el('div','mklegend');
      Object.keys(j.summary||{}).forEach(k=>{
        if(!j.summary[k])return;
        const kd=KD[k]||['#a1a1aa',k];
        const ch=S.el('span','mkchip');
        ch.innerHTML='<i style="background:'+kd[0]+'"></i>'+kd[1]+' '+j.summary[k];
        legend.appendChild(ch);
      });
      bar.appendChild(legend);
      const list=S.el('div','mklist');
      mks.slice(0,60).forEach(m=>{
        const kd=KD[m.kind]||['#a1a1aa',m.kind];
        const it=S.el('div','mkitem');
        it.innerHTML='<i style="background:'+kd[0]+'"></i><span>'+S.esc(m.label||m.kind)+'</span>'
          +'<b>'+S.tcSMPTE(m.t0)+' – '+S.tcSMPTE(m.t1)+'</b>';
        it.onclick=()=>{p.seek(m.t0);};
        list.appendChild(it);
      });
      bar.appendChild(list);
      if(mks.length>60)list.appendChild(S.el('div','sub','… +'+(mks.length-60)+' more — hover the waveform'));
      host.appendChild(bar);
      p.setMarkers(mks);
    };
  }
  function buildDolbyCard(res,srcSid){
    buildEngineCard(res,srcSid,'Dolby One','dolby-one-output.wav');
  }

  /* ---- MIC STUDIO decision table (engine-specific rows) ---- */
  function micDecisionTable(d){
    d=d||{};
    const rows=[
      ['AI backend',(d.ai_backend==='resemble'?'RESEMBLE-ENHANCE':String(d.ai_backend||'—').toUpperCase()),(d.ai_backend_desc||'')],
      ['AI clean',(d.ai_clean!=null?d.ai_clean+'%':'—'),'denoise strength inside the generative restore (lambd)'],
      ['AI quality',d.ai_quality||'fast (nfe 16)','nfe 64 + rk4 = max quality, 4× slower'],
      ['Mic profile',(d.mic_profile||'—').toUpperCase(),(d.mic_profile_desc||'')],
      ['Mic chain',d.mic_chain||'—','the expensive-microphone analog chain'],
      ['Loudness target',(d.loudness_target!=null?fdb(d.loudness_target)+' LUFS':'—'),(d.loudness_rule||'')],
      ['Repair','declick '+(d.declick?'on':'off')+' · dehum '+(d.dehum?'on':'off'),'notch 50/60/100 Hz + HPF 35 Hz'],
      ['True-peak ceiling',fdb(d.true_peak_ceiling)+' dBTP','safety limiter 0.97'],
      ['Output format',d.output_format||'48 kHz · 24-bit WAV','mono voice focus']
    ];
    const t=S.el('table','dtable');
    t.innerHTML='<tbody>'+rows.map(r=>
      '<tr><td>'+S.esc(r[0])+'</td><td><b>'+S.esc(String(r[1]))+'</b>'
      +(r[2]?'<span class="lp-sub">'+S.esc(r[2])+'</span>':'')+'</td></tr>').join('')+'</tbody>';
    return t;
  }

  /* generic A/B output card — Dolby One + Mic Studio share the layout */
  function buildEngineCard(res,srcSid,title,fname){
    const host=S.el('div','labcard');
    $('labOuts').prepend(host);
    const v=String(res.verdict||'?').toUpperCase();
    const cap=S.el('div','labcaph');
    cap.innerHTML='<b>'+S.esc(title)+' — output</b>'
      +'<span class="chip '+(res.verdict==='pass'?'good':(res.verdict==='warn'?'warn':'bad'))+'">QA '+S.esc(v)+'</span>'
      +'<span class="sub">'+S.fd((res.stats&&res.stats.duration)||0)+' · A = original · B = enhanced — same exact position</span>'
      +'<span style="flex:1"></span>';
    const dl=S.el('button','btn sm');dl.textContent='Download WAV';
    dl.onclick=()=>{const a=S.el('a');a.href='/api/dsp/download/'+res.out_id;
      a.download=fname;a.click();};
    cap.appendChild(dl);
    host.appendChild(cap);

    /* dual A/B player + markers */
    const ph=S.el('div');host.appendChild(ph);
    const p=S.Player(ph,{dual:true,labels:{A:'Original',B:title}});
    p.setUrl('A','/api/dsp/file/'+srcSid);
    p.setUrl('B','/api/dsp/file/'+res.out_id);
    const mkHost=S.el('div');host.appendChild(mkHost);
    S.jget('/api/dsp/analyze/'+srcSid).then(markerBar(mkHost,p)).catch(()=>{});

    /* analysis & decisions panel */
    const pn=S.el('div','labpanel');
    pn.appendChild(S.el('div','lp-h','Analysis & Decisions — '+title));
    const grid=S.el('div','lp-grid');
    grid.appendChild(statBox('Input — before',res.stats_before||{}));
    grid.appendChild(statBox('Output — after',res.stats||{},'acc'));
    grid.appendChild(qaBox(res.qa));
    grid.appendChild(beforeAfter(res.stats_before,res.stats));
    pn.appendChild(grid);
    pn.appendChild(S.el('div','lp-h2','Engine decisions — what '+title+' chose for this file'));
    pn.appendChild(title==='Mic Studio'?micDecisionTable(res.decision):decisionTable(res.decision));
    pn.appendChild(S.el('div','lp-h2','Pipeline — stages + QA gate'));
    pn.appendChild(stageList(res.stages));
    host.appendChild(pn);
  }

  $('labRunBtn').onclick=async()=>{
    let sid=srcSel.value;
    if(!sid){S.err('Pick a source file in the Mic Studio first.');return;}
    const eng=labSel.value;
    const params=(eng==='studiomic')?S._micParams():((eng==='dolby_off')?S._labParams():{});
    const btn=$('labRunBtn');btn.disabled=true;
    $('labBar').style.width='4%';
    if($('micStatus'))$('micStatus').textContent='starting '+LAB_ENGINES[eng]+'…';
    try{
      const j=await S.jpost('/api/dsp/run',{src_id:sid,engine:eng,params});
      if(!j.ok)throw S.richErr(j.reason||'engine start failed');
      /* poll */
      await new Promise((res,rej)=>{
        const t=setInterval(async()=>{
          let jj=null;
          try{jj=await S.jget('/api/dsp/job/'+j.job_id);}catch(e){return;}
          if(!jj.ok){clearInterval(t);rej(S.richErr('job lost'));return;}
          const job=jj.job;
          if(eng==='studiomic'&&$('micStatus'))$('micStatus').textContent=(job.stage||job.state)+' · '+job.elapsed+'s';
          else S.toast((job.stage||job.state)+' · '+job.elapsed+'s');
          $('labBar').style.width=Math.max(4,job.progress)+'%';
          if(job.state==='done'||job.state==='error'){
            clearInterval(t);
            if(job.state==='error')rej(S.richErr((job.result&&job.result.reason)||'engine failed'));
            else res(job.result);
          }
        },1500);
      }).then(res=>{
        if(res&&res.out_id){
          OUTS.push({id:res.out_id,label:LAB_ENGINES[eng]+' → '+String(res.stats&&res.stats.duration||'')});
          refreshSrc();srcSel.value=res.out_id;
          if(S._labSyncMicBar)S._labSyncMicBar();
          if(eng==='studiomic'){
            buildEngineCard(res,sid,'Mic Studio','mic-studio-output.wav');   /* full card: A/B + markers + decisions */
            if($('micStatus'))$('micStatus').textContent='done — QA '+(res.verdict||'?')+' · '+S.fd((res.stats&&res.stats.duration)||0)+' · A/B compare below';
          }else if(eng==='dolby_off'){
            buildDolbyCard(res,sid);          /* full card: A/B + markers + decisions */
          }else{
            const host=S.el('div');
            $('labOuts').prepend(host);
            const p=S.Player(host,{});
            p.setUrl('A','/api/dsp/file/'+res.out_id);
            const cap=S.el('div','rmeta',LAB_ENGINES[eng]+' · QA '+(res.verdict||'?')+' · '+S.fd((res.stats&&res.stats.duration)||0));
            host.prepend(cap);
          }
        }
        S.toast('Engine done — output playable below');
        $('labBar').style.width='100%';
      });
    }catch(e){S.err(e);if($('micStatus'))$('micStatus').textContent='failed — see the error box';}
    finally{btn.disabled=false;setTimeout(()=>{$('labBar').style.width='0%';},1500);}
  };
}

/* ---------- collapsibles ---------- */
if($('labBtn'))$('labBtn').onclick=()=>{$('labPanel').classList.toggle('hidden');$('labBtn').classList.toggle('open');};
if($('wshGoStem'))$('wshGoStem').onclick=()=>{
  if($('wshSection')&&!$('wshSection').classList.contains('hidden'))
    $('wshSection').scrollIntoView({behavior:'smooth',block:'center'});
};

/* ---------- keyboard: space plays/stops the LAST focused player ---------- */
document.addEventListener('keydown',e=>{
  if(e.code==='Space'&&e.target===document.body){
    e.preventDefault();
  }
});

/* ---------- init ---------- */
S.switchTab('main');
$('startBtn').disabled=true;
console.log('[studio v33] ENHANCE agent online — diagnose → plan → process → verify → rollback → report · Mic Studio + Dolby One untouched');
})();
