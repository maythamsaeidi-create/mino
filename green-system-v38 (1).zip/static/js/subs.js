/* ============================================================
   subs.js — Subtitles: independent source picker (any audio),
   Gemini transcription, broadcast-standard cues, karaoke,
   SRT / VTT / TXT exports. SMPTE in UI, SRT in exports.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;

/* broadcast standards (Netflix TTSG / EBU-inspired) */
const SUB={MAX_LINE:42,MAX_CHARS:84,MAX_CPS:21,MIN_DUR:0.9,MAX_DUR:7.0,GAP:0.08};

let segs=[];        // word-level [{speaker,startSec,endSec,text}]
let cues=[];        // grouped cues
let src=null;       // {key,kind,name,blob,buffer,duration}
let busy=false;
let prevPlayer=null;

/* ---------- helpers ---------- */
async function b64(blob){
  const ab=await blob.arrayBuffer();
  const u8=new Uint8Array(ab);let bin='';
  for(let i=0;i<u8.length;i+=8192)
    bin+=String.fromCharCode.apply(null,u8.subarray(i,Math.min(i+8192,u8.length)));
  return btoa(bin);
}
S.b64blob=b64;
function normSpk(ws){
  if(!Array.isArray(ws)||!ws.length)return ws;
  const map={};let n=0;
  for(const w of ws){
    let s=String(w.speaker==null?'A':w.speaker).trim()||'A';
    if(!(s in map))map[s]=String.fromCharCode(65+((n++)%26));
    w.speaker=map[s];
  }
  return ws;
}
function off2s(v){
  if(typeof v==='number')return v;
  const m=String(v==null?'':v).match(/-?\d+(?:\.\d+)?/);
  return m?parseFloat(m[0]):0;
}
function wrap2(t){
  const w=String(t||'').split(/\s+/).filter(Boolean);
  if(!w.length)return[''];
  const L=[];let cur='';
  for(const x of w){
    const c2=cur?cur+' '+x:x;
    if(c2.length>SUB.MAX_LINE&&cur){L.push(cur);cur=x;}else cur=c2;
  }
  if(cur)L.push(cur);
  if(L.length>2)return[L[0],L.slice(1).join(' ')];
  return L;
}
function normCues(cs,audioDur){
  if(!cs.length)return;
  cs.sort((a,b)=>a.startSec-b.startSec);
  for(let i=0;i<cs.length;i++){
    const c=cs[i];               // (was: const c=cs — the ARRAY, so the
                                  //  whole normalization never ran)
    const st=Math.max(0,c.startSec),dur=c.endSec-c.startSec,chars=(c.text||'').trim().length;
    const want=Math.max(dur,Math.min(chars/SUB.MAX_CPS,SUB.MAX_DUR),SUB.MIN_DUR);
    let en=st+Math.min(want,SUB.MAX_DUR);
    if(i+1<cs.length)en=Math.min(en,Math.max(cs[i+1].startSec-SUB.GAP,st+0.15));
    if(en<=st)en=st+SUB.MIN_DUR;
    if(audioDur&&i===cs.length-1)en=Math.min(en,Math.max(audioDur,st+0.4));
    c.startSec=Math.round(st*1000)/1000;
    c.endSec=Math.round(en*1000)/1000;
  }
}
function groupCues(){
  cues=[];
  const ws=segs.slice().sort((a,b)=>a.startSec-b.startSec||a.endSec-b.endSec);
  let cur=null,prevSpk=null,prevEnd=-999;
  for(const w of ws){
    const sp=String(w.speaker||'');
    const nW=cur?cur.words.length:0;
    const lastT=cur?String(cur.words[nW-1].text||'').trim():'';
    const brkP=cur&&nW>=4&&/[.!?؟…。！？]$/.test(lastT);
    const proj=cur?cur.text.length+1+(w.text||'').length:(w.text||'').length;
    if(!cur||sp!==prevSpk||(w.startSec-prevEnd)>1.0||nW>=14||brkP||proj>SUB.MAX_CHARS){
      cur={speaker:sp,startSec:w.startSec,endSec:w.endSec,words:[],text:''};cues.push(cur);
    }
    cur.words.push(w);cur.endSec=Math.max(cur.endSec,w.endSec);
    cur.text=(cur.text?cur.text+' ':'')+(w.text||'');
    prevSpk=sp;prevEnd=w.endSec;
  }
  normCues(cues,src&&src.duration);
}
function spkCount(){const s=new Set();for(const w of segs){if(w.speaker)s.add(w.speaker);}return s.size;}

/* ---------- Gemini (ported, lean) ---------- */
S.geminiSend=async function(b64d,mime,numSpk){
  const gk=$('geminiKey').value.trim();
  const gm=$('geminiModel').value||'gemini-3.5-transcribe';
  const url=S.GEMINI_PROXY+'/v1beta/models/'+gm+':generateContent';
  if(!gk)throw S.richErr('No Gemini API key',{hint:'Options → Gemini API Key — one key everywhere (get one at aistudio.google.com/apikey).'});
  let body;
  if(gm==='gemini-3.5-transcribe'){
    body={contents:[{parts:[{inline_data:{mime_type:mime,data:b64d}}]}],
          generationConfig:{audioTranscriptionConfig:{diarization:true,wordTimestamp:true,languageCodes:[]}}};
  }else{
    const prompt='Transcribe this audio word by word. Identify '+numSpk+' distinct speakers, label them A, B, C... Output ONLY a JSON array. Each element = one word. Format: [{"speaker":"A","start":0.0,"end":0.3,"text":"hello"}]. Times in seconds. No markdown, just JSON.';
    body={contents:[{parts:[{text:prompt},{inline_data:{mime_type:mime,data:b64d}}]}],
          generationConfig:{temperature:0.1,maxOutputTokens:65536,responseMimeType:'application/json',
          responseSchema:{type:'ARRAY',items:{type:'OBJECT',properties:{speaker:{type:'STRING'},start:{type:'NUMBER'},end:{type:'NUMBER'},text:{type:'STRING'}},required:['speaker','start','end','text']}}}};
  }
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':gk},body:JSON.stringify(body)});
  const t=await r.text();
  S.diag({m:'POST',u:'…gemini…:generateContent',s:r.status,b:t.slice(0,240)});
  const det={url,httpStatus:r.status,respBody:t.slice(0,600)};
  if(!r.ok){
    let em=t.slice(0,300);
    try{const j=JSON.parse(t);if(j.error)em=j.error.message;}catch(e){}
    if(/api[ _]?key|invalid.*key/i.test(em))det.hint='The Gemini key is invalid/expired — paste a fresh key from aistudio.google.com/apikey.';
    else if(r.status===404)det.hint='Model "'+gm+'" is unavailable for this key/region — use gemini-3.5-transcribe.';
    else if(r.status===429)det.hint='Rate limit — wait ~60 s or switch to gemini-3.5-flash-lite.';
    throw S.richErr('Gemini HTTP '+r.status+' — '+em,det);
  }
  let gj=null;
  try{gj=JSON.parse(t);}catch(e){throw S.richErr('Gemini/proxy returned non-JSON',Object.assign(det,{hint:'Usually a proxy error page or outage — raw response below.'}));}
  const c0=(gj.candidates&&gj.candidates[0])||null;
  if(gm==='gemini-3.5-transcribe'){
    const out=[];
    for(const part of ((c0&&c0.content&&c0.content.parts)||[])){
      const tr=part.audioTranscription;if(!tr)continue;
      const spk=tr.speakerLabel||'spk_1';
      for(const w of (tr.words||[]))out.push({speaker:spk,startSec:off2s(w.startOffset),endSec:off2s(w.endOffset),text:w.word||''});
    }
    if(!out.length)throw S.richErr('Transcribe model returned no words',{respBody:t.slice(0,600),hint:'Silent/too-short audio, unsupported language, or >30 min audio.'});
    return normSpk(out);
  }
  let textOut='';
  for(const part of ((c0&&c0.content&&c0.content.parts)||[]))if(part.text&&!part.thought)textOut+=part.text;
  const m=String(textOut||'').replace(/```json\s*/gi,'').replace(/```\s*/g,'').trim().match(/\[[\s\S]*\]/);
  if(!m)throw S.richErr('Gemini did not return a JSON array',{respBody:textOut.slice(0,500),hint:'If output looks truncated, switch to gemini-3.5-transcribe (native word timestamps).'});
  let parsed;
  try{parsed=JSON.parse(m[0]);}
  catch(e){
    const fixed=m[0].replace(/,\s*\]/g,']');
    try{parsed=JSON.parse(fixed);}
    catch(e2){
      const objs=fixed.match(/\{[^}]+\}/g);
      if(objs)parsed=objs.map(o=>{try{return JSON.parse(o);}catch(x){return null;}}).filter(Boolean);
      else throw S.richErr('Cannot parse Gemini JSON',{respBody:textOut.slice(0,500)});
    }
  }
  if(!parsed||!parsed.length)throw S.richErr('Gemini returned an empty word array',{respBody:textOut.slice(0,400)});
  return normSpk(parsed.map(u=>({speaker:u.speaker||'A',startSec:parseFloat(u.start||0),endSec:parseFloat(u.end||0),text:u.text||''})));
};

/* ---------- source picker (v29) ----------
   LOCAL FILE is its own button → the OS file picker opens
   immediately, no list in between. The dropdown lists only
   RELATED audio: this-session separation results (vocal first),
   engine outputs and server files — grouped, deduped, every
   item actually loadable. The menu DOM only rebuilds when its
   content really changes, so a click can never be eaten by a
   background re-render (v28 bug). The demo was removed.     */
let serverFiles=null,userPicked=false,_menuKeys='';
async function refreshServerFiles(){
  /* files that live on the SERVER (uploads + engine outputs) —
     after a reload or a server restart these are still there, so the
     user can subtitle them again without redoing the whole pipeline. */
  try{
    const j=await S.jget('/api/dsp/sources');
    serverFiles=(j&&j.sources)||[];
  }catch(e){serverFiles=null;}
}
const isVoc=n=>/vocal|voice|speech|sing/i.test(String(n||''))?1:0;
function sourceList(){
  const st=S.state;const groups=[];
  const ses=[];
  if(st.lf&&st.sab)ses.push({key:'studio',kind:'studio',label:String(st.lf.name).slice(0,44),tag:'SRC',data:null});
  if(st.finalMode){
    const fm=(st.stems||[]).find(s=>String(s.id||'').indexOf('fin_')===0&&/final/i.test(String(s.name||'')));
    if(fm)ses.push({key:'fin:'+fm.id,kind:'fin',label:'Final Mix'+(fm.duration?' · '+S.fd(fm.duration):''),tag:'FINAL',data:fm});
  }
  /* separated audio from the AUDIO section — vocal stems sort FIRST */
  (st.stems||[]).slice().sort((a,b)=>isVoc(b.name)-isVoc(a.name))
    .forEach(s=>{if(s&&s.blob)ses.push({key:'stem:'+s.id,kind:'stem',label:String(s.name||'stem').slice(0,40),tag:'STEM',data:s});});
  (st.spkTrk||[]).forEach(s=>{if(s&&s.blob)ses.push({key:'spk:'+s.id,kind:'spk',label:String(s.name||'speaker').slice(0,40),tag:'SPK',data:s});});
  if(ses.length)groups.push({h:'Separated — this session',items:ses});
  const seen={};const srv=[];
  /* engine outputs live on the server too → same fetch path, so they
     are now ACTUALLY loadable (v28 listed them but never decoded) */
  (S.dspOutputs?S.dspOutputs():[]).forEach(o=>{
    if(!o||seen[o.id])return;seen[o.id]=1;
    srv.push({key:'out:'+o.id,kind:'out',url:'/api/dsp/file/'+o.id,
      label:String(o.label||'engine output').slice(0,56),tag:'OUT',data:o});
  });
  (serverFiles||[]).forEach(e=>{
    if(seen[e.id])return;seen[e.id]=1;
    const d=(e.stats&&e.stats.duration)?' · '+S.fd(e.stats.duration):'';
    srv.push({key:'srv:'+e.id,kind:'srv',url:'/api/dsp/file/'+e.id,
      label:String(e.name||e.id).slice(0,52)+(e.engine?' ('+e.engine+')':'')+d,tag:'FILE'});
  });
  if(srv.length)groups.push({h:'Server — uploads & engine outputs',items:srv});
  return groups;
}
function renderMenu(){
  const m=$('subsSrcMenu');if(!m)return;
  const groups=sourceList();
  const keys=(src?src.key:'-')+'§'+groups.map(g=>g.h+'|'+g.items.map(i=>i.key).join(',')).join('/');
  /* keys-guarded rebuild: zero DOM churn while open unless the list OR
     the selection really changed → clicks can no longer be swallowed */
  if(keys===_menuKeys&&m.dataset.built)return;
  _menuKeys=keys;m.dataset.built='1';
  m.innerHTML='';
  if(!groups.length){
    const e=S.el('div','src-empty','no audio yet — pick a Local File, or run separation / an engine first');
    m.appendChild(e);return;
  }
  groups.forEach(g=>{
    m.appendChild(S.el('div','src-h',g.h));
    g.items.forEach(it=>{
      const sel=!!(src&&src.key===it.key);
      const b=S.el('button',sel?'srcsel':'srcit');
      b.dataset.key=it.key;
      b.innerHTML='<span class="si">'+S.esc(it.label)+'</span><span class="st">'+S.esc(it.tag||'')+'</span>';
      b.onclick=ev=>{ev.stopPropagation();toggleMenu(false);userPicked=true;pickSource(it);};
      m.appendChild(b);
    });
  });
}
function toggleMenu(force){
  const m=$('subsSrcMenu');
  const show=force!=null?force:m.classList.contains('hidden');
  if(show){
    renderMenu();                            /* instant, from the cached list */
    refreshServerFiles().then(renderMenu);   /* fresh — re-renders ONLY if changed */
  }
  m.classList.toggle('hidden',!show);
}
$('subsLocalBtn').onclick=()=>{$('subsFileInput').click();};
$('subsChooseBtn').onclick=ev=>{ev.stopPropagation();toggleMenu();};
document.addEventListener('click',ev=>{
  const m=$('subsSrcMenu');
  if(m&&!m.classList.contains('hidden')&&!ev.target.closest('#subsSrcMenu,#subsChooseBtn'))toggleMenu(false);
});
$('subsFileInput').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';
  if(!f)return;
  userPicked=true;
  try{
    const buf=await S.decode(f);
    /* kind 'local' = LOAD the chosen file (the old 'upload' kind
       re-opened the picker in a loop — local pick never worked) */
    pickSource({key:'up:'+f.name,kind:'local',label:f.name,
      data:{name:f.name,blob:f,buffer:buf,duration:buf.duration}});
  }catch(x){S.err(S.richErr('Cannot decode this file',{hint:'Use a standard MP3/WAV file.'}));}
};
async function pickSource(it){
  if(it.kind==='srv'||it.kind==='out'){
    /* file on the server (upload OR engine output) → fetch + decode here */
    const url=it.url||('/api/dsp/file/'+(it.data&&it.data.id));
    updChipBusy(true);
    try{
      const r=await fetch(url);
      if(!r.ok)throw new Error('HTTP '+r.status);
      const ab=await r.arrayBuffer();
      const buf=await S.decode(ab);
      src={key:it.key,kind:it.kind,name:String(it.label||'server file').split(' · ')[0],
           blob:null,buffer:buf,duration:buf.duration,url};
      primeCuePlayer();
      updChip();
    }catch(e){
      S.err(S.richErr('Could not load the server file — '+(e.message||e),{hint:'The file may have been removed. Re-run the pipeline or pick another source.'}));
      updChip();
    }
    return;
  }
  let d=it.data;
  if(it.key==='studio')d={name:S.state.lf.name,blob:S.state.lf,buffer:S.state.sab,duration:S.state.sab.duration};
  if(!d)return;
  src={key:it.key,kind:it.kind,name:d.name,blob:d.blob,buffer:d.buffer,duration:d.duration};
  if(!src.buffer&&src.blob){
    try{src.buffer=await S.decode(src.blob);}catch(e){}
  }
  primeCuePlayer();
  updChip();
}
function updChipBusy(b){
  const c=$('subsSrcName');
  if(c&&b){c.textContent='Loading…';c.style.color='var(--info)';c.classList.remove('loaded');}
  $('subsGemBtn').disabled=b||!src;
}
function updChip(){
  const c=$('subsSrcName');
  if(c){
    c.style.color='';
    if(src){c.textContent=String(src.name||'audio').slice(0,60)
      +(src.duration?' · '+S.fd(src.duration):'')
      +(src.blob?' · '+S.fb(src.blob.size):'');
      c.classList.add('loaded');}
    else{c.textContent='No audio selected';c.classList.remove('loaded');}
  }
  $('subsGemBtn').disabled=!src||busy;
}
S.setStat;
setInterval(()=>{
  /* auto-pick the studio file ONLY until the user chooses something
     themselves — after that the choice is never overridden */
  if(!userPicked&&(!src||src.kind==='studio')&&S.state.lf&&S.state.sab)
    pickSource({key:'studio',kind:'studio',label:''});
  const m=$('subsSrcMenu');
  if(m&&!m.classList.contains('hidden'))renderMenu();   /* keys-guarded → no DOM churn */
},2000);

/* ---------- generate ---------- */
$('subsGemBtn').onclick=async()=>{
  if(!src||busy)return;
  busy=true;updChip();
  $('errBox').classList.add('hidden');
  const bar=$('subsGemBar');
  const st=(t)=>{$('subsGemStatus').textContent=t||'';
    $('subsGemStatus').parentElement.classList.toggle('show',!!t);};
  try{
    st('Encoding audio for upload…');bar.style.width='10%';
    /* prefer MP3 (smaller upload), fall back to the raw blob */
    let up=src.blob,mime='audio/wav';
    if(src.buffer){up=S.ab2mp3(src.buffer,128);mime='audio/mp3';}
    st('Uploading to Gemini ('+S.fb(up.size)+')…');bar.style.width='30%';
    const b64d=await b64(up);
    st('Gemini transcribing word-by-word…');bar.style.width='55%';
    const num=parseInt(($('subsSpk').value)||'-1');
    const ws=await S.geminiSend(b64d,mime,num>0?num:2);
    st('Building broadcast-standard cues…');bar.style.width='85%';
    S.applySubs(ws);
    bar.style.width='100%';
    st('Done — '+ws.length+' words · '+spkCount()+' speakers');
    S.toast('Subtitles ready — '+cues.length+' cues');
  }catch(e){S.err(e);st('');}
  finally{busy=false;updChip();setTimeout(()=>{bar.style.width='0%';},1500);}
};

/* ---------- apply results (called from anywhere) ---------- */
S.applySubs=function(ws,silent){
  segs=(ws||[]).map(u=>({speaker:String(u.speaker||'A'),
    startSec:parseFloat(u.startSec!=null?u.startSec:(u.start||0)),
    endSec:parseFloat(u.endSec!=null?u.endSec:(u.end||0)),text:u.text||''}))
    .filter(w=>w.endSec>w.startSec);
  groupCues();
  renderCues();renderKaraoke();
  /* v27 — Subtitle Layer: hand the word model to the VIZ engine */
  if(window.VIZ&&VIZ.setWords)VIZ.setWords(segs,src&&src.name,src&&src.duration);
  else if(!window.VIZ){window.__VIZ_PEND_WORDS=segs;window.__VIZ_PEND_NAME=src&&src.name;window.__VIZ_PEND_DUR=src&&src.duration;}
  primeCuePlayer();          // Play button = the WHOLE subtitle, ready
  const b=$('tabSubsBadge');
  if(b){b.textContent=cues.length+' cues';b.classList.toggle('show',!!cues.length);}
  const cc=$('subCount');
  if(cc)cc.textContent=cues.length+' cues · '+segs.length+' words · '+spkCount()+' speakers';
  if(!silent)S.switchTab('subs');
  return segs.length;
};

/* ---------- cue list ---------- */
function renderCues(){
  const box=$('subList');if(!box)return;
  box.innerHTML='';
  cues.forEach((s,i)=>{
    const dur=Math.max(0.001,s.endSec-s.startSec);
    const cps=Math.round(String(s.text||'').length/dur);
    const over=cps>SUB.MAX_CPS+7;
    const row=S.el('div','cue');
    row.innerHTML='<span class="tc">'+S.tcSRT(s.startSec)+' → '+S.tcSRT(s.endSec)+'</span>'
      +(s.speaker?'<span class="sp">'+S.esc(s.speaker)+'</span>':'')
      +'<span class="tx">'+S.esc(s.text)+'</span>'
      +'<span class="tag'+(over?' qa-warn':'')+'" title="reading speed" style="margin-left:auto">'+cps+' cps</span>';
    row.onclick=()=>playCue(s,row);
    box.appendChild(row);
  });
}
/* ---------- THE stage player: Play = whole subtitle ----------
   v28: minimal player bar lives UNDER the 16:9 stage.
   Play plays the WHOLE audio from the current position; onTick
   drives the cue row highlight, the karaoke word highlight and
   the stage (via VIZ's own rAF, which reads this player). */
let curCueEl=null,cueBufRef=null,OFF=0;     /* OFF = word-timing offset (advanced settings) */
S._cueOffset=0;
function ensureCueP(){
  if(S._cueP)return S._cueP;
  S._cueP=S.Player($('subPlayerHost'),{
    mini:true,
    onTick:function(side,pos,ended){cueTick(pos,ended);}
  });
  if(prevPlayer&&prevPlayer!==S._cueP)prevPlayer.stop();
  prevPlayer=S._cueP;
  return S._cueP;
}
function primeCuePlayer(){
  if(!src||!src.buffer)return;
  try{
    const p=ensureCueP();
    if(cueBufRef!==src.buffer){p.setBuffer('A',src.buffer);cueBufRef=src.buffer;}
  }catch(e){}
}
function cueTick(t,ended){
  if(ended){                       // playback finished → clear the green
    if(curCueEl){curCueEl.classList.remove('play');curCueEl=null;}
    const lc=$('liveCap');if(lc)lc.classList.add('hidden');
    return;
  }
  const tt=t+OFF;                  // shifted clock for every highlight
  let idx=-1;
  for(let i=0;i<cues.length;i++){
    if(cues[i].startSec<=tt&&tt<cues[i].endSec)idx=i;
    else if(cues[i].startSec>tt)break;
  }
  const rows=$('subList').children;
  if(idx>=0&&rows[idx]&&curCueEl!==rows[idx]){
    if(curCueEl)curCueEl.classList.remove('play');
    rows[idx].classList.add('play');curCueEl=rows[idx];
    curCueEl.scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  if(idx<0&&curCueEl){curCueEl.classList.remove('play');curCueEl=null;}
  karaokeTick(tt);                 // live word highlight
}
function playCue(s,row){
  if(!src||!src.buffer){S.toast('No playable source for these cues',true);return;}
  const p=ensureCueP();
  primeCuePlayer();
  p.seek(Math.max(0,s.startSec-OFF));   // jump AND keep playing (offset-aware)
  p.play();
  if(curCueEl)curCueEl.classList.remove('play');
  if(row){row.classList.add('play');curCueEl=row;}   // instant, onTick follows
}

/* ---------- karaoke ---------- */
let kwEls=[],kwSegs=[],kPrev=-1;
function renderKaraoke(){
  const kb=$('karaokeBox');if(!kb)return;
  kb.innerHTML='';kwEls=[];kwSegs=[];kPrev=-1;
  if(!segs.length)return;
  kwSegs=segs.slice().sort((a,b)=>a.startSec-b.startSec||a.endSec-b.endSec);
  kb.dir=/[\u0600-\u06FF]/.test(String(kwSegs[0]&&kwSegs[0].text||''))?'rtl':'ltr';
  kwSegs.forEach(s=>{
    const el=S.el('span','kw',s.text||'');
    el.title=S.tcSRT(s.startSec)+' → '+S.tcSRT(s.endSec);
    kwEls.push(el);kb.appendChild(el);
  });
}
function karaokeTick(t){
  if(!kwEls.length)return;
  /* v28: the 16:9 stage renders the live caption itself — the fixed
     floating caption stays hidden; the classic karaoke box updates
     only while it is the visible view in the display card. */
  const kb=$('karaokeBox');
  const karOn=kb&&!kb.classList.contains('hidden');
  let idx=-1;
  for(let i=0;i<kwSegs.length;i++){if(kwSegs[i].startSec<=t)idx=i;else break;}
  if(idx===kPrev){
    const live=$('liveCap');if(live)live.classList.add('hidden');
    return;
  }
  kPrev=idx;
  if(karOn)kwEls.forEach((el,i)=>{el.className='kw'+(i<idx?' done':(i===idx?' now':''));});
  const live=$('liveCap');if(live)live.classList.add('hidden');
}
S.karaokeTick=karaokeTick;
S.resetKaraoke=function(){kPrev=-2;};   /* force one re-render after a view switch */
function srtTxt(){
  let s='';
  cues.forEach((seg,i)=>{
    const L=wrap2((seg.speaker?'['+seg.speaker+'] ':'')+seg.text);
    s+=(i+1)+'\n'+S.tcSRT(seg.startSec)+' --> '+S.tcSRT(seg.endSec)+'\n'+L.join('\n')+'\n\n';
  });
  return s;
}
function vttTxt(){
  let s='WEBVTT\n\n';
  cues.forEach((seg,i)=>{
    const L=wrap2(seg.text);
    s+=(i+1)+'\n'+S.tcSRT(seg.startSec).replace(',','.')+' --> '+S.tcSRT(seg.endSec).replace(',','.')
      +'\n'+(seg.speaker?'<v '+seg.speaker+'> ':'')+L.join('\n')+'\n\n';
  });
  return s;
}
function txtTxt(){
  const turns=[];
  for(const c of cues){
    const last=turns[turns.length-1];
    if(last&&last.sp===c.speaker&&(c.startSec-last.end)<6)
      last.text=(last.text+' '+c.text).trim(),last.end=c.endSec;
    else turns.push({sp:c.speaker,start:c.startSec,end:c.endSec,text:c.text});
  }
  return turns.map(t=>'['+S.fd(t.start)+'] '+(t.sp?t.sp+': ':'')+t.text).join('\n');
}
function dl(txt,name,mime){
  const a=S.el('a');
  a.href=URL.createObjectURL(new Blob([txt],{type:mime||'text/plain;charset=utf-8'}));
  a.download=name;a.click();
}
$('dlSrt').onclick=()=>dl(srtTxt(),'Subtitles_'+(S.pn||'audio').replace(/\.[^/.]+$/,'')+'.srt');
$('dlVtt').onclick=()=>dl(vttTxt(),'Subtitles_'+(S.pn||'audio').replace(/\.[^/.]+$/,'')+'.vtt','text/vtt');
$('dlTxt').onclick=()=>dl(txtTxt(),'Transcript_'+(S.pn||'audio').replace(/\.[^/.]+$/,'')+'.txt');
$('copySub').onclick=()=>{navigator.clipboard.writeText(txtTxt()).then(()=>{
  $('copySub').textContent='✓';setTimeout(()=>$('copySub').textContent='Copy',1500);});};

/* ---------- ADVANCED SETTINGS — modal (v28) ----------
   Same menu pattern as the Dolby One settings modal; opening it
   never reflows the page. The sync slider is a separate control —
   live preview in the stage, zero layout impact. */
(function(){
  const setM=$('subsSetModal');
  if(!setM)return;
  const updOff=()=>{
    OFF=parseFloat($('subsOffset').value)||0;
    S._cueOffset=OFF;                     /* VIZ core adds this to the player clock */
    const s=(OFF>=0?'+':'')+OFF.toFixed(2);
    $('subsOffsetVal').textContent=s+' s';
    $('subsSetLive').textContent='timing offset '+s+' s'+
      (Math.abs(OFF)>0.001?' · live in stage':'');
  };
  const open=()=>{setM.classList.remove('hidden');updOff();};
  const close=()=>setM.classList.add('hidden');
  $('subsAdvBtn').onclick=open;
  $('subsSetClose').onclick=close;
  $('subsSetApply').onclick=()=>{close();S.toast('Subtitle settings applied');};
  $('subsSetReset').onclick=()=>{
    $('subsOffset').value='0';$('subsSpk').value='-1';updOff();
    S.toast('Subtitle settings reset');
  };
  $('subsOffset').addEventListener('input',updOff);
  setM.addEventListener('click',e=>{
    if(e.target===setM||e.target.classList.contains('modal-bg'))close();
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&!setM.classList.contains('hidden'))close();
  });
  updOff();
})();

/* v30: FX export needs the CURRENT source (audio bytes) — closed over
   here, so expose a read-only getter. */
S.fxSrcInfo=function(){return src?{name:src.name,blob:src.blob,buffer:src.buffer,url:src.url}:null;};

updChip();
})();
