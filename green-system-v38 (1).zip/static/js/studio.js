/* ============================================================
   studio.js — STEM STUDIO: one Scan & Fix, per-stem engine chains,
   per-engine ACTIVITY MODULES (tick every single processing step
   on/off, with amount sliders), per-row live Preview (A/B at the
   exact same position), batch engine actions, Final Mix.
   Every file playable, downloadable, inspectable.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;

const KINDS={voice:['VOC','voc'],music:['MUS','mus'],fx:['FX','fx'],clean:['MIX','mus']};
const ENGINES={
  enhance:{n:'Enhance Agent',d:'intelligent adaptive agent — diagnose → plan → verify → rollback'},
  studiomic:{n:'Mic Studio AI',d:'resemble-enhance AI + analog mic-model — expensive-mic voice'},
  studiomax:{n:'Studio Max AI',d:'strongest combination: Demucs AI split + Apollo music restore + Resemble voice + remaster chain'},
  voice:{n:'Voice Enhance',d:'Denoise + presence EQ for speech stems'},
  music:{n:'Music Enhance',d:'Widen + polish for music beds'},
  fx:{n:'FX Enhance',d:'Transient restore for effects stems'},
  clean:{n:'Clean',d:'Denoise + declick + dehum (full mix)'},
  spatial:{n:'3D Spatial',d:'ITD/ILD stereo widening'},
  master:{n:'Master',d:'Loudness (LUFS) + true-peak limit'},
  dolby_off:{n:'Dolby OFFLINE',d:'7-stage offline chain — no keys, no cloud'},
};
const DEFAULT_ENG={voice:['studiomic'],music:['music'],fx:['fx'],clean:['clean']};
const CHAIN=['enhance','studiomic','studiomax','voice','music','fx','clean','spatial','master','dolby_off'];

let ROWS=[];            // row models
let pollTimer=null;
let busyScan=false,busyMix=false;   // ONE scan or mix at a time
let CATALOG=null;       // /api/dsp/engine_catalog — per-engine modules

/* ---------- engine catalog (v37: per-activity ticks) ---------- */
async function loadCatalog(){
  if(CATALOG)return CATALOG;
  try{
    const j=await S.jget('/api/dsp/engine_catalog');
    if(j&&j.ok&&j.engines)CATALOG=j.engines;
  }catch(e){/* catalog-less fallback: engine toggles still work */}
  return CATALOG;
}
loadCatalog();

/* seed per-engine params from the catalog defaults (modules on + amounts) */
function seedParams(ek){
  const cat=CATALOG&&CATALOG[ek];
  const out={modules:{}};
  if(!cat)return out;
  (cat.modules||[]).forEach(m=>{
    out.modules[m.key]=(m.default!==false);
    if(m.amount)out[m.amount.key]=m.amount.default;
  });
  return out;
}

/* build the {engine:{modules,amounts,param-offs}} payload for a row */
function engineParams(r){
  const out={};
  (r.engines||[]).forEach(ek=>{
    const cat=CATALOG&&CATALOG[ek];
    const ep=r.eparams&&r.eparams[ek];
    if(!cat)return;
    const p={modules:{}};
    (cat.modules||[]).forEach(m=>{
      const on=!(ep&&ep.modules&&ep.modules[m.key]===false);
      p.modules[m.key]=on;
      if(!on&&m.param!==undefined&&m.off!==undefined)p[m.param]=m.off;
      if(m.amount&&ep&&ep[m.amount.key]!=null)p[m.amount.key]=ep[m.amount.key];
    });
    out[ek]=p;
  });
  return out;
}

/* "(3/5 on)" suffix for the row meta when some activities are off */
function modsOn(r,ek){
  const cat=CATALOG&&CATALOG[ek];
  const ep=r.eparams&&r.eparams[ek];
  if(!cat||!cat.modules)return '';
  const on=cat.modules.filter(m=>!(ep&&ep.modules&&ep.modules[m.key]===false)).length;
  return on<cat.modules.length?(' ('+on+'/'+cat.modules.length+' on)'):'';
}

function classify(name,isSpk){
  const n=String(name||'').toLowerCase();
  if(isSpk||n.startsWith('spk')||n.includes('speaker'))return 'voice';
  if(n.includes('no vocal')||n.includes('instrumental')||n.trim()==='other'||n.trim()==='music')return 'music';
  if(n.includes('vocal')||n.includes('voice')||n.includes('speech'))return 'voice';
  if(n.includes('fx')||n.includes('effect')||n.includes('sfx'))return 'fx';
  return 'music';
}

/* ---------- ensure rows from pipeline results ---------- */
function ensureRow(key,name,kind,blob,duration,isSpk,buffer){
  let r=ROWS.find(x=>x.key===key);
  if(r){if(blob&&!r.blob){r.blob=blob;r.buffer=buffer;r.duration=duration;render();}return r;}
  r={key,name,kind:kind||classify(name,isSpk),isSpk:!!isSpk,
     blob,buffer:buffer||null,duration:duration||0,
     serverId:null,outId:null,passthrough:false,verdict:null,reason:'',
     statsBefore:null,stats:null,engines:(DEFAULT_ENG[kind||classify(name,isSpk)]||[]).slice(),
     eparams:{},final:false,open:false,player:null,busyPrev:false};
  ROWS.push(r);render();
  return r;
}
S.ensureWRow=ensureRow;

/* auto-populate from state (poll — mirrors old behavior) */
setInterval(()=>{
  const st=S.state;
  (st.spkTrk||[]).forEach(s=>{
    if(s&&s.blob&&String(s.id||'').indexOf('fin_')!==0)
      ensureRow('spk:'+s.id,s.name||'speaker','voice',s.blob,s.duration,true,s.buffer);
  });
  const hasSpk=(st.spkTrk||[]).some(s=>s&&String(s.id||'').indexOf('fin_')!==0);
  /* speakers REPLACE the plain vocal stem — if the vocal row was created
     during the Gemini wait (before spkTrk arrived) remove it now, or the
     Final Mix doubles the vocals and the count reads wrong. */
  if(hasSpk){
    const before=ROWS.length;
    ROWS=ROWS.filter(r=>!( !r.isSpk && String(r.key).indexOf('stem:')===0
      && (r.kind==='voice'||/vocal|voice|speech/i.test(String(r.name||''))) ));
    if(ROWS.length!==before){render();}
  }
  (st.stems||[]).forEach(s=>{
    if(!s||!s.blob)return;
    if(String(s.id||'').indexOf('fin_')===0)return;
    const k=classify(s.name,false);
    if(k==='voice'&&hasSpk)return;   // vocal → already per-speaker
    ensureRow('stem:'+s.id,s.name||'stem',k,s.blob,s.duration,false,s.buffer);
  });
  $('wshSection').classList.toggle('hidden',ROWS.length===0);
},2500);

/* full reset — a NEW separation must never mix rows from the previous
   file (stale rows kept their Final ✓ tick → wrong count + wrong mix) */
S.resetStudio=function(){
  ROWS.forEach(r=>{if(r.player){r.player.destroy();r.player=null;}});
  ROWS=[];render();
  const b=$('wshBar');if(b)b.style.width='0%';
};

/* ---------- upload row to server (once) ---------- */
async function uploadRow(r){
  if(r.serverId)return r.serverId;
  const fname=String(r.name||'stem').replace(/[^\w\-. ]+/g,'_').trim().replace(/\s+/g,'_')+'.wav';
  const j=await S.upl('/api/dsp/upload',r.blob,null,fname);
  r.serverId=j.id;
  return j.id;
}

/* ---------- render ---------- */
function meta(r){
  const lb=(r.statsBefore&&r.statsBefore.lufs!=null)?(+r.statsBefore.lufs).toFixed(1)+' LUFS':'—';
  const la=(r.stats&&r.stats.lufs!=null)?(+r.stats.lufs).toFixed(1)+' LUFS':null;
  const eng=r.engines.length?r.engines.map(e=>(ENGINES[e]?ENGINES[e].n:e)+modsOn(r,e)).join(' → '):'pass-through (original)';
  const parts=[S.fd(r.duration||0),lb+(la?' → '+la:''),eng];
  if(r.reason)parts.push(r.reason.slice(0,80));
  return parts.join(' · ');
}

/* one engine's activity panel (checkbox + optional amount slider) */
function modPanel(r,ek){
  const cat=CATALOG&&CATALOG[ek];
  const box=S.el('div','modbox');
  if(!cat){box.innerHTML='<div class="modhead">'+S.esc(ENGINES[ek]?ENGINES[ek].n:ek)+'</div>';return box;}
  const head=S.el('div','modhead');
  head.innerHTML='<span>'+S.esc(cat.name||ENGINES[ek].n)+'</span>'
    +'<span class="sub">'+(cat.modules?cat.modules.length:0)+' activities'
    +(cat.heavy?' · heavy':'')+'</span>';
  box.appendChild(head);
  const grid=S.el('div','modgrid');
  (cat.modules||[]).forEach(m=>{
    const ep=r.eparams[ek]||(r.eparams[ek]=seedParams(ek));
    const on=!(ep.modules&&ep.modules[m.key]===false);
    const lab=S.el('label','mod'+(on?' on':''));
    lab.title=m.desc||'';
    const cb=S.el('input');cb.type='checkbox';cb.checked=on;
    cb.onchange=ev=>{
      ev.stopPropagation();
      ep.modules[m.key]=cb.checked;
      lab.classList.toggle('on',cb.checked);
      const hd=lab.closest('.row');if(hd)hd.querySelectorAll('.rmeta').forEach(x=>x.textContent=meta(r));
    };
    lab.appendChild(cb);
    const tx=S.el('span','modlab');tx.textContent=m.label;
    lab.appendChild(tx);
    if(m.amount){
      const a=m.amount;
      const sl=S.el('input','modamt');sl.type='range';
      sl.min=a.min;sl.max=a.max;sl.step=a.step;
      sl.value=(ep[a.key]!=null?ep[a.key]:a.default);
      sl.onclick=e=>e.stopPropagation();
      sl.oninput=ev=>{ev.stopPropagation();ep[a.key]=parseFloat(sl.value);vl.textContent=fmtAmt(sl.value,a);};
      const vl=S.el('span','modval');
      const fmtAmt=(v,a)=>v+(a.unit?' '+a.unit:'');
      vl.textContent=fmtAmt(sl.value,a);
      lab.appendChild(sl);lab.appendChild(vl);
    }
    grid.appendChild(lab);
  });
  box.appendChild(grid);
  return box;
}

function render(){
  const box=$('wshList');if(!box)return;
  ROWS.forEach(r=>{if(r.player){r.player.destroy();r.player=null;}});   // dispose old timelines
  box.innerHTML='';
  ROWS.forEach(r=>{
    const K=KINDS[r.kind]||KINDS.music;
    const hasB=!!(r.outId&&!r.passthrough);
    const row=S.el('div','row'+(r.open?' open':''));

    /* header */
    const head=S.el('div','rhead');
    head.innerHTML='<div class="rid">'
      +'<span class="tag '+(r.isSpk?'spk':K[1])+'">'+(r.isSpk?'SPK':K[0])+'</span>'
      +'<div style="min-width:0"><div class="rname">'+S.esc(r.name)+'</div>'
      +'<div class="rmeta">'+S.esc(meta(r))+'</div></div>'
      +(r.passthrough?'<span class="tag">ORIGINAL</span>':'')
      +(r.verdict?'<span class="tag qa-'+r.verdict+'">QA '+r.verdict.toUpperCase()+'</span>':'')
      +'</div>'
      +'<div class="rbtns">'
      +'<button class="btn sm" data-a="wshF" title="Include this stem in the Final Mix">Final ✓</button>'
      +'</div>';
    const chk=S.el('input');chk.type='checkbox';chk.checked=r.final;
    chk.onchange=()=>{r.final=chk.checked;updMixBtn();};
    chk.onclick=e=>e.stopPropagation();
    head.querySelector('[data-a=wshF]').prepend(chk);
    head.onclick=ev=>{
      if(ev.target.closest('button,input,label'))return;
      r.open=!r.open;render();
    };
    row.appendChild(head);

    /* body: TIMELINE PLAYER (dual A/B) */
    const body=S.el('div');body.style.padding='0 11px 11px';
    const pHost=S.el('div');
    body.appendChild(pHost);
    row.appendChild(body);

    /* engine chain panel + activity modules + preview (when open) */
    if(r.open){
      const eng=S.el('div','engs');
      Object.keys(ENGINES).forEach(ek=>{
        if(CHAIN.indexOf(ek)<0)return;
        const on=r.engines.indexOf(ek)>=0;
        const lab=S.el('label','eng'+(on?' on':''));
        lab.title=ENGINES[ek].d;
        lab.innerHTML='<input type="checkbox" '+(on?'checked':'')+'>'+S.esc(ENGINES[ek].n);
        const cb=lab.querySelector('input');
        cb.onchange=ev=>{
          ev.stopPropagation();
          if(cb.checked){
            if(r.engines.indexOf(ek)<0)r.engines.push(ek);
            if(!r.eparams[ek])r.eparams[ek]=seedParams(ek);
          }else r.engines=r.engines.filter(x=>x!==ek);
          lab.classList.toggle('on',cb.checked);
          rebuildPanel(r,row,body,pHost);
        };
        eng.appendChild(lab);
      });
      row.appendChild(eng);

      /* per-engine activity panels (selection order) */
      const wrap=S.el('div','modwrap');
      r.engines.forEach(ek=>wrap.appendChild(modPanel(r,ek)));
      row.appendChild(wrap);

      /* live preview button — runs THIS row only, updates B immediately */
      const pv=S.el('div','pvrow');
      const pbtn=S.el('button','btn sm primary');
      pbtn.innerHTML=r.busyPrev?'Preview running…':'▶ Preview this stem (live A/B)';
      pbtn.disabled=r.busyPrev;
      pbtn.title='Runs this stem chain with your activity ticks — then flip A/B at the exact same position';
      pbtn.onclick=ev=>{ev.stopPropagation();runPreview(r);};
      pv.appendChild(pbtn);
      row.appendChild(pv);
    }
    box.appendChild(row);

    /* build the player for this row — dual with A/B */
    const p=S.Player(pHost,{dual:true,labels:{A:'Original',B:'Fixed'}});
    if(r.buffer)p.setBuffer('A',r.buffer);
    else if(r.blob)p.setBlob('A',r.blob);
    if(hasB)p.setUrl('B','/api/dsp/file/'+r.outId);
    r.player=p;

    /* WAV download */
    const dbtn=S.el('button','btn sm');dbtn.textContent='WAV';
    dbtn.title=hasB?'Download the FIXED file':'Download the ORIGINAL file';
    dbtn.onclick=e=>{e.stopPropagation();
      const a=S.el('a');
      if(hasB)a.href='/api/dsp/download/'+r.outId;
      else a.href=URL.createObjectURL(r.blob);
      a.download=String(r.name).replace(/[^\w\-. ]+/g,'_').trim().replace(/\s+/g,'_')+'_'+(hasB?'fixed':'original')+'.wav';
      a.click();
    };
    head.querySelector('.rbtns').appendChild(dbtn);
  });
  const c=$('wshCount');
  if(c)c.textContent=ROWS.length+(ROWS.length===1?' stem':' stems');
  updMixBtn();
}

/* rebuild the open-row sub-panels after an engine tick change */
function rebuildPanel(r,row,body,pHost){
  const metaEl=row.querySelector('.rmeta');
  if(metaEl)metaEl.textContent=meta(r);
  const wrap=row.querySelector('.modwrap');
  if(wrap){
    wrap.innerHTML='';
    r.engines.forEach(ek=>wrap.appendChild(modPanel(r,ek)));
  }
}

function updMixBtn(){
  const n=ROWS.filter(r=>r.final).length;
  $('wshMix').disabled=n<1||busyScan||busyMix;
  const el=$('wshMixN');if(el)el.textContent=n;
}

/* ---------- batch toolbar: All engines / Defaults / Pass-through --- */
function setAllEngines(mode){
  if(!ROWS.length){S.toast('No stems yet — run Start (Studio tab) first',true);return;}
  ROWS.forEach(r=>{
    if(mode==='all')r.engines=CHAIN.slice();
    else if(mode==='none')r.engines=[];
    else r.engines=(DEFAULT_ENG[r.kind]||['clean']).slice();
    r.outId=null;r.passthrough=false;r.verdict=null;r.reason='';
  });
  render();
  S.setStat(mode==='all'?'All engines selected on every stem':
    mode==='none'?'Pass-through — originals go to the mix untouched':
    'Default engine per stem kind restored');
}

/* ---------- SCAN & FIX (the ONE scan) ---------- */
$('wshRun').onclick=async()=>{
  if(!ROWS.length){S.err('No stems yet — run Start (Studio tab) or Generate Subtitles first.');return;}
  if(busyScan||busyMix){S.toast('Another scan/mix is still running — wait for it to finish',true);return;}
  busyScan=true;updMixBtn();
  const btn=$('wshRun');btn.disabled=true;
  $('wshError').classList.add('hidden');
  try{
    const items=[];
    for(const r of ROWS){
      if(!r.serverId){
        S.setStat('Uploading '+r.name+'…');
        r.serverId=await uploadRow(r);
      }
      items.push({src_id:r.serverId,kind:r.kind,name:r.name,
                  engines:r.engines.slice(),params:engineParams(r)});
    }
    const engN=ROWS.filter(r=>r.engines.length).length;
    S.setStat('Scan & fix '+items.length+' stems ('+engN+' with engine, '+(items.length-engN)+' pass-through)…');
    $('wshBar').style.width='4%';
    const j=await S.jpost('/api/dsp/workshop_run',{items});
    if(!j.ok)throw S.richErr(j.reason||'could not start the scan');
    await pollJob(j.job_id,false);
  }catch(e){S.err(e);S.setStat('Scan failed — see the error box',true);$('wshBar').style.width='0%';}
  finally{busyScan=false;btn.disabled=false;updMixBtn();}
};

/* ---------- PREVIEW one stem (live A/B) ---------- */
async function runPreview(r){
  if(busyScan||busyMix){S.toast('Scan/mix in progress — wait for it',true);return;}
  if(!r.engines.length){S.toast('Tick at least one engine for this stem first',true);return;}
  r.busyPrev=true;render();
  try{
    if(!r.serverId){S.setStat('Uploading '+r.name+'…');r.serverId=await uploadRow(r);}
    const item={src_id:r.serverId,kind:r.kind,name:r.name,
                engines:r.engines.slice(),params:engineParams(r)};
    S.setStat('Preview: '+r.name+' ('+r.engines.length+' engine'+(r.engines.length>1?'s':'')+')…');
    const j=await S.jpost('/api/dsp/workshop_run',{items:[item]});
    if(!j.ok)throw S.richErr(j.reason||'preview could not start');
    const res=await pollJob(j.job_id,false,true);
    const stem=res&&res.stems&&res.stems[0];
    if(stem){
      r.outId=stem.out_id||null;
      r.passthrough=!!stem.passthrough;
      r.verdict=stem.verdict||null;
      r.reason=stem.reason||'';
      r.stats=stem.stats||null;
      r.statsBefore=stem.stats_before||null;
    }
    render();
    S.setStat('Preview ready — flip A⇄B on the timeline to hear the difference at the exact same position.');
  }catch(e){S.err(e);S.setStat('Preview failed — see the error box',true);}
  finally{r.busyPrev=false;render();}
}

function pollJob(jid,isMix,quiet){
  return new Promise((resolve,reject)=>{
    if(pollTimer)clearInterval(pollTimer);
    let bad=0;
    pollTimer=setInterval(async()=>{
      let j=null;
      try{j=await S.jget('/api/dsp/job/'+jid);bad=0;}
      catch(e){
        bad++;
        if(bad>=3){clearInterval(pollTimer);pollTimer=null;reject(e);return;}
        return;
      }
      try{
        if(!j.ok)throw S.richErr(j.reason||'job lost',{
          hint:/job not found|job lost/.test(String(j.reason||''))?
            'This tab was open before the server restarted — its old job is gone. '
            +'Reload the page (F5); your stems are still in Stem Studio and any '
            +'finished file still downloads from the server.':null});
        const job=j.job;
        S.setStat((job.stage||job.state)+' · '+job.elapsed+'s');
        $('wshBar').style.width=Math.max(4,job.progress)+'%';
        if(job.state==='done'||job.state==='error'){
          clearInterval(pollTimer);pollTimer=null;
          if(job.state==='error')throw S.richErr((job.result&&job.result.reason)||'engine failed');
          if(isMix)S.onFinalMixDone(job.result);
          else if(!quiet)applyResults(job.result);
          resolve(job.result);
        }
      }catch(e){clearInterval(pollTimer);pollTimer=null;S.err(e);reject(e);}
    },1500);
  });
}

function applyResults(res){
  const stems=(res&&res.stems)||[];
  let okN=0,ptN=0;
  stems.forEach((r,i)=>{
    const row=ROWS[i];if(!row)return;
    row.outId=r.out_id||null;
    row.passthrough=!!r.passthrough;
    row.verdict=r.verdict||null;
    row.reason=r.reason||'';
    row.stats=r.stats||null;
    row.statsBefore=r.stats_before||null;
    if(r.ok){okN++;if(r.passthrough)ptN++;}
  });
  render();
  $('wshBar').style.width='100%';
  S.setStat('Stem Studio complete — '+okN+'/'+stems.length+' ready'+(ptN?' ('+ptN+' pass-through)':'')+'. A/B compare, tick Final, mix.');
}

/* ---------- FINAL MIX ---------- */
$('wshMix').onclick=async()=>{
  if(busyScan||busyMix){S.toast('Another scan/mix is still running — wait for it to finish',true);return;}
  const items=[];
  const ticked=ROWS.filter(r=>r.final);
  for(const r of ticked){
    let id=(r.outId&&!r.passthrough)?r.outId:r.serverId;
    if(!id){                       // never scanned/uploaded → do it now
      try{S.setStat('Uploading '+r.name+'…');r.serverId=await uploadRow(r);id=r.serverId;}
      catch(e){S.err(e);S.setStat('Final Mix stopped — a stem could not be uploaded',true);return;}
    }
    if(id)items.push({out_id:id,orig_lufs:(r.statsBefore&&r.statsBefore.lufs)||null});
  }
  if(!items.length){S.err(S.richErr('Final Mix has nothing to mix — no ticked stem has a usable file.',{hint:'Tick at least one stem (Final ✓), run Scan & Fix All first, then Final Mix.'}));return;}
  busyMix=true;updMixBtn();
  const btn=$('wshMix');btn.disabled=true;
  try{
    const j=await S.jpost('/api/dsp/workshop_mix',{items,lufs:-16,tp:-1.5});
    if(!j.ok)throw S.richErr(j.reason||'could not start the mix');
    S.setStat('Mixing '+items.length+' stem(s)…');
    $('wshBar').style.width='4%';
    await pollJob(j.job_id,true);
  }catch(e){S.err(e);}
  finally{busyMix=false;btn.disabled=false;updMixBtn();}
};

/* ---------- toolbar wiring ---------- */
document.addEventListener('DOMContentLoaded',()=>{
  const a=$('wshAll'),d=$('wshDef'),n=$('wshNone');
  if(a)a.onclick=()=>setAllEngines('all');
  if(d)d.onclick=()=>setAllEngines('def');
  if(n)n.onclick=()=>setAllEngines('none');
});

/* exports for other modules */
S.wshRows=()=>ROWS;
})();
