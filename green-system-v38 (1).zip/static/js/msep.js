/* ============================================================
   msep.js — source loading + MVSEP separation pipeline.
   Ported battle-tested logic: 540 s smart chunking (quiet-point
   cuts), job create with retry, polling, stem download + decode,
   stem merge, vocal MP3, Gemini diarization → speaker tracks.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;
let abort=null;          // AbortController for cancel
S.pn='';                 // current source name (for exports)

/* ---------- buffer helpers (ported, proven) ---------- */
S.sliceAB=function(b,s,e){
  const c=S.ctx(),sr=b.sampleRate;
  const ss=Math.floor(s*sr),es=Math.min(b.length,Math.floor(e*sr)),fc=Math.max(1,es-ss),nc=b.numberOfChannels;
  const n=c.createBuffer(nc,fc,sr);
  for(let ch=0;ch<nc;ch++)n.getChannelData(ch).set(b.getChannelData(ch).subarray(ss,es),0);
  return n;
};
S.ab2wav=function(b){
  const nc=b.numberOfChannels,sr=b.sampleRate,len=b.length*nc*2;
  const o=new ArrayBuffer(44+len),v=new DataView(o);
  const ws=(of,s)=>{for(let i=0;i<s.length;i++)v.setUint8(of+i,s.charCodeAt(i));};
  ws(0,'RIFF');v.setUint32(4,36+len,true);ws(8,'WAVE');ws(12,'fmt ');
  v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,nc,true);
  v.setUint32(24,sr,true);v.setUint32(28,sr*nc*2,true);v.setUint16(32,nc*2,true);
  v.setUint16(34,16,true);ws(36,'data');v.setUint32(40,len,true);
  let of=44;const ch=[];
  for(let i=0;i<nc;i++)ch.push(b.getChannelData(i));
  for(let i=0;i<b.length;i++)for(let j=0;j<nc;j++){
    let s=Math.max(-1,Math.min(1,ch[j][i]));s=s<0?s*0x8000:s*0x7FFF;v.setInt16(of,s,true);of+=2;}
  return new Blob([o],{type:'audio/wav'});
};
S.ab2mp3=function(b,k){
  k=k||192;
  const nc=Math.min(2,b.numberOfChannels),sr=b.sampleRate;
  const enc=new lamejs.Mp3Encoder(nc,sr,k),md=[];
  const l=b.getChannelData(0),r=nc>1?b.getChannelData(1):l;
  const blk=1152,li=new Int16Array(blk),ri=new Int16Array(blk);
  for(let i=0;i<b.length;i+=blk){
    const e=Math.min(i+blk,b.length),c=e-i;
    for(let j=0;j<c;j++){
      const x=Math.max(-1,Math.min(1,l[i+j]));li[j]=x<0?x*0x8000:x*0x7FFF;
      const y=Math.max(-1,Math.min(1,r[i+j]));ri[j]=y<0?y*0x8000:y*0x7FFF;
    }
    const buf=nc===1?enc.encodeBuffer(li.subarray(0,c)):enc.encodeBuffer(li.subarray(0,c),ri.subarray(0,c));
    if(buf.length>0)md.push(buf);
  }
  const eb=enc.flush();if(eb.length>0)md.push(eb);
  return new Blob(md,{type:'audio/mp3'});
};
S.concatAB=function(bs){
  const f=bs.filter(Boolean);if(!f.length)return null;if(f.length===1)return f[0];
  const c=S.ctx(),nc=f[0].numberOfChannels,sr=f[0].sampleRate;
  let tl=0;for(const b of f)tl+=b.length;
  const o=c.createBuffer(nc,tl,sr);
  for(let ch=0;ch<nc;ch++){const od=o.getChannelData(ch);let of=0;
    for(const b of f){od.set(b.getChannelData(ch),of);of+=b.length;}}
  return o;
};
S.cleanStemName=function(raw){
  let n=String(raw||'').toLowerCase();
  n=n.replace(/\.wav$|\.mp3$|\.flac$/,'');
  n=n.replace(/^\d+[_\-]+/,'');
  n=n.replace(/bs_roformer_mt_\d+_/,'').replace(/melband_roformer_/,'')
     .replace(/scnet_/,'').replace(/mdx23c_/,'').replace(/htdemucs_/,'')
     .replace(/polarformer_\d+_/,'').replace(/dnr_v3_/,'').replace(/bandit_/,'');
  n=n.replace(/[_\-]+/g,' ').replace(/\s+/g,' ').trim();
  const map={vocals:'Vocals',vocal:'Vocals',voice:'Voice',no_vocals:'No Vocals',
    no_vocal:'No Vocals',instrumental:'Instrumental',instrument:'Instrument',
    other:'Music',others:'Music',drums:'Drums',bass:'Bass',fx:'FX',
    speech:'Speech',male:'Male Voice',female:'Female Voice',piano:'Piano',guitar:'Guitar'};
  for(const k of Object.keys(map))if(n===k)return map[k];
  return n.replace(/\b\w/g,x=>x.toUpperCase())||'Stem';
};

/* ---------- choose + decode source (robust read) ---------- */
$('chooseBtn').onclick=()=>$('fileInput').click();
$('fileInput').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';
  if(!f)return;
  S.closeErr();S.stopAllPlayers();
  S.state.lf=f;S.pn=f.name;
  setStat('Reading '+f.name+' ('+S.fb(f.size)+')…');
  /* FULL explicit read FIRST — a locked file / cloud placeholder dies
     HERE with a precise message instead of a fake "network error"
     later while streaming it to the server. */
  let ab=null;
  try{ab=await f.arrayBuffer();}
  catch(x){
    S.state.lf=null;S.state.sab=null;S.state.lab=null;
    $('startBtn').disabled=true;
    S.err(S.richErr('Cannot read this file — no access',{hint:'The file may be a cloud placeholder (OneDrive/Drive "online-only"), locked, or moved. Download it fully (or "Always keep on this device") and choose it again.'}));
    return;
  }
  if(!ab||!ab.byteLength){
    S.state.lf=null;S.state.sab=null;S.state.lab=null;
    $('startBtn').disabled=true;
    S.err(S.richErr('This file is empty (0 bytes)',{hint:'Re-download or re-export the file — nothing can be decoded from an empty file.'}));
    return;
  }
  S.state.lab=ab;                     // keep the bytes for the upload fallback
  setStat('Decoding '+f.name+'…');
  try{
    /* decode from a COPY so the original bytes stay intact for upload;
       90 s guard — decodeAudioData can hang forever on a dead file */
    S.state.sab=await Promise.race([
      S.ctx().decodeAudioData(ab.slice(0)),
      new Promise((_,rej)=>setTimeout(()=>rej(new Error('decode hung')),90000))
    ]);
    /* #fileName does not exist in this build — the name goes into the
       chead #fileInfo chip (was: $('fileName') → TypeError mislabeled
       as "Cannot decode this file", the file-not-reading ghost bug) */
    const fi=$('fileInfo');if(fi)fi.textContent=f.name;
    $('fileMeta').textContent=S.fd(S.state.sab.duration)+' · '+S.fb(f.size)+' · '+S.state.sab.numberOfChannels+'ch';
    const dm=S.state.sab.duration/60,cc=dm>10?Math.ceil(dm/9):1;
    $('filePlan').textContent=cc>1?cc+' chunks planned':'direct upload';
    $('fileInfo').classList.remove('hidden');
    $('srcPlayer').classList.remove('hidden');
    if(!S._srcP)S._srcP=S.Player($('srcPlayer'),{});
    S._srcP.setBuffer('A',S.state.sab);
    $('startBtn').disabled=false;
    setStat('Ready — press Start');
  }catch(x){
    S.state.sab=null;
    $('startBtn').disabled=true;
    S.err(S.richErr('Cannot decode this file as audio',{hint:'The browser could not decode it. It will be converted on the server automatically at Start — if that fails too, convert to MP3/WAV (44.1 or 48 kHz) and retry.'}));
  }
};
function setStat(t,warn){const e=$('status');if(e){e.textContent=t||'';e.style.color=warn?'var(--warn)':'';}}
S.setStat=setStat;

/* ---------- smart chunking at quiet points (ported) ---------- */
function calcChunks(b,max){
  max=max||540;
  const d=b.duration;if(d<=max)return[{s:0,e:d}];
  const cs=[];let c0=0;
  const sr=b.sampleRate,data=b.getChannelData(0);
  while(c0<d){
    let pe=Math.min(d,c0+max);
    if(pe>=d){cs.push({s:c0,e:d});break;}
    const ss=Math.max(c0+max*0.7,pe-45);
    const si=Math.floor(ss*sr),ei=Math.floor(pe*sr),w=Math.floor(sr*0.1);
    let mr=Infinity,mt=pe;
    for(let i=si;i<ei-w;i+=w){
      let sum=0;for(let j=0;j<w;j+=8){const v=data[i+j];sum+=v*v;}
      const rms=Math.sqrt(sum/(w/8));
      if(rms<mr){mr=rms;mt=i/sr;}
    }
    const bs=mr<0.05?mt:pe;
    cs.push({s:c0,e:bs});c0=bs;
  }
  return cs;
}
function isComp(f){const n=(f.name||'').toLowerCase();
  return ['.mp3','.m4a','.aac','.ogg','.opus','.wma'].some(x=>n.endsWith(x));}

/* ---------- MVSEP HTTP with retry (lean port) ---------- */
async function mpost(fd,onp,sig){
  const u=S.mvsep()+'/separation/create';
  return new Promise((res,rej)=>{
    const x=new XMLHttpRequest();
    x.open('POST',u);
    const k=S.authV();if(k)x.setRequestHeader('Authorization','Bearer '+k);
    if(sig)x.signal=sig;
    x.upload.onprogress=e=>{if(e.lengthComputable&&onp)onp(e.loaded,e.total);};
    x.onload=()=>{
      let j=null;try{j=JSON.parse(x.responseText);}catch(e){}
      S.diag({m:'POST',u:'…/separation/create',s:x.status,b:(x.responseText||'').slice(0,240)});
      res({json:j,httpStatus:x.status});
    };
    x.onerror=()=>rej(S.richErr('Network error — cannot reach the Worker',{url:u}));
    x.send(fd);
  });
}
async function mget(p,sig){
  const u=S.mvsep()+(p.startsWith('/')?p:'/'+p);
  for(let rt=3;rt>0;rt--){
    try{
      const r=await fetch(u,{method:'GET',signal:sig,headers:S.authH()});
      const t=await r.text();
      if(r.status===429){const ra=parseFloat(r.headers.get('Retry-After')||'5');
        await new Promise(rr=>setTimeout(rr,ra*1000));continue;}
      let j=null;try{j=JSON.parse(t);}catch(e){}
      if(!j)throw S.richErr('MVSEP/proxy returned non-JSON (HTTP '+r.status+')',{url:u,httpStatus:r.status,respBody:t.slice(0,300),hint:'Usually a proxy error page or an MVSEP outage — exact response below.'});
      return{json:j,httpStatus:r.status};
    }catch(e){
      if(e&&e.det&&e.det.respBody)throw e;          // structured — no blind retry
      if(sig&&sig.aborted)throw new Error('Canceled');
      if(rt<=1)throw S.richErr('MVSEP unreachable after retries',{url:u,hint:'Check the Worker URL in Options and your connection, then Retry.'});
      await new Promise(rr=>setTimeout(rr,2000));
    }
  }
}
async function fetchStem(u,onp){
  return new Promise((res,rej)=>{
    const x=new XMLHttpRequest();
    x.open('GET',u);x.responseType='arraybuffer';
    const k=S.authV();if(k)x.setRequestHeader('Authorization','Bearer '+k);
    x.onprogress=e=>{if(e.lengthComputable&&onp)onp(e.loaded,e.total);};
    x.onload=()=>{if(x.status<300)res(x.response);
      else rej(S.richErr('Stem download failed (HTTP '+x.status+')',{url:u,hint:'The link may have expired — press Retry to restart the job.'}));};
    x.onerror=()=>rej(S.richErr('Network error downloading a stem',{url:u}));
    x.send();
  });
}
function decodeWav(ab){return S.decode(ab);}

/* ---------- speaker tracks (ported) ---------- */
S.genSpk=function(vb,segs){
  const c=S.ctx(),nc=vb.numberOfChannels,sr=vb.sampleRate,len=vb.length;
  const sm={};
  for(const s of segs){const sp=s.speaker||'A';if(!sm[sp])sm[sp]=[];sm[sp].push(s);}
  const sk=Object.keys(sm).sort(),tr=[];let si=1;
  for(const sp of sk){
    const tb=c.createBuffer(nc,len,sr),gs=sm[sp];
    for(let ch=0;ch<nc;ch++){
      const sd=vb.getChannelData(ch),td=tb.getChannelData(ch);
      for(const s of gs){
        const sti=Math.max(0,Math.floor(s.startSec*sr)),ei=Math.min(len,Math.floor(s.endSec*sr)),fs=Math.floor(sr*0.02);
        for(let i=sti;i<ei;i++){
          let g=1;
          if(i<sti+fs)g=0.5*(1-Math.cos(Math.PI*(i-sti)/fs));
          else if(i>ei-fs)g=0.5*(1+Math.cos(Math.PI*(i-(ei-fs))/fs));
          td[i]=sd[i]*g;
        }
      }
    }
    tr.push({id:'spk_'+sp.replace(/[^a-zA-Z0-9_]/g,'_'),name:'Speaker '+si+' ('+sp+')',
             buffer:tb,blob:S.ab2wav(tb),mp3Blob:S.ab2mp3(tb,192),duration:tb.duration});
    si++;
  }
  return tr;
};

/* ---------- THE PIPELINE ---------- */
/* MVSEP output_format — INTEGER per the official API docs:
   0=mp3 320, 1=wav 16, 2=flac 16, 3=m4a, 4=wav 32, 5=flac 24.
   The old client sent the STRING ('mp3') → MVSEP DB error
   "1366 Incorrect integer value 'mp3' for column output_type".
   FMT_API maps any legacy stored value to its number. */
const FMT_API={mp3:0,mp3_320:0,wav:1,wav16:1,wav_16:1,flac:2,flac16:2,
               flac_16:2,m4a:3,wav32:4,wav_32:4,flac24:5,flac_24:5};
function fmtNum(v){
  const s=String(v==null?'0':v).trim();
  if(FMT_API[s]!=null)return FMT_API[s];
  if(/^\d+$/.test(s))return parseInt(s,10);
  return 0;
}
$('startBtn').onclick=async()=>{
  const sab=S.state.sab,lf=S.state.lf;
  if(!sab){S.err('Choose an audio file first — wait for "Ready".');return;}
  const tk=S.mvTok();
  if(!tk){S.err(S.richErr('No MVSEP API token',{hint:'Options → MVSEP API Token → paste your token from mvsep.com (profile → API token). Remembered after reload.'}));return;}
  if(!S.workerOk()){S.err(S.richErr('Worker not connected',{hint:'Press "Recheck" in Options. Check the Worker URL and your connection.'}));return;}

  S.stopAllPlayers();
  abort=new AbortController();
  /* a NEW separation must never keep rows/ticks from the previous file */
  if(S.resetStudio)S.resetStudio();
  S.state.stems=[];S.state.spkTrk=[];
  const btn=$('startBtn');btn.disabled=true;$('cancelBtn').classList.remove('hidden');
  $('errBox').classList.add('hidden');
  const ofmt=fmtNum($('fmt').value),sc=parseInt($('spk').value);
  const algo=S.getAlgo(),st=algo.t;
  const o1=$('opt1').classList.contains('hidden')?algo.d1:$('opt1').value;
  const o2=$('opt2').classList.contains('hidden')?algo.d2:$('opt2').value;

  const setP=(p,t)=>{$('bar').style.width=p+'%';setStat(t||Math.round(p)+'%');};
  try{
    /* cancel stuck jobs first (proven behavior) */
    setP(3,'Checking for stuck MVSEP jobs…');
    try{
      const {json:ui}=await mget('/app/user?api_token='+encodeURIComponent(tk),abort.signal);
      const q=(ui&&ui.data&&ui.data.current_queue)||[];
      for(const h of q){
        try{
          const fd=new FormData();fd.append('api_token',tk);fd.append('hash',h);
          await fetch(S.mvsep()+'/separation/cancel',{method:'POST',body:fd,headers:S.authH()});
        }catch(e){}
      }
      if(q.length){setStat('Cancelled '+q.length+' stuck job(s)…');await new Promise(r=>setTimeout(r,1500));}
    }catch(e){}

    /* plan chunks */
    const chunks=calcChunks(sab,540),tc2=chunks.length,srp=[];
    setP(4,'Planned '+tc2+' chunk(s) — uploading…');

    for(let i=0;i<tc2;i++){
      if(abort.signal.aborted)throw new Error('Canceled');
      const ch=chunks[i],cn=i+1;
      /* build chunk file */
      let cb,cn2;
      if(isComp(lf)&&tc2===1){cb=lf;cn2=lf.name;}
      else if(tc2===1){cb=lf;cn2=lf.name;}
      else{cb=S.ab2mp3(S.sliceAB(sab,ch.s,ch.e),192);cn2='chunk_'+cn+'.mp3';}

      /* create job (retry loop, structured errors) */
      const ub=5+Math.round(i/tc2*50);
      setP(ub,'Uploading chunk '+cn+'/'+tc2+' ('+S.fb(cb.size)+')…');
      let jh2=null,memBlob=null;
      for(let at=1;at<=6;at++){
        if(abort.signal.aborted)throw new Error('Canceled');
        try{
          const fd=new FormData();
          fd.append('api_token',tk);fd.append('sep_type',String(st));
          fd.append('add_opt1',String(o1));fd.append('add_opt2',String(o2));fd.append('add_opt3','0');
          fd.append('output_format',String(ofmt));fd.append('is_demo','0');
          fd.append('audiofile',cb,cn2);
          const {json:j,httpStatus:hs}=await mpost(fd,(_,__)=>{},abort.signal);
          if(j&&j.success&&j.data&&j.data.hash){jh2=j.data.hash;break;}
          const em=[j&&j.upstream_body,(Array.isArray(j&&j.errors)?j.errors.join('; '):null),j&&j.error,j&&j.data&&j.data.message,j&&j.message].filter(Boolean).join(' | ')||'create failed';
          const lw=String(em).toLowerCase();
          /* token ONLY on real token errors — an SQL text containing
             "firebase_token" is NOT a token problem (the old mislabel) */
          if(hs===401||/\b(invalid|expired|wrong|bad|missing|no)\s+(api\s*)?token\b/.test(lw)||lw.includes('credentials'))
            throw S.richErr('MVSEP token rejected — '+em,{hint:'Options → paste a valid MVSEP token (press Verify to test it).'});
          if(lw.includes('premium'))
            throw S.richErr('Premium-only option — '+em,{hint:'Switch to a free option (default BS Roformer works on free accounts) or buy premium minutes.'});
          /* MVSEP 5xx / HTML error page → fail FAST, no blind retries */
          if(hs>=500||/^\s*<!doctype/i.test(String(em))||/^\s*<html/i.test(String(em)))
            throw S.richErr('MVSEP server error (HTTP '+hs+') — '+em,{httpStatus:hs,hint:'The MVSEP server itself failed. Retry in a minute — nothing is wrong on your side.'});
          if(hs===429||lw.includes('rate')){setStat('Rate-limited — retry '+at+'/6…');await new Promise(r=>setTimeout(r,5000));continue;}
          if(lw.includes('queue')||lw.includes('already')){setStat('Previous job still running — retry '+at+'/6…');await new Promise(r=>setTimeout(r,10000));continue;}
          throw S.richErr('MVSEP error (HTTP '+hs+') — '+em,{httpStatus:hs});
        }catch(e2){
          if(e2&&e2.det&&e2.det.hint)throw e2;   // structured = fatal
          /* streaming the FILE died (fake network error) → upload from
             the in-memory bytes instead of streaming the dead file again */
          if(!memBlob&&cb===lf&&S.state.lab&&S.state.lab.byteLength){
            try{memBlob=new Blob([S.state.lab],{type:(lf&&lf.type)||'audio/mpeg'});
              cb=memBlob;cn2=(lf&&lf.name)||cn2;
              setStat('Retrying upload from memory…');}
            catch(_mb){}
          }
          if(at>=6)throw e2;
          setStat('Retry '+at+'/6: '+(e2.message||'?'));
          await new Promise(r=>setTimeout(r,2500));
        }
      }
      if(!jh2)throw S.richErr('MVSEP did not create a job',{hint:'All attempts failed — open the Diagnostic Log (top right) for every response.'});

      /* poll */
      setStat('AI processing chunk '+cn+'/'+tc2+'…');
      let dl2=null,pc2=0;
      while(true){
        if(abort.signal.aborted)throw new Error('Canceled');
        await new Promise(r=>setTimeout(r,3500));pc2++;
        const {json:pj}=await mget('/separation/get?hash='+encodeURIComponent(jh2),abort.signal);
        const s2=pj.status||(pj.data&&pj.data.status)||'';
        if(s2==='done'){dl2=(pj.data&&pj.data.files)||[];break;}
        if(s2==='failed'||s2==='error')
          throw S.richErr('MVSEP processing failed'+(pj.data&&pj.data.message?' — '+pj.data.message:''),{hint:'The job ran on MVSEP servers and failed there — exact reply below.'});
        if(s2==='not_found'){
          if(pc2<=4)continue;
          throw S.richErr('Job dropped by MVSEP',{hint:'Most often the daily FREE quota is exhausted (resets daily). Try tomorrow, use premium minutes, or use Subtitles-only mode.'});
        }
        let pt=s2;
        if(pj.data&&typeof pj.data.finished_chunks==='number'&&pj.data.all_chunks>0)pt=s2+' '+pj.data.finished_chunks+'/'+pj.data.all_chunks;
        const pp=ub+5+Math.min(15,pc2*2);
        $('bar').style.width=pp+'%';setStat('AI: '+pt+'…');
      }

      /* download + decode stems */
      setStat('Downloading '+dl2.length+' stems (chunk '+cn+')…');
      const csm={};
      for(let si2=0;si2<dl2.length;si2++){
        if(abort.signal.aborted)throw new Error('Canceled');
        const f=dl2[si2],su=f.url,sn=f.download||f.url.split('/').pop()||('Stem_'+cn);
        setStat('Stem '+(si2+1)+'/'+dl2.length+': '+sn+'…');
        const ab2=await fetchStem(S.wu()+'/mvsepfile/'+encodeURIComponent(su));
        const dbuf=await decodeWav(ab2);
        csm[sn]=dbuf;
      }
      srp.push(csm);
    }

    /* merge chunks → stems */
    if(srp.length){
      setP(78,'Merging stems…');
      const asn=Object.keys(srp[0]||{});
      S.state.stems=[];
      for(const sn of asn){
        const bc=srp.map(m=>m[sn]).filter(Boolean);
        const mb=S.concatAB(bc);if(!mb)continue;
        S.state.stems.push({id:'stem_'+sn.replace(/[^a-zA-Z0-9_]/g,'_'),
          name:S.cleanStemName(sn),buffer:mb,blob:S.ab2wav(mb),duration:mb.duration});
      }
    }

    /* vocal → find + Gemini diarization → speaker tracks */
    const vs=S.state.stems.find(s=>/vocal|voice/i.test(s.name))||S.state.stems[0];
    let sseg=[];
    if(sc!==0&&vs){
      setP(88,'Gemini: transcribing the vocal for speaker tracks…');
      try{
        const vmp3=S.ab2mp3(vs.buffer,192);
        const b64=await S.b64blob(vmp3);
        sseg=await S.geminiSend(b64,'audio/mp3',sc>0?sc:2);
        S.state.spkTrk=S.genSpk(vs.buffer,sseg);
      }catch(ae){
        if(abort.signal.aborted)throw ae;
        S.err(ae);S.toast('Speaker tracks skipped — Gemini failed (see error)',true);
      }
    }
    if(sseg.length)S.applySubs(sseg,true);

    /* done — show the studio */
    setP(100,'Separation complete — stems ready in Stem Studio');
    S.onSeparationDone();
  }catch(e){
    if(abort&&abort.signal.aborted)setStat('Canceled');
    else{S.err(e);setStat('Failed — see the error box',true);}
  }finally{
    btn.disabled=false;$('cancelBtn').classList.add('hidden');
    setTimeout(()=>{$('bar').style.width='0%';},1200);
  }
};
$('cancelBtn').onclick=()=>{
  if(abort)abort.abort();
  $('cancelBtn').classList.add('hidden');$('startBtn').disabled=false;
  setStat('Canceled');
};
})();
