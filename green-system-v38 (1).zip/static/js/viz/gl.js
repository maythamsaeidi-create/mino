/* ============================================================
   VIZ GL SYSTEM — real WebGL presets (v27, three.js r169)

   Four art directions behind a proper post-processing chain:
     RenderPass → UnrealBloomPass → FXPass (custom GLSL) → OutputPass

     depth3d  — extruded editorial 3D type, restrained bloom,
                micro-dolly camera
     metal    — PBR chrome/gold type under a PMREM room env,
                reflective floor, slow orbit
     particles— words as GPU point-clouds (glyph raster → points),
                single hue, additive
     holo     — shader hologram: RGB-shift + scanlines + grain
                + vignette, low bloom

   Latin words → TextGeometry; non-latin words → canvas-texture
   plane fallback (no tofu). DPR capped at 1.75. All resources
   disposed on preset switch.
   ============================================================ */
import * as THREE from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {ShaderPass} from 'three/addons/postprocessing/ShaderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import {FontLoader} from 'three/addons/loaders/FontLoader.js';
import {TextGeometry} from 'three/addons/geometries/TextGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import VIZ from './core.js';

const S=window.S;
const FONT_URL='/static/vendor/three/fonts/helvetiker_bold.typeface.json';
const RASTER_SANS='700 96px "Inter",Arial,sans-serif';
const RASTER_MONO='700 96px "JetBrains Mono",Menlo,monospace';
const fontP=new Promise((res,rej)=>{
  try{new FontLoader().load(FONT_URL,res,undefined,rej);}catch(e){rej(e);}
});
const latinRe=/^[\x20-\x7E\u00C0-\u024F]*$/;
const isLatin=t=>latinRe.test(String(t||'').trim())&&String(t||'').trim().length>0;

/* ---------- custom FX pass (grain · vignette · rgb-shift · scan) ---------- */
const FXShader={
  uniforms:{tDiffuse:{value:null},uTime:{value:0},uRGB:{value:0.0025},
            uScan:{value:0},uScanN:{value:320},uGrain:{value:0.05},uVig:{value:0.32}},
  vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
  fragmentShader:`
    uniform sampler2D tDiffuse;uniform float uTime,uRGB,uScan,uScanN,uGrain,uVig;varying vec2 vUv;
    float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
    void main(){
      vec2 uv=vUv;float d=distance(uv,vec2(.5,.5));
      vec2 off=(uv-.5)*(uRGB*2.4)*(.3+d*1.4);
      vec3 c;
      c.g=texture2D(tDiffuse,uv).g;
      c.r=texture2D(tDiffuse,uv+off).r;
      c.b=texture2D(tDiffuse,uv-off).b;
      if(uScan>.001){c*=1.0-uScan*.5*(.5+.5*sin(uv.y*uScanN*6.28318));}
      c+=(hash(uv*vec2(1287.0,718.0)+fract(uTime)*13.7)-.5)*uGrain;
      c*=1.0-uVig*smoothstep(.42,.98,d);
      gl_FragColor=vec4(c,1.0);
    }`
};

/* ---------- glyph raster → canvas (plane fallback + particles) ---------- */
function rasterWord(text,font){
  const c=document.createElement('canvas');
  const x=c.getContext('2d');
  x.font=font;
  const w=Math.max(8,Math.ceil(x.measureText(text).width)+14);
  const h=Math.ceil(96*1.35);
  c.width=w;c.height=h;
  x.font=font;x.fillStyle='#fff';x.textBaseline='middle';
  x.fillText(text,7,h/2);
  return c;
}
function texturePlane(text,pal,font){
  const cv=rasterWord(text,font||RASTER_SANS);
  const tex=new THREE.CanvasTexture(cv);
  tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;
  const asp=cv.width/cv.height;
  const mat=new THREE.MeshBasicMaterial({map:tex,transparent:true,
    color:new THREE.Color(pal.acc||'#ffffff'),toneMapped:false});
  const geo=new THREE.PlaneGeometry(asp*0.66,0.66);
  const m=new THREE.Mesh(geo,mat);
  m.userData.w=asp*0.66;          /* world width — layout NEEDS this */
  m.userData.h=0.66;
  return m;
}

/* ============================================================ */
VIZ.glPreset=function(cfg){
  const MODE=cfg.mode;
  const RFONT=(MODE==='holo'||MODE==='particles')?RASTER_MONO:RASTER_SANS;
  let host=null,model=null,params=null,pal=null;
  let renderer=null,scene=null,camera=null,composer=null,bloom=null,fx=null,renderScene=null;
  let group=null,wordObjs=[],geoCache={},actMesh=null;
  let W=0,H=0,t0=performance.now(),builtFor='',fontOk=false;
  let camA=0,gtX=0,gtY=0;

  function ensure(){
    if(renderer)return true;
    try{
      renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
    }catch(e){fail('WebGL unavailable');return false;}
    const DPR=Math.min(1.75,window.devicePixelRatio||1);
    renderer.setPixelRatio(DPR);
    renderer.domElement.className='vz-canvas';
    host.appendChild(renderer.domElement);
    scene=new THREE.Scene();
    camera=new THREE.PerspectiveCamera(42,16/9,0.1,100);
    camera.position.set(0,0,8);

    /* lights — per mode */
    if(MODE==='depth3d'){
      const key=new THREE.DirectionalLight(0xffffff,2.6);key.position.set(3,5,6);scene.add(key);
      const fill=new THREE.DirectionalLight(0x8fa3c8,0.7);fill.position.set(-4,-1,4);scene.add(fill);
      const rim=new THREE.PointLight(new THREE.Color('#f2c94c'),14,20);rim.position.set(-2,2,-4);scene.add(rim);
      camera.position.set(0,0.4,8.2);
    }else if(MODE==='metal'){
      const pm=new THREE.PMREMGenerator(renderer);
      const env=pm.fromScene(new RoomEnvironment(),0.04);
      scene.environment=env.texture;
      /* ⚠ three.js scene.add() returns the SCENE, not the light —
         chaining .position.set() here was moving the whole scene */
      const key=new THREE.DirectionalLight(0xffffff,0.9);
      key.position.set(4,6,5);scene.add(key);
      camera.position.set(0,1.15,8.6);
    }else if(MODE==='particles'){
      camera.position.set(0,0,9);
    }else if(MODE==='holo'){
      camera.position.set(0,0,7.5);
    }
    scene.add(new THREE.AmbientLight(0xffffff,MODE==='metal'?0.15:0.35));

    group=new THREE.Group();scene.add(group);

    /* post chain */
    renderScene=new RenderPass(scene,camera);
    composer=new EffectComposer(renderer);
    composer.addPass(renderScene);
    const useBloom=(MODE!=='particles');
    if(useBloom){
      bloom=new UnrealBloomPass(new THREE.Vector2(W||640,(H||360)/2),0.3,0.55,
        MODE==='holo'?0.55:(MODE==='depth3d'?0.88:0.82));
      composer.addPass(bloom);
    }
    fx=new ShaderPass(FXShader);
    fx.uniforms.uRGB.value=(MODE==='holo')?0.0009:0;   /* aberration is holo's one effect only */
    fx.uniforms.uScan.value=(MODE==='holo')?0.22:0;
    fx.uniforms.uGrain.value=(MODE==='holo')?0.02:0.012;
    fx.uniforms.uVig.value=(MODE==='holo')?0.3:0.2;
    composer.addPass(fx);
    composer.addPass(new OutputPass());
    fontP.then(()=>{fontOk=true;builtFor='';}).catch(()=>{});
    resize();
    return true;
  }
  function fail(msg){
    if(host){
      const d=document.createElement('div');
      d.className='viz-load';
      d.textContent='⚠ '+msg+' — this preset needs WebGL; the other presets work everywhere.';
      host.appendChild(d);
    }
  }

  function resize(){
    if(!renderer||!host)return;
    const r=host.getBoundingClientRect();
    if(r.width<4)return;
    W=Math.round(r.width);H=Math.round(r.height);
    renderer.setSize(W,H,false);
    composer.setSize(W,H);
    camera.aspect=W/H;camera.updateProjectionMatrix();
    builtFor='';
  }
  function palApply(){
    pal=cfg.palettes[params.palette]||cfg.palettes[0];
    if(!scene)return;
    scene.background=new THREE.Color(pal.bg);
    builtFor='';
  }

  /* ---------- word objects ---------- */
  function makeWordObj(text){
    if(MODE==='particles')return makePoints(text);
    if(MODE==='holo')return texturePlane(text,pal,RFONT);
    if(!isLatin(text)||!fontOk)return texturePlane(text,pal,RFONT);
    let geo=geoCache[text];
    if(!geo){
      try{
        geo=new TextGeometry(String(text).toUpperCase(),{
          font:fontP.FONT, /* replaced below once resolved */
          size:0.9,depth:0.18,curveSegments:6,
          bevelEnabled:true,bevelThickness:0.012,bevelSize:0.009,bevelSegments:2});
      }catch(e){return texturePlane(text,pal);}
      geo.computeBoundingBox();
      geoCache[text]=geo;
    }
    const mat=(MODE==='metal')
      ?new THREE.MeshPhysicalMaterial({color:new THREE.Color(pal.mat),metalness:.95,
        roughness:.38,envMapIntensity:.75,
        emissive:new THREE.Color(pal.acc),emissiveIntensity:0.04})
      :new THREE.MeshStandardMaterial({color:new THREE.Color(pal.mat),metalness:0.08,
        roughness:0.42,emissive:new THREE.Color(pal.acc),emissiveIntensity:0.05});
    const m=new THREE.Mesh(geo,mat);
    geo.boundingBox||geo.computeBoundingBox();
    const bb=geo.boundingBox;
    m.userData.w=bb.max.x-bb.min.x;
    m.userData.h=bb.max.y-bb.min.y;
    return m;
  }
  /* TextGeometry needs the resolved Font object — patch after load */
  fontP.then(f=>{fontP.FONT=f;});

  function makePoints(text){
    const cv=rasterWord(text,RFONT);
    const x=cv.getContext('2d');
    const img=x.getImageData(0,0,cv.width,cv.height).data;
    const SC=137;                        /* px → world-unit divisor (matches userData.w) */
    /* LED-matrix sampling: snap to an even grid, average alpha per cell,
       dot ON/OFF — a REGULAR grid reads as intentional display tech,
       irregular scatter reads as noise/corruption */
    const step=3,pts=[];
    for(let py=0;py+step<=cv.height;py+=step){
      for(let px=0;px+step<=cv.width;px+=step){
        let a=0;
        for(let yy=0;yy<step;yy++)for(let xx=0;xx<step;xx++)
          a+=img[((py+yy)*cv.width+(px+xx))*4+3];
        if(a/(step*step)>90)
          pts.push((px+step/2-cv.width/2)/SC,
                   (cv.height/2-(py+step/2))/SC,
                   0);
      }
    }
    if(!pts.length)pts.push(0,0,0);
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));
    g.setAttribute('aB',new THREE.Float32BufferAttribute(new Float32Array(pts.length/3).fill(0.35),1));
    const mat=new THREE.ShaderMaterial({
      uniforms:{uAct:{value:0},uCtx:{value:1},uColor:{value:new THREE.Color(pal.color)},
                uPx:{value:H||360},uBeat:{value:0}},
      transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
      vertexShader:`
        attribute float aB;varying float vB;uniform float uPx,uBeat,uAct,uCtx;
        void main(){
          vB=min(1.0,aB+uAct*1.45)*uCtx;
          vec4 mv=modelViewMatrix*vec4(position,1.0);
          float s=2.75*(uPx/720.0)*(1.0+uBeat*.25+vB*.5);
          gl_PointSize=s;
          gl_Position=projectionMatrix*mv;
        }`,
      fragmentShader:`
        uniform vec3 uColor;varying float vB;
        void main(){
          float d=length(gl_PointCoord-vec2(.5));
          float a=smoothstep(.5,.16,d);
          float hot=min(1.0,vB*1.15);
          vec3 col=uColor*(0.35+1.75*hot);
          gl_FragColor=vec4(col,a*(0.42+0.58*hot));
        }`
    });
    const p=new THREE.Points(g,mat);
    p.userData.w=cv.width/SC;
    p.userData.isPoints=true;
    return p;
  }

  /* ---------- layout: one ROW GROUP per screen ----------
     Each row scales INDEPENDENTLY to the view width (the old
     single-block fit shrank every row to the widest screen's
     scale → 20px text). Active row full size; context rows
     60% + dimmed — like a broadcast stack. */
  function build(){
    if(!model||!pal)return;
    while(group.children.length)group.remove(group.children[0]);
    rows=[];wordObjs=[];actMesh=null;curRow=-1;
    const GAP=0.36;
    const camD=(MODE==='holo')?7.5:(MODE==='metal'?8.2:(MODE==='particles'?9:9.0));
    const viewW=2*Math.tan(THREE.MathUtils.degToRad(21))*camD*0.94;
    model.screens.forEach((sc,si)=>{
      const row=new THREE.Group();
      let x=0;
      sc.words.forEach(w=>{
        const o=makeWordObj(w.text||'');
        if(!o)return;
        o.userData.t0=w.startSec;o.userData.t1=w.endSec;o.userData._i=w._i;
        const ww=(o.userData.w||0.6);
        o.userData.si=si;
        if(o.material&&o.material.color&&!o.userData.baseCol)
          o.userData.baseCol=o.material.color.clone();
        if(o.userData.isPoints){
          o.position.x=x+ww/2;            /* points span ±ww/2 around center */
        }else if(o.geometry&&o.geometry.boundingBox&&o.geometry.boundingBox.min&&!o.material.map){
          o.position.x=x-o.geometry.boundingBox.min.x;   /* TextGeometry: glyph LEFT edge at x */
        }else{
          o.position.x=x+ww/2;            /* texture planes: center-anchored */
        }
        row.add(o);wordObjs.push(o);
        x+=ww+GAP;
      });
      const rowW=x-GAP;
      const k=Math.min(1.18,viewW/Math.max(rowW,1.2));
      row.userData={rowW,k,si};
      row.scale.setScalar(k);
      row.position.x=-rowW*k/2;         /* center the row on the origin */
      group.add(row);rows.push(row);
    });
    builtFor='m'+(model.nWords)+'p'+params.palette;
  }
  let rows=[],curRow=-1;

  function frame(st){
    if(!host)return;
    if(!renderer&&!ensure())return;
    if(!laid(st))return;
    if(builtFor!=='m'+model.nWords+'p'+params.palette)build();
    const t=(performance.now()-t0)/1000;

    /* active word mesh — unmistakable karaoke state in EVERY mode */
    const accCol=new THREE.Color(pal.acc||pal.color||'#ffffff');
    const si=st.screenIdx<0?holdIdx(st):st.screenIdx;
    let act=null;
    const siRow=si<0?0:si;
    wordObjs.forEach(o=>{
      const i=o.userData._i;
      const isA=i===st.wordIdx;
      const inRow=o.userData.si===siRow;
      if(o.userData.isPoints){
        o.material.uniforms.uAct.value=isA?st.wordP:0;
        o.material.uniforms.uPx.value=H||360;
        o.material.uniforms.uBeat.value=(params.react&&st.playing)?st.audio.beat:0;
      }else if(o.material.map){
        /* texture planes (holo + fallbacks): active word brightens + pops */
        const bc=o.userData.baseCol;
        o.material.color.copy(bc);
        if(isA)o.material.color.lerp(accCol,0.35).multiplyScalar(1.12);
        const sc=VIZ.lerp(o.scale.x||1,isA?1.1:1,0.25);
        o.scale.setScalar(sc);
        if(isA)act=o;
      }else{
        /* 3D type: active word shifts toward the accent + emissive fill */
        const bc=o.userData.baseCol||o.material.color;
        o.material.color.copy(bc);
        if(isA){
          o.material.color.lerp(accCol,MODE==='metal'?0.35:0.6);
          o.material.emissiveIntensity=0.12+0.9*st.wordP;
          const sc=VIZ.lerp(o.scale.x||1,1.07,0.3);
          o.scale.setScalar(sc);
          act=o;
        }else{
          o.material.emissiveIntensity=(i<st.wordIdx&&inRow)?0.05:0;
          const sc=VIZ.lerp(o.scale.x||1,1,0.2);
          o.scale.setScalar(sc);
        }
      }
    });
    actMesh=act;

    /* row stack: active row full size at center; prev/next 72% + dim */
    const ROWGAP=2.15;
    rows.forEach((row,i)=>{
      const rel=i-(si<0?0:si);
      const isCtx=Math.abs(rel)===1;
      row.visible=Math.abs(rel)<=1;
      if(!row.visible)return;
      const k=row.userData.k*(isCtx?0.72:1);
      row.scale.setScalar(k);
      row.position.y=-rel*ROWGAP*0.62;
      row.children.forEach(o=>{
        if(o.userData.isPoints){
          o.material.uniforms.uCtx.value=isCtx?0.3:1;
        }else if(o.material.transparent){
          o.material.opacity=isCtx?0.34:1;
        }else if(o.userData.baseCol){
          o.material.color.copy(o.userData.baseCol);
          if(isCtx)o.material.color.multiplyScalar(0.45);
        }
      });
    });

    /* rows are centered; the active word carries the emphasis
       (color + scale + emissive) — NO horizontal group drift, which
       pushed long rows off-view */
    const targetX=0;
    const targetY=0;
    const spd=1-Math.pow(0.0018,VIZ.lerp(0.012,0.05,VIZ.REDUCED?0.1:params.motion));
    gtX=VIZ.lerp(gtX,targetX,spd);gtY=VIZ.lerp(gtY,targetY,spd);
    group.position.x=gtX;group.position.y=gtY;

    /* camera language per mode */
    if(MODE==='depth3d'){
      const breathe=VIZ.REDUCED?0:Math.sin(t*0.6)*0.1;
      const dz=act?0.18:0;
      camera.position.z=VIZ.lerp(camera.position.z,8.2-dz+ (params.react&&st.playing?st.audio.beat*0.1:0)+breathe,0.06);
      camera.position.y=VIZ.lerp(camera.position.y,0.42+Math.sin(t*0.4)*0.05,0.05);
      camera.lookAt(0,0.35,0);
      bloom.strength=(MODE==='depth3d')?(0.13+0.24*params.fx+((params.react&&st.playing)?st.audio.beat*0.1*params.fx:0))
        :(0.18+0.32*params.fx);
    }else if(MODE==='metal'){
      /* straight-on title card — slow drift, no orbit (orbiting chrome
         reads as dated 3D; a static card reads as title design) */
      camera.position.x=Math.sin(t*0.07)*0.4;
      camera.position.z=8.2;
      camera.position.y=1.05+Math.sin(t*0.3)*0.06;
      camera.lookAt(0,gtY*0.15,0);
      bloom.strength=0.1+0.22*params.fx;
    }else if(MODE==='particles'){
      camera.position.z=VIZ.lerp(camera.position.z,9,0.04);
      camera.lookAt(0,0,0);
    }else if(MODE==='holo'){
      camera.position.z=7.5;
      camera.lookAt(0,0,0);
      fx.uniforms.uRGB.value=0.0005+0.002*params.fx+((params.react&&st.playing)?st.audio.beat*0.0008:0);
      bloom.strength=0.14+0.2*params.fx;
    }
    fx.uniforms.uTime.value=t;
    fx.uniforms.uGrain.value=(MODE==='holo'?0.014:0.01)*(0.4+0.6*params.fx);
    fx.uniforms.uVig.value=0.16+0.22*params.fx;

    composer.render();
  }
  function laid(st){return model&&pal;}
  function holdIdx(st){let b=-1;for(let i=0;i<model.screens.length;i++){if(model.screens[i].t0<=st.t)b=i;else break;}return b;}
  frame._wi=-99;

  const R={};
  R.mount=function(h){host=h;ensure();};
  R.setModel=function(m){model=m;builtFor='';gtX=0;gtY=0;};
  R.applyParams=function(p){params=p;palApply();};
  R.resize=function(){resize();};
  R.frame=frame;
  R.snapshot=function(){
    if(!renderer||!composer)return null;
    composer.render();
    return renderer.domElement.toDataURL('image/png');
  };
  R.dispose=function(){
    try{
      if(composer)composer.dispose();
      if(group)group.traverse(o=>{
        if(o.geometry)o.geometry.dispose();
        if(o.material){if(o.material.map)o.material.map.dispose();o.material.dispose();}
      });
      Object.values(geoCache).forEach(g=>g.dispose&&g.dispose());
      if(renderer){renderer.dispose();renderer.domElement.remove();}
    }catch(e){}
    geoCache={};group=null;renderer=null;composer=null;scene=null;camera=null;bloom=null;fx=null;wordObjs=[];
  };
  return R;
};
window.VIZ=VIZ;

/* ============================================================
   13 · EXPERIMENTAL 3D — extruded editorial type
   ============================================================ */
VIZ.register({
  id:'depth3d',name:'Experimental 3D',family:'3D',engine:'gl',
  concept:'Extruded editorial type — real TextGeometry depth, key + rim light, restrained bloom, camera micro-dolly that breathes with the word.',
  palettes:[
    {name:'Ivory',bg:'#0b0c10',mat:'#e9e4d8',acc:'#f2c94c'},
    {name:'Ice',   bg:'#070a10',mat:'#cfe0ea',acc:'#7cc4ff'},
    {name:'Clay',  bg:'#100b09',mat:'#cf8a6a',acc:'#ff9d6b'}
  ],
  def:{motion:.45,fx:.4},mode:'depth3d',make:function(){return VIZ.glPreset(this);}
});

/* ============================================================
   14 · METAL — PBR studio type
   ============================================================ */
VIZ.register({
  id:'metal',name:'Metal',family:'3D',engine:'gl',
  concept:'Brushed-steel title card — PBR metal under a soft studio environment, straight-on camera with a slow drift, gold fills the active word. Specular restraint, no orbit, no floor.',
  palettes:[
    {name:'Chrome',bg:'#0a0b0d',mat:'#d7dade',acc:'#b9c6d8'},
    {name:'Gold',  bg:'#0c0a06',mat:'#d4af5e',acc:'#f0d08a'},
    {name:'Obsidian',bg:'#08080a',mat:'#2e3036',acc:'#8a93a2'}
  ],
  def:{motion:.3,fx:.25},mode:'metal',make:function(){return VIZ.glPreset(this);}
});

/* ============================================================
   15 · PARTICLE WORDS — glyph point-clouds
   ============================================================ */
VIZ.register({
  id:'particles',name:'Particle Words',family:'Particle',engine:'gl',
  concept:'LED-matrix words — glyphs raster-sampled onto a regular dot grid like a stadium ticker; the active word’s dots brighten and swell on the beat. One hue, additive.',
  palettes:[
    {name:'Teal',  bg:'#0a0d12',color:'#59d6d0'},
    {name:'Amber', bg:'#100c06',color:'#f0b45c'},
    {name:'Violet',bg:'#0d0a14',color:'#a78bfa'}
  ],
  def:{motion:.5,fx:.45},mode:'particles',make:function(){return VIZ.glPreset(this);}
});

/* ============================================================
   16 · HOLO — shader hologram
   ============================================================ */
VIZ.register({
  id:'holo',name:'Holo',family:'Futuristic',engine:'gl',
  concept:'Shader hologram — crisp text plane through a GLSL post chain: edge RGB-shift, 1px scanlines, film grain, vignette, low bloom. Cyan on near-black. Futuristic broadcast, not rave.',
  palettes:[
    {name:'Cyan',   bg:'#070a0f',color:'#7be3ff',acc:'#7be3ff'},
    {name:'Green',  bg:'#060b08',color:'#6ef2a8',acc:'#6ef2a8'},
    {name:'Magenta',bg:'#0c0710',color:'#ff7bd5',acc:'#ff7bd5'}
  ],
  def:{motion:.4,fx:.55},mode:'holo',make:function(){return VIZ.glPreset(this);}
});
