/* boot.js — Subtitle Layer entry (v30)
   classic → module bridge: everything attaches to window.VIZ;
   fx.js/fxpanel.js/fxexport.js = FX STUDIO (modern caption engine,
   panel + standalone HTML export); gl.js loads in the background. */
import './core.js';
import './dom.js';
import './canvas.js';
import './fx.js';
import './fxpanel.js';
import './fxexport.js';
import './ui.js';
import('./gl.js').catch(e=>console.warn('[viz] GL presets unavailable:',e&&e.message||e));
