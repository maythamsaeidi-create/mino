/* ============================================================
   FX.js — FX STUDIO: modern caption engine (v30)

   2025-26 caption research distilled:
   · word-by-word kinetic captions (TikTok / CapCut / Shorts era)
   · entrance FX with a DIRECTION (8-way + in-place)
   · real CSS 3D — perspective, rotateX/Y flips, layered extrusion
   · one-line broadcast mode pinned at the stage bottom
   · every theme readable first: contrast gate, weight caps

   FXCSS below is the single source of truth for stage styles —
   the same string powers the standalone HTML export.
   ============================================================ */
import VIZ from './core.js';
const S=window.S;

const FONT={
  sans:"'Inter','SF Pro Text',system-ui,-apple-system,'Segoe UI',Arial,sans-serif",
  mono:"'JetBrains Mono',ui-monospace,'Cascadia Code',Menlo,Consolas,monospace",
  display:"'Archivo Black','Inter',system-ui,sans-serif",
  grotesk:"'Space Grotesk','Inter','Helvetica Neue',Arial,sans-serif",
  fa:"'Vazirmatn','Inter',system-ui,sans-serif"
};

/* ---------- stage + theme + animation CSS (shared with export) ---------- */
export const FXCSS=`
/* ===== FX STUDIO — stage base ===== */
.vzfx{position:absolute;inset:0;background:var(--vBg);font-family:var(--vF),sans-serif;
  display:flex;align-items:center;justify-content:center;overflow:hidden;
  --fs:36px;--ease:cubic-bezier(.22,1,.36,1);
  font-size:calc(var(--fs)*var(--vScale,1)*var(--ffit,1));color:var(--vInk);
  perspective:calc(1000px - 720px*var(--fxd,.35))}
.vzfx[data-fa="1"]{font-family:var(--vFa),var(--vF)}
.fx-view{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;
  justify-content:center;padding:0 6%;transform-style:preserve-3d;
  transform:rotateX(calc(var(--fxd,0)*-9deg)) scale(calc(1 + var(--beat,0)))}
.vzfx[data-pos="bottom"] .fx-view{justify-content:flex-end;padding:0 5% 7.5%}
.fx-rest-in{display:flex;flex-direction:column;gap:.5em;align-items:center;text-align:center}
.fx-rest-in b{font-size:1.15em;letter-spacing:.02em;color:var(--vInk)}
.fx-rest-in span{font-family:var(--mono);font-size:.34em;letter-spacing:.14em;
  text-transform:uppercase;color:var(--vDim)}
.fx-scr{display:flex;flex-direction:column;gap:.4em;align-items:center;max-width:100%;
  transform-style:preserve-3d}
.fx-line{display:flex;flex-wrap:wrap;gap:.14em .26em;line-height:1.3;justify-content:center;max-width:100%}
.vzfx.oneline .fx-line{flex-wrap:nowrap;white-space:nowrap;overflow:visible}
.fx-w{position:relative;display:inline-block;opacity:0;transition:color .18s,transform .18s}
.fx-w.in{opacity:1}
.vzfx[data-wm="line"] .fx-w{opacity:1}
.vzfx.at-rest .fx-w{opacity:.9}
.vzfx.at-rest .fx-w .fx-wt{color:var(--vDone)}
.fx-wt{position:relative;display:inline-block}

/* ===== highlight engines (karaoke) ===== */
.vzfx[data-hl="grad"] .fx-w.st-past .fx-wt{background:none;color:var(--vDone)}
.vzfx[data-hl="grad"] .fx-w.st-fut .fx-wt{background:none;color:var(--vDim)}
.vzfx[data-hl="grad"] .fx-w.st-act .fx-wt{
  background-image:linear-gradient(90deg,var(--vAcc) 0%,var(--vB,var(--vAcc)) calc(var(--p,0)*100%)),
                    linear-gradient(90deg,var(--vDim),var(--vDim));
  background-size:100% 100%,100% 100%;background-repeat:no-repeat;
  -webkit-background-clip:text;background-clip:text;color:transparent}
.vzfx[dir="rtl"][data-hl="grad"] .fx-w.st-act .fx-wt{
  background-image:linear-gradient(270deg,var(--vAcc) 0%,var(--vB,var(--vAcc)) calc(var(--p,0)*100%)),
                    linear-gradient(270deg,var(--vDim),var(--vDim))}
.vzfx[data-hl="grad"] .fx-w.st-act{transform:scale(1.04)}
.vzfx[data-hl="box"] .fx-w.st-past .fx-wt{color:var(--vDone)}
.vzfx[data-hl="box"] .fx-w.st-act{background:var(--vAcc);color:var(--vInkB,#101010);
  border-radius:.18em;padding:.02em .14em .04em;transform:scale(1.08) rotate(-1.2deg);
  box-shadow:.06em .08em 0 rgba(0,0,0,.45)}
.vzfx[data-hl="glow"] .fx-w.st-past .fx-wt{color:var(--vDone)}
.vzfx[data-hl="glow"] .fx-w.st-fut .fx-wt{color:var(--vDim)}
.vzfx[data-hl="glow"] .fx-w.st-act .fx-wt{color:var(--vAcc);
  text-shadow:0 0 calc(.14em + .3em*var(--vFx,.5)) color-mix(in oklab,var(--vAcc) 75%,transparent),
    0 0 calc(.5em + .9em*var(--vFx,.5)) color-mix(in oklab,var(--vB,var(--vAcc)) 45%,transparent)}
.vzfx[data-hl="under"] .fx-w.st-past .fx-wt{color:var(--vDone)}
.vzfx[data-hl="under"] .fx-w.st-fut .fx-wt{color:var(--vDim)}
.vzfx[data-hl="under"] .fx-w.st-act .fx-wt{color:var(--vInk);font-weight:700}
.vzfx[data-hl="under"] .fx-w.st-act::after{content:'';position:absolute;left:0;bottom:-.09em;
  height:.06em;width:calc(var(--p,0)*100%);background:var(--vAcc);border-radius:.03em}

/* ===== entrance FX (direction-aware · 3D) ===== */
.vzfx[data-e="pop"]{--ease:cubic-bezier(.34,1.56,.64,1)}
@keyframes fxSlide{from{opacity:0;transform:translate(calc(var(--dx,0)*72px),calc(var(--dy,1)*72px))}}
@keyframes fxZoom{from{opacity:0;transform:scale(.35)}}
@keyframes fxPop{from{opacity:0;transform:scale(.3) rotate(-4deg)}}
@keyframes fxFlip{from{opacity:0;transform:rotateX(-96deg) translateY(-8%)}}
@keyframes fxSpin{from{opacity:0;transform:rotateY(-115deg) scale(.82)}}
@keyframes fxBlur{from{opacity:0;filter:blur(16px);letter-spacing:.14em}}
@keyframes fxType{from{opacity:0;clip-path:inset(-40% 100% -40% 0)}to{opacity:1;clip-path:inset(-40% 0 -40% 0)}}
@keyframes fxTypeR{from{opacity:0;clip-path:inset(-40% 0 -40% 100%)}to{opacity:1;clip-path:inset(-40% 0 -40% 0)}}
@keyframes fxWave{from{opacity:0;transform:translateY(calc(var(--dy,1)*30px)) rotate(4deg)}}
/* word mode: each word plays the entrance the moment it is spoken */
.vzfx[data-wm="word"][data-e="slide"] .fx-w.in{animation:fxSlide var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="zoom"]  .fx-w.in{animation:fxZoom  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="pop"]   .fx-w.in{animation:fxPop   var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="flip"]  .fx-w.in{animation:fxFlip  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="spin"]  .fx-w.in{animation:fxSpin  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="blur"]  .fx-w.in{animation:fxBlur  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="word"][data-e="type"]  .fx-w.in{animation:fxType  var(--fdur) steps(8) backwards}
.vzfx[dir="rtl"][data-wm="word"][data-e="type"] .fx-w.in{animation-name:fxTypeR}
.vzfx[data-wm="word"][data-e="wave"]  .fx-w.in{animation:fxWave  var(--fdur) var(--ease) backwards}
/* line mode: the whole caption block enters at once */
.vzfx[data-wm="line"][data-e="slide"] .fx-scr.is-cur{animation:fxSlide var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="zoom"]  .fx-scr.is-cur{animation:fxZoom  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="pop"]   .fx-scr.is-cur{animation:fxPop   var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="flip"]  .fx-scr.is-cur{animation:fxFlip  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="spin"]  .fx-scr.is-cur{animation:fxSpin  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="blur"]  .fx-scr.is-cur{animation:fxBlur  var(--fdur) var(--ease) backwards}
.vzfx[data-wm="line"][data-e="type"]  .fx-scr.is-cur{animation:fxType  var(--fdur) steps(10) backwards}
.vzfx[dir="rtl"][data-wm="line"][data-e="type"] .fx-scr.is-cur{animation-name:fxTypeR}
.vzfx[data-wm="line"][data-e="wave"]  .fx-w{animation:fxWave var(--fdur) var(--ease) backwards;
  animation-delay:calc(var(--wid,0)*70ms)}
.vzfx[data-wm="line"][data-e="cut"]   .fx-scr.is-cur{animation:none}

/* ===== shared utility keyframes ===== */
@keyframes fxBlink{0%,49%{opacity:1}50%,100%{opacity:0}}
@keyframes fxHoloShift{to{background-position:280% 0}}
@keyframes fxEmber{0%,100%{filter:drop-shadow(0 0 10px rgba(251,146,60,.55))}
  50%{filter:drop-shadow(0 0 18px rgba(251,146,60,.85))}}
@keyframes fxJitter{0%,88%,100%{transform:none}90%{transform:translate(1.5px,-1px)}94%{transform:translate(-1.5px,1px)}}

/* ============================================================
   THEMES — ten modern caption directions
   ============================================================ */

/* 1 · VIRAL BOLD — TikTok/CapCut-era kinetic caption */
.vzfx-viral{--fs:44px}
.vzfx-viral .fx-wt{font-weight:900;letter-spacing:-.02em;text-transform:uppercase;
  text-shadow:2px 2px 0 #000,-2px 2px 0 #000,2px -2px 0 #000,-2px -2px 0 #000,
    0 3px 0 #000,0 -3px 0 #000,3px 0 0 #000,-3px 0 0 #000,0 7px 16px rgba(0,0,0,.55)}
.vzfx-viral .fx-w.st-past .fx-wt{color:#fff}
.vzfx-viral[data-hl="box"] .fx-w.st-act{background:var(--vAcc);color:#0d0d0d}
.vzfx-viral[data-hl="box"] .fx-w.st-act .fx-wt{text-shadow:none}

/* 2 · NEON CYBER — signage glow */
.vzfx-neon{--fs:40px}
.vzfx-neon .fx-wt{font-weight:700;letter-spacing:.04em;color:#e8f6ff;
  text-shadow:0 0 6px rgba(34,211,238,.5),0 0 22px rgba(34,211,238,.3)}
.vzfx-neon .fx-w.st-past .fx-wt{color:#e8f6ff}
.vzfx-neon[data-hl="glow"] .fx-w.st-act .fx-wt{color:var(--vAcc);
  text-shadow:0 0 10px var(--vAcc),0 0 36px color-mix(in oklab,var(--vAcc) 60%,transparent),
    0 0 80px color-mix(in oklab,var(--vB) 45%,transparent)}

/* 3 · CHROME 3D — extruded metal */
.vzfx-chrome3d{--fs:46px;--ease:cubic-bezier(.34,1.56,.64,1)}
.vzfx-chrome3d .fx-wt{font-weight:900;text-transform:uppercase;letter-spacing:.015em;
  background:linear-gradient(180deg,#f8fafc 0%,#cbd5e1 28%,#64748b 48%,#e2e8f0 56%,#94a3b8 80%,#f1f5f9 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  filter:drop-shadow(calc(var(--fxd,.35)*2px) calc(var(--fxd,.35)*3px) 0 #334155)
         drop-shadow(calc(var(--fxd,.35)*5px) calc(var(--fxd,.35)*7px) 0 #1e293b)
         drop-shadow(calc(var(--fxd,.35)*8px) calc(var(--fxd,.35)*11px) 10px rgba(8,12,20,.6))}
.vzfx-chrome3d .fx-w.st-past .fx-wt{opacity:.62}
.vzfx-chrome3d .fx-w.st-act{transform:scale(1.07)}
.vzfx-chrome3d .fx-w.st-act .fx-wt{filter:drop-shadow(calc(var(--fxd,.35)*2px) calc(var(--fxd,.35)*3px) 0 #0ea5e9)
         drop-shadow(calc(var(--fxd,.35)*5px) calc(var(--fxd,.35)*7px) 0 #0369a1)
         drop-shadow(calc(var(--fxd,.35)*8px) calc(var(--fxd,.35)*11px) 12px rgba(14,165,233,.5));
  background:linear-gradient(180deg,#ffffff 0%,#e0f2fe 30%,#0284c7 52%,#f0f9ff 58%,#38bdf8 82%,#ffffff 100%);
  -webkit-background-clip:text;background-clip:text}

/* 4 · FIRE — ember gradient */
.vzfx-fire{--fs:46px}
.vzfx-fire .fx-wt{font-weight:900;
  background:linear-gradient(180deg,#fde047 0%,#fb923c 40%,#ef4444 74%,#991b1b 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  filter:drop-shadow(0 3px 12px rgba(251,146,60,.4))}
.vzfx-fire .fx-w.st-past .fx-wt{opacity:.5}
.vzfx-fire .fx-w.st-act{transform:scale(1.06)}
.vzfx-fire .fx-w.st-act .fx-wt{
  background:linear-gradient(180deg,#fef9c3 0%,#fdba74 34%,#f97316 66%,#dc2626 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  animation:fxEmber 1.5s ease-in-out infinite}

/* 5 · CANDY POP — soft gradient chips */
.vzfx-candy{--fs:38px}
.vzfx-candy .fx-line{background:color-mix(in oklab,#ffffff 13%,transparent);
  border-radius:.55em;padding:.12em .5em;backdrop-filter:blur(5px)}
.vzfx-candy .fx-wt{font-weight:800;
  background:linear-gradient(90deg,#f472b6,#a78bfa,#38bdf8,#f472b6);background-size:260% 100%;
  -webkit-background-clip:text;background-clip:text;color:transparent}
.vzfx-candy .fx-w.st-past .fx-wt{opacity:.5}
.vzfx-candy .fx-w.st-act .fx-wt{animation:fxHoloShift 3.2s linear infinite;
  filter:drop-shadow(0 2px 8px rgba(244,114,182,.45))}

/* 6 · BOX CAPTION — broadcast-safe chip */
.vzfx-boxc{--fs:29px}
.vzfx-boxc .fx-line{background:rgba(8,10,14,.7);border-radius:.32em;padding:.2em .55em;
  backdrop-filter:blur(8px)}
.vzfx-boxc .fx-wt{font-weight:600}
.vzfx-boxc .fx-w.st-past .fx-wt{color:#ffffff}
.vzfx-boxc .fx-w.st-act .fx-wt{color:var(--vAcc);font-weight:800}

/* 7 · HACKER — typewriter terminal */
.vzfx-hacker{--fs:27px}
.vzfx-hacker .fx-wt{font-weight:500}
.vzfx-hacker .fx-w.st-past .fx-wt{color:rgba(74,222,128,.75)}
.vzfx-hacker .fx-w.st-act .fx-wt{color:#4ade80;text-shadow:0 0 12px rgba(74,222,128,.55)}
.vzfx-hacker .fx-w.st-act::after{content:'▮';margin-left:.05em;color:#4ade80;
  animation:fxBlink .9s steps(1) infinite;font-size:.85em}
.vzfx-hacker::after{content:'';position:absolute;inset:0;z-index:4;pointer-events:none;
  background:repeating-linear-gradient(0deg,rgba(0,0,0,.16) 0 1px,transparent 1px 3px)}

/* 8 · Y2K HOLO — iridescent chrome-plastic */
.vzfx-y2k{--fs:42px}
.vzfx-y2k .fx-wt{font-weight:900;text-transform:uppercase;letter-spacing:.01em;
  background:linear-gradient(100deg,#22d3ee,#e879f9,#fde047,#4ade80,#22d3ee);background-size:280% 100%;
  -webkit-background-clip:text;background-clip:text;color:transparent;
  animation:fxHoloShift 5s linear infinite;
  filter:drop-shadow(-2px 0 rgba(232,121,249,.5)) drop-shadow(2px 0 rgba(34,211,238,.5))}
.vzfx-y2k .fx-w.st-past .fx-wt{opacity:.45}
.vzfx-y2k .fx-w.st-act{transform:scale(1.09) rotate(-1.5deg)}

/* 9 · VHS — chroma-shifted tape */
.vzfx-vhs{--fs:34px}
.vzfx-vhs .fx-wt{font-weight:700;color:#ececf2;
  text-shadow:2px 0 rgba(255,60,60,.55),-2px 0 rgba(60,130,255,.55),0 2px 0 rgba(0,0,0,.45)}
.vzfx-vhs .fx-w.st-past .fx-wt{color:#c8c8d4}
.vzfx-vhs .fx-w.st-act{animation:fxJitter 2.4s linear infinite}
.vzfx-vhs .fx-w.st-act .fx-wt{color:#fff;text-shadow:3px 0 rgba(255,60,60,.75),-3px 0 rgba(60,130,255,.75)}
.vzfx-vhs::after{content:'';position:absolute;inset:0;z-index:4;pointer-events:none;
  background:repeating-linear-gradient(0deg,rgba(0,0,0,.24) 0 1px,transparent 1px 3px)}
.vzfx-vhs::before{content:'';position:absolute;inset:0;z-index:3;pointer-events:none;
  background:radial-gradient(ellipse at center,transparent 58%,rgba(4,6,12,.5) 100%)}

/* 10 · AURORA GLASS — frosted aurora panel */
.vzfx-aurora{--fs:30px}
.vzfx-aurora .fx-scr{background:color-mix(in oklab,#ffffff 9%,transparent);
  border:1px solid color-mix(in oklab,#ffffff 26%,transparent);
  backdrop-filter:blur(16px) saturate(1.5);-webkit-backdrop-filter:blur(16px) saturate(1.5);
  border-radius:.7em;padding:.5em 1em .6em;
  box-shadow:0 20px 60px rgba(2,6,23,.5),inset 0 1px 0 rgba(255,255,255,.2)}
.vzfx-aurora .fx-wt{font-weight:600;color:#f4f7fb}
.vzfx-aurora .fx-w.st-past .fx-wt{color:rgba(244,247,251,.85)}

/* ===== WORD POOL — special-word emphasis (v31) ===== */
.fx-w{--vEI:.8}
.vzfx[data-emph] .fx-w.st-fx-emph .fx-wt{color:var(--vEmphC,#fde047)}
.fx-w.pool-hit::after{content:'';position:absolute;top:-.34em;left:50%;width:.14em;height:.14em;
  border-radius:50%;background:var(--vEmphC,#fde047);opacity:.7;transform:translateX(-50%)}
@keyframes fxEmphBurst{0%{transform:scale(.55)}55%{transform:scale(calc(1 + .34*var(--vEI)))}100%{transform:scale(1.07)}}
@keyframes fxEmphRing{0%{opacity:.85;transform:scale(.5)}100%{opacity:0;transform:scale(1.75)}}
@keyframes fxEmphPulse{0%,100%{transform:scale(1.04)}50%{transform:scale(calc(1 + .26*var(--vEI)))}}
@keyframes fxEmphGlow{0%,100%{text-shadow:0 0 .14em var(--vEmphC,#fde047)}
  50%{text-shadow:0 0 calc(.55em*var(--vEI)) var(--vEmphC,#fde047),
    0 0 calc(1.1em*var(--vEI)) color-mix(in oklab,var(--vEmphC,#fde047) 55%,transparent)}}
@keyframes fxEmphFlip{0%{transform:rotateX(0)}48%{transform:rotateX(-172deg) scale(1.1)}
  100%{transform:rotateX(-360deg) scale(1.06)}}
.vzfx[data-emph="burst"] .fx-w.st-fx-emph .fx-wt{animation:fxEmphBurst .55s cubic-bezier(.34,1.56,.64,1)}
.vzfx[data-emph="burst"] .fx-w.st-fx-emph .fx-wt::after{content:'';position:absolute;inset:-.1em -.22em;
  border:.075em solid var(--vEmphC,#fde047);border-radius:.14em;
  animation:fxEmphRing .62s ease-out forwards}
.vzfx[data-emph="pulse"] .fx-w.st-fx-emph .fx-wt{animation:fxEmphPulse .48s ease-in-out infinite;
  text-shadow:0 0 .28em var(--vEmphC,#fde047)}
.vzfx[data-emph="glow"] .fx-w.st-fx-emph .fx-wt{animation:fxEmphGlow 1.1s ease-in-out infinite}
.vzfx[data-emph="flip"] .fx-w.st-fx-emph .fx-wt{animation:fxEmphFlip .72s cubic-bezier(.45,0,.2,1)}
.vzfx[data-emph="flip"] .fx-w{perspective:520px}

/* reduced-motion guard */
.vzfx.rm *{animation-duration:.001s!important}
`;

/* inject once — app runtime */
(function(){
  const st=document.createElement('style');
  st.id='fxcss';
  st.textContent=FXCSS;
  document.head.appendChild(st);
})();

/* ---------- FX param defaults (persist across theme switches) ---------- */
Object.assign(VIZ.params,{
  entrance:'pop',direction:'s',wmode:'word',oneline:false,pos:'bottom',depth:0.35,
  engine:'css',pool:[],emph:'burst',emphI:.8
});
VIZ.fxTouchedEntrance=false;

/* ---------- WORD POOL (v31) ----------
   Special words get a distinct FX the moment they are spoken.
   Matching is normalized: case/punctuation-insensitive, any script. */
const NORM=w=>String(w||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');
VIZ.fxNorm=NORM;
VIZ.fxPoolSet=new Set();
VIZ.fxPoolHits=0;
VIZ.fxRebuildPool=function(){
  VIZ.fxPoolSet.clear();
  (VIZ.params.pool||[]).forEach(w=>{const n=NORM(w);if(n)VIZ.fxPoolSet.add(n);});
  let hits=0;
  if(VIZ.model&&VIZ.model.words)VIZ.model.words.forEach(w=>{if(VIZ.fxPoolSet.has(NORM(w.text)))hits++;});
  VIZ.fxPoolHits=hits;
  if(VIZ.fxPoolCount)VIZ.fxPoolCount(VIZ.fxPoolSet.size,hits);
};

/* ---------- ENGINE switch (v31): CSS 2.5D ⇄ real three.js WebGL ----------
   The 3D module (fx3d.js + local three r169) loads lazily on first
   toggle; on failure the CSS engine stays live — never a dead stage. */
VIZ.setEngine=async function(mode){
  VIZ.params.engine=mode;
  if(mode==='3d'&&!VIZ.fx3dCaption){
    try{await import('./fx3d.js');}
    catch(e){
      VIZ.params.engine='css';
      if(S.toast)S.toast('3D engine unavailable — CSS engine kept',true);
      return 'css';
    }
  }
  const cur=VIZ.current;
  if(cur&&cur.engine==='fx'&&VIZ.presets[cur.id]){
    try{await VIZ.use(cur.id,true);}catch(e){}
  }
  return VIZ.params.engine;
};

/* 8-way + in-place direction vectors (up/down kept as aliases of s/n) */
const DIR={n:[0,-1],ne:[1,-1],e:[1,0],se:[1,1],s:[0,1],sw:[-1,1],w:[-1,0],nw:[-1,-1],c:[0,0],up:[0,1],down:[0,-1]};
export const FXDIR=DIR;

/* ---------- renderer factory ---------- */
VIZ.fxCaption=function(cfg){
  let host=null,root=null,view=null,viewKey='';
  let model=null,params=null,spans=[],_prevAct=null;
  let _lOne=null,_lE=null,_lWm=null;

  function applyTheme(){
    if(!root||!params)return;
    const t=cfg.theme,s=root.style;
    s.setProperty('--vBg',t.bg);
    s.setProperty('--vInk',t.ink);
    s.setProperty('--vDim',t.dim);
    s.setProperty('--vDone',t.done||t.dim);
    s.setProperty('--vAcc',t.acc);
    s.setProperty('--vB',t.accB||t.acc);
    s.setProperty('--vF',t.font);
    s.setProperty('--vFa',t.fontFa||FONT.fa);
    s.setProperty('--vScale',String(params.scale));
    s.setProperty('--vM',String(VIZ.REDUCED?0.12:params.motion));
    s.setProperty('--vFx',String(params.fx));
    const d=DIR[params.direction]||DIR.up;
    s.setProperty('--dx',String(d[0]));
    s.setProperty('--dy',String(d[1]));
    s.setProperty('--fxd',String(params.depth));
    /* word mode = word-by-word pops → snappier; line mode = block entrance → fuller */
    s.setProperty('--fdur',VIZ.scaleDur(params.wmode==='word'?250:420,params.motion)+'ms');
    root.dataset.e=params.entrance;
    root.dataset.pos=params.pos;
    root.dataset.wm=params.wmode;
    root.dataset.hl=cfg.hl||'grad';
    root.classList.toggle('oneline',!!params.oneline);
    root.dataset.emph=params.emph||'burst';
    s.setProperty('--vEI',String(params.emphI!=null?params.emphI:0.8));
    root.dir=(model&&model.rtl)?'rtl':'ltr';
    root.dataset.fa=(model&&model.rtl&&cfg.theme.fontFa!==false)?'1':'0';
  }

  function ensureRoot(){
    if(root)return;
    root=S.el('div','vzfx vzfx-'+cfg.id+(VIZ.REDUCED?' rm':''));
    host.appendChild(root);
    applyTheme();
  }

  function holdIdx(st){
    let b=-1;const sc=model.screens;
    for(let i=0;i<sc.length;i++){if(sc[i].t0<=st.t)b=i;else break;}
    return b;
  }

  function buildScreen(sc){
    const d=S.el('div','fx-scr is-cur');
    let lines=sc.lines;
    if(params.oneline)lines=[sc.lines.reduce((a,b)=>a.concat(b),[])];
    lines.forEach(lw=>{
      const L=S.el('span','fx-line');
      lw.forEach((w,wi)=>{
        const el=S.el('span','fx-w');
        el.dataset.i=String(w._i);
        el.style.setProperty('--wid',String(wi));
        const t=S.el('span','fx-wt');
        t.textContent=w.text||'';
        el.appendChild(t);
        if(params.wmode==='line')el.classList.add('in');
        L.appendChild(el);
      });
      d.appendChild(L);
    });
    return d;
  }

  function render(st){
    ensureRoot();
    const m=model;
    let sc=null,si=-1;
    if(m){
      si=st.screenIdx;
      if(si<0&&!st.playing&&st.t<=0.01)si=holdIdx(st);      /* ready card = first screen */
      if(si>=0&&si<m.screens.length)sc=m.screens[si];
    }
    let key;
    if(!m)key='rest0';
    else if(!sc)key=st.playing?'gap':'gap';
    else key='s'+si;
    key+='|'+params.wmode+':'+(params.oneline?1:0)+':'+params.entrance;
    if(key===viewKey&&view)return;
    viewKey=key;
    if(view)view.remove();
    view=S.el('div','fx-view');
    if(!m){
      view.innerHTML='<div class="fx-rest-in"><b>'+S.esc(cfg.name)+'</b>'
        +'<span>pick audio · generate · press play</span></div>';
    }else if(!sc){
      /* between cues — clean stage */
    }else{
      view.appendChild(buildScreen(sc));
    }
    root.appendChild(view);
    spans=[].slice.call(view.querySelectorAll('.fx-w'));
    _prevAct=null;
    fitOne();
  }

  function fitOne(){
    if(!view||!root){return;}
    if(!params.oneline){root.style.removeProperty('--ffit');return;}
    const maxW=root.clientWidth*0.94||600;
    let fit=1;
    [].forEach.call(view.querySelectorAll('.fx-line'),L=>{
      const w=L.scrollWidth;
      if(w>maxW)fit=Math.min(fit,maxW/w);
    });
    root.style.setProperty('--ffit',String(Math.max(0.45,+fit.toFixed(3))));
  }

  function classify(st){
    const wi=st.wordIdx;
    const wm=params.wmode;
    spans.forEach(el=>{
      const i=parseInt(el.dataset.i,10);
      el.classList.toggle('st-act',i===wi);
      el.classList.toggle('st-past',i<wi);
      el.classList.toggle('st-fut',i>wi);
      if(wm==='word'&&i<=wi)el.classList.add('in');
      /* v31 word pool — the live pool word ignites, upcoming pool words
         carry a small gold dot so the editor can see them coming */
      if(VIZ.fxPoolSet.size){
        const hit=VIZ.fxPoolSet.has(NORM(el.textContent));
        el.classList.toggle('st-fx-emph',hit&&i===wi);
        el.classList.toggle('pool-hit',hit&&i!==wi);
      }else if(el.classList.contains('st-fx-emph')||el.classList.contains('pool-hit')){
        el.classList.remove('st-fx-emph','pool-hit');
      }
    });
    const act=view?view.querySelector('.fx-w.st-act'):null;
    if(act!==_prevAct){
      if(_prevAct)_prevAct.style.removeProperty('--p');
      _prevAct=act;
    }
    if(act)act.style.setProperty('--p',st.wordP.toFixed(4));
  }

  const R={};
  R.mount=function(h){host=h;};
  R.setModel=function(m){model=m;viewKey='';if(root){root.remove();root=null;view=null;spans=[];}
    if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();};
  R.applyParams=function(p){
    params=p;
    if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
    if(!root)return;
    applyTheme();
    if(params.oneline!==_lOne||params.entrance!==_lE||params.wmode!==_lWm){
      _lOne=params.oneline;_lE=params.entrance;_lWm=params.wmode;
      viewKey='';render(VIZ.state);
    }else fitOne();
  };
  R.resize=function(){fitOne();};
  R.frame=function(st){
    if(!host)return;
    ensureRoot();
    render(st);
    classify(st);
    root.classList.toggle('at-rest',!st.playing&&st.wordIdx<0);
    const beat=(params&&params.react&&st.playing)?st.audio.beat:0;
    root.style.setProperty('--beat',String(+(beat*0.05).toFixed(3)));
  };
  R.snapshot=function(){
    try{return fxSnapshot();}catch(e){return null;}
  };
  R.dispose=function(){if(root){root.remove();}root=null;view=null;host=null;model=null;spans=[];};
  return R;

  /* canvas raster — palette/typography faithful enough for a PNG frame */
  function fxSnapshot(){
    if(!VIZ.model||!view)return null;
    const m=VIZ.model,st=VIZ.state,t=cfg.theme;
    const W=1600,H=900;
    const cv=document.createElement('canvas');cv.width=W;cv.height=H;
    const x=cv.getContext('2d');
    x.fillStyle=t.snapBg||'#0f1118';x.fillRect(0,0,W,H);
    const si=st.screenIdx<0?Math.max(0,holdIdx(st)):st.screenIdx;
    const sc=m.screens[si];
    if(sc){
      const fs=Math.round(56*VIZ.params.scale);
      x.font=(cfg.id==='hacker'?'500 ':'800 ')+fs+'px '+(t.font||'Inter').split(',')[0].replace(/'/g,'');
      x.textBaseline='alphabetic';x.textAlign='center';
      const pos=(VIZ.params.pos==='bottom');
      const lines=params.oneline?[sc.lines.reduce((a,b)=>a.concat(b),[])]:sc.lines;
      let y=pos?H-140-lines.length*fs*0.6:H/2-((lines.length-1)*fs*0.8);
      lines.forEach(lw=>{
        const txt=lw.map(w=>w.text).join(' ');
        if(/[\u0600-\u06FF]/.test(txt))x.direction='rtl';
        x.fillStyle='rgba(255,255,255,.94)';
        x.fillText(txt,W/2,y);
        const actw=lw.find(w=>w._i===st.wordIdx);
        if(actw){
          const full=lw.map(w=>w.text).join(' ');
          const aw=x.measureText(actw.text).width;
          const tw=x.measureText(full).width;
          const ax=W/2-tw/2+x.measureText(full.slice(0,full.indexOf(actw.text))).width+aw/2;
          x.fillStyle=t.acc;
          x.fillRect(ax-aw/2-8,y-fs*0.82,aw+16,fs*1.06);
          x.fillStyle='#0d0d0d';
          x.fillText(actw.text,ax,y);
        }
        y+=fs*1.5;
      });
    }
    x.textAlign='left';
    x.font='700 26px JetBrains Mono, monospace';
    x.fillStyle=t.acc||'#34d399';
    x.fillText('AUDIO STUDIO — FX '+cfg.name.toUpperCase(),48,64);
    x.font='400 22px JetBrains Mono, monospace';
    x.fillStyle='rgba(255,255,255,.5)';
    x.fillText(S.tcSRT(st.t)+' · '+VIZ.params.entrance+' '+VIZ.params.direction+' · depth '
      +Math.round(VIZ.params.depth*100)+'%',48,94);
    return cv.toDataURL('image/png');
  }
};

/* ============================================================
   THEME DEFINITIONS — ten modern caption directions
   ============================================================ */
VIZ.register({
  id:'viral',name:'Viral Bold',family:'FX Modern',engine:'fx',
  concept:'TikTok/CapCut-era kinetic caption — 900-weight caps with a hard ink outline, every word pops in as it is spoken, the live word rides an acid chip.',
  theme:{bg:'radial-gradient(110% 90% at 50% 0%,#2c3c55 0%,#17202f 55%,#0b111c 100%)',
    ink:'#ffffff',dim:'rgba(255,255,255,.6)',done:'rgba(255,255,255,.9)',
    acc:'#ccff00',accB:'#34d399',font:FONT.display,fontFa:FONT.fa,snapBg:'#141d2c'},
  def:{motion:.72,fx:.5,entrance:'pop'},hl:'box',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'neon',name:'Neon Cyber',family:'FX Modern',engine:'fx',
  concept:'Signage glow — cyan tube with a magenta halo, dark city backdrop. The live word ignites.',
  theme:{bg:'radial-gradient(130% 100% at 50% 110%,#0b2030 0%,#061019 55%,#030712 100%)',
    ink:'#e8f6ff',dim:'rgba(232,246,255,.55)',done:'rgba(232,246,255,.9)',
    acc:'#22d3ee',accB:'#e879f9',font:FONT.grotesk,fontFa:FONT.fa,snapBg:'#071018'},
  def:{motion:.6,fx:.6,entrance:'blur'},hl:'glow',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'chrome3d',name:'Chrome 3D',family:'FX Modern',engine:'fx',
  concept:'Extruded metal — brushed chrome fill, layered drop-shadow extrusion that grows with the 3D depth slider, flips in on rotateX.',
  theme:{bg:'radial-gradient(120% 100% at 50% 100%,#1b2634 0%,#101825 60%,#0a0f18 100%)',
    ink:'#e2e8f0',dim:'rgba(226,232,240,.5)',done:'rgba(226,232,240,.8)',
    acc:'#7dd3fc',accB:'#38bdf8',font:FONT.display,fontFa:FONT.fa,snapBg:'#111a26'},
  def:{motion:.55,fx:.5,entrance:'flip',depth:.55},hl:'box',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'fire',name:'Fire',family:'FX Modern',engine:'fx',
  concept:'Ember gradient — yellow-to-coal fill, the live word breathes heat.',
  theme:{bg:'radial-gradient(120% 100% at 50% 100%,#30140a 0%,#180a05 55%,#0a0402 100%)',
    ink:'#fdba74',dim:'rgba(253,186,116,.5)',done:'rgba(253,186,116,.85)',
    acc:'#fb923c',accB:'#fbbf24',font:FONT.display,fontFa:FONT.fa,snapBg:'#190a04'},
  def:{motion:.65,fx:.55,entrance:'zoom'},hl:'glow',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'candy',name:'Candy Pop',family:'FX Modern',engine:'fx',
  concept:'Soft social gradient — pink-violet-sky words on frosted chips, the live word slides along its gradient.',
  theme:{bg:'radial-gradient(120% 90% at 80% 0%,#3b2a55 0%,#241a3a 55%,#120d20 100%)',
    ink:'#f5d0fe',dim:'rgba(245,208,254,.55)',done:'rgba(245,208,254,.9)',
    acc:'#f472b6',accB:'#a78bfa',font:FONT.sans,fontFa:FONT.fa,snapBg:'#221838'},
  def:{motion:.7,fx:.5,entrance:'wave'},hl:'under',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'boxc',name:'Box Caption',family:'FX Modern',engine:'fx',
  concept:'Broadcast-safe — clean white on a soft black chip, the live word turns amber. The readability workhorse.',
  theme:{bg:'linear-gradient(180deg,#232a33 0%,#141920 60%,#0c1015 100%)',
    ink:'#ffffff',dim:'rgba(255,255,255,.62)',done:'rgba(255,255,255,.92)',
    acc:'#fbbf24',accB:'#f59e0b',font:FONT.sans,fontFa:FONT.fa,snapBg:'#151a21'},
  def:{motion:.5,fx:.4,entrance:'slide'},hl:'box',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'hacker',name:'Hacker',family:'FX Modern',engine:'fx',
  concept:'Terminal typewriter — mono green phosphor, the live word wears a block cursor.',
  theme:{bg:'radial-gradient(120% 100% at 50% 100%,#04150c 0%,#020c07 60%,#010503 100%)',
    ink:'#86efac',dim:'rgba(134,239,172,.5)',done:'rgba(134,239,172,.8)',
    acc:'#4ade80',accB:'#22d3ee',font:FONT.mono,fontFa:FONT.mono,snapBg:'#02110a'},
  def:{motion:.45,fx:.5,entrance:'type'},hl:'glow',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'y2k',name:'Y2K Holo',family:'FX Modern',engine:'fx',
  concept:'Iridescent chrome-plastic — a living spectrum with cyan/pink chromatic edges.',
  theme:{bg:'radial-gradient(130% 100% at 50% 0%,#1c1038 0%,#120a24 55%,#080512 100%)',
    ink:'#f0abfc',dim:'rgba(240,171,252,.5)',done:'rgba(240,171,252,.85)',
    acc:'#e879f9',accB:'#22d3ee',font:FONT.display,fontFa:FONT.fa,snapBg:'#130b26'},
  def:{motion:.75,fx:.6,entrance:'spin'},hl:'box',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'vhs',name:'VHS Tape',family:'FX Modern',engine:'fx',
  concept:'Chroma-shifted tape — red/blue fringing, scanlines, the live word jitters like tracking noise.',
  theme:{bg:'linear-gradient(180deg,#141722 0%,#0d0f16 60%,#07080d 100%)',
    ink:'#ececf2',dim:'rgba(236,236,242,.5)',done:'rgba(236,236,242,.85)',
    acc:'#ffffff',accB:'#60a5fa',font:FONT.grotesk,fontFa:FONT.fa,snapBg:'#0d1016'},
  def:{motion:.55,fx:.6,entrance:'blur'},hl:'glow',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});
VIZ.register({
  id:'aurora',name:'Aurora Glass',family:'FX Modern',engine:'fx',
  concept:'Frosted aurora panel — glassmorphism over teal and violet skies, the live word underlines in mint.',
  theme:{bg:'radial-gradient(700px 320px at 18% 82%,rgba(45,212,191,.24),transparent 62%),radial-gradient(560px 300px at 84% 18%,rgba(167,139,250,.26),transparent 62%),linear-gradient(180deg,#060c1a 0%,#0b1226 100%)',
    ink:'#f4f7fb',dim:'rgba(244,247,251,.55)',done:'rgba(244,247,251,.9)',
    acc:'#5eead4',accB:'#a78bfa',font:FONT.sans,fontFa:FONT.fa,snapBg:'#0a1120'},
  def:{motion:.5,fx:.45,entrance:'slide',direction:'s'},hl:'under',
  make:function(){return (VIZ.params.engine==='3d'&&VIZ.fx3dCaption)?VIZ.fx3dCaption(this):VIZ.fxCaption(this);}
});

window.VIZ=VIZ;
