/* ============================================================
   fxexport.js — STANDALONE HTML EXPORT (v30)

   One click → a self-contained .html file:
     · the audio embedded as an MP3 data URI
     · the word-timed screens embedded as JSON
     · the SAME FXCSS that powers the live stage
     · a compact runtime that renders the chosen theme,
       entrance + direction, word/line mode, one-line fit and
       3D depth — karaoke fill included
   Plays anywhere: double-click the file, press ▶.
   ============================================================ */
import VIZ from './core.js';
import {FXCSS} from './fx.js';
const S=window.S;
const $=S.$;

/* ---------- export runtime (embedded verbatim; no template
   literals inside — it is stringified into the file) ---------- */
const RUN=[
'(function(){',
'"use strict";',
'var D=__DATA__;',
'function E(id){return document.getElementById(id);}',
'var st=E("stage");',
'var root=document.createElement("div");',
'root.className="vzfx vzfx-"+D.theme;',
'st.appendChild(root);',
'var V=D.vars,DIRS={n:[0,-1],ne:[1,-1],e:[1,0],se:[1,1],s:[0,1],sw:[-1,1],w:[-1,0],nw:[-1,-1],c:[0,0]};',
'var d=DIRS[D.params.direction]||[0,1];',
'(function(){var s=root.style;',
' s.setProperty("--vBg",V.vBg);s.setProperty("--vInk",V.vInk);s.setProperty("--vDim",V.vDim);',
' s.setProperty("--vDone",V.vDone);s.setProperty("--vAcc",V.vAcc);s.setProperty("--vB",V.vB);',
' s.setProperty("--vF",V.vF);s.setProperty("--vFa",V.vFa);s.setProperty("--vScale",String(D.params.scale));',
' s.setProperty("--dx",String(d[0]));s.setProperty("--dy",String(d[1]));',
' s.setProperty("--fxd",String(D.params.depth));',
' s.setProperty("--fdur",Math.round((D.params.wmode==="word"?250:420)*(1.55-0.85*D.params.motion))+"ms");',
' root.dataset.e=D.params.entrance;root.dataset.pos=D.params.pos;root.dataset.wm=D.params.wmode;',
' root.dataset.hl=D.hl;root.dataset.emph=D.emph||"burst";root.classList.toggle("oneline",!!D.params.oneline);',
' s.setProperty("--vEI",String(D.emphI!=null?D.emphI:0.8));',
' root.dir=D.rtl?"rtl":"ltr";if(D.rtl)root.dataset.fa="1";',
'})();',
'var view=null,key="",spans=[];',
'var POOL={},TXT={};',
'(D.pool||[]).forEach(function(w){POOL[w]=1;});',
'D.screens.forEach(function(sc){sc.lines.forEach(function(lw){lw.forEach(function(w){TXT[w.i]=w.t;});});});',
'function N(s){return String(s||"").toLowerCase().replace(/[^a-z0-9\\u0600-\\u06FF]+/g,"");}',
'function build(i){',
' if(view)view.remove();view=document.createElement("div");view.className="fx-view";',
' root.appendChild(view);spans=[];',
' if(i<0)return;',
' var sc=D.screens[i];',
' var scr=document.createElement("div");scr.className="fx-scr is-cur";scr.dataset.e=D.params.entrance;',
' var lines=D.params.oneline?[sc.lines.reduce(function(a,b){return a.concat(b);},[])]:sc.lines;',
' lines.forEach(function(lw){',
'  var L=document.createElement("span");L.className="fx-line";',
'  lw.forEach(function(w,wi){',
'   var e=document.createElement("span");e.className="fx-w";e.dataset.i=String(w.i);',
'   e.style.setProperty("--wid",String(wi));',
'   var t=document.createElement("span");t.className="fx-wt";t.textContent=w.t;',
'   e.appendChild(t);if(D.params.wmode==="line")e.classList.add("in");',
'   L.appendChild(e);});',
'  scr.appendChild(L);});',
' view.appendChild(scr);',
' spans=[].slice.call(view.querySelectorAll(".fx-w"));',
' fit();',
'}',
'function fit(){',
' if(!D.params.oneline){root.style.removeProperty("--ffit");return;}',
' var maxW=root.clientWidth*0.94||600,f=1;',
' [].forEach.call(view.querySelectorAll(".fx-line"),function(L){var w=L.scrollWidth;if(w>maxW)f=Math.min(f,maxW/w);});',
' root.style.setProperty("--ffit",String(Math.max(0.45,Math.round(f*1000)/1000)));',
'}',
'function si(t){var i=-1;for(var k=0;k<D.screens.length;k++){if(D.screens[k].t0<=t)i=k;else break;}',
' if(i>=0&&t>D.screens[i].t1+0.2)i=-1;return i;}',
'function wi(t){var w=-1;for(var k=0;k<D.flat.length;k++){if(D.flat[k].a<=t)w=D.flat[k].i;else break;}return w;}',
'function wordAt(i,idx){var out=null;if(i>=0)D.screens[i].lines.forEach(function(lw){lw.forEach(function(x){if(x.i===idx)out=x;});});return out;}',
'function frame(t){',
' var i=si(t);',
' if(i<0&&!playing&&t<0.05&&D.screens.length)i=0;',
' var k=(i<0?"gap":"s"+i)+"|"+D.params.wmode+":"+(D.params.oneline?1:0)+":"+D.params.entrance;',
' if(k!==key){key=k;build(i);}',
' var wd=wi(t);',
' spans.forEach(function(el){',
'  var idx=parseInt(el.dataset.i,10);',
'  el.classList.toggle("st-act",idx===wd);',
'  el.classList.toggle("st-past",idx<wd);',
'  el.classList.toggle("st-fut",idx>wd);',
'  if(D.params.wmode==="word"&&idx<=wd)el.classList.add("in");',
'  var tx=N(TXT[idx]);',
'  el.classList.toggle("st-fx-emph",!!POOL[tx]&&idx===wd);',
'  el.classList.toggle("pool-hit",!!POOL[tx]&&idx!==wd);});',
' var act=view?view.querySelector(".fx-w.st-act"):null;',
' if(act){var w=wordAt(Math.max(0,i),wd);',
'  var p=w?Math.max(0,Math.min(1,(t-w.a)/Math.max(0.001,w.b-w.a))):0;',
'  act.style.setProperty("--p",p.toFixed(4));}',
' root.classList.toggle("at-rest",!playing&&wd<0&&t<0.05);',
'}',
'var au=D.hasAudio?E("au"):null,pp=E("pp"),fill=E("fill"),tm=E("tm"),trk=E("trk");',
'var playing=false,vStart=0;',
'function now(){return au?au.currentTime:(playing?(performance.now()-vStart)/1000%D.dur:0);}',
'function play(){if(au){au.currentTime=au.currentTime||0;au.play();}else{vStart=performance.now();}',
' playing=true;pp.textContent="❚❚";}',
'function pause(){if(au)au.pause();playing=false;pp.textContent="▶";}',
'pp.onclick=function(){playing?pause():play();};',
'if(au)au.addEventListener("ended",function(){playing=false;pp.textContent="▶";});',
'function fmt(t){t=Math.max(0,t);var m=Math.floor(t/60),s=Math.floor(t%60);return m+":"+(s<10?"0":"")+s;}',
'(function loop(){var t=now();frame(t);',
' fill.style.width=(t/D.dur*100)+"%";',
' tm.textContent=fmt(t)+" / "+fmt(D.dur);',
' requestAnimationFrame(loop);})();',
'window.addEventListener("resize",function(){if(view)fit();});',
'trk.onclick=function(ev){',
' if(!au)return;',
' var r=trk.getBoundingClientRect();',
' var p=Math.max(0,Math.min(1,(ev.clientX-r.left)/r.width));',
' au.currentTime=p*D.dur;frame(au.currentTime);};',
'})();'
].join('\n');

const PLAYERCSS=`
body{margin:0;background:#09090b;color:#e4e4e7;
  font-family:'SF Mono',ui-monospace,'Cascadia Code',Menlo,Consolas,monospace;
  display:flex;min-height:100vh;align-items:center;justify-content:center;padding:20px}
.xp{width:min(1020px,96vw)}
.stage{position:relative;aspect-ratio:16/9;border-radius:14px;overflow:hidden;
  border:1px solid #27272a;box-shadow:0 24px 80px rgba(0,0,0,.6);background:#0b0b0e}
.pbar{display:flex;align-items:center;gap:12px;margin-top:14px}
.pbar button{background:#131318;border:1px solid #3f3f46;color:#e4e4e7;border-radius:9px;
  padding:9px 18px;font-family:inherit;font-weight:700;font-size:13px;cursor:pointer;
  transition:border-color .15s}
.pbar button:hover{border-color:#71717a}
.trk{flex:1;height:6px;background:#27272a;border-radius:99px;overflow:hidden;cursor:pointer}
.trk i{display:block;height:100%;width:0;background:linear-gradient(90deg,#34d399,#14b8a6)}
.tm{font-size:11px;color:#a1a1aa;letter-spacing:.05em;white-space:nowrap}
.meta{margin-top:10px;font-size:10px;color:#71717a;letter-spacing:.12em;text-transform:uppercase}
.meta b{color:#34d399;font-weight:700}
`;

/* ---------- export ---------- */
VIZ.fxExportHTML=async function(){
  if(!VIZ.model||!VIZ.model.words){
    S.toast('Generate subtitles first — then export HTML',true);return;
  }
  const themeId=(VIZ.current&&VIZ.current.engine==='fx'&&VIZ.current.id)||VIZ._lastFx||'viral';
  const cfg=VIZ.presets[themeId];
  if(!cfg){S.toast('FX theme not found',true);return;}
  const P=VIZ.params;
  const DIRN=P.direction==='up'?'s':(P.direction==='down'?'n':P.direction);   /* normalize legacy aliases */
  S.toast('Building standalone HTML…');
  /* audio → mp3 data URI (falls back to a timed preview without audio) */
  let audioURI=null,srcName='audio';
  try{
    const info=S.fxSrcInfo&&S.fxSrcInfo();
    if(info&&info.name)srcName=String(info.name).slice(0,60);
    let buf=info&&info.buffer;
    if(!buf&&info&&info.url)buf=await S.decode(await(await fetch(info.url)).arrayBuffer());
    if(!buf&&info&&info.blob)buf=await S.decode(info.blob);
    if(buf&&S.ab2mp3){
      const mp=S.ab2mp3(buf,128);
      audioURI=await new Promise(res=>{
        const fr=new FileReader();
        fr.onload=()=>res(fr.result);
        fr.onerror=()=>res(null);
        fr.readAsDataURL(mp);
      });
    }
  }catch(e){audioURI=null;}

  const m=VIZ.model;
  const screens=m.screens.map(sc=>({
    t0:+sc.t0.toFixed(3),t1:+sc.t1.toFixed(3),
    lines:sc.lines.map(lw=>lw.map(w=>({i:w._i,t:w.text,
      a:+w.startSec.toFixed(3),b:+w.endSec.toFixed(3)})))
  }));
  const flat=m.words.map(w=>({i:w._i,a:+w.startSec.toFixed(3)}));
  const t=cfg.theme;
  const DATA={
    theme:themeId,name:cfg.name,hl:cfg.hl||'grad',
    screens,flat,rtl:!!m.rtl,
    params:{entrance:P.entrance,direction:DIRN,wmode:P.wmode,
      oneline:!!P.oneline,pos:P.pos,depth:+(+P.depth).toFixed(2),
      scale:+P.scale,motion:+(+P.motion).toFixed(2)},
    pool:(VIZ.params.pool||[]).map(w=>String(w).trim().toLowerCase()).filter(Boolean),
    emph:P.emph||'burst',emphI:+(+(P.emphI!=null?P.emphI:0.8)).toFixed(2),
    vars:{vBg:t.bg,vInk:t.ink,vDim:t.dim,vDone:t.done||t.dim,vAcc:t.acc,vB:t.accB||t.acc,
      vF:t.font,vFa:t.fontFa||"'Vazirmatn','Inter',system-ui,sans-serif"},
    dur:+(Math.max(m.duration||0,(screens.length?screens[screens.length-1].t1:0))+0.8).toFixed(2),
    hasAudio:!!audioURI
  };
  const dataJSON=JSON.stringify(DATA).replace(/<\//g,'<\\/');
  const fontLink='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Space+Grotesk:wght@500;700&family=JetBrains+Mono&family=Archivo+Black&family=Vazirmatn:wght@400;700;900&display=swap">';
  const audioTag=audioURI
    ?'<audio id="au" preload="auto" src="'+audioURI+'"></audio>'
    :'<div class="meta" style="color:#fbbf24">no embedded audio — timed preview mode</div>';
  const html='<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n'
    +'<meta name="viewport" content="width=device-width,initial-scale=1">\n'
    +'<title>Subtitles — '+S.esc(cfg.name)+' · '+S.esc(srcName)+'</title>\n'
    +fontLink+'\n<style>\n'+PLAYERCSS+'\n'+FXCSS+'\n</style>\n</head>\n<body>\n'
    +'<div class="xp">\n  <div class="stage" id="stage"></div>\n'
    +'  <div class="pbar">\n    <button id="pp">▶</button>\n'
    +'    <div class="trk" id="trk"><i id="fill"></i></div>\n'
    +'    <span class="tm" id="tm">0:00 / 0:00</span>\n  </div>\n'
    +'  <div class="meta"><b>FX '+S.esc(cfg.name).toUpperCase()+'</b> · entrance '
    +S.esc(P.entrance)+' · '+S.esc(DIRN)+(P.oneline?' · one-line':'')
    +' · 3D '+Math.round(P.depth*100)+'%'+((VIZ.params.pool||[]).length?' · word pool '+String(VIZ.params.pool.length):'')
    +' · audio studio export</div>\n'
    +'</div>\n'+audioTag+'\n'
    +'<script>\n'+RUN.replace('__DATA__',function(){return dataJSON;})+'\n</script>\n</body>\n</html>\n';

  const a=S.el('a');
  a.href=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));
  a.download='Subtitles_'+(S.pn||'audio').replace(/\.[^/.]+$/,'')+'_'+themeId+'.html';
  a.click();
  S.toast('HTML exported — '+(audioURI?'audio embedded':'timed preview')+' · '+cfg.name);
  return true;
};

/* wire the download button (listcard row) */
(function(){
  const b=$('dlHtml');
  if(b)b.onclick=()=>VIZ.fxExportHTML();
})();
window.VIZ=VIZ;
