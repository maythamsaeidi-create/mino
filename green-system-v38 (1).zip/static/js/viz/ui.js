/* ============================================================
   VIZ UI — stage chrome, preset rail, art-direction panel (v27)

   Wires the Subtitle Layer into the Subtitles tab:
     · preset rail (16 curated systems, grouped by family)
     · palette dots · type scale · motion · fx · audio-react
     · fullscreen stage · frame PNG export
     · VIZ view toggle beside Cues / Karaoke
   ============================================================ */
import VIZ from './core.js';
const S=window.S;
const $=S.$;

const VIEW_HINT='pick an audio file · Generate · press play — every word lights in sync';

/* ---------- palette strip helpers ---------- */
function pstrip(p){
  const cols=[p.palettes[0].bg,p.palettes[0].ink,p.palettes[0].acc];
  if(p.palettes[1])cols.push(p.palettes[1].acc);
  return cols.map(c=>`<i style="background:${c}"></i>`).join('');
}
function firstHex(s){
  const m=String(s||'').match(/#[0-9a-fA-F]{3,8}/);
  return m?m[0]:'#101014';
}

/* ---------- rail (v30: SYSTEMS tab — FX themes live in their own row) ---------- */
function buildRail(){
  const rail=$('vizRail');if(!rail)return;
  rail.innerHTML='';
  VIZ.registry.forEach(p=>{
    if(p.engine==='fx')return;          /* FX themes have their own chip row */
    const c=S.el('button','viz-card'+(VIZ.current&&VIZ.current.id===p.id?' on':''));
    c.dataset.id=p.id;
    c.title=p.concept||'';
    c.innerHTML='<div class="nm">'+S.esc(p.name)+'</div>'+
      '<div class="fm">'+S.esc(p.family)+' · '+p.engine.toUpperCase()+'</div>'+
      '<div class="viz-pstrip">'+pstrip(p)+'</div>';
    c.onclick=()=>{VIZ.use(p.id);};
    rail.appendChild(c);
  });
}

/* ---------- panel ---------- */
function buildPanel(){
  const dots=$('vizPdots');if(!dots)return;
  dots.innerHTML='';
  const p=VIZ.current;if(!p)return;
  /* FX themes own their look end-to-end — no palette dots */
  if(!p.palettes||!p.palettes.length){
    if($('vizPalName'))$('vizPalName').textContent='';
    return;
  }
  p.palettes.forEach((pl,i)=>{
    const b=S.el('button','');
    b.style.background=pl.acc;
    b.title=pl.name||('palette '+(i+1));
    if(i===VIZ.params.palette){b.classList.add('on');}
    b.onclick=()=>{VIZ.setParam('palette',i);syncPanel();};
    dots.appendChild(b);
  });
  const nm=$('vizPalName');if(nm)nm.textContent=(p.palettes[VIZ.params.palette]||{}).name||'';
}
function syncPanel(){
  buildPanel();
  const seg=$('vizScale');
  if(seg)[].forEach.call(seg.children,b=>{
    b.classList.toggle('on',Math.abs(parseFloat(b.dataset.v)-VIZ.params.scale)<0.01);
  });
  const mo=$('vizMotion'),fx=$('vizFx');
  if(mo){mo.value=VIZ.params.motion;$('vizMotionV').textContent=Math.round(VIZ.params.motion*100)+'%';}
  if(fx){fx.value=VIZ.params.fx;$('vizFxV').textContent=Math.round(VIZ.params.fx*100)+'%';}
  const re=$('vizReact');if(re)re.checked=!!VIZ.params.react;
}
function wirePanel(){
  const seg=$('vizScale');
  if(seg)[].forEach.call(seg.children,b=>{
    b.onclick=()=>{VIZ.setParam('scale',parseFloat(b.dataset.v));syncPanel();};
  });
  const mo=$('vizMotion');
  if(mo){
    mo.oninput=()=>{VIZ.setParam('motion',parseFloat(mo.value));
      $('vizMotionV').textContent=Math.round(mo.value*100)+'%';};
  }
  const fx=$('vizFx');
  if(fx){
    fx.oninput=()=>{VIZ.setParam('fx',parseFloat(fx.value));
      $('vizFxV').textContent=Math.round(fx.value*100)+'%';};
  }
  const re=$('vizReact');
  if(re)re.onchange=()=>{VIZ.setParam('react',re.checked);};
}

/* ---------- HUD + tools ---------- */
function hud(){
  const p=VIZ.current;
  const a=$('vhName'),b=$('vhFam');
  if(a&&p)a.textContent=p.name;
  if(b&&p)b.textContent=p.family;
}
function wireTools(){
  const fs=$('vizFull');
  if(fs)fs.onclick=()=>{
    const st=$('vizStage');
    if(!document.fullscreenElement)st.requestFullscreen&&st.requestFullscreen();
    else document.exitFullscreen&&document.exitFullscreen();
  };
  const sh=$('vizShot');
  if(sh)sh.onclick=()=>{
    let url=null;
    try{url=VIZ.snapshot();}catch(e){}
    if(!url&&VIZ.current&&VIZ.current.engine==='dom')url=domSnapshot(VIZ.current);
    if(!url){S.toast('Nothing to export yet — load subtitles first',true);return;}
    const a=S.el('a');
    a.href=url;
    a.download='viz-'+(VIZ.current?VIZ.current.id:'frame')+'-'+S.tcSRT(VIZ.state.t).replace(/[:,.]/g,'-')+'.png';
    a.click();
    S.toast('Frame exported — PNG saved');
  };
}

/* ---------- DOM-preset frame export (palette/typography faithful) ---------- */
function domSnapshot(p){
  const m=VIZ.model,st=VIZ.state;
  if(!m)return null;
  const pal=p.palettes[VIZ.params.palette]||p.palettes[0];
  const W=1600,H=900;
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;
  const x=cv.getContext('2d');
  const bg=firstHex(pal.bg);
  x.fillStyle=bg;x.fillRect(0,0,W,H);
  const fs=54*VIZ.params.scale;
  x.font=(p.id==='swiss'||p.id==='poster'?'800 ':'600 ')+Math.round(fs)+'px '+(p.font||'Inter, Arial');
  x.textBaseline='alphabetic';
  const si=st.screenIdx<0?holdIdx():st.screenIdx;
  const sc=m.screens[Math.max(0,si)];
  if(sc){
    let y=H/2-((sc.lines.length-1)*fs*0.75);
    sc.lines.forEach(lw=>{
      const words=lw.map(w=>({text:w.text||'',_i:w._i,w:x.measureText(w.text||'').width}));
      const sp=x.measureText(' ').width;
      const tot=words.reduce((a,b)=>a+b.w,0)+sp*(words.length-1);
      let px=(W-tot)/2;
      words.forEach(wd=>{
        if(wd._i===st.wordIdx){
          x.fillStyle=pal.dim;x.fillText(wd.text,px,y);
          x.save();x.beginPath();x.rect(px,y-fs,wd.w*st.wordP,fs*1.4);x.clip();
          x.fillStyle=pal.acc;x.fillText(wd.text,px,y);x.restore();
        }else{
          x.fillStyle=wd._i<st.wordIdx?pal.done:pal.dim;
          x.fillText(wd.text,px,y);
        }
        px+=wd.w+sp;
      });
      y+=fs*1.5;
    });
  }
  /* chrome */
  x.font='700 26px JetBrains Mono, monospace';
  x.fillStyle=pal.acc;
  x.fillText('AUDIO STUDIO — SUBTITLE LAYER',48,64);
  x.font='400 22px JetBrains Mono, monospace';
  x.fillStyle=pal.dim;
  x.fillText(p.name.toUpperCase()+' · '+(pal.name||'').toUpperCase()+' · '+S.tcSRT(st.t),48,94);
  x.fillText(VIEW_HINT.toUpperCase(),48,H-48);
  return cv.toDataURL('image/png');
  function holdIdx(){let b=-1;for(let i=0;i<m.screens.length;i++){if(m.screens[i].t0<=st.t)b=i;else break;}return b;}
}

/* ---------- view toggle (Cues / Karaoke — display card) ----------
   v28: the 16:9 stage is ALWAYS the live preview; this toggle only
   switches the display card between the structured cue list and the
   classic karaoke word stream. */
function setView(v){
  const cues=$('subList'),kar=$('karaokeBox');
  if(cues)cues.classList.toggle('hidden',v!=='cue');
  if(kar)kar.classList.toggle('hidden',v!=='kar');
  const bC=$('vwCue'),bK=$('vwKar');
  if(bC)bC.classList.toggle('on',v==='cue');
  if(bK)bK.classList.toggle('on',v==='kar');
  /* karaoke box was stale while hidden → force one fresh render */
  if(v==='kar'&&S.resetKaraoke){S.resetKaraoke();if(S.karaokeTick)S.karaokeTick(VIZ.state.t);}
  /* VIZ rAF pauses itself when hidden — nothing else to do */
}
function wireView(){
  const bC=$('vwCue'),bK=$('vwKar');
  if(bC)bC.addEventListener('click',()=>setView('cue'));
  if(bK)bK.addEventListener('click',()=>setView('kar'));
  setView('cue');   /* default: structured cue list; the stage carries the karaoke */
}

/* ---------- boot ---------- */
function boot(){
  const stage=$('vizStage');
  if(!stage)return;
  /* preload every webfont the layer uses — canvas/GL raster text does NOT
     trigger lazy font loading on its own (silent Arial fallback) */
  if(document.fonts&&document.fonts.load){
    ['400 16px "Inter"','600 16px "Inter"','800 16px "Inter"',
     '600 16px "Playfair Display"','900 16px "Playfair Display"','italic 600 16px "Playfair Display"',
     '500 16px "Space Grotesk"','700 16px "Space Grotesk"',
     '400 16px "JetBrains Mono"','700 16px "JetBrains Mono"',
     '400 16px "Archivo Black"','700 16px "Vazirmatn"','900 16px "Vazirmatn"'
    ].forEach(f=>{try{document.fonts.load(f,'Welcome to Audio Studio');}catch(e){}});
  }
  VIZ.onPreset=function(p){
    buildRail();hud();syncPanel();
    if(VIZ.fxSyncPanel)VIZ.fxSyncPanel();   /* v30: FX chips stay truthful */
  };
  VIZ.onRegister=function(){buildRail();};
  VIZ.boot(stage);
  wirePanel();wireTools();wireView();
  buildRail();
  /* first preset: v30 — the modern FX workhorse, systems as fallback */
  Promise.resolve(VIZ.use('viral')).then(function(ok){if(!ok)return VIZ.use('cleankaraoke');});
  /* if subtitles already exist (demo loaded before viz boot), adopt them */
  if(window.__VIZ_PEND_WORDS){
    VIZ.setWords(window.__VIZ_PEND_WORDS,window.__VIZ_PEND_NAME,window.__VIZ_PEND_DUR);
    window.__VIZ_PEND_WORDS=null;
  }
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);
else boot();
window.VIZ=VIZ;
