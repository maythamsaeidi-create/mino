/* ============================================================
   VIZ DOM SYSTEM — typography-driven presets (v27)

   One renderer, five layouts, nine art-directed presets:
     stack   → editorial · cinema · luxury · glass · swiss
     lower   → broadcast · retro
     bubbles → interview
     poster  → poster (kinetic)

   Karaoke = per-word continuous fill (--p 0..1) via
   background-clip:text — never a discrete blink.
   Windowed rendering: only current screen ± context is in the
   DOM, so 10-minute transcripts stay 60fps-cheap.
   ============================================================ */
import VIZ from './core.js';

const FONT={
  sans:"'Inter','SF Pro Text',system-ui,-apple-system,'Segoe UI',Arial,sans-serif",
  serif:"'Playfair Display','Noto Serif',Georgia,'Times New Roman',serif",
  mono:"'JetBrains Mono',ui-monospace,'Cascadia Code',Menlo,Consolas,monospace",
  display:"'Archivo Black','Inter',system-ui,sans-serif",
  grotesk:"'Space Grotesk','Inter','Helvetica Neue',Arial,sans-serif",
  fa:"'Vazirmatn','Inter',system-ui,sans-serif"
};

/* ---------- renderer factory ---------- */
VIZ.domPreset=function(cfg){
  const L=cfg.layoutHint||'stack';
  let host=null,root=null,model=null,params=null,pal=null;
  let viewKey='',cur=null,old=null,spans=[],actEl=null,metaEl=null,trackEl=null,metaMetaEl=null;

  function ensureRoot(){
    if(root)return;
    root=document.createElement('div');
    root.className='vz vz-kar vz-'+cfg.id+(VIZ.REDUCED?' rm':'');
    host.appendChild(root);
    applyPal();
    /* persistent per-preset chrome — above the views, static */
    if(cfg.grain){const g=document.createElement('div');g.className='vz-grain';root.appendChild(g);}
    if(cfg.vignette){const v=document.createElement('div');v.className='vz-vig';root.appendChild(v);}
    if(cfg.live){const b=document.createElement('div');b.className='vz-blive';b.innerHTML='<i></i>LIVE';root.appendChild(b);}
    if(cfg.frame){const f=document.createElement('div');f.className='vz-fr';f.innerHTML='<i></i><i></i><i></i><i></i>';root.appendChild(f);}
  }
  function applyPal(){
    if(!root||!params)return;
    pal=cfg.palettes[params.palette]||cfg.palettes[0];
    const s=root.style;
    s.setProperty('--vBg',pal.bg);
    s.setProperty('--vInk',pal.ink);
    s.setProperty('--vDim',pal.dim);
    s.setProperty('--vDone',pal.done||pal.dim);
    s.setProperty('--vAcc',pal.acc);
    s.setProperty('--vHair',pal.hair||'rgba(128,128,128,.25)');
    s.setProperty('--vSurf',pal.surf||'transparent');
    s.setProperty('--vA',pal.a||pal.acc);
    s.setProperty('--vB',pal.b||pal.acc);
    root.style.setProperty('--vScale',String(params.scale));
    root.style.setProperty('--vM',String(VIZ.REDUCED?0.12:params.motion));
    root.style.setProperty('--vFx',String(params.fx));
    root.style.setProperty('--vF',cfg.font);
    if(cfg.fontFa)root.style.setProperty('--vFa',cfg.fontFa);
    root.dir=(model&&model.rtl)?'rtl':'ltr';
    root.setAttribute('data-fa',model&&model.rtl?'1':'0');
    if(cfg.grain||cfg.vignette)root.classList.add('vz-ovr');
  }

  /* ----- view window: what belongs in the DOM right now ----- */
  function windowOf(st){
    if(!model)return null;
    const m=model;
    if(L==='flow'){
      const WIN=14,idx=Math.max(0,(st.wordIdx<0?0:st.wordIdx)-3);
      return {kind:'flow',from:idx,to:Math.min(m.nWords,idx+WIN),anchor:st.wordIdx};
    }
    if(L==='poster'){
      const i=Math.max(0,st.wordIdx);
      return {kind:'poster',from:i,to:Math.min(m.nWords,i+3),anchor:i};
    }
    const si=st.screenIdx<0?idxOfScreenFor(st):st.screenIdx;
    const s=Math.max(0,(si<0?0:si));
    if(L==='bubbles')return {kind:'bubbles',from:Math.max(0,s-2),to:Math.min(m.screens.length,s+1),anchor:s};
    return {kind:'screen',from:Math.max(0,s-1),to:Math.min(m.screens.length,s+2),anchor:s};
  }
  function idxOfScreenFor(st){
    let best=-1;
    for(let i=0;i<model.screens.length;i++){if(model.screens[i].t0<=st.t)best=i;else break;}
    return best;
  }
  function keyOf(w){return w?w.kind+':'+w.from+':'+w.to+':'+w.anchor:'';}

  /* ----- build the view ----- */
  function wordSpan(w){
    const el=document.createElement('span');
    el.className='vz-w';
    el.dataset.i=String(w._i);
    const t=document.createElement('span');
    t.className='vz-wt';
    t.textContent=w.text||'';
    el.appendChild(t);
    return el;
  }
  function lineEl(words){
    const L=document.createElement('span');
    L.className='vz-line';
    words.forEach(w=>L.appendChild(wordSpan(w)));
    return L;
  }
  function screenEl(sc,role){
    const d=document.createElement('div');
    d.className='vz-scr '+role;
    d.dataset.sp=String(spkIdx(sc));
    if(cfg.speakerTags){
      const t=document.createElement('div');
      t.className='vz-spktag';
      t.innerHTML='<i></i>'+S.esc(sc.speaker||'A');
      d.appendChild(t);
    }
    sc.lines.forEach(lw=>d.appendChild(lineEl(lw)));
    return d;
  }
  function buildView(w,st){
    const m=model;
    const d=document.createElement('div');
    d.className='vz-view vz-'+L;
    if(!w){d.innerHTML='<div class="vz-empty">'+(cfg.empty||'pick audio & generate subtitles — then press play')+'</div>';return d;}
    if(w.kind==='screen'){
      m.screens.slice(w.from,w.to).forEach((sc,i)=>{
        const anchor=sc===m.screens[w.anchor];
        d.appendChild(screenEl(sc,anchor?'is-cur':'is-ctx'));
      });
    }else if(w.kind==='bubbles'){
      m.screens.slice(w.from,w.to).forEach(sc=>{
        const anchor=sc===m.screens[w.anchor];
        const b=document.createElement('div');
        b.className='vz-bub'+(anchor?' is-cur':'')+(anchor?' spk-'+(spkIdx(sc)+0):'');
        b.setAttribute('data-sp',String(spkIdx(sc)));
        const h=document.createElement('div');
        h.className='vz-bub-h';
        h.innerHTML='<i></i>'+S.esc(sc.speaker||'A');
        b.appendChild(h);
        const body=document.createElement('div');
        body.className='vz-bub-b';
        sc.lines.forEach(lw=>body.appendChild(lineEl(lw)));
        b.appendChild(body);
        d.appendChild(b);
      });
    }else if(w.kind==='flow'){
      trackEl=document.createElement('div');
      trackEl.className='vz-track';
      const slice=m.words.slice(w.from,w.to);
      slice.forEach((wd,i)=>{
        if(i%7===3&&i>0&&i<slice.length-1){
          const dot=document.createElement('span');
          dot.className='vz-dot';
          trackEl.appendChild(dot);
        }
        trackEl.appendChild(wordSpan(wd));
      });
      d.appendChild(trackEl);
    }else if(w.kind==='poster'){
      m.words.slice(w.from,w.to).forEach((wd,i)=>{
        const tile=document.createElement('div');
        tile.className='vz-pw'+(i===0?' is-cur':'')+' vzt-'+(i%3);
        tile.dataset.i=String(wd._i);
        tile.textContent=wd.text||'';
        d.appendChild(tile);
      });
    }
    return d;
  }
  function spkIdx(sc){return model.speakers.indexOf(sc.speaker||'A');}

  function metaKickerEl(parent,st){
    const k=document.createElement('div');
    k.className='vz-kick';
    k.innerHTML='<span class="vz-kick-a"></span><span class="vz-kick-b"></span>';
    parent.insertBefore(k,parent.firstChild);
    return k;
  }

  /* ----- render (window changed) ----- */
  function render(st){
    ensureRoot();
    const w=windowOf(st);
    const key=keyOf(w);
    if(key===viewKey&&cur)return;
    viewKey=key;
    if(old){old.remove();old=null;}
    if(cur){cur.classList.add('is-out');old=cur;}
    cur=buildView(w,st);
    root.appendChild(cur);
    spans=[];actEl=null;trackEl=cur.querySelector?cur.querySelector('.vz-track'):null;
    cur.querySelectorAll('.vz-w').forEach(el=>spans.push(el));
    metaEl=null;
    if(cfg.metaMeta!==false){
      const mm=document.createElement('div');
      mm.className='vz-meta';
      cur.appendChild(mm);
      metaMetaEl=mm;
    }else metaMetaEl=null;
    setTimeout(()=>{if(old){old.remove();old=null;}},Math.max(220,VIZ.scaleDur(300,params.motion)));
    classify(st);
    centerFlow();
  }

  function classify(st){
    const wi=st.wordIdx;
    spans.forEach(el=>{
      const i=parseInt(el.dataset.i,10);
      el.classList.toggle('st-act',i===wi);
      el.classList.toggle('st-past',i<wi);
      el.classList.toggle('st-fut',i>wi);
    });
    const tiles=cur.querySelectorAll('.vz-pw');
    tiles.forEach(el=>{
      const i=parseInt(el.dataset.i,10);
      el.classList.toggle('st-act',i===wi);
    });
  }
  function centerFlow(){
    if(!trackEl)return;
    const host=trackEl.closest('.vz-view');
    if(!host)return;
    const act=spans.find(el=>el.classList.contains('st-act'));
    if(!act)return;
    const hw=host.clientWidth;
    const x=act.offsetLeft+act.offsetWidth/2;
    trackEl.style.transform='translateX('+((root.dir==='rtl'?-1:1)*(hw/2-x))+'px)';
  }

  function updateActive(st){
    if(!cur)return;
    if(actEl&&actEl.dataset.i!==String(st.wordIdx)){actEl.style.removeProperty('--p');actEl=null;}
    if(st.wordIdx>=0){
      if(!actEl){
        actEl=spans.find(el=>el.dataset.i===String(st.wordIdx))||null;
        if(!actEl){
          const t=cur.querySelector('.vz-pw.st-act');
          actEl=t||null;
        }
      }
      if(actEl)actEl.style.setProperty('--p',st.wordP.toFixed(4));
    }
  }
  function updateMeta(st){
    if(metaMetaEl&&model){
      const sc=(st.screenIdx>=0&&model.screens[st.screenIdx])||null;
      metaMetaEl.textContent=(sc&&sc.speaker?sc.speaker+' · ':'')+
        tcShort(st.t)+' · '+Math.max(0,st.wordIdx+1)+'/'+model.nWords;
    }
  }
  function tcShort(t){
    t=Math.max(0,t||0);
    const m=Math.floor(t/60),s=Math.floor(t%60),f=Math.floor((t%1)*25);
    return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')+':'+String(f).padStart(2,'0');
  }

  const R={};
  R.mount=function(h){host=h;};
  R.setModel=function(m){model=m;viewKey='';if(root){root.remove();root=null;cur=null;old=null;}};
  R.applyParams=function(p){params=p;if(root){const k=viewKey;viewKey='';applyPal();render(VIZ.state);viewKey=k;}else applyPal();};
  R.resize=function(){centerFlow();};
  R.frame=function(st){
    if(!host)return;
    ensureRoot();
    render(st);
    classify(st);          /* v28: per-frame — within one screen the active
                              word must advance; render() only rebuilds on
                              screen change, so the st-act sweep froze on
                              the word that was live when the screen built */
    if(root)root.classList.toggle('at-rest',!st.playing&&st.wordIdx<0);   /* v28: ready title-card state */
    updateActive(st);
    updateMeta(st);
  };
  R.snapshot=function(){
    if(!VIZ.stage)return null;
    /* DOM → raster via foreignObject-free path: draw stage bg + text
       is unreliable; instead the UI composites over a canvas snapshot
       of the app — here we return null and let ui.js use its own
       DOM-rasterizer (html2canvas-free, draw manual). */
    return VIZ.domSnapshot?VIZ.domSnapshot(cfg,root,pal):null;
  };
  R.dispose=function(){if(root){root.remove();root=null;}host=null;model=null;cur=null;old=null;spans=[];actEl=null;};
  return R;
}
window.VIZ=VIZ;

/* ============================================================
   PRESET DEFINITIONS — nine art directions (DOM family)
   ============================================================ */

/* ---- 1 · MINIMAL EDITORIAL — print-magazine caption block ---- */
VIZ.register({
  id:'editorial',name:'Minimal Editorial',family:'Editorial',engine:'dom',
  concept:'Print-magazine caption block — paper stock, ink hierarchy, one accent, hairline rules. Motion = one quiet 220ms rise.',
  palettes:[
    {name:'Sienna', bg:'#f6f2ea',ink:'#171310',dim:'#8d857a',done:'#5c564f',acc:'#c2410c',hair:'rgba(23,19,16,.22)',surf:'#fffdf8'},
    {name:'Forest', bg:'#f4f3ee',ink:'#141714',dim:'#8b8b83',done:'#575751',acc:'#166534',hair:'rgba(20,23,20,.22)',surf:'#fdfdfa'},
    {name:'Ink Blue',bg:'#f5f4ef',ink:'#14161a',dim:'#8a8c92',done:'#55585f',acc:'#1e40af',hair:'rgba(20,22,26,.22)',surf:'#fdfdf9'}
  ],
  def:{motion:.22,fx:.2},font:FONT.serif,fontFa:FONT.fa,
  make:function(){return VIZ.domPreset(this);},
  layoutHint:'stack',metaKicker:true
});

/* ---- 2 · BROADCAST — network-news lower third ---- */
VIZ.register({
  id:'broadcast',name:'Broadcast',family:'Broadcast',engine:'dom',
  concept:'Network-news lower third — safe-area bar, 600-weight sans, amber word chip sweeps left→right in 160ms. LIVE dot, SMPTE clock.',
  palettes:[
    {name:'Nightly', bg:'#0a0f1c',ink:'#f4f7fc',dim:'#93a0b6',done:'#c6cfdd',acc:'#f5b942',a:'#e0483e',surf:'rgba(15,24,44,.92)',hair:'rgba(255,255,255,.14)'},
    {name:'Sky',     bg:'#071524',ink:'#eef6fd',dim:'#8fa9c0',done:'#c2d5e6',acc:'#4cc3ff',a:'#e0483e',surf:'rgba(10,31,54,.92)',hair:'rgba(255,255,255,.14)'},
    {name:'Graphite',bg:'#0c0c0e',ink:'#f5f5f4',dim:'#9b9ba0',done:'#cfcfd2',acc:'#eab308',a:'#e0483e',surf:'rgba(24,24,27,.92)',hair:'rgba(255,255,255,.13)'}
  ],
  def:{motion:.55,fx:.25},font:FONT.sans,fontFa:FONT.fa,
  make:function(){return VIZ.domPreset(this);},layoutHint:'lower'
});

/* ---- 3 · CINEMATIC — main-on-end title card ---- */
VIZ.register({
  id:'cinema',name:'Cinematic',family:'Cinematic',engine:'dom',
  concept:'Main-on-end title card — letterbox bars, wide-tracked serif caps, gold leaf fills the word in 300ms. Grain and vignette stay under 5%.',
  palettes:[
    {name:'Gold',  bg:'#050505',ink:'#efe6cf',dim:'#786f5d',done:'#b9ad8e',acc:'#e8c877',b:'#f5e6bb',hair:'rgba(239,230,207,.16)'},
    {name:'Steel', bg:'#05070a',ink:'#e7edf4',dim:'#69727d',done:'#aab4c0',acc:'#b9c6d8',b:'#e2ecf7',hair:'rgba(231,237,244,.15)'},
    {name:'Silver',bg:'#060606',ink:'#ececec',dim:'#777777',done:'#c4c4c4',acc:'#dedede',b:'#ffffff',hair:'rgba(236,236,236,.14)'}
  ],
  def:{motion:.3,fx:.35},font:FONT.serif,fontFa:FONT.fa,
  make:function(){return VIZ.domPreset(this);},layoutHint:'stack',grain:true
});

/* ---- 4 · LUXURY — maison title frame ---- */
VIZ.register({
  id:'luxury',name:'Luxury',family:'Luxury',engine:'dom',
  concept:'Maison title frame — hairline frame with corner ticks, light-weight serif display, champagne fills the word slowly (320ms). Nothing else moves.',
  palettes:[
    {name:'Champagne',bg:'#161311',ink:'#ede4d3',dim:'#786f5f',done:'#bfb39c',acc:'#cfab63',b:'#e9d9b2',hair:'rgba(207,171,99,.35)'},
    {name:'Porcelain',bg:'#f2ede4',ink:'#23201c',dim:'#989081',done:'#6c6455',acc:'#8a6a2f',b:'#c7a55c',hair:'rgba(35,32,28,.3)'},
    {name:'Rosé',     bg:'#1a1416',ink:'#f0e4e2',dim:'#8a7a79',done:'#c5b2b0',acc:'#d3a4a4',b:'#eccfcf',hair:'rgba(211,164,164,.35)'}
  ],
  def:{motion:.2,fx:.15},font:FONT.serif,fontFa:FONT.fa,metaMeta:false,
  make:function(){return VIZ.domPreset(this);},layoutHint:'stack',frame:true
});

/* ---- 5 · GLASS — frosted system panels ---- */
VIZ.register({
  id:'glass',name:'Glass',family:'Glass',engine:'dom',
  concept:'Frosted system panel — every word a translucent chip, backdrop-blurred; the active chip gets one light sweep and a 2px lift. Soft, quiet, pro-tool.',
  palettes:[
    {name:'Frost',bg:'radial-gradient(120% 90% at 18% 12%,#eef2f6 0%,#dde5ee 55%,#cfd9e4 100%)',ink:'#1b2330',dim:'rgba(27,35,48,.68)',done:'rgba(27,35,48,.88)',acc:'#0f6dc2',hair:'rgba(255,255,255,.55)',surf:'rgba(255,255,255,.42)'},
    {name:'Slate',bg:'radial-gradient(120% 90% at 20% 10%,#2a3340 0%,#232a33 55%,#1a1f26 100%)',ink:'#eef2f7',dim:'rgba(238,242,247,.62)',done:'rgba(238,242,247,.86)',acc:'#7cc4ff',hair:'rgba(255,255,255,.16)',surf:'rgba(255,255,255,.08)'},
    {name:'Sage', bg:'radial-gradient(120% 90% at 18% 12%,#e9efe6 0%,#dce5d8 55%,#cfd9cb 100%)',ink:'#1c2a20',dim:'rgba(28,42,32,.66)',done:'rgba(28,42,32,.88)',acc:'#2f7d4f',hair:'rgba(255,255,255,.5)',surf:'rgba(255,255,255,.44)'}
  ],
  def:{motion:.45,fx:.3},font:FONT.grotesk,fontFa:FONT.fa,metaMeta:false,
  make:function(){return VIZ.domPreset(this);},layoutHint:'stack',chips:true
});

/* ---- 6 · RETRO — calibrated CRT phosphor ---- */
VIZ.register({
  id:'retro',name:'Analog CRT',family:'Retro',engine:'dom',
  concept:'Calibrated CRT phosphor — one amber hue, 2px scanlines, glow capped at 16px. Words brighten like a tube warming up. No flicker gimmicks.',
  palettes:[
    {name:'Amber',bg:'#140d04',ink:'#ffcb6b',dim:'rgba(255,203,107,.52)',done:'rgba(255,203,107,.78)',acc:'#ffd98a',hair:'rgba(255,203,107,.18)'},
    {name:'Green',bg:'#05130a',ink:'#7cf29a',dim:'rgba(124,242,154,.5)',done:'rgba(124,242,154,.76)',acc:'#a8f7bc',hair:'rgba(124,242,154,.16)'},
    {name:'Paperback',bg:'#f3ead8',ink:'#7a3d10',dim:'rgba(122,61,16,.5)',done:'rgba(122,61,16,.74)',acc:'#9c5219',hair:'rgba(122,61,16,.2)'}
  ],
  def:{motion:.5,fx:.5},font:FONT.mono,fontFa:FONT.fa,
  make:function(){return VIZ.domPreset(this);},layoutHint:'lower',scan:true
});

/* ---- 7 · INTERVIEW — diarized conversation ---- */
VIZ.register({
  id:'interview',name:'Conversation',family:'Interview',engine:'dom',
  concept:'Diarized conversation — speaker bubbles, alternating sides, small-caps labels. Active word underlines in the speaker hue. Past turns recede.',
  palettes:[
    {name:'Studio',bg:'#f5f3ef',ink:'#1c1a17',dim:'#8b867d',done:'#57534c',acc:'#2563eb',b:'#d6336c',hair:'rgba(28,26,23,.16)',surf:'#ffffff'},
    {name:'Dark Booth',bg:'#15171a',ink:'#e8eaed',dim:'#83868c',done:'#b9bdc4',acc:'#60a5fa',b:'#f472b6',hair:'rgba(232,234,237,.12)',surf:'#1f2226'},
    {name:'Terracotta',bg:'#f7f2ec',ink:'#241c15',dim:'#97897c',done:'#615348',acc:'#b45309',b:'#0f766e',hair:'rgba(36,28,21,.16)',surf:'#fffdf9'}
  ],
  def:{motion:.4,fx:.2},font:FONT.sans,fontFa:FONT.fa,metaMeta:false,
  make:function(){return VIZ.domPreset(this);},layoutHint:'stack',speakerTags:true
});

/* ---- 8 · SWISS — geometric grid poster ---- */
VIZ.register({
  id:'swiss',name:'Swiss Geometric',family:'Swiss',engine:'dom',
  concept:'Geometric grid — huge grotesk flush left, red underline grows with the word, index numerals, strict baseline grid. The underline IS the karaoke.',
  palettes:[
    {name:'Classic',bg:'#fafafa',ink:'#101010',dim:'#a0a0a0',done:'#3f3f3f',acc:'#e10600',hair:'rgba(16,16,16,.14)'},
    {name:'Ink',    bg:'#0f0f0f',ink:'#f5f5f5',dim:'#7c7c7c',done:'#c8c8c8',acc:'#ff2d1a',hair:'rgba(245,245,245,.14)'},
    {name:'Cobalt', bg:'#f7f7f4',ink:'#0e0e10',dim:'#9c9c98',done:'#3d3d3a',acc:'#1d4ed8',hair:'rgba(14,14,16,.14)'}
  ],
  def:{motion:.5,fx:.15},font:FONT.grotesk,fontFa:FONT.grotesk,metaMeta:false,
  make:function(){return VIZ.domPreset(this);},layoutHint:'stack',indexNums:true
});

/* ---- 9 · KINETIC POSTER — duotone type machine ---- */
VIZ.register({
  id:'poster',name:'Kinetic Poster',family:'Kinetic',engine:'dom',
  concept:'Duotone type machine — one giant word at a time, spring-overshoot entrance (140ms), −1.5° tilt, riso palette. Beat pop only when audio-react is on.',
  palettes:[
    {name:'Riso',      bg:'#f1e7d3',ink:'#181410',dim:'rgba(24,20,16,.35)',done:'rgba(24,20,16,.6)',acc:'#ff4d2e',hair:'rgba(24,20,16,.2)'},
    {name:'Ultra',     bg:'#0e0c0a',ink:'#f6efe2',dim:'rgba(246,239,226,.34)',done:'rgba(246,239,226,.6)',acc:'#ffe14d',hair:'rgba(246,239,226,.16)'},
    {name:'Vinyl',     bg:'#17141f',ink:'#f0e9ff',dim:'rgba(240,233,255,.35)',done:'rgba(240,233,255,.62)',acc:'#b18cff',hair:'rgba(240,233,255,.16)'}
  ],
  def:{motion:.85,fx:.3},font:FONT.display,fontFa:FONT.display,metaMeta:false,
  make:function(){return VIZ.domPreset(this);},layoutHint:'poster'
});

/* shared snapshot helper is installed by ui.js (canvas raster of stage bg +
   measured text) — DOM presets call back into it. */
