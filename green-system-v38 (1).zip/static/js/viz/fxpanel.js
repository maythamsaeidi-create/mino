/* ============================================================
   fxpanel.js — FX STUDIO panel (v30)

   Modern caption-editor control surface:
     · theme chips, each carrying a LIVE mini preview of its style
     · entrance chips, each looping its own animation
     · 8-way direction pad (the slide demo chip follows it live)
     · one-line switch · position · word/line mode · 3D depth · size
     · tabs: FX Themes  ⇄  Systems (the 16 art-directed presets)
   ============================================================ */
import VIZ from './core.js';
import {FXDIR} from './fx.js';
const S=window.S;
const $=S.$;

const ENTRANCES=[['pop','Pop'],['slide','Slide'],['zoom','Zoom'],['flip','Flip 3D'],
  ['spin','Spin 3D'],['blur','Blur'],['type','Type'],['wave','Wave'],['cut','Cut']];
const PAD=[['nw','↖','from top-left'],['n','↑','from top'],['ne','↗','from top-right'],
  ['w','←','from left'],['c','⊙','in place'],['e','→','from right'],
  ['sw','↙','from bottom-left'],['s','↓','from bottom'],['se','↘','from bottom-right']];
/* 'up' = from bottom (s) · 'down' = from top (n) — legacy aliases */
const DNORM=d=>d==='up'?'s':(d==='down'?'n':d);

/* ---------- theme rail ---------- */
function buildThemes(){
  const host=$('fxThemes');if(!host)return;
  host.innerHTML='';
  VIZ.registry.filter(p=>p.engine==='fx').forEach(p=>{
    const b=S.el('button','fxth');
    b.dataset.id=p.id;
    b.title=p.concept||p.name;
    b.innerHTML='<span class="fxth-p fxth-'+p.id+'"><i>Aa</i><b>Bc</b></span>'
      +'<span class="fxth-n">'+S.esc(p.name)+'</span>';
    b.onclick=()=>{useFxTheme(p);};
    host.appendChild(b);
  });
}

function useFxTheme(p){
  VIZ._lastFx=p.id;
  /* a theme may prefer its own entrance & depth — honoured until the
     user explicitly picks one, then the user's choice wins forever */
  if(p.def&&p.def.entrance&&!VIZ.fxTouchedEntrance)VIZ.params.entrance=p.def.entrance;
  if(p.def&&p.def.depth!=null&&!VIZ.fxTouchedDepth)VIZ.params.depth=p.def.depth;
  const keepScale=VIZ.fxTouchedSize?VIZ.params.scale:null;
  const keepMotion=VIZ.fxTouchedSpeed?VIZ.params.motion:null;
  VIZ.use(p.id).then(ok=>{
    if(!ok)return;
    if(keepScale!=null)VIZ.setParam('scale',keepScale);
    if(keepMotion!=null)VIZ.setParam('motion',keepMotion);
    syncFxPanel();
  });
}

/* ---------- WORD POOL (v31) ----------
   Special words get a distinct FX the moment they are spoken:
   gold emphasis in CSS, a z-pop + GPU particle burst in 3D.
   The pool persists in localStorage across sessions. */
const POOL_KEY='fxPoolV1';
function loadPool(){
  try{const a=JSON.parse(localStorage.getItem(POOL_KEY)||'[]');
    return Array.isArray(a)?a.filter(w=>typeof w==='string'&&w.trim()).slice(0,24):[];}
  catch(e){return[];}
}
function savePool(p){try{localStorage.setItem(POOL_KEY,JSON.stringify(p));}catch(e){}}
function poolMatches(){
  const set=VIZ.fxPoolSet;if(!set||!set.size)return 0;
  let n=0;(VIZ.model&&VIZ.model.words||[]).forEach(w=>{
    if(set.has(VIZ.fxNorm(w.text)))n++;});
  return n;
}
function renderPool(){
  const host=$('fxPoolChips');if(!host)return;
  host.innerHTML='';
  (VIZ.params.pool||[]).forEach(w=>{
    const b=S.el('span','fxtag');
    b.innerHTML='<i></i><b>'+S.esc(w)+'</b>';
    const x=S.el('button');
    x.textContent='×';
    x.title='remove "'+w+'"';
    x.onclick=()=>{addPool(w,true);};
    b.appendChild(x);
    host.appendChild(b);
  });
  if(!(VIZ.params.pool||[]).length){
    host.innerHTML='<span class="fxpool-empty">no special words yet — add one and watch it ignite when spoken</span>';
  }
  updatePoolCount();
}
function updatePoolCount(){
  const c=$('fxPoolCount');if(!c)return;
  const n=(VIZ.params.pool||[]).length;
  c.textContent=n+' word'+(n===1?'':'s')+' · '+poolMatches()+' in this audio';
}
function addPool(w,remove){
  let arr=(VIZ.params.pool||[]).slice();
  const t=String(w||'').trim();
  if(!t)return;
  if(remove)arr=arr.filter(x=>x!==t);
  else{
    if(arr.length>=24){S.toast&&S.toast('Pool is full (24 words) — remove one first',true);return;}
    if(arr.indexOf(t)<0)arr.push(t);
  }
  VIZ.params.pool=arr;
  savePool(arr);
  if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
  if(VIZ.renderer&&VIZ.renderer.applyParams)VIZ.renderer.applyParams(VIZ.params);
  renderPool();
}

/* ---------- panel build + sync ---------- */
function buildChips(){
  const host=$('fxChips');if(!host)return;
  host.innerHTML='';
  ENTRANCES.forEach(pair=>{
    const b=S.el('button','fxchip');
    b.dataset.e=pair[0];
    b.title='entrance: '+pair[1].toLowerCase();
    b.innerHTML='<span class="fxd fxd-'+pair[0]+'">Aa</span><span>'+pair[1]+'</span>';
    b.onclick=()=>{VIZ.fxTouchedEntrance=true;VIZ.setParam('entrance',pair[0]);syncFxPanel();};
    host.appendChild(b);
  });
}
function buildPad(){
  const host=$('fxDir');if(!host)return;
  host.innerHTML='';
  PAD.forEach(item=>{
    const b=S.el('button','');
    b.dataset.d=item[0];
    b.textContent=item[1];
    b.title=item[2];
    b.onclick=()=>{VIZ.setParam('direction',item[0]);syncFxPanel();};
    host.appendChild(b);
  });
}
function setSeg(id,val){
  const seg=$(id);if(!seg)return;
  [].forEach.call(seg.children,b=>b.classList.toggle('on',String(b.dataset.v)===String(val)));
}
function wireSeg(id,cb){
  const seg=$(id);if(!seg)return;
  [].forEach.call(seg.children,b=>{b.onclick=()=>{cb(b.dataset.v);};});
}

function syncFxPanel(){
  const panel=$('fxPanel');if(!panel)return;
  const P=VIZ.params;
  /* the panel carries the direction vars → the SLIDE demo chip loops
     in the CURRENTLY chosen direction, live */
  const d=FXDIR[P.direction]||[0,1];
  panel.style.setProperty('--dx',String(d[0]));
  panel.style.setProperty('--dy',String(d[1]));
  [].forEach.call(panel.querySelectorAll('.fxth'),b=>{
    b.classList.toggle('on',!!(VIZ.current&&VIZ.current.id===b.dataset.id));
  });
  [].forEach.call(panel.querySelectorAll('.fxchip'),b=>{
    b.classList.toggle('on',b.dataset.e===P.entrance);
  });
  [].forEach.call(panel.querySelectorAll('.fxdir button'),b=>{
    b.classList.toggle('on',b.dataset.d===DNORM(P.direction));
  });
  setSeg('fxWmode',P.wmode);
  setSeg('fxPos',P.pos);
  setSeg('fxSize',String(P.scale));
  setSeg('fxEngine',P.engine||'css');
  setSeg('fxEmph',P.emph||'burst');
  const gl=$('fxGlow');if(gl){gl.value=(P.fx!=null?P.fx:0.5);if($('fxGlowV'))$('fxGlowV').textContent=Math.round((P.fx!=null?P.fx:0.5)*100)+'%';}
  const ei=$('fxEmphI');if(ei){ei.value=(P.emphI!=null?P.emphI:0.8);if($('fxEmphIV'))$('fxEmphIV').textContent=Math.round((P.emphI!=null?P.emphI:0.8)*100)+'%';}
  const ol=$('fxOneline');if(ol)ol.checked=!!P.oneline;
  const dp=$('fxDepth');if(dp){dp.value=P.depth;if($('fxDepthV'))$('fxDepthV').textContent=Math.round(P.depth*100)+'%';}
  const sp=$('fxSpeed');if(sp){sp.value=P.motion;if($('fxSpeedV'))$('fxSpeedV').textContent=Math.round(P.motion*100)+'%';}
}

/* ---------- wire everything ---------- */
function wire(){
  buildChips();
  buildPad();
  wireSeg('fxWmode',v=>{VIZ.setParam('wmode',v);syncFxPanel();});
  wireSeg('fxPos',v=>{VIZ.setParam('pos',v);syncFxPanel();});
  wireSeg('fxSize',v=>{VIZ.fxTouchedSize=true;VIZ.setParam('scale',parseFloat(v));syncFxPanel();});
  const ol=$('fxOneline');
  if(ol)ol.addEventListener('change',e=>{VIZ.setParam('oneline',e.target.checked);syncFxPanel();});
  const dp=$('fxDepth');
  if(dp)dp.addEventListener('input',e=>{
    VIZ.fxTouchedDepth=true;
    VIZ.setParam('depth',parseFloat(e.target.value));
    if($('fxDepthV'))$('fxDepthV').textContent=Math.round(e.target.value*100)+'%';
  });
  const sp=$('fxSpeed');
  if(sp)sp.addEventListener('input',e=>{
    VIZ.fxTouchedSpeed=true;
    VIZ.setParam('motion',parseFloat(e.target.value));
    if($('fxSpeedV'))$('fxSpeedV').textContent=Math.round(e.target.value*100)+'%';
  });
  /* v31: engine switch — CSS 2.5D ⇄ real three.js WebGL */
  wireSeg('fxEngine',async v=>{
    const got=await VIZ.setEngine(v);
    syncFxPanel();
    if(got==='3d')S.toast&&S.toast('3D engine live — three.js + GLSL + bloom');
  });
  /* v31: glow (bloom in 3D, shadows in CSS) */
  const gl=$('fxGlow');
  if(gl)gl.addEventListener('input',e=>{
    VIZ.setParam('fx',parseFloat(e.target.value));
    if($('fxGlowV'))$('fxGlowV').textContent=Math.round(e.target.value*100)+'%';
  });
  /* v31: emphasis style + intensity */
  wireSeg('fxEmph',v=>{VIZ.setParam('emph',v);syncFxPanel();});
  const ei=$('fxEmphI');
  if(ei)ei.addEventListener('input',e=>{
    VIZ.setParam('emphI',parseFloat(e.target.value));
    if($('fxEmphIV'))$('fxEmphIV').textContent=Math.round(e.target.value*100)+'%';
  });
  /* v31: word pool add / clear */
  const pin=$('fxPoolIn'),pad=$('fxPoolAdd');
  if(pin){
    pin.addEventListener('keydown',e=>{
      if(e.key==='Enter'){addPool(pin.value);pin.value='';}
    });
  }
  if(pad)pad.onclick=()=>{if(pin){addPool(pin.value);pin.value='';}};
  const pcl=$('fxPoolClear');
  if(pcl)pcl.onclick=()=>{
    VIZ.params.pool=[];savePool([]);
    if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
    if(VIZ.renderer&&VIZ.renderer.applyParams)VIZ.renderer.applyParams(VIZ.params);
    renderPool();
  };
  /* tabs: FX Themes ⇄ Systems */
  const tf=$('fxTabF'),ts=$('fxTabS');
  const setTab=function(fx){
    const fp=$('fxPanel'),spn=$('sysPanel');
    if(fp)fp.classList.toggle('hidden',!fx);
    if(spn)spn.classList.toggle('hidden',fx);
    if(tf)tf.classList.toggle('on',fx);
    if(ts)ts.classList.toggle('on',!fx);
  };
  if(tf)tf.onclick=()=>setTab(true);
  if(ts)ts.onclick=()=>setTab(false);
}

/* ---------- init ---------- */
function init(){
  if(!$('fxPanel'))return;
  /* v31: restore the saved word pool before first render */
  if(!VIZ.params.pool||!VIZ.params.pool.length){
    const saved=loadPool();
    if(saved.length)VIZ.params.pool=saved;
  }
  if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
  VIZ.fxPoolCount=function(){updatePoolCount();};
  VIZ.fxPoolRender=renderPool;
  buildThemes();
  wire();
  renderPool();
  syncFxPanel();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
else init();

/* ui.js calls this from VIZ.onPreset — keeps chips/sliders truthful
   whenever a preset switch happens from anywhere (theme chip, code) */
VIZ.fxSyncPanel=syncFxPanel;
window.VIZ=VIZ;
