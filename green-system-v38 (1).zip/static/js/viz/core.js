/* ============================================================
   VIZ CORE — Subtitle Layer engine (v27)
   Professional karaoke / kinetic-typography presentation layer.

   Design principles encoded here (research synthesis):
   · per-word continuous progress 0..1 (not just on/off)
   · broadcast line discipline (≤2 lines, ≤42 chars, 21 cps aware)
   · one easing family + duration scale per system
   · prefers-reduced-motion respected (motion auto-capped)
   · DPR capped, render paused when hidden, GL contexts disposed
   · renderers are interchangeable modules behind one interface

   Interface every renderer implements:
     mount(host)            — create its surface inside host
     setModel(model)        — new word/line model
     applyParams(params)    — palette/scale/motion/fx/react
     frame(state)           — per-rAF state (called only when visible)
     resize()               — stage geometry changed
     snapshot() → dataURL   — current frame PNG
     dispose()              — release DOM/GL resources
   ============================================================ */
const VIZ={};
window.VIZ=VIZ;

VIZ.version='27';
VIZ.REDUCED=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;

/* motion tokens — one family, four steps; intensity scales them */
VIZ.MO={ease:'cubic-bezier(.22,1,.36,1)',dur:{xs:120,s:180,m:300,l:450}};
VIZ.scaleDur=function(ms,intensity){      // 0=calm →×1.55, 1=live →×0.7
  const k=1.55-0.85*VIZ.clamp(intensity,0,1);
  return Math.round(ms*k);
};

/* ---------- tiny math ---------- */
VIZ.clamp=function(v,a,b){return v<a?a:(v>b?b:v);};
VIZ.lerp=function(a,b,t){return a+(b-a)*t;};
VIZ.smooth=function(t){t=VIZ.clamp(t,0,1);return t*t*(3-2*t);};
VIZ.easeOutCubic=function(t){t=VIZ.clamp(t,0,1);return 1-Math.pow(1-t,3);};
VIZ.easeOutBack=function(t,s){      // gentle overshoot — kinetic presets only
  t=VIZ.clamp(t,0,1);s=(s==null?1.35:s);
  return 1+(s+1)*Math.pow(t-1,3)+s*Math.pow(t-1,2);
};

/* ---------- registry ---------- */
VIZ.registry=[];           // ordered — drives the preset rail
VIZ.presets={};
VIZ.register=function(p){
  if(!p||!p.id||!p.name||!p.make)throw new Error('preset needs id,name,make');
  VIZ.presets[p.id]=p;
  VIZ.registry.push(p);
  if(VIZ.onRegister)VIZ.onRegister(p);
  return p;
};

/* ---------- broadcast-standard model ----------
   words → display lines (≤2 lines per screen, ≤42 chars/line) */
const MAX_LINE=42,MAX_SCREEN=2;

function buildModel(words,srcName,duration){
  const ws=(words||[]).slice().sort((a,b)=>a.startSec-b.startSec||a.endSec-b.endSec);
  if(!ws.length)return null;
  const rtl=/[\u0600-\u06FF\u0750-\u077F]/.test(ws[0].text||'');
  const speakers=[];ws.forEach(w=>{if(w.speaker&&speakers.indexOf(w.speaker)<0)speakers.push(w.speaker);});

  /* screens: greedy pack words; break on sentence end, speaker change,
     long pause (>1.0s), screen budget full */
  const screens=[];let cur=null;
  for(const w of ws){
    const lastTxt=cur&&cur.words.length?cur.words[cur.words.length-1].text:'';
    const sentenceEnd=cur&&cur.words.length>=4&&/[.!?؟…。！？]$/.test(String(lastTxt).trim());
    const gap=cur?(w.startSec-cur.t1)>1.1:false;
    const spkCh=cur&&cur.speaker&&w.speaker&&cur.speaker!==w.speaker;
    const lenCh=cur&&cur.chars+(w.text||'').length+1>MAX_LINE*MAX_SCREEN;
    if(!cur||sentenceEnd||gap||spkCh||lenCh){
      cur={t0:w.startSec,t1:w.endSec,speaker:w.speaker||'',words:[],chars:0,lines:[]};
      screens.push(cur);
    }
    cur.words.push(w);cur.t1=Math.max(cur.t1,w.endSec);
    cur.chars+=(w.text||'').length+(cur.words.length>1?1:0);
  }
  /* split each screen into ≤2 balanced lines (≤42 chars) */
  screens.forEach((sc,si)=>{
    let line=[],chars=0;
    const flush=()=>{if(line.length){sc.lines.push(line);line=[];chars=0;}};
    sc.words.forEach((w,wi)=>{
      const add=(w.text||'').length+(line.length?1:0);
      const isLast=wi===sc.words.length-1;
      if(chars+add>MAX_LINE&&line.length)flush();
      line.push(w);chars+=add;
      if(isLast)flush();
    });
    if(!sc.lines.length)sc.lines.push([]);
  });

  /* flat index words */
  let wi=0;
  ws.forEach(w=>{w._i=wi++;});
  return {words:ws,screens,rtl,speakers,duration:duration||ws[ws.length-1].endSec,
          srcName:srcName||'',nWords:ws.length};
}

/* ---------- audio tap (shared analyser on the app ctx) ---------- */
const S=window.S;
let _an=null,_anF=null,_anT=null;
S.anTap=function(){
  if(!_an){
    const c=S.ctx();
    _an=c.createAnalyser();
    _an.fftSize=1024;_an.smoothingTimeConstant=0.78;
    _an.connect(c.destination);          // passthrough — tapped, not diverted
    _anF=new Uint8Array(_an.frequencyBinCount);
    _anT=new Uint8Array(_an.fftSize);
  }
  return _an;
};
VIZ.audio=function(){
  const out={rms:0,bass:0,mid:0,treble:0,beat:0};
  if(!_an)return out;
  try{
    _an.getByteFrequencyData(_anF);
    _an.getByteTimeDomainData(_anT);
    let sum=0;for(let i=0;i<_anT.length;i+=2){const v=(_anT[i]-128)/128;sum+=v*v;}
    out.rms=Math.sqrt(sum/(_anT.length/2));
    const avg=(a,b)=>{let s=0;for(let i=a;i<b;i++)s+=_anF[i];return s/((b-a)*255);};
    out.bass=avg(1,7);out.mid=avg(8,64);out.treble=avg(65,240);
    out.beat=VIZ.clamp((out.bass-0.45)*2.2,0,1);   // soft beat envelope
  }catch(e){}
  return out;
};

/* ---------- params (art-direction panel state) ---------- */
VIZ.params={palette:0,scale:1,motion:0.5,fx:0.5,react:true};
VIZ.setParam=function(k,v){
  if(!(k in VIZ.params))return;
  VIZ.params[k]=v;
  if(VIZ.renderer&&VIZ.renderer.applyParams)VIZ.renderer.applyParams(VIZ.params);
};

/* ---------- current renderer ---------- */
VIZ.renderer=null;
VIZ.current=null;          // preset meta
VIZ.stage=null;            // host element
VIZ.use=async function(id,keepParams){
  let p=VIZ.presets[id];
  if(!p){                       /* GL presets register when gl.js loads */
    try{await import('./gl.js');}catch(e){}
    p=VIZ.presets[id];
  }
  if(!p)return false;
  if(VIZ.renderer){try{VIZ.renderer.dispose();}catch(e){}VIZ.renderer=null;}
  VIZ.current=p;
  if(!keepParams){VIZ.params.palette=0;VIZ.params.scale=1;VIZ.params.motion=p.def&&p.def.motion!=null?p.def.motion:0.5;
    VIZ.params.fx=p.def&&p.def.fx!=null?p.def.fx:0.5;VIZ.params.react=true;}
  VIZ.hostClear();
  const r=p.make(VIZ.stage);
  VIZ.renderer=r;
  r.mount(VIZ.stage);
  if(VIZ.model)r.setModel(VIZ.model);
  r.applyParams(VIZ.params);
  r.resize();
  if(VIZ.onPreset)VIZ.onPreset(p);
  return true;
};
VIZ.hostClear=function(){
  /* v28: the stage chrome (HUD chips · FRAME/FULL tools) lives inside
     the stage element — a full innerHTML='' wipe deleted them, so the
     buttons vanished after the first preset switch. Clear only the
     renderer surfaces, keep the chrome. */
  if(!VIZ.stage)return;
  [].forEach.call(VIZ.stage.children,function(el){
    if(el.classList&&(el.classList.contains('viz-hud')||el.classList.contains('viz-tools')))return;
    el.remove();
  });
};

/* ---------- model wiring (called by subs.js hook) ---------- */
VIZ.setWords=function(words,srcName,duration){
  VIZ.model=buildModel(words,srcName,duration);
  if(VIZ.renderer&&VIZ.renderer.setModel)VIZ.renderer.setModel(VIZ.model);
  if(VIZ.onModel)VIZ.onModel(VIZ.model);
  return !!VIZ.model;
};

/* ---------- per-frame state ---------- */
VIZ.state={t:0,playing:false,ended:false,wordIdx:-1,screenIdx:-1,lineIdx:-1,
           linePhase:0,wordP:0,audio:{rms:0,bass:0,mid:0,treble:0,beat:0}};

function computeState(){
  const p=window.S&&S._cueP;
  let t=p?p.pos():0;
  t+=(window.S&&S._cueOffset)||0;   /* v28: advanced-settings sync offset */
  const playing=!!(p&&p.playing());
  const st=VIZ.state;
  const m=VIZ.model;
  st.t=t;st.playing=playing;
  if(!m){st.wordIdx=-1;st.screenIdx=-1;st.lineIdx=-1;return;}
  st.ended=(!playing&&p&&p.dur&&t>=p.dur()-0.05);

  /* active word (last word whose start ≤ t) */
  let wi=-1;
  const ws=m.words;
  for(let i=0;i<ws.length;i++){if(ws[i].startSec<=t)wi=i;else break;}
  st.wordIdx=wi;
  if(wi>=0){
    const w=ws[wi];
    st.wordP=VIZ.clamp((t-w.startSec)/Math.max(0.001,w.endSec-w.startSec),0,1);
  }else st.wordP=0;

  /* active screen + line */
  let si=-1;for(let i=0;i<m.screens.length;i++){if(m.screens[i].t0<=t)si=i;else break;}
  if(si>=0&&t>m.screens[si].t1+0.15)si=-1;      // between screens → hold nothing
  st.screenIdx=si;
  let li=-1;
  if(si>=0){
    const sc=m.screens[si];
    let acc=0;
    for(let l=0;l<sc.lines.length;l++){
      const lw=sc.lines[l];
      if(lw.length){
        const stime=lw[0].startSec,etime=lw[lw.length-1].endSec;
        if(t>=stime-0.12){li=l;break;}
      }
    }
    st.lineIdx=li;
    if(li>=0){
      const lw=sc.lines[li];
      const a=lw[0].startSec,b=Math.max(lw[lw.length-1].endSec,a+0.2);
      st.linePhase=VIZ.clamp((t-a)/(b-a),0,1);
    }
  }else st.lineIdx=-1;

  /* audio reactivity (only while playing) */
  if(playing&&VIZ.params.react)st.audio=VIZ.audio();
  else{const a=st.audio;a.rms*=0.9;a.bass*=0.9;a.mid*=0.9;a.treble*=0.9;a.beat*=0.9;}
}

/* ---------- master loop (renders only when visible) ----------
   Bullet-proof: a throwing renderer must NEVER kill the rAF chain.
   After 5 consecutive errors the renderer is quarantined and a
   notice is shown — the rest of the app keeps running. */
let _raf=0,_errs=0;
VIZ.visible=function(){
  const el=VIZ.stage;
  if(!el)return false;
  if(document.hidden)return false;
  return !!(el.offsetParent||el.getClientRects().length);
};
function loop(){
  cancelAnimationFrame(_raf);
  (function tick(){
    computeState();
    if(VIZ.renderer&&VIZ.visible()){
      try{
        VIZ.renderer.frame(VIZ.state);
        _errs=0;
      }catch(e){
        _errs++;
        if(console&&console.warn)console.warn('[viz] renderer error ('+_errs+'):',e&&e.message||e);
        if(_errs>=5&&VIZ.renderer&&VIZ.renderer.quarantine){
          try{VIZ.renderer.quarantine();}catch(e2){}
        }
      }
    }
    _raf=requestAnimationFrame(tick);
  })();
}

/* ---------- boot ---------- */
VIZ.boot=function(stageEl){
  VIZ.stage=stageEl;
  /* v28: renderers size their surface ONCE at mount. If the stage was
     hidden at mount time (Subtitles tab not open yet) the rect is 0×0,
     the canvas keeps its 300×150 default backing and the browser
     upscales it ~3.3× → heavy blur. Watch the stage box and re-run
     renderer.resize() whenever it actually changes. */
  if(window.ResizeObserver&&!VIZ._ro){
    VIZ._ro=new ResizeObserver(function(){
      if(VIZ.renderer&&VIZ.renderer.resize){
        try{VIZ.renderer.resize();}catch(e){}
      }
    });
    VIZ._ro.observe(stageEl);
  }
  loop();
};
VIZ.snapshot=function(){
  if(VIZ.renderer&&VIZ.renderer.snapshot)return VIZ.renderer.snapshot();
  return null;
};

/* ---------- quality gates ---------- */
VIZ.gate={
  minFont:15,                       // px on stage — readability floor
  dprCap:2,
  contrast:function(hex1,hex2){     // dev-time check helper for palettes
    const L=h=>{const c=parseInt(h.slice(1),16);
      const f=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);};
      return 0.2126*f(c>>16&255)+0.7152*f(c>>8&255)+0.0722*f(c&255);};
    const a=L(hex1),b=L(hex2);
    return (Math.max(a,b)+0.05)/(Math.min(a,b)+0.05);
  }
};

export default VIZ;
window.VIZ=VIZ;
