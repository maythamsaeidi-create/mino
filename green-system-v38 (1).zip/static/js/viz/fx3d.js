/* ============================================================
   fx3d.js — FX STUDIO 3D ENGINE (v31)

   Real three.js r169 + custom GLSL — the FX themes rendered as
   actual 3D objects, not CSS transforms:

   · words = canvas-glyph planes with a custom GLSL material
     (karaoke fill sweep · gradient lit · ember flicker · chroma
     fringe · scanlines · emphasis wash)
   · REAL extrusion: a depth-stack of planes baked into one
     geometry; vZ varying shades each slice → solid 3D sides
   · UnrealBloomPass post chain per theme (neon/fire/hacker glow)
   · entrance motion in 3D space: slide 8-way · flip rotateX ·
     spin rotateY · zoom/pop scale · wave stagger · type reveal
   · WORD POOL: the live pool word pops toward the camera, turns
     gold and fires a GPU particle burst (custom point shader)
   · one-line mode: whole screen in a single auto-fitted row
   · RTL mirrored layout + reversed fill sweep (Persian etc.)
   · theme background recreated as a GLSL gradient quad
   · DPR cap 1.75 · full disposal + context release on switch

   Same renderer interface as fxCaption — core.js mounts it
   through the engine switch (VIZ.setEngine('3d')).
   ============================================================ */
import * as THREE from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import VIZ from './core.js';

const S=window.S;
const NORM=VIZ.fxNorm||(w=>String(w||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,''));

/* ---------- per-theme 3D art direction ----------
   extr  : max extrusion slices (scaled by the 3D depth slider)
   grad  : vertical gradient on the lit fill (lit → accB)
   ember : fire flicker in the shader
   chroma: RGB fringe strength (vhs / y2k)
   scan  : CRT scanlines
   glowM : bloom multiplier (neon burns, broadcast stays sober)
   chip  : word = per-word accent chip · line = whole-row chip ·
           glass = frosted panel behind the screen
   tilt  : how much the 3D depth slider tilts the stage
   pop   : active-word z-pop amount
   w     : canvas raster weight */
const STY={
  viral:   {extr:5,grad:0,ember:0,chroma:0,scan:0,glowM:.65,chip:'word', tilt:.45,pop:.16,w:900},
  neon:    {extr:0,grad:0,ember:0,chroma:0,scan:0,glowM:1.9,chip:0,     tilt:.22,pop:.10,w:700},
  chrome3d:{extr:6,grad:1,ember:0,chroma:0,scan:0,glowM:.55,chip:'word', tilt:.6, pop:.12,w:900},
  fire:    {extr:3,grad:1,ember:1,chroma:0,scan:0,glowM:.9, chip:0,     tilt:.3, pop:.12,w:900},
  candy:   {extr:0,grad:1,ember:0,chroma:0,scan:0,glowM:.5, chip:'line',tilt:.22,pop:.14,w:800},
  boxc:    {extr:0,grad:0,ember:0,chroma:0,scan:0,glowM:.3, chip:'line',tilt:.15,pop:.08,w:600},
  hacker:  {extr:0,grad:0,ember:0,chroma:0,scan:1,glowM:.9, chip:0,     tilt:.15,pop:.07,w:500},
  y2k:     {extr:3,grad:1,ember:0,chroma:.5,scan:0,glowM:1.0,chip:'word',tilt:.35,pop:.14,w:900},
  vhs:     {extr:0,grad:0,ember:0,chroma:1,scan:1,glowM:.45,chip:0,     tilt:.15,pop:.08,w:700},
  aurora:  {extr:0,grad:0,ember:0,chroma:0,scan:0,glowM:.55,chip:'glass',tilt:.22,pop:.09,w:600}
};

/* ---------- GLSL: the word material ---------- */
const WORD_VS=`
varying vec2 vUv;varying float vZ;
void main(){vUv=uv;vZ=position.z;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`;
const WORD_FS=`
uniform sampler2D uMap;
uniform vec3 uLit,uUnlit,uAccB,uEmphC;
uniform float uFill,uFillDir,uIn,uEmph,uGrad,uDarkK,uEmber,uChroma,uScan,uTime,uGap;
varying vec2 vUv;varying float vZ;
void main(){
  vec2 uv=vUv;
  float a=texture2D(uMap,uv).a;
  if(a<0.02)discard;
  a*=uIn;
  float depth=clamp(-vZ/max(uGap,0.0001),0.0,1.0);   /* extrusion slice # */
  float cut=(uFillDir>0.0)?uv.x:(1.0-uv.x);          /* karaoke sweep     */
  vec3 col=(cut<uFill)?uLit:uUnlit;
  if(uGrad>0.001&&cut<uFill)col=mix(uLit,uAccB,clamp(1.0-uv.y,0.0,1.0)*0.85);
  if(uEmber>0.001&&cut<uFill)col*=1.0+uEmber*(0.5+0.5*sin(uTime*5.5+uv.x*9.0+depth*2.0));
  /* word-pool emphasis: gold wash + punch */
  col=mix(col,uEmphC,uEmph*0.8);
  col*=1.0+uEmph*1.15;
  col*=1.0-uDarkK*depth;                             /* darker 3D sides   */
  if(uChroma>0.001){
    vec2 o=vec2(uChroma*0.012,0.0);
    float r=texture2D(uMap,uv+o).a;
    float b=texture2D(uMap,uv-o).a;
    col+=vec3(r*a,0.0,b*a)*uChroma*0.55;
  }
  if(uScan>0.001)col*=1.0-uScan*0.5*(0.5+0.5*sin(uv.y*300.0+depth*20.0));
  gl_FragColor=vec4(col,a);
}`;

/* ---------- GLSL: rounded-rect chips (word / line / glass) ---------- */
const CHIP_VS=`varying vec2 vUv;void main(){vUv=uv;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`;
const CHIP_FS=`
uniform vec3 uCol;uniform float uOp,uR;
varying vec2 vUv;
float sdRound(vec2 p,vec2 b,float r){vec2 d=abs(p)-b+r;
  return length(max(d,0.0))+min(max(d.x,d.y),0.0)-r;}
void main(){
  vec2 p=vUv-0.5;
  float d=sdRound(p,vec2(0.5-0.015),uR);
  float a=smoothstep(0.004,-0.004,d)*uOp;
  if(a<0.01)discard;
  gl_FragColor=vec4(uCol,a);}`;

/* ---------- GLSL: theme background gradient quad ---------- */
const BG_VS=CHIP_VS;
const BG_FS=`
uniform vec3 uC0,uC1,uC2;uniform vec2 uC;uniform float uRadial;
varying vec2 vUv;
void main(){
  float t;
  if(uRadial>0.5){t=clamp(distance(vUv,uC)/0.75,0.0,1.0);}
  else{t=clamp(1.0-vUv.y,0.0,1.0);}
  vec3 c=mix(uC0,uC1,smoothstep(0.0,0.55,t));
  c=mix(c,uC2,smoothstep(0.55,1.0,t));
  gl_FragColor=vec4(c,1.0);}`;

/* ---------- GLSL: emphasis particle burst ---------- */
const PT_VS=`
attribute float aSeed;
uniform float uLife;
varying float vA;
void main(){
  vA=clamp(1.0-uLife,0.0,1.0);
  vec4 mv=modelViewMatrix*vec4(position,1.0);
  float sz=(8.0+aSeed*10.0)*vA;
  gl_PointSize=sz*(8.0/max(1.0,-mv.z));
  gl_Position=projectionMatrix*mv;
}`;
const PT_FS=`
uniform vec3 uCol;uniform float uLife;
varying float vA;
void main(){
  vec2 p=gl_PointCoord-0.5;
  float d=length(p);
  float a=smoothstep(0.5,0.05,d)*vA*vA;
  if(a<0.02)discard;
  gl_FragColor=vec4(uCol*(1.4+vA),a);
}`;

/* ---------- helpers ---------- */
function col(hex,def){try{return new THREE.Color(hex||def||'#ffffff');}catch(e){return new THREE.Color(def||'#ffffff');}}
function parseBg(css){
  const s=String(css||'');
  const hexes=(s.match(/#[0-9a-fA-F]{3,8}/g)||['#0b0f18','#0b0f18']).map(h=>col(h));
  const radial=/radial-gradient/.test(s)?1:0;
  let cx=.5,cy=.5;
  const m=s.match(/at\s+([0-9.]+)%\s+([0-9.]+)%/);
  if(m){cx=m[1]/100;cy=1-m[2]/100;}
  return {c0:hexes[0],c1:hexes[1]||hexes[0],c2:hexes[2]||hexes[1]||hexes[0],radial,cx,cy};
}
/* merge N z-translated planes into ONE geometry (real extrusion,
   one draw call per word) */
function extrudeGeometry(w,h,layers,gap){
  const base=new THREE.PlaneGeometry(w,h);
  if(layers<=0){base.deleteAttribute('normal');return base;}
  const pos=[],uv=[],idx=[];
  const bp=base.attributes.position,bu=base.attributes.uv,bi=base.index;
  const stride=bp.count;
  for(let k=0;k<=layers;k++){
    for(let i=0;i<stride;i++){
      pos.push(bp.getX(i),bp.getY(i),-k*gap);
      uv.push(bu.getX(i),bu.getY(i));
    }
    for(let i=0;i<bi.count;i++)idx.push(bi.getX(i)+k*stride);
  }
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  g.setIndex(idx);
  base.dispose();
  return g;
}
function raster(text,fontCSS,pad){
  const c=document.createElement('canvas');
  const x=c.getContext('2d',{willReadFrequently:false});
  x.font=fontCSS;
  const w=Math.max(8,Math.ceil(x.measureText(text).width)+pad*2);
  const h=Math.ceil(120);
  c.width=w;c.height=h;
  x.font=fontCSS;
  x.fillStyle='#fff';
  x.textBaseline='middle';
  x.fillText(text,pad,h/2);
  return c;
}

/* ============================================================ */
VIZ.fx3dCaption=function(cfg){
  const ST=STY[cfg.id]||STY.viral;
  const POOLC=new THREE.Color('#fde047');
  let host=null,model=null,params=null,theme=null;
  let renderer=null,scene=null,camera=null,composer=null,bloom=null;
  let bgMesh=null,wordsGroup=null,wordObjs=[],chips=[],unders=[];
  let ptGeo=null,ptMat=null,ptPoints=null,ptVel=null,ptSpawn=0,ptActive=false;
  let builtKey='',lastScr=-1,W=0,H=0,ok=false,fitScale=1;
  let emphWords=new Set(),prevWi=-1,burstWi=-1;
  const dbg={bursts:0,rows:0,draws:0};

  /* color cache (recomputed on theme/param apply) */
  const C={};
  function cacheColors(){
    const t=theme||cfg.theme;
    C.ink=col(t.ink,'#ffffff');
    C.dim=col(t.dim,'rgba(255,255,255,.55)');
    C.done=col(t.done||t.dim,'#cccccc');
    C.acc=col(t.acc,'#34d399');
    C.accB=col(t.accB||t.acc,'#14b8a6');
    C.inkB=new THREE.Color('#101010');
    C.emph=POOLC.clone();
    C.chip=col(t.acc,'#ccff00');
  }
  function fontCSS(){
    const t=theme||cfg.theme;
    const fam=(model&&model.rtl&&t.fontFa)?t.fontFa:(t.font||"'Inter',sans-serif");
    return ST.w+' 96px '+fam;
  }
  function gapNow(){return 0.035+((params&&params.depth)||0)*0.055;}
  function layersNow(){return Math.round(((params&&params.depth)||0.35)*ST.extr);}

  /* ---------- GL setup ---------- */
  function ensure(){
    if(renderer)return true;
    if(!host)return false;
    try{
      renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,
        powerPreference:'high-performance',preserveDrawingBuffer:true});
    }catch(e){return false;}
    const DPR=Math.min(1.75,window.devicePixelRatio||1);
    renderer.setPixelRatio(DPR);
    renderer.domElement.className='vzfx3d-canvas';
    scene=new THREE.Scene();
    camera=new THREE.PerspectiveCamera(38,16/9,0.1,100);
    camera.position.set(0,0,8);
    composer=new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene,camera));
    bloom=new UnrealBloomPass(new THREE.Vector2(1280,720),0.6,0.55,0.5);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());
    host.appendChild(renderer.domElement);
    wordsGroup=new THREE.Group();
    scene.add(wordsGroup);
    initParticles();
    bgMesh=new THREE.Mesh(new THREE.PlaneGeometry(20,11.4),new THREE.ShaderMaterial({
      vertexShader:BG_VS,fragmentShader:BG_FS,depthWrite:false,
      uniforms:{uC0:{value:new THREE.Color()},uC1:{value:new THREE.Color()},
        uC2:{value:new THREE.Color()},uC:{value:new THREE.Vector2(.5,.5)},
        uRadial:{value:1}}
    }));
    bgMesh.position.z=-7;
    bgMesh.renderOrder=-10;
    scene.add(bgMesh);
    ok=true;
    doResize();
    applyBG();          /* v31 fix: theme colors NOW — Color() defaults to white! */
    dbg.scene=scene;dbg.renderer=renderer;dbg.camera=camera;dbg.group=wordsGroup;dbg.bg=bgMesh;
    return true;
  }
  function doResize(){
    if(!renderer||!host)return;
    const w=host.clientWidth||640,h=host.clientHeight||360;
    W=w;H=h;
    renderer.setSize(w,h,false);
    composer.setSize(w,h);
    camera.aspect=w/h;
    camera.updateProjectionMatrix();
  }

  /* ---------- particles ---------- */
  const PN=110;
  function initParticles(){
    ptGeo=new THREE.BufferGeometry();
    const pos=new Float32Array(PN*3);
    const seed=new Float32Array(PN);
    for(let i=0;i<PN;i++)seed[i]=Math.random();
    ptGeo.setAttribute('position',new THREE.BufferAttribute(pos,3));
    ptGeo.setAttribute('aSeed',new THREE.BufferAttribute(seed,1));
    ptVel=new Float32Array(PN*3);
    ptMat=new THREE.ShaderMaterial({
      vertexShader:PT_VS,fragmentShader:PT_FS,
      transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
      uniforms:{uLife:{value:1},uCol:{value:POOLC.clone()}}
    });
    ptPoints=new THREE.Points(ptGeo,ptMat);
    ptPoints.visible=false;
    ptPoints.frustumCulled=false;
    scene.add(ptPoints);
  }
  function fireBurst(wx,wy,wz){
    if(!ptGeo)return;
    const p=ptGeo.attributes.position.array;
    for(let i=0;i<PN;i++){
      p[i*3]=wx;p[i*3+1]=wy;p[i*3+2]=wz+0.05;
      const th=Math.random()*Math.PI*2;
      const ph=(Math.random()-0.5)*Math.PI;
      const sp=1.3+Math.random()*1.5;
      ptVel[i*3]=Math.cos(th)*Math.cos(ph)*sp;
      ptVel[i*3+1]=Math.sin(ph)*sp*1.15+0.55;
      ptVel[i*3+2]=Math.sin(th)*Math.cos(ph)*sp*0.55;
    }
    ptGeo.attributes.position.needsUpdate=true;
    ptSpawn=performance.now();
    ptActive=true;
    ptPoints.visible=true;
    dbg.bursts++;
  }
  function stepParticles(dt){
    if(!ptActive||!ptGeo)return;
    const life=(performance.now()-ptSpawn)/700;
    ptMat.uniforms.uLife.value=Math.min(1,life);
    if(life>=1){ptActive=false;ptPoints.visible=false;return;}
    const p=ptGeo.attributes.position.array;
    for(let i=0;i<PN;i++){
      p[i*3]+=ptVel[i*3]*dt;
      p[i*3+1]+=ptVel[i*3+1]*dt;
      p[i*3+2]+=ptVel[i*3+2]*dt;
      ptVel[i*3+1]-=2.4*dt;
    }
    ptGeo.attributes.position.needsUpdate=true;
  }

  /* ---------- word construction ---------- */
  function wordMaterial(tex){
    return new THREE.ShaderMaterial({
      vertexShader:WORD_VS,fragmentShader:WORD_FS,
      transparent:true,depthWrite:false,side:THREE.DoubleSide,
      uniforms:{
        uMap:{value:tex},
        uLit:{value:new THREE.Color()},uUnlit:{value:new THREE.Color()},
        uAccB:{value:new THREE.Color()},uEmphC:{value:POOLC.clone()},
        uFill:{value:0},uFillDir:{value:1},uIn:{value:0},uEmph:{value:0},
        uGrad:{value:ST.grad||0},uDarkK:{value:0.3},uEmber:{value:ST.ember||0},
        uChroma:{value:ST.chroma||0},uScan:{value:ST.scan||0},
        uTime:{value:0},uGap:{value:gapNow()}
      }
    });
  }
  function chipMaterial(cHex,op){
    return new THREE.ShaderMaterial({
      vertexShader:CHIP_VS,fragmentShader:CHIP_FS,
      transparent:true,depthWrite:false,
      uniforms:{uCol:{value:col(cHex,'#0a0c10')},uOp:{value:op||1},uR:{value:0.12}}
    });
  }
  function disposeWords(){
    wordObjs.forEach(o=>{
      if(o.mesh.parent)wordsGroup.remove(o.mesh);
      o.mesh.geometry.dispose();
      o.mat.uniforms.uMap.value.dispose();
      o.mat.dispose();
      if(o.chip){if(o.chip.parent)wordsGroup.remove(o.chip);o.chip.geometry.dispose();o.chip.material.dispose();}
    });
    chips.forEach(c=>{if(c.mesh.parent)wordsGroup.remove(c.mesh);
      c.mesh.geometry.dispose();c.mesh.material.dispose();});
    unders.forEach(u=>{if(u.mesh.parent)wordsGroup.remove(u.mesh);
      u.mesh.geometry.dispose();u.mesh.material.dispose();});
    wordObjs=[];chips=[];unders=[];
  }
  function buildRest(){
    disposeWords();
    const t=theme||cfg.theme;
    const big=wordMesh(cfg.name||'FX',ST.w+' 96px '+(t.font||"'Inter',sans-serif"),0.62,0);
    const small=wordMesh('pick audio · generate · press play','700 96px "JetBrains Mono",Menlo,monospace',0.16,0);
    if(big){big.mesh.position.set(0,0.16,0);big.baseX=0;big.baseY=0.16;big.i=null;wordObjs.push(big);}
    if(small){small.mesh.position.set(0,-0.28,0);small.baseX=0;small.baseY=-0.28;small.i=null;wordObjs.push(small);}
    big.mat.uniforms.uLit.value.copy(C.dim);
    big.mat.uniforms.uUnlit.value.copy(C.dim);
    big.mat.uniforms.uFill.value=1;big.mat.uniforms.uIn.value=1;
    small.mat.uniforms.uLit.value.copy(C.dim);
    small.mat.uniforms.uUnlit.value.copy(C.dim);
    small.mat.uniforms.uFill.value=1;small.mat.uniforms.uIn.value=1;
  }
  function wordMesh(text,font,worldH,pad){
    const cv=raster(text,font,14);
    const tex=new THREE.CanvasTexture(cv);
    tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;
    const asp=cv.width/cv.height;
    const mat=wordMaterial(tex);
    const geo=extrudeGeometry(asp*worldH,worldH,layersNow(),gapNow());
    const mesh=new THREE.Mesh(geo,mat);
    wordsGroup.add(mesh);
    return {mesh,mat,w:asp*worldH,h:worldH,text};
  }
  function chipPlane(w,h,cHex,op,r){
    const g=new THREE.PlaneGeometry(w,h);
    const m=chipMaterial(cHex,op);
    m.uniforms.uR.value=r==null?0.12:r;
    const mesh=new THREE.Mesh(g,m);
    wordsGroup.add(mesh);
    return mesh;
  }
  /* underline: geometry anchored at its left (or right for RTL) edge */
  function underPlane(){
    const g=new THREE.PlaneGeometry(1,0.055);
    if(model&&model.rtl)g.translate(-0.5,0,0);else g.translate(0.5,0,0);
    const m=chipMaterial('#34d399',1,0.028);
    const mesh=new THREE.Mesh(g,m);
    wordsGroup.add(mesh);
    return mesh;
  }

  /* ---------- screen build + layout ---------- */
  function holdIdx(st){
    let b=-1;const sc=model.screens;
    for(let i=0;i<sc.length;i++){if(sc[i].t0<=st.t)b=i;else break;}
    return b;
  }
  function buildScreen(sc,rest){
    disposeWords();
    const P=params;
    const worldH=0.6*Math.max(0.85,P.scale||1);
    let lines;
    if(!sc){buildRest();return;}
    lines=P.oneline?[sc.lines.reduce((a,b)=>a.concat(b),[])]:sc.lines;
    dbg.rows=lines.length;
    const rtl=!!(model&&model.rtl);
    const maxW=8.5;
    let y0;
    const rowH=worldH*1.05;
    if(P.pos==='center')y0=(lines.length-1)*0.5*rowH;              /* centered block */
    else y0=-0.95+(lines.length-1)*rowH;    /* bottom: last row at y=-0.95 (three: -y = down) */
    /* row chips first (behind words) */
    let maxRowW=0;
    lines.forEach((lw,li)=>{
      const meshes=lw.map(w=>wordMesh(String(w.text||''),fontCSS(),worldH,14));
      const total=meshes.reduce((a,m)=>a+m.w+0.16,0)-0.16;
      maxRowW=Math.max(maxRowW,total);
      let x=-total/2;
      meshes.forEach((m,mi)=>{
        m.i=lw[mi]._i;
        m.startSec=lw[mi].startSec;
        m.endSec=lw[mi].endSec;
        m.baseX=x+m.w/2;
        if(rtl)m.baseX=-(x+m.w/2);      /* RTL: first word sits on the RIGHT */
        m.baseY=y0-li*rowH;
        m.inProg=rest?1:0;
        m.emph=0;
        m.wid=mi;
        m.rtl=rtl;
        m.mesh.position.set(m.baseX,m.baseY,0);
        wordObjs.push(m);
        x+=m.w+0.16;
      });
      if(ST.chip==='line'||ST.chip==='glass'){
        const isGlass=ST.chip==='glass';
        const cw=Math.min(maxW,total+worldH*1.1);
        const ch=worldH*(isGlass?2.5:1.55);
        const c=chipPlane(cw,ch,isGlass?'#ffffff':'rgba(8,10,14,.9)',
          isGlass?0.085:0.72,isGlass?0.09:0.3);
        c.position.set(0,meshes[0]?meshes[0].baseY:0,-0.06);
        chips.push({mesh:c});
      }
      /* word chips for box themes */
      if(ST.chip==='word'){
        meshes.forEach(m=>{
          const c=chipPlane(m.w*1.14+0.1,worldH*1.3,'#ccff00',1,0.1);
          c.material.uniforms.uCol.value.copy(C.chip);
          c.position.set(m.baseX,m.baseY,-0.012);
          c.visible=false;
          m.chip=c;
        });
      }
      /* underline for hl==='under' themes */
      if(cfg.hl==='under'){
        meshes.forEach(m=>{
          const u=underPlane();
          u.material.uniforms.uCol.value.copy(C.acc);
          u.material.uniforms.uR.value=0.028;
          u.position.set(m.baseX-m.w/2,m.baseY-worldH*0.66,0.005);
          u.scale.x=0.001;
          m.under=u;
          unders.push({mesh:u});
        });
      }
    });
    /* whole-screen fit — one-line mode and long rows shrink to the stage */
    fitScale=Math.max(0.42,Math.min(1,maxW/Math.max(0.001,maxRowW)));
  }

  /* ---------- per-frame ---------- */
  const easePop=VIZ.easeOutBack;
  function frame(st){
    if(!host)return;
    if(!ensure())return;
    const t=st.t,P=params,m=model;
    /* screen pick (same semantics as the CSS engine) */
    let si=-1,sc=null,rest=false;
    if(m){
      si=st.screenIdx;
      if(si<0&&!st.playing&&st.t<=0.01){si=holdIdx(st);rest=true;}
      if(si>=0&&si<m.screens.length)sc=m.screens[si];
      if(si>=0&&sc&&!rest)rest=!st.playing&&st.t<=0.01;
    }
    const key=(m?(sc?'s'+si:'gap'):'rest')+'|'+(P.wmode)+':'+(P.oneline?1:0)+':'+(P.pos)
      +':'+(P.scale)+':'+(layersNow())+':'+(gapNow().toFixed(3));
    if(key!==builtKey){
      builtKey=key;
      if(m&&sc)buildScreen(sc,rest);
      else if(!m)buildScreen(null,rest);
      else disposeWords();
    }
    lastScr=si;

    /* stage transforms: tilt (3D depth) + reactive pulse */
    const d=P.depth||0;
    wordsGroup.rotation.x=-d*0.55*ST.tilt;
    const beat=(P.react&&st.playing)?st.audio.beat:0;
    wordsGroup.scale.setScalar(fitScale*(1+beat*0.03));

    /* per-word state */
    const wi=st.wordIdx;
    const dur=(VIZ.scaleDur(P.wmode==='word'?250:420,P.motion)/1000);
    const e=P.entrance||'pop';
    const dir=VIZ.params.direction||'s';
    const DV={n:[0,-1],ne:[1,-1],e:[1,0],se:[1,1],s:[0,1],sw:[-1,1],w:[-1,0],nw:[-1,-1],c:[0,0]};
    const dv=DV[dir]||DV.s;
    const tNow=performance.now()/1000;
    const jit=(cfg.id==='vhs')?1:0;
    const rtlDir=(model&&model.rtl)?-1:1;
    wordObjs.forEach(o=>{
      const mm=o.mesh,u=o.mat.uniforms;
      const i=o.i==null?-1:o.i;
      /* entrance progress */
      let ip=o.inProg;
      if(sc&&m){
        const startT=P.wmode==='line'?(sc.t0-0.02):((o.startSec!=null)?o.startSec-0.02:sc.t0-0.02);
        ip=rest?1:VIZ.clamp((t-startT)/Math.max(0.05,dur),0,1);
      }else ip=1;
      o.inProg=ip;
      /* word state: 0 future · 1 active · 2 past */
      const state=(i<0)?1:(i<wi?2:(i===wi?1:0));
      /* pool emphasis envelope */
      const isPool=emphWords.size&&o.text&&emphWords.has(NORM(o.text));
      const tgt=(state===1&&isPool)?1:0;
      o.emph+= (tgt-o.emph)*0.22;
      if(o.emph<0.004)o.emph=0;
      /* colors by state */
      if(state===1){
        u.uLit.value.copy((ST.chip==='word')?C.inkB:C.acc);
        u.uUnlit.value.copy(C.dim);
        u.uFill.value=(P.wmode==='line')?1:st.wordP;
      }else if(state===2){
        u.uLit.value.copy(C.ink);u.uUnlit.value.copy(C.done);u.uFill.value=1;
      }else{
        u.uLit.value.copy(C.ink);u.uUnlit.value.copy(C.dim);u.uFill.value=0;
      }
      if(!m){u.uLit.value.copy(C.dim);u.uUnlit.value.copy(C.dim);u.uFill.value=1;}
      u.uIn.value=ip;
      u.uEmph.value=o.emph;
      u.uTime.value=tNow;
      u.uFillDir.value=rtlDir;
      u.uGap.value=gapNow();
      u.uDarkK.value=(ST.darkK!=null?ST.darkK:0.32)*(0.55+0.85*d);
      /* transforms — entrance in 3D space */
      const k=easePop(ip);
      const kS=VIZ.smooth(ip);
      let px=o.baseX||0,py=o.baseY||0,rz=0,rx=0,ry=0,scl=1;
      if(sc&&ip<1){
        px+=(dv[0]!==0||dv[1]!==0)?dv[0]*1.55*(1-kS):0;
        py+=(dv[0]!==0||dv[1]!==0)?dv[1]*1.05*(1-kS):0;
        if(e==='flip')rx=(1-kS)*-1.55;
        if(e==='spin')ry=(1-kS)*-2.0;
        if(e==='zoom'||e==='pop')scl=0.3+0.7*k;
        if(e==='blur')scl=0.8+0.2*kS;
        if(e==='wave'){py+=(1-kS)*-0.35;rz=(1-kS)*(o.wid%2?4:-4)*Math.PI/180;}
      }else if(sc&&ip>=1){
        /* active word pop + pool pop toward camera */
        const actA=state===1?VIZ.easeOutBack(VIZ.clamp((t-((o.startSec!=null)?o.startSec:sc.t0))/0.3,0,1)):0;
        scl=1+ST.pop*actA+0.2*o.emph;
      }
      if(e==='type'&&state!==0&&ip<1){u.uIn.value=1;}
      /* vhs tracking jitter on the live word */
      if(jit&&state===1&&st.playing){
        px+=Math.sin(tNow*37.0)*0.006;
        py+=Math.cos(tNow*29.0)*0.005;
      }
      /* pool: pop toward the camera */
      mm.position.set(px,py,(o.emph*0.55*(P.emphI!=null?P.emphI:0.8)));
      mm.rotation.set(rx,ry,rz);
      mm.scale.setScalar(scl);
      /* word chip follows its word */
      if(o.chip){
        const vis=state===1&&ip>0.2;
        o.chip.visible=vis;
        if(vis){
          o.chip.position.copy(mm.position);
          o.chip.position.z=mm.position.z-0.014;
          o.chip.scale.setScalar(mm.scale.x);
          o.chip.material.uniforms.uOp.value=VIZ.clamp(ip*1.4,0,1)*(1-0.15*(1-o.emph));
          if(o.emph>0.3)o.chip.material.uniforms.uCol.value.copy(C.emph);
          else o.chip.material.uniforms.uCol.value.copy(C.chip);
        }
      }
      /* underline sweep under the live word */
      if(o.under){
        const on=state===1;
        const f=on?u.uFill.value:0;
        o.under.visible=on;
        if(on){
          o.under.position.set(mm.position.x-(o.w/2)*mm.scale.x,mm.position.y-o.h*0.66*mm.scale.y,0.005);
          if(o.rtl){
            o.under.position.set(mm.position.x+(o.w/2)*mm.scale.x,o.under.position.y,0.005);
          }
          o.under.scale.x=Math.max(0.001,o.w*mm.scale.x*f);
          if(o.emph>0.3)o.under.material.uniforms.uCol.value.copy(C.emph);
        }
      }
      /* pool burst fires once per word activation */
      if(m&&state===1&&isPool&&wi!==burstWi&&ip>0.05){
        burstWi=wi;
        const wp=new THREE.Vector3();
        mm.getWorldPosition(wp);
        fireBurst(wp.x,wp.y,wp.z);
      }
    });
    if(wi!==prevWi){prevWi=wi;}
    stepParticles(1/60);
    /* bloom per theme + glow slider */
    if(bloom)bloom.strength=ST.glowM*(0.3+((P.fx!=null?P.fx:0.5))*1.15);
    /* gentle reactive dolly */
    camera.position.z=8-beat*0.1;
    try{composer.render();}catch(e){throw e;}
    dbg.draws=renderer.info.render.calls;
  }

  /* ---------- renderer interface ---------- */
  const R={};
  R.mount=function(h){host=h;};
  R.setModel=function(m){
    model=m;builtKey='';lastScr=-1;disposeWords();
    if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
    rebuildEmph();
  };
  function rebuildEmph(){
    emphWords=new Set(VIZ.fxPoolSet||[]);
  }
  /* theme background → GLSL gradient quad + clear color.
     v31 fix: THREE.Color() with no args is WHITE — must always
     write real colors, at creation AND on every param apply. */
  function applyBG(){
    if(!bgMesh)return;
    const bg=parseBg((theme||cfg.theme).bg);
    bgMesh.material.uniforms.uC0.value.copy(bg.c0);
    bgMesh.material.uniforms.uC1.value.copy(bg.c1);
    bgMesh.material.uniforms.uC2.value.copy(bg.c2);
    bgMesh.material.uniforms.uC.value.set(bg.cx,bg.cy);
    bgMesh.material.uniforms.uRadial.value=bg.radial;
    if(renderer)renderer.setClearColor(bg.c0,1);
  }
  R.applyParams=function(p){
    params=p;theme=cfg.theme;cacheColors();
    if(VIZ.fxRebuildPool)VIZ.fxRebuildPool();
    rebuildEmph();
    builtKey='';lastScr=-1;disposeWords();
    applyBG();
  };
  R.resize=function(){doResize();};
  R.frame=function(st){
    /* WebGL creation failure → graceful CSS fallback, stage never dies */
    if(!ok&&!ensure()){
      VIZ.params.engine='css';
      if(S.toast)S.toast('WebGL unavailable — switched back to the CSS engine',true);
      if(VIZ.current)VIZ.use(VIZ.current.id,true);
      return;
    }
    frame(st);
  };
  R.snapshot=function(){
    if(!renderer||!ok)return null;
    try{
      const st=VIZ.state;
      frame(st);
      return renderer.domElement.toDataURL('image/png');
    }catch(e){return null;}
  };
  R.quarantine=function(){
    try{R.dispose();}catch(e){}
    VIZ.params.engine='css';
    if(VIZ.current)VIZ.use(VIZ.current.id,true);
  };
  R.dispose=function(){
    disposeWords();
    if(ptGeo){ptGeo.dispose();ptGeo=null;}
    if(ptMat){ptMat.dispose();ptMat=null;}
    if(ptPoints&&ptPoints.parent){ptPoints.parent.remove(ptPoints);ptPoints=null;}
    if(bgMesh){if(bgMesh.parent)bgMesh.parent.remove(bgMesh);
      bgMesh.geometry.dispose();bgMesh.material.dispose();bgMesh=null;}
    if(wordsGroup&&wordsGroup.parent)wordsGroup.parent.remove(wordsGroup);
    if(composer){composer.dispose&&composer.dispose();composer=null;}
    if(renderer){
      try{renderer.dispose();}catch(e){}
      try{renderer.forceContextLoss();}catch(e){}
      if(renderer.domElement&&renderer.domElement.parentNode)renderer.domElement.parentNode.removeChild(renderer.domElement);
      renderer=null;
    }
    host=null;ok=false;builtKey='';
  };
  R._dbg=dbg;
  /* debug/test hooks — direct render bypass, no composer */
  R._dbg.direct=function(){
    renderer.render(scene,camera);
    return renderer.domElement.toDataURL('image/png');
  };
  R._dbg.renderOnly=function(){renderer.render(scene,camera);};
  params=VIZ.params;theme=cfg.theme;cacheColors();
  return R;
};
window.VIZ=VIZ;
