/* ============================================================
   VIZ CANVAS SYSTEM — pixel-level presets (v27)

   Three art directions, one Canvas2D renderer:
     cleankaraoke — premium podcast center stack (the workhorse)
     social       — short-form caption card (pop words)
     hud          — technical telemetry HUD (data-driven)

   Words are pre-measured into line layouts; the active word
   gets a continuous clip-rect sweep (real karaoke fill), a
   controlled glow, and mono telemetry. DPR-aware, relayout on
   resize + font-ready. Audio-reactive hooks read VIZ.state.audio.
   ============================================================ */
import VIZ from './core.js';

const SANS="'Inter','Segoe UI',Arial,sans-serif";
const MONO="'JetBrains Mono',ui-monospace,Menlo,Consolas,monospace";
const FA="'Vazirmatn','Inter',sans-serif";

VIZ.canvasPreset=function(cfg){
  let host=null,cvs=null,ctx=null,model=null,params=null,pal=null;
  let W=0,H=0,DPR=1,laid=null,fontReady=false;
  let enterAt=0,lastWi=-99;

  function ensure(){
    if(cvs)return;
    cvs=document.createElement('canvas');
    cvs.className='vz-canvas';
    host.appendChild(cvs);
    ctx=cvs.getContext('2d');
    if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{fontReady=true;laid=null;});
    resize();
  }
  function resize(){
    if(!cvs||!host)return;
    const r=host.getBoundingClientRect();
    if(r.width<4)return;
    DPR=Math.min(VIZ.gate.dprCap,window.devicePixelRatio||1);
    W=Math.round(r.width);H=Math.round(r.height);
    cvs.width=Math.round(W*DPR);cvs.height=Math.round(H*DPR);
    ctx.setTransform(DPR,0,0,DPR,0,0);
    laid=null;
  }
  function palApply(){pal=cfg.palettes[params.palette]||cfg.palettes[0];laid=null;}

  /* ---------- line layout with measured words ---------- */
  function relayout(){
    if(!model||!ctx)return null;
    const rtl=model.rtl;
    const fs=Math.max(VIZ.gate.minFont,H*(cfg.fsH||0.085)*params.scale);
    const fam=(rtl?FA+' ':'')+cfg.font;
    ctx.font=(cfg.weight||600)+' '+Math.round(fs)+'px '+fam;
    const space=ctx.measureText(' ').width||fs*0.3;
    const maxW=W*(cfg.maxW||0.82);
    const screens=model.screens.map(sc=>({
      t0:sc.t0,t1:sc.t1,speaker:sc.speaker,
      lines:sc.lines.map(lw=>{
        const words=lw.map(w=>({text:w.text||'',_i:w._i,t0:w.startSec,t1:w.endSec,
                                w:ctx.measureText(w.text||'').width}));
        let total=words.reduce((a,b)=>a+b.w,0)+space*(words.length-1);
        /* hard guard: if a pre-split line still overflows, shrink this line */
        let fsLine=fs;
        if(total>maxW){fsLine=Math.max(VIZ.gate.minFont*.8,fs*maxW/total);
          ctx.font=(cfg.weight||600)+' '+Math.round(fsLine)+'px '+fam;
          words.forEach(w=>{w.w=ctx.measureText(w.text).width;});
          total=words.reduce((a,b)=>a+b.w,0)+space*(words.length-1);
          ctx.font=(cfg.weight||600)+' '+Math.round(fs)+'px '+fam;
        }
        const x0=rtl?(W+total)/2:(W-total)/2;
        let x=x0;
        words.forEach(w=>{w.x=x;if(rtl)x-=w.w+space;else x+=w.w+space;});
        return {words,total,x0,fsLine};
      })
    }));
    laid={screens,fs,fam,space,rtl};
    return laid;
  }

  /* ---------- shared draw helpers ---------- */
  function sweepWord(word,y,p,col,dimCol,glow){
    const rtl=laid.rtl;
    ctx.fillStyle=dimCol;
    ctx.font=(cfg.weight||600)+' '+Math.round(word.fsLine||laid.fs)+'px '+laid.fam;
    ctx.fillText(word.text,word.x,y);
    if(p>0.001){
      ctx.save();
      if(glow){ctx.shadowColor=col;ctx.shadowBlur=glow;}
      ctx.beginPath();
      const cw=word.w*p;
      if(rtl)ctx.rect(word.x+word.w-cw,y-laid.fs,cw,laid.fs*1.5);
      else ctx.rect(word.x,y-laid.fs,cw,laid.fs*1.5);
      ctx.clip();
      ctx.fillStyle=col;
      ctx.fillText(word.text,word.x,y);
      ctx.restore();
    }
  }
  function mono(px){ctx.font='400 '+px+'px '+MONO;}
  function tc(t){
    t=Math.max(0,t||0);
    const m=Math.floor(t/60),s=Math.floor(t%60),f=Math.floor((t%1)*25);
    return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')+':'+String(f).padStart(2,'0');
  }

  /* ---------- preset draw functions ---------- */
  function drawClean(st){
    ctx.fillStyle=pal.bg;ctx.fillRect(0,0,W,H);
    if(!laid)return;
    /* v28: at rest (never played) future words read as a ready title
       card — done-level ink instead of the deep karaoke dim */
    const futDim=st.playing?pal.dim:pal.ink;
    const scr=laid.screens[st.screenIdx<0?Math.max(0,holdIdx(st)):st.screenIdx];
    const prev=laid.screens[Math.max(0,(st.screenIdx<0?holdIdx(st):st.screenIdx)-1)];
    const next=laid.screens[(st.screenIdx<0?holdIdx(st):st.screenIdx)+1];
    const baseY=H/2+((scr&&scr.lines.length>1)?-laid.fs*0.18:0);
    ctx.textBaseline='alphabetic';
    /* next line below, dim */
    if(next){drawCtxScreen(next,baseY+laid.fs*1.25,0.3,0.55,st,-2);}
    if(prev){drawCtxScreen(prev,baseY-laid.fs*1.5,0.34,0.62,st,-1);}
    if(scr){
      scr.lines.forEach((ln,li)=>{
        const y=baseY+li*laid.fs*1.28;
        ln.words.forEach(wd=>{
          const i=wd._i;
          if(i===st.wordIdx)sweepWord(wd,y,st.wordP,pal.acc,pal.dim,10+16*params.fx);
          else if(i<st.wordIdx)sweepWord(wd,y,1,pal.done,pal.dim,0);
          else sweepWord(wd,y,0,pal.ink,futDim,0);
        });
      });
    }
    /* bottom meta */
    mono(9.5);ctx.fillStyle=pal.meta||'rgba(128,128,128,.7)';
    const spk=(scr&&scr.speaker)?scr.speaker+'  ·  ':'';
    ctx.fillText(spk+tc(st.t)+'  ·  '+(Math.max(0,st.wordIdx+1))+'/'+model.nWords,14,H-12);
  }
  function holdIdx(st){let b=-1;for(let i=0;i<model.screens.length;i++){if(model.screens[i].t0<=st.t)b=i;else break;}return b;}
  function drawCtxScreen(sc,y,alpha,scale,st,off){
    if(!sc)return;
    ctx.save();ctx.globalAlpha=alpha;
    ctx.font=(cfg.weight||600)+' '+Math.round(laid.fs*scale)+'px '+laid.fam;
    ctx.fillStyle=pal.dim;
    sc.lines.forEach((ln,li)=>{
      const yy=y+li*laid.fs*scale*1.25;
      ln.words.forEach(wd=>ctx.fillText(wd.text,wd.x,yy));
    });
    ctx.restore();
  }

  function drawSocial(st){
    ctx.fillStyle=pal.bg;ctx.fillRect(0,0,W,H);
    if(!laid)return;
    const scr=laid.screens[st.screenIdx<0?Math.max(0,holdIdx(st)):st.screenIdx];
    if(!scr)return;
    /* word-pop age since active word changed */
    if(st.wordIdx!==lastWi){lastWi=st.wordIdx;enterAt=performance.now();}
    const age=(performance.now()-enterAt)/1000;
    const pop=VIZ.easeOutBack(Math.min(1,age/0.16),1.6);
    const beat=(params.react&&st.playing)?1+0.05*st.audio.beat:1;
    /* caption card: bottom-safe rounded panel */
    const padX=W*0.06,padY=18;
    const fs=Math.max(VIZ.gate.minFont+2,H*0.062*params.scale);
    ctx.font='800 '+Math.round(fs)+'px '+SANS;
    const cw=scr.lines.length;
    const cardW=W-2*padX,cardH=fs*1.5*cw+padY*2+22;
    const cardY=H-cardH-H*0.09;
    const rr=(x,y,w,h,r)=>{ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);
      ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.closePath();};
    rr(padX,cardY,cardW,cardH,16);
    ctx.fillStyle=pal.card||'rgba(12,12,14,.88)';ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,.09)';ctx.lineWidth=1;ctx.stroke();
    /* words per line with active chip — social measures with its own
       bigger font, so iterate the RAW model lines (not laid metrics) */
    const space=ctx.measureText(' ').width;
    const raw=(model.screens[st.screenIdx<0?Math.max(0,holdIdx(st)):st.screenIdx])||{lines:[]};
    let y=cardY+padY+fs;
    raw.lines.forEach(line=>{
      /* re-measure with social font */
      ctx.font='800 '+Math.round(fs)+'px '+SANS;
      const ws=line.map(w=>({text:w.text||'',_i:w._i,t0:w.startSec,
        w:ctx.measureText(w.text||'').width}));
      let total=ws.reduce((a,b)=>a+b.w,0)+space*(ws.length-1);
      let x=(W-total)/2;
      if(total>cardW-2*padX){const k=(cardW-2*padX)/total;
        ctx.save();ctx.translate(x,y);ctx.scale(k,1);
        total=cardW-2*padX;x=padX;ctx.restore();}
      ws.forEach(wd=>{
        const i=wd._i;
        if(i===st.wordIdx){
          /* accent chip + pop scale */
          const s=pop*beat;
          ctx.save();
          ctx.translate(x+wd.w/2,y-fs*0.36);
          ctx.scale(s,s);
          rr(-wd.w/2-7,-fs*0.36,wd.w+14,fs*1.1,6);
          ctx.fillStyle=pal.acc;ctx.fill();
          ctx.font='800 '+Math.round(fs)+'px '+SANS;
          ctx.fillStyle=pal.chipInk;ctx.textBaseline='middle';
          ctx.fillText(wd.text,-wd.w/2,fs*0.19);
          ctx.restore();ctx.textBaseline='alphabetic';
          ctx.font='800 '+Math.round(fs)+'px '+SANS;
        }else{
          ctx.fillStyle=(i<st.wordIdx)?pal.ink:(st.playing?pal.dim:pal.ink);
          ctx.font='800 '+Math.round(fs)+'px '+SANS;
          ctx.fillText(wd.text,x,y);
        }
        x+=wd.w+space;
      });
      y+=fs*1.5;
    });
    /* progress line at card bottom */
    const lp=st.linePhase;
    ctx.fillStyle='rgba(255,255,255,.14)';ctx.fillRect(padX+14,cardY+cardH-10,cardW-28,3);
    ctx.fillStyle=pal.acc;ctx.fillRect(padX+14,cardY+cardH-10,(cardW-28)*lp,3);
    /* counter chip */
    mono(9.5);ctx.fillStyle=pal.acc;
    ctx.fillText((Math.max(0,st.wordIdx+1))+'/'+model.nWords,W-58,cardY-10);
    mono(9.5);ctx.fillStyle=pal.meta||'rgba(255,255,255,.5)';
    ctx.fillText('CAPTION',padX+2,cardY-10);
  }

  function drawHUD(st){
    ctx.fillStyle=pal.bg;ctx.fillRect(0,0,W,H);
    if(!laid)return;
    const a=st.audio;
    /* corner frame brackets */
    ctx.strokeStyle='rgba(128,150,160,.22)';ctx.lineWidth=1;
    const m=16,b=12;
    [[m,m,1,1],[W-m,m,-1,1],[m,H-m,1,-1],[W-m,H-m,-1,-1]].forEach(([x,y,sx,sy])=>{
      ctx.beginPath();ctx.moveTo(x+sx*b,y);ctx.lineTo(x,y);ctx.lineTo(x,y+sy*b);ctx.stroke();
    });
    /* top bar: TC left, meters right */
    mono(10.5);ctx.fillStyle=pal.acc;
    ctx.fillText('TC '+tc(st.t),m+14,m+22);
    mono(9.5);ctx.fillStyle=pal.dim2||'rgba(128,150,160,.75)';
    ctx.fillText((st.playing?'PLAYING':'PAUSED')+'  ·  SRC '+String(model.srcName||'—').slice(0,18),m+14,m+36);
    /* RMS meter */
    const mw=150,mx=W-m-14-mw,my=m+18;
    ctx.fillStyle='rgba(128,150,160,.18)';ctx.fillRect(mx,my,mw,5);
    const rms=params.react?a.rms*1.6:0.12;
    ctx.fillStyle=pal.acc;ctx.fillRect(mx,my,mw*Math.min(1,rms),5);
    if(rms>0.72){ctx.fillStyle=pal.amber||'#f5b942';ctx.fillRect(mx+mw*0.72,my,mw*0.28,5);}
    mono(8.5);ctx.fillStyle=pal.dim2||'rgba(128,150,160,.75)';
    ctx.fillText('RMS '+(rms*100|0).toString().padStart(2,'0'),mx,my+16);
    /* spectrum — 26 bars from analyser */
    const bars=26,bw=Math.floor(mw/bars);
    for(let i=0;i<bars;i++){
      const v=params.react?(a.bass*(1-i/bars)+a.mid*Math.min(1,i/8)*(i<12?1:0.4)+a.treble*(i>=12?1:0)*0.5):0.02;
      const bh=Math.max(1,v*26);
      ctx.fillStyle=(i<8)?pal.acc:(i<16?(pal.dim):'rgba(128,150,160,.35)');
      ctx.fillRect(mx+i*bw,my+34-bh,bw-1,bh);
    }
    /* current line — center, mono, tick marks, brackets on active */
    const scr=laid.screens[st.screenIdx<0?Math.max(0,holdIdx(st)):st.screenIdx];
    if(scr){
      scr.lines.forEach((ln,li)=>{
        const y=H*0.55+li*laid.fs*1.3;
        ln.words.forEach(wd=>{
          const i=wd._i;
          if(i===st.wordIdx){
            ctx.save();
            ctx.shadowColor=pal.acc;ctx.shadowBlur=8*params.fx;
            ctx.fillStyle=pal.acc;
            ctx.font=(cfg.weight||700)+' '+Math.round(laid.fs)+'px '+MONO;
            ctx.fillText(wd.text,wd.x,y);
            ctx.restore();
            /* brackets */
            ctx.strokeStyle=pal.acc;ctx.lineWidth=1.5;
            const bh=laid.fs*0.78;
            ctx.beginPath();ctx.moveTo(wd.x-4,y+4);ctx.lineTo(wd.x-4,y-bh);ctx.lineTo(wd.x-1,y-bh);ctx.stroke();
            ctx.beginPath();ctx.moveTo(wd.x+wd.w+4,y+4);ctx.lineTo(wd.x+wd.w+4,y-bh);ctx.lineTo(wd.x+wd.w+1,y-bh);ctx.stroke();
            /* progress caret under word */
            ctx.fillStyle=pal.acc;
            ctx.fillRect(wd.x,y+7,wd.w*st.wordP,2);
          }else{
            ctx.fillStyle=i<st.wordIdx?pal.done:(st.playing?pal.dim:pal.ink);
            ctx.font=(cfg.weight||700)+' '+Math.round(laid.fs)+'px '+MONO;
            ctx.fillText(wd.text,wd.x,y);
            /* tick marks */
            ctx.fillStyle=i<st.wordIdx?pal.done:(st.playing?pal.dim:pal.ink);
            ctx.fillRect(wd.x,y+7,Math.min(wd.w,3),2);
          }
        });
      });
    }
    /* footer telemetry */
    mono(9);ctx.fillStyle=pal.dim2||'rgba(128,150,160,.75)';
    const cps=scr&&scr.t1>scr.t0?Math.round(String(model.words.slice().filter(w=>w.startSec>=scr.t0&&w.endSec<=scr.t1).map(w=>w.text).join('')).length/(scr.t1-scr.t0)):0;
    ctx.fillText('SCR '+String((st.screenIdx<0?holdIdx(st):st.screenIdx)+1).padStart(2,'0')+'/'+String(model.screens.length).padStart(2,'0')
      +'   CPS '+cps+'   SPK '+(scr&&scr.speaker?scr.speaker:'—')+'   W '+Math.max(0,st.wordIdx+1)+'/'+model.nWords,m+14,H-m-8);
    ctx.textAlign='right';
    ctx.fillText('SUBTITLE-LAYER v27',W-m-14,H-m-8);
    ctx.textAlign='left';
  }

  const DRAW={clean:drawClean,social:drawSocial,hud:drawHUD};

  const R={};
  R.mount=function(h){host=h;ensure();};
  R.setModel=function(m){model=m;laid=null;};
  R.applyParams=function(p){params=p;palApply();};
  R.resize=function(){resize();};
  R.frame=function(st){
    if(!host)return;ensure();
    if(!laid)relayout();
    if(!laid){
      ctx.fillStyle=(pal&&pal.bg)||'#101014';ctx.fillRect(0,0,W,H);
      /* v28: canvas empty-state hint — same message the DOM presets show */
      if(W>60&&H>30){
        ctx.fillStyle='rgba(161,161,170,.66)';
        ctx.font='500 11px '+MONO;
        ctx.textAlign='center';
        ctx.fillText('PICK AUDIO · GENERATE · PRESS PLAY',W/2,H/2+4);
        ctx.textAlign='left';
      }
      return;
    }
    (DRAW[cfg.draw]||drawClean)(st);
  };
  R.snapshot=function(){return cvs?cvs.toDataURL('image/png'):null;};
  R.dispose=function(){if(cvs){cvs.remove();cvs=null;ctx=null;}host=null;model=null;laid=null;};
  return R;
};
window.VIZ=VIZ;

/* ============================================================
   10 · CLEAN KARAOKE — premium podcast center stack
   ============================================================ */
VIZ.register({
  id:'cleankaraoke',name:'Clean Karaoke',family:'Podcast',engine:'canvas',
  concept:'Premium podcast captions — center stack, active word sweeps in one accent with a capped glow. The readability workhorse: 3 lines max, past above, next below.',
  palettes:[
    {name:'Mint', bg:'#0e1013',ink:'#e8ecef',dim:'rgba(232,236,239,.36)',done:'rgba(232,236,239,.62)',acc:'#39d3a0',meta:'#6b7280'},
    {name:'Amber',bg:'#12100d',ink:'#f0e9dd',dim:'rgba(240,233,221,.36)',done:'rgba(240,233,221,.6)',acc:'#f0b429',meta:'#6d675f'},
    {name:'Ice',  bg:'#0b0f14',ink:'#e9f1f8',dim:'rgba(233,241,248,.34)',done:'rgba(233,241,248,.6)',acc:'#7cc4ff',meta:'#5f6d7a'}
  ],
  def:{motion:.4,fx:.45},font:SANS,weight:600,fsH:.082,maxW:.84,
  draw:'clean',make:function(){return VIZ.canvasPreset(this);}
});

/* ============================================================
   11 · SOCIAL POP — short-form caption card
   ============================================================ */
VIZ.register({
  id:'social',name:'Short-form Social',family:'Social',engine:'canvas',
  concept:'Short-form caption card — bottom-safe panel, extra-bold sans, the active word pops onto an accent chip with a 160ms spring. Beat pop only when audio-react is on.',
  palettes:[
    {name:'Lemon',bg:'#0e0d0b',ink:'#ffffff',dim:'rgba(255,255,255,.55)',acc:'#ffd42a',chipInk:'#171310',card:'rgba(12,12,14,.88)',meta:'rgba(255,255,255,.5)'},
    {name:'Mint', bg:'#0b0f0d',ink:'#ffffff',dim:'rgba(255,255,255,.55)',acc:'#34e0a1',chipInk:'#06281c',card:'rgba(10,14,12,.88)',meta:'rgba(255,255,255,.5)'},
    {name:'Coral',bg:'#0f0c0b',ink:'#ffffff',dim:'rgba(255,255,255,.55)',acc:'#ff6b57',chipInk:'#2a0d08',card:'rgba(15,11,10,.88)',meta:'rgba(255,255,255,.5)'}
  ],
  def:{motion:.75,fx:.3},font:SANS,weight:800,fsH:.06,maxW:.84,
  draw:'social',make:function(){return VIZ.canvasPreset(this);}
});

/* ============================================================
   12 · DATA HUD — technical telemetry
   ============================================================ */
VIZ.register({
  id:'hud',name:'Technical HUD',family:'Technical',engine:'canvas',
  concept:'Telemetry overlay — SMPTE clock, RMS meter, 26-band spectrum, per-word progress ticks, bracket cursor on the active word. One hue + amber peak. No rainbow.',
  palettes:[
    {name:'Phosphor',bg:'#05070a',ink:'#c9f5db',dim:'rgba(120,200,150,.5)',done:'rgba(160,230,180,.75)',acc:'#46e08a',amber:'#f5b942',dim2:'rgba(120,150,135,.75)'},
    {name:'Amber',   bg:'#0a0705',ink:'#f5e3c0',dim:'rgba(200,160,90,.5)', done:'rgba(235,200,140,.75)',acc:'#f5b942',amber:'#ff7a45',dim2:'rgba(170,140,100,.75)'},
    {name:'Cyan',    bg:'#050a0d',ink:'#d4f2fa',dim:'rgba(90,170,200,.5)', done:'rgba(150,220,240,.75)',acc:'#53d6e8',amber:'#f5d042',dim2:'rgba(100,150,165,.75)'}
  ],
  def:{motion:.35,fx:.4},font:MONO,weight:700,fsH:.052,maxW:.8,
  draw:'hud',make:function(){return VIZ.canvasPreset(this);}
});
