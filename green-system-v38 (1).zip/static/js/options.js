/* ============================================================
   options.js — one settings panel, one storage, ONE key everywhere.
   MVSEP token / Worker URL+key / Gemini key+model / algorithm.
   The Subtitles Advanced Settings mirrors the same fields.
   ============================================================ */
(function(){
'use strict';
const S=window.S;
const $=S.$;
const OPT=['workerUrl','workerKey','mvsepToken','geminiKey','geminiModel','model','opt1','opt2','fmt','spk','subsSpk'];

/* ---------- defaults — extracted from the ORIGINAL app (v22.9 seeding).
   They live client-side only; emptying a field in the panel returns it
   to these defaults after reload (documented behavior). ---------- */
const DEFAULTS={
  workerUrl:'https://mvsep-proxy.mvsep-proxy.workers.dev',
  workerKey:'H0HoNdwMQhN9zNivPugEIrboNWyApjLw7/igPOQUK3+rlMgMSKp7M7EXMq3',
  mvsepToken:'QL5fwfrJ1tzX3Hk1MWQG6WBqHFEABI',
  geminiKey:'AQ.Ab8RN6IhycvakHmBScn5sxN15da0tiuR4b-1OXIk3T9Dh9UKsQ',
  geminiModel:'gemini-3.5-transcribe',
  model:'40',opt1:'81',opt2:'2',
  fmt:'0',spk:'-1',subsSpk:'-1'
};

function save(){try{const o={};for(const id of OPT){const e=$(id);if(e)o[id]=e.value;}localStorage.setItem('studio22_opts',JSON.stringify(o));}catch(e){}}
function load(){
  let o={};
  try{o=JSON.parse(localStorage.getItem('studio22_opts')||'{}');}catch(e){}
  for(const id of OPT){
    const e=$(id);if(!e)continue;
    let v=o[id];
    if(v==null||String(v).trim()==='')v=DEFAULTS[id];   // empty → default
    if(v==null)continue;
    try{e.value=String(v);}catch(x){}
  }
}
S.saveOpts=save;

/* endpoints */
S.wu=function(){return $('workerUrl').value.trim().replace(/\/$/,'');};
S.mvsep=function(){return S.wu()+'/mvsep';};
S.authV=function(){return ($('workerKey').value||'').trim().replace(/^Bearer\s+/i,'').trim();};
S.authH=function(){const k=S.authV();return k?{'Authorization':'Bearer '+k}:{};};
S.mvTok=function(){return $('mvsepToken').value.trim().replace(/^Bearer\s+/i,'').trim();};

/* panel toggle — v32: the options live in a SETTINGS MODAL (subbar pattern,
   same as Subtitles Advanced + Mic Studio). Every field id is unchanged,
   so persistence/mirroring keep working untouched. */
const optModal=$('optModal');
$('optBtn').onclick=()=>{
  optModal.classList.remove('hidden');
  syncWhDotMini();
};
function closeModal(){optModal.classList.add('hidden');save();}
if($('optClose'))$('optClose').onclick=closeModal;
if(optModal)optModal.addEventListener('click',e=>{
  if(e.target===optModal||e.target.classList.contains('modal-bg'))closeModal();});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&!optModal.classList.contains('hidden'))closeModal();});
/* Save & Close / Reset defaults (v22.11 user request) */
if($('optSaveBtn'))$('optSaveBtn').onclick=()=>{
  save();mirrorToSubs();
  optModal.classList.add('hidden');
  S.toast('Settings saved — modal closed');
};
if($('optResetBtn'))$('optResetBtn').onclick=()=>{
  try{localStorage.removeItem('studio22_opts');}catch(e){}
  for(const id of OPT){
    const e=$(id);if(!e)continue;
    const v=DEFAULTS[id];
    if(v==null)continue;
    try{e.value=String(v);}catch(x){}
  }
  popModel();load();mirrorToSubs();updGemDot();save();
  S.toast('Defaults restored');
};
/* worker-health mini chip on the subbar mirrors the modal chip */
function syncWhDotMini(){
  const src=$('whDot'),mini=$('whDotMini');
  if(src&&mini){mini.textContent=src.textContent;mini.className=src.className;}
}
if($('whDot')){new MutationObserver(syncWhDotMini).observe($('whDot'),{childList:true,attributes:true,characterData:true,subtree:true});}
S._syncWhDotMini=syncWhDotMini;

/* ---------- algorithms (MVSEP) ---------- */
S.ALGOS=[
{t:40,n:'BS Roformer — 2 Stems ★',f:true,o1:{'81':'v.2025.07 (11.89) ★','171':'124-band (12.33) [prem]','172':'becruily 124b instr-HF [prem]','143':'HyperACE v2 vocals','142':'HyperACE v2 instrum','85':'unwa instr-HF','29':'2024.08 (11.31)','5':'2024.04','4':'viperx','3':'2024.02'},o2:{'2':'50% overlap','8':'87.5% overlap'},d1:'81',d2:'2'},
{t:26,n:'Ensemble — 2 Stems (max quality)',f:false,o1:{'0':'Standard set','1':'Include intermediates'},o2:{'7':'SDR 11.93 ★','8':'Vocal fullness (11.69)','9':'Instrum fullness (17.69)','6':'SDR 11.61','5':'SDR 11.50','4':'SDR 11.33'},d1:'0',d2:'7'},
{t:20,n:'Demucs v4 HT — 4 Stems',f:true,o1:{'0':'htdemucs_ft (HQ, slow)','1':'htdemucs (fast)','2':'htdemucs_6s (6 stems)'},o2:{},d1:'1',d2:'2'},
{t:48,n:'MelBand Roformer — 2 Stems',f:true,o1:{'4':'v.2024.10 (11.28)','11':'becruily deux (11.35)','12':'gabox v10 flowers','2':'Bas Curtiz (11.18)','1':'2024.08 (11.17)','0':'Kimberley Jensen','10':'gabox v7','9':'unwa v1e plus'},o2:{'2':'50% overlap','8':'87.5% overlap'},d1:'4',d2:'2'},
{t:123,n:'BS PolarFormer — 2 Stems',f:true,o1:{'163':'124 bands (12.02) ★','158':'62 bands (11.75)'},o2:{'2':'50% overlap','8':'87.5% overlap'},d1:'163',d2:'2'},
{t:46,n:'SCNet — 2 Stems',f:true,o1:{'5':'XL IHF (11.11) ★','6':'XL IHF becruily','4':'XL v-high fullness','3':'XL high fullness','2':'XL (10.96)','1':'Large (10.74)','0':'base (10.25)'},o2:{},d1:'5',d2:'2'},
{t:25,n:'MDX23C — 2 Stems (fast)',f:true,o1:{'7':'8K FFT (10.36) ★','4':'8K older (10.17)','3':'12K Large (9.95)','0':'12K FFT (9.68)'},o2:{},d1:'7',d2:'2'},
{t:63,n:'BS Roformer SW — 6 Stems',f:true,o1:{},o2:{},d1:'0',d2:'2'},
{t:28,n:'Ensemble — 5 Stems',f:false,o1:{'0':'Standard set','1':'Include intermediates'},o2:{'11':'SDR 13.67 (2025.06) ★','10':'SDR 13.07','9':'SDR 13.01','8':'SDR 12.84','7':'SDR 12.76'},d1:'0',d2:'11'},
{t:36,n:'BandIt Plus — 3 Stems (speech/music/fx)',f:true,o1:{},o2:{},d1:'0',d2:'2'},
{t:56,n:'MVSep DnR v3 — 3 Stems',f:true,o1:{'2':'Mel+SCNet (11.54) ★','0':'SCNet Large (11.22)','1':'MelBand (10.99)'},o2:{'0':'Direct from mix','1':'Vocals model assist'},d1:'2',d2:'0'},
{t:57,n:'Male/Female Voices — 2 Stems',f:true,o1:{'2':'MelRoformer 2025.01 (13.03) ★','1':'SCNet XL (11.83)','3':'BSRoformer aufr33 (8.18)','0':'BSRoformer Sucial (6.52)'},o2:{'0':'Direct from mix','1':'Vocals first'},d1:'2',d2:'0'},
];
function popModel(){
  const m=$('model');m.innerHTML='';
  S.ALGOS.forEach(a=>{const o=document.createElement('option');o.value=a.t;o.textContent=a.n+(a.f?' (Free)':' (Premium)');m.appendChild(o);});
  syncOpt();
}
function getAlgo(){const t=parseInt($('model').value);return S.ALGOS.find(a=>a.t===t)||S.ALGOS[0];}
S.getAlgo=getAlgo;
function syncOpt(){
  const a=getAlgo();
  for(const [sel,map,d] of [[$('opt1'),a.o1,a.d1],[$('opt2'),a.o2,a.d2]]){
    if(!sel)continue;
    if(Object.keys(map).length){
      sel.innerHTML='';
      Object.entries(map).forEach(([k,v])=>{const o=document.createElement('option');o.value=k;o.textContent=v;sel.appendChild(o);});
      sel.value=d;sel.classList.remove('hidden');
    }else sel.classList.add('hidden');
  }
}
S.syncOpt=syncOpt;
$('model').onchange=()=>{syncOpt();save();};

/* ---------- Gemini models ---------- */
S.GEM_MODELS=['gemini-3.5-transcribe','gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash-lite','gemini-3.5-flash','gemini-3.7-flash'];
S.GEMINI_PROXY='https://gemini-proxy.maytham-saeidi.workers.dev';

/* ---------- key mirror: Options ⇄ Subtitles Advanced (ONE source of truth) ---------- */
const PAIRS=[['geminiKey','subsGemKey'],['geminiModel','subsGemModel'],['spk','subsSpk']];
function updGemDot(){
  const k=($('geminiKey').value||'').trim(),d=$('gemDot');
  if(!d)return;
  d.textContent=k?('Key …'+k.slice(-4)):'No key';
  d.className='chip '+(k?'good':'warn');
}
function mirrorToSubs(){
  for(const [mid,sid] of PAIRS){const m=$(mid),s2=$(sid);
    if(m&&s2&&document.activeElement!==s2&&s2.value!==m.value)s2.value=m.value;}
  updGemDot();
}
function mirrorToMain(mid){
  return function(){
    let sid=null;for(const [a,b] of PAIRS)if(a===mid)sid=b;
    const m=$(mid),s2=sid?$(sid):null;
    if(m&&s2&&m.value!==s2.value)m.value=s2.value;
    save();updGemDot();
  };
}
const gm=$('geminiModel'),sm=$('subsGemModel');
if(gm&&sm&&sm.options.length===0){
  S.GEM_MODELS.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;sm.appendChild(o);});
}
for(const [mid,sid] of PAIRS){
  const m=$(mid),s2=$(sid);
  if(m){m.addEventListener('input',mirrorToSubs);m.addEventListener('change',()=>{mirrorToSubs();save();});}
  if(s2){s2.addEventListener('input',mirrorToMain(mid));s2.addEventListener('change',mirrorToMain(mid));}
}

/* ---------- token verify ---------- */
$('verifyBtn').onclick=async()=>{
  const tk=S.mvTok();
  if(!tk){S.err('Enter the MVSEP token first');return;}
  const b=$('verifyBtn');b.textContent='…';b.disabled=true;
  try{
    const r=await fetch(S.mvsep()+'/app/user?api_token='+encodeURIComponent(tk),{headers:S.authH()});
    const t=await r.text();
    let j=null;try{j=JSON.parse(t);}catch(e){}
    if(j&&j.success&&j.data){
      S.toast('Token OK — '+(j.data.premium_enabled?'Premium':'Free')+' · minutes: '+(j.data.premium_minutes!=null?j.data.premium_minutes:'-'));
    }else{
      S.err(S.richErr('MVSEP rejected this token',{respBody:t.slice(0,300),hint:'Copy the exact API token (not your password) from mvsep.com → profile → API token.'}));
    }
  }catch(e){
    S.err(S.richErr('Cannot reach the Worker / MVSEP',{hint:'Check the Worker URL in Options and your internet connection.'}));
  }finally{b.textContent='Verify';b.disabled=false;}
};

/* ---------- worker health ---------- */
let workerOk=false;
S.workerOk=function(){return workerOk;};
async function checkWH(){
  const u=S.wu();
  $('whDot').textContent='…';
  try{
    const r=await fetch(u+'/mvsep/separation/get?hash=__hc__',{headers:S.authH()});
    workerOk=true;
    $('whDot').textContent='connected';$('whDot').className='chip good';
  }catch(e){
    try{await fetch(u+'/mvsep/separation/get?hash=__hc__');workerOk=true;
      $('whDot').textContent='connected (no key)';$('whDot').className='chip good';}
    catch(e2){workerOk=false;
      $('whDot').textContent='unreachable';$('whDot').className='chip bad';}
  }
}
$('recheckBtn').onclick=checkWH;

/* persist on every change (fields live inside the modal now) */
[...document.querySelectorAll('#optModal input,#optModal select')].forEach(e=>{
  e.addEventListener('change',save);e.addEventListener('input',save);
});

/* order matters: build the algorithm selects FIRST, then restore the
   saved values — otherwise popModel() rebuilds #model and wipes the
   restored selection (the v22 algorithm-persistence bug). */
popModel();load();mirrorToSubs();checkWH();
})();
