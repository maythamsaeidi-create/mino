#!/usr/bin/env bash
# Green System — start/stop daemon for the ORIGINAL legacy green app
# (rollback of "Vocal Music Speaker Splitter" — the system that worked)
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$APP_DIR/daemon.pid"
LOG_FILE="$APP_DIR/daemon.log"
PY="$(command -v python3)"
[ -x "$HOME/.venv/bin/python3" ] && PY="$HOME/.venv/bin/python3"

start() {
  if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "already running (pid $(cat "$PID_FILE"))"
    return 0
  fi
  nohup "$PY" "$APP_DIR/serve.py" >>"$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  sleep 1.5
  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "started (pid $(cat "$PID_FILE")) on port 3000 — legacy green system"
  else
    echo "failed to start — see $LOG_FILE"
    tail -5 "$LOG_FILE"
    return 1
  fi
}

stop() {
  if [ -f "$PID_FILE" ]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null
    rm -f "$PID_FILE"
    echo "stopped"
  else
    echo "not running"
  fi
}

restart() { stop; sleep 1; start; }

case "${1:-start}" in
  start) start ;;
  stop) stop ;;
  restart) restart ;;
  status)
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
      echo "running (pid $(cat "$PID_FILE"))"
    else
      echo "not running"
    fi ;;
  *) echo "usage: $0 {start|stop|restart|status}" ;;
esac
