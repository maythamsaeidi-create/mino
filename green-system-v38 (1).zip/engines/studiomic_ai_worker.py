#!/usr/bin/env python3
"""Studio Mic — AI stage worker (runs in an ISOLATED subprocess).

Why a subprocess: loading Resemble-Enhance peaks at ~2.5 GB RAM. On a
4 GB box that would live permanently inside the Flask server and risk
OOM-killing the whole app. Running the AI stage in a child process
returns every byte to the OS the moment it exits — the server stays
lean and the app stays alive.

Protocol (stdout, line-based):
  CHUNK <k> <n>    progress: k-th of n 30-second chunks
  DONE             success — out_wav written
  ERR <message>    failure — parent falls back to noisereduce/afftdn

Usage:
  studiomic_ai_worker.py <in_48k_mono.wav> <out_48k_mono.wav> <ai_clean 0-100> <max_quality 0|1>
"""
from __future__ import annotations

import math
import sys
import time
from pathlib import Path

def _run_dir() -> Path:
    """Model location lookup — MUST mirror engines/studiomic.py."""
    here = Path(__file__).resolve()
    app_root = here.parents[1]          # green-system/
    candidates = [app_root / "models" / "resemble-enhance",
                  app_root.parent / "models" / "resemble-enhance"]
    for c in candidates:
        if (c / "ds" / "G" / "default" / "mp_rank_00_model_states.pt").exists():
            return c
    return candidates[0]


RUN_DIR = _run_dir()


def main() -> int:
    in_wav, out_wav = sys.argv[1], sys.argv[2]
    ai_clean = float(sys.argv[3]) if len(sys.argv) > 3 else 70.0
    max_q = (sys.argv[4] == "1") if len(sys.argv) > 4 else False

    import numpy as np
    import soundfile as sf
    import torch
    import resemble_enhance.inference as rei
    from resemble_enhance.enhancer.inference import enhance  # noqa: F401 (kept for reference)

    # RAM relief: torch.load with mmap=True keeps the checkpoint pages
    # file-backed instead of eager-copying 713 MB into anonymous RAM —
    # peak drops from ~2.5 GB to ~1.3 GB, which matters on small boxes
    # (the worker was OOM-killed at -9 otherwise when a browser is open).
    _orig_load = torch.load

    def _mmap_load(*a, **k):
        try:
            k.setdefault("mmap", True)
            k.setdefault("map_location", "cpu")
        except Exception:
            pass
        return _orig_load(*a, **k)
    torch.load = _mmap_load

    x, sr = sf.read(in_wav, dtype="float32", always_2d=True)
    x = x.mean(axis=1)
    orig_len = len(x)

    class ProgTrange:
        def __init__(self):
            pass

        def __call__(self, *args, **kwargs):
            start, stop = args[0], args[1]
            step = args[2] if len(args) > 2 else 1
            total = max(1, math.ceil((stop - start) / step))

            def gen():
                import gc as _g
                import ctypes as _ct
                for k, v in enumerate(range(start, stop, step)):
                    # free the PREVIOUS chunk's cached activations — the
                    # torch CPU allocator holds them otherwise and the
                    # peak creeps up chunk after chunk
                    _g.collect()
                    try:
                        _ct.CDLL("libc.so.6").malloc_trim(0)
                    except Exception:
                        pass
                    sys.stdout.write(f"CHUNK {k + 1} {total}\n")
                    sys.stdout.flush()
                    yield v
            return gen()

    dwav = torch.from_numpy(np.ascontiguousarray(x))
    lambd = max(0.0, min(1.0, ai_clean / 100.0))
    nfe = 64 if max_q else 16
    solver = "rk4" if max_q else "midpoint"
    t0 = time.time()

    # ---- memory-lean model load -----------------------------------------
    # The checkpoint stores all 909 tensors in fp16 (713 MB). The naive
    # path (construct + load_state_dict copy) peaks at ~2.5 GB anon and
    # with activations OOM-kills the worker on small boxes. Instead:
    #   construct (fp32, 1.75 GB transient)
    #   torch.load(..., mmap=True) — file-backed state dict, ~0 anon
    #   load_state_dict(assign=True) — params POINT at the mmap'd tensors
    #   model.float() — cast half→fp32 in place of the copies
    #   remove_weight_norm — materialize plain weights, drop g/v
    # Peak lands at ~2.1 GB (vs 3.0 GB), steady state ~1.4 GB.
    import gc as _gc
    import ctypes as _ct
    from resemble_enhance.enhancer.train import Enhancer as _Enh, HParams as _HP
    hp = _HP.load(RUN_DIR)
    model = _Enh(hp)
    _sd = torch.load(RUN_DIR / "ds" / "G" / "default" / "mp_rank_00_model_states.pt",
                     map_location="cpu", mmap=True)
    model.load_state_dict(_sd["module"], assign=True)
    _sd = None
    model.float()
    _gc.collect()
    try:
        _ct.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass
    from resemble_enhance.inference import inference as _inference, \
        remove_weight_norm_recursively as _rwn
    _rwn(model)
    _gc.collect()
    try:
        _ct.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass
    model.eval()
    model.configurate_(nfe=nfe, solver=solver, lambd=lambd, tau=0.5)

    old = rei.trange
    rei.trange = ProgTrange()
    try:
        hwav, osr = _inference(model=model, dwav=dwav, sr=sr, device="cpu",
                               chunk_seconds=4.0, overlap_seconds=1.0)
    finally:
        rei.trange = old

    out = hwav.numpy().astype(np.float64)
    from scipy.signal import resample_poly
    g = math.gcd(48000, 44100) or 1
    out = resample_poly(out, 48000 // g, 44100 // g)
    want = int(orig_len * 48000 / max(1, sr))
    if len(out) > want:
        out = out[:want]
    elif len(out) < want:
        out = np.pad(out, (0, want - len(out)))
    sf.write(out_wav, out, 48000, subtype="FLOAT")
    dt = time.time() - t0
    sys.stdout.write(f"DONE {dt:.1f}\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # noqa: BLE001 — protocol requires ERR line
        sys.stdout.write(f"ERR {type(exc).__name__}: {str(exc)[:300]}\n")
        sys.stdout.flush()
        sys.exit(2)
