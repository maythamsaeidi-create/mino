"""OFFLINE Dolby-style 7-stage engine — no API, no keys, no internet.

This is the local twin of core/dolby.py (the Dolby.io Media /enhance call).
It mirrors the same processing stage model used by the Dolby.io enhance
pipeline (and the reference APK's audio chain order), implemented entirely
with local FFmpeg so it runs 100% offline:

  Stage 1  ANALYZE    : ebur128 + astats pre-scan (LUFS / true-peak / channels)
  Stage 2  REPAIR     : declick + mains-hum notches (50/60/100 Hz) + rumble HPF
  Stage 3  DENOISE    : spectral afftdn, amount-mapped, hard-capped (0..45)
  Stage 4  DYNAMICS   : gentle leveling that PRESERVES dynamics (no pumping)
  Stage 5  PROFILE EQ : Dolby-style "music" / "voice" contour curves
  Stage 6  SPATIAL    : stereo widening + Haas micro-delay (stereo sources;
                        mono stays mono — we never fake-stereo)
  Stage 7  MASTER     : loudnorm with source-preserved LUFS + true-peak safety

Safety profile — identical to the online engine (the anti-"killer" rules):
  - noise strength is hard-capped at 45 (mixed content survives)
  - loudness target = source LUFS clamped to [-35, -9] — the level is
    preserved, never crushed to a fixed number
  - every stage is ffprobe-verified right after it runs (no silent failures)
  - the final output passes the shared QA gate (duration / aliveness /
    DC / level) before it is allowed to exist
  - every failure returns a structured reason; nothing is swallowed

The function signature and result dict match dolby.run() exactly, so the
pipeline and the web UI can treat both engines interchangeably:
  run(path, out_path, noise_strength=20, profile="music", spatial=True,
      declick=True, dehum=True, on_progress=...) ->
      {ok, verdict, qa, stats, output, notes, engine:"dolby_off"}
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Callable

from .analysis import analyze, probe, qa_gate
from .local import DSPError, _ff

# stage weights for progress reporting (out of 100)
_STAGE_PCT = {1: 6, 2: 20, 3: 34, 4: 48, 5: 60, 6: 72, 7: 90}


class DolbyOfflineError(DSPError):
    """Raised with a human-readable, stage-tagged reason."""


def _verify(out: Path, stage: int, what: str) -> dict:
    """ffprobe a stage output immediately — a broken intermediate must
    abort the chain with a precise reason, never pass silently."""
    p = probe(out)
    if not p.get("ok") or not p.get("duration"):
        out.unlink(missing_ok=True)
        raise DolbyOfflineError(
            f"[dolby-offline stage {stage} ({what})] ffmpeg produced "
            f"invalid output: {p.get('error', 'empty file')}")
    return p


# ------------------------------------------------------------------ profiles

def _eq_profile(profile: str) -> list[str]:
    """Stage-5 contour curves (Dolby content-type style).

    music  : protect the mix — sub-bass body, presence, sheen; nothing harsh
    voice  : speech band focus — mud cut, presence lift, de-harsh, air
    """
    if profile == "voice":
        return [
            "equalizer=f=240:width_type=o:width=0.8:g=-2.0",   # mud cut
            "equalizer=f=2800:width_type=o:width=1.2:g=3.0",   # presence
            "equalizer=f=6800:width_type=o:width=0.8:g=-2.5",  # harshness
            "equalizer=f=10500:width_type=o:width=1.0:g=1.5",  # air
            "lowpass=f=14000",
        ]
    # music (default)
    return [
        "equalizer=f=55:width_type=q:width=0.9:g=1.5",         # sub-bass body
        "equalizer=f=220:width_type=q:width=1.0:g=0.8",        # warmth
        "equalizer=f=2800:width_type=o:width=1.2:g=2.0",       # presence
        "equalizer=f=6800:width_type=o:width=0.8:g=-1.5",      # harshness dip
        "equalizer=f=12000:width_type=q:width=0.8:g=1.0",      # sheen
    ]


def _dynamics_profile(profile: str, intensity: int) -> list[str]:
    """Stage-4 leveling — deliberately gentle (dynamics-preserving).

    Voice gets slightly tighter control than music; intensity (the mapped
    noise_strength) only nudges the threshold, never the ratio, so loud
    passages keep their shape. Ratios stay <= 2.2:1 — no pumping, no
    crushing, the classic Dolby 'gentle leveling' behavior.
    """
    if profile == "voice":
        thr = max(-26.0, -21.0 - (intensity - 20) * 0.08)
        return [f"acompressor=threshold={thr:.1f}dB:ratio=2.2:attack=12:"
                f"release=180:makeup=2"]
    thr = max(-24.0, -19.0 - (intensity - 20) * 0.06)
    return [f"acompressor=threshold={thr:.1f}dB:ratio=1.8:attack=25:"
            f"release=320:makeup=1.5"]


# --------------------------------------------------------------------- run

def run(path: str | Path, out_path: str | Path,
        noise_strength: int = 20, profile: str = "music",
        spatial: bool = True, declick: bool = True, dehum: bool = True,
        on_progress: Callable[[str, int], None] | None = None) -> dict:
    """Full offline Dolby-style enhance — 7 verified stages + QA gate.

    Returns the same shape as dolby.run() so callers can swap engines.
    Raises nothing for engine-level failure — returns ok=False with a
    structured reason instead (same contract as the online engine).
    """
    src = Path(path)
    dst = Path(out_path)
    notes: list[str] = ["Dolby OFFLINE — 7-stage local engine (no API, "
                        "no keys, no upload)"]
    # structured analysis & decision trail — drives the UI decision panel
    stages: list[dict] = []
    decision: dict = {}

    def stage(n: int, name: str, status: str, detail: str) -> None:
        stages.append({"n": n, "name": name, "status": status,
                       "detail": detail})

    def prog(msg: str, pct: int) -> None:
        if on_progress:
            on_progress(msg, pct)

    try:
        # ============ STAGE 1 — ANALYZE ================================
        prog("Dolby-off 1/7: analyzing input", _STAGE_PCT[1])
        ref = analyze(src)
        if not ref.duration:
            return {"ok": False, "verdict": "fail",
                    "reason": "input analysis failed — unreadable audio",
                    "stages": stages, "decision": decision, "notes": notes}
        profile = "voice" if profile in ("voice", "voiceover") else "music"
        stereo = (ref.channels or 1) >= 2
        lufs = ref.lufs
        decision.update({
            "profile": profile,
            "profile_desc": (
                "speech contour — mud cut 240Hz, presence 2.8k, "
                "de-harsh 6.8k, air 10.5k, LPF 14kHz"
                if profile == "voice" else
                "full-mix contour — sub-bass 55Hz, warmth 220Hz, "
                "presence 2.8k, dip 6.8k, sheen 12kHz"),
            "channels": ref.channels,
            "stereo": stereo,
            "noise_requested": max(0, min(45, int(noise_strength))),
            "noise_cap": 45,
            "spatial_requested": bool(spatial),
            "declick": bool(declick),
            "dehum": bool(dehum),
            "true_peak_ceiling": -1.5,
            "output_format": "48 kHz · 24-bit WAV",
            "loudness_rule": "source LUFS preserved, clamped to [-35, -9]",
        })
        stage(1, "ANALYZE",
              "done",
              f"{ref.duration:.1f}s · {ref.sample_rate} Hz · {ref.channels} ch · "
              f"{lufs if lufs is not None else '?'} LUFS · profile={profile}")
        notes.append(
            f"stage1 analyze: {ref.duration:.1f}s, {ref.sample_rate}Hz, "
            f"{ref.channels}ch, {lufs if lufs is not None else '?'} LUFS, "
            f"profile={profile}")
        # loudness target = source LUFS, clamped to the safe window
        # (identical rule to the online engine — preserve, never crush)
        target_lufs = None
        if lufs is not None:
            target_lufs = max(-35.0, min(-9.0, float(lufs)))
            decision["loudness_target"] = round(target_lufs, 1)
            notes.append(f"stage1 loudness target: {target_lufs:.1f} LUFS "
                         "(source-preserved)")
        else:
            decision["loudness_target"] = -16.0

        # workdir for staged intermediates
        workdir = Path(tempfile.mkdtemp(prefix="dolbyoff_"))
        try:
            cur_in: Path = src

            def next_file(stage: int) -> Path:
                return workdir / f"s{stage}.wav"

            # ============ STAGE 2 — REPAIR ============================
            prog("Dolby-off 2/7: repair (declick / dehum / rumble)",
                 _STAGE_PCT[2])
            chain: list[str] = []
            if dehum:
                chain += [
                    "equalizer=f=50:width_type=h:width=1.2:g=-10",
                    "equalizer=f=60:width_type=h:width=1.2:g=-10",
                    "equalizer=f=100:width_type=h:width=1.2:g=-8",
                ]
            chain += ["highpass=f=35"]  # rumble
            if declick:
                chain += ["adeclick=window=55:overlap=75:arorder=4"]
            if chain:
                s2 = next_file(2)
                _ff(["-i", str(cur_in), "-af", ",".join(chain),
                     "-ar", "48000", str(s2)])
                _verify(s2, 2, "repair")
                cur_in = s2
                stage(2, "REPAIR", "done",
                      f"declick={'on' if declick else 'off'} · "
                      f"dehum 50/60/100Hz {'on' if dehum else 'off'} · "
                      f"rumble HPF 35Hz · resample 48kHz")
                notes.append(f"stage2 repair: declick={declick}, "
                             f"dehum={dehum}, rumble HPF 35Hz")
            else:
                stage(2, "REPAIR", "skipped", "disabled in settings")
                notes.append("stage2 repair: skipped (disabled)")

            # ============ STAGE 3 — SPECTRAL DENOISE ==================
            prog("Dolby-off 3/7: spectral noise reduction", _STAGE_PCT[3])
            nr = max(0, min(45, int(noise_strength)))  # hard cap, like online
            decision["noise_applied"] = nr
            if nr > 0:
                nf = -50 if profile == "voice" else -45
                s3 = next_file(3)
                _ff(["-i", str(cur_in), "-af",
                     f"afftdn=nr={nr}:nf={nf}:tn=1", str(s3)])
                _verify(s3, 3, "denoise")
                cur_in = s3
                stage(3, "DENOISE", "done",
                      f"spectral afftdn nr={nr}dB (cap 45) · "
                      f"floor {nf}dB · trained noise")
                notes.append(f"stage3 denoise: afftdn nr={nr}dB "
                             f"(cap 45, mixed-content safe)")
            else:
                stage(3, "DENOISE", "skipped", "noise reduction = 0")
                notes.append("stage3 denoise: off (0)")

            # ============ STAGE 4 — DYNAMICS ==========================
            prog("Dolby-off 4/7: dynamics leveling", _STAGE_PCT[4])
            s4 = next_file(4)
            dyn = _dynamics_profile(profile, nr)
            _ff(["-i", str(cur_in), "-af", ",".join(dyn), str(s4)])
            _verify(s4, 4, "dynamics")
            cur_in = s4
            ratio = "2.2:1" if profile == "voice" else "1.8:1"
            thr_s = dyn[0].split("threshold=")[1].split("dB")[0]
            decision["dynamics"] = (f"gentle leveling · ratio {ratio} · "
                                    f"threshold {thr_s}dB · "
                                    "dynamics preserved (no pumping)")
            stage(4, "DYNAMICS", "done",
                  f"acompressor ratio {ratio} · threshold {thr_s}dB · "
                  "dynamics kept")
            notes.append("stage4 dynamics: " +
                         dyn[0].split(":threshold=")[0].split("=")[0] +
                         " gentle leveling (ratio <= 2.2:1, dynamics kept)")

            # ============ STAGE 5 — PROFILE EQ ========================
            prog("Dolby-off 5/7: profile EQ curve", _STAGE_PCT[5])
            s5 = next_file(5)
            _ff(["-i", str(cur_in), "-af", ",".join(_eq_profile(profile)),
                 str(s5)])
            _verify(s5, 5, "profile-eq")
            cur_in = s5
            pts = []
            for e in _eq_profile(profile):
                if "g=" not in e:
                    continue          # lowpass has no gain node
                f_hz = e.split("f=")[1].split(":")[0]
                g_db = e.split("g=")[1]
                pts.append(f"{f_hz}Hz "
                           + (g_db if g_db.startswith("-") else "+" + g_db)
                           + "dB")
            decision["eq"] = (f"{profile} contour · "
                              + " · ".join(pts))
            stage(5, "PROFILE EQ", "done", decision["eq"])
            notes.append(f"stage5 profile EQ: {profile} contour "
                         "(body/presence/air, harshness dip)")

            # ============ STAGE 6 — SPATIAL ===========================
            prog("Dolby-off 6/7: spatial widening", _STAGE_PCT[6])
            if spatial and stereo:
                s6 = next_file(6)
                _ff(["-i", str(cur_in), "-af",
                     "extrastereo=m=1.25:c=true,"
                     "adelay=0.4:0:all=1,"          # Haas micro-delay
                     "alimiter=limit=0.97:level=false",
                     str(s6)])
                _verify(s6, 6, "spatial")
                cur_in = s6
                decision["spatial_applied"] = True
                decision["spatial_reason"] = ("stereo source — width ×1.25 + "
                                             "Haas 0.4ms")
                stage(6, "SPATIAL", "done",
                      "extrastereo ×1.25 + Haas 0.4ms (stereo source)")
                notes.append("stage6 spatial: width x1.25 + Haas 0.4ms "
                             "(stereo source)")
            else:
                decision["spatial_applied"] = False
                decision["spatial_reason"] = (
                    "mono source — mono stays mono, never fake-stereo"
                    if not stereo else "disabled in settings")
                stage(6, "SPATIAL", "skipped", decision["spatial_reason"])
                notes.append("stage6 spatial: skipped "
                             f"({'mono source' if not stereo else 'disabled'})")

            # ============ STAGE 7 — MASTER ============================
            prog("Dolby-off 7/7: loudness + true-peak master", _STAGE_PCT[7])
            if target_lufs is not None:
                af = (f"loudnorm=I={target_lufs:.1f}:TP=-1.5:LRA=11,"
                      f"alimiter=limit=0.97:level=false")
            else:
                af = "loudnorm=I=-16:TP=-1.5:LRA=11," \
                     "alimiter=limit=0.97:level=false"
            dst.parent.mkdir(parents=True, exist_ok=True)
            _ff(["-i", str(cur_in), "-af", af,
                 "-ar", "48000", "-c:a", "pcm_s24le", str(dst)])
            _verify(dst, 7, "master")
            stage(7, "MASTER", "done",
                  f"loudnorm {target_lufs:.1f} LUFS · TP -1.5 dBTP · "
                  "safety limiter 0.97" if target_lufs is not None else
                  "loudnorm -16 LUFS (default) · TP -1.5 dBTP · "
                  "safety limiter 0.97")
            notes.append(f"stage7 master: loudnorm "
                         f"({target_lufs:.1f} LUFS, TP -1.5) + safety limiter"
                         if target_lufs is not None else
                         "stage7 master: loudnorm (-16 LUFS default) "
                         "+ safety limiter")

            # ============ QA GATE =====================================
            prog("Dolby-off: QA gate", 95)
            out_stats = analyze(dst)
            qa = qa_gate(ref, out_stats, label="dolby_off")
            stage(8, "QA GATE", "done" if qa.ok else qa.verdict,
                  ("all gates passed — duration, aliveness, DC, level, clip"
                   if qa.ok else "; ".join(qa.issues)[:200]))
            notes.extend(qa.issues)
            if not qa.ok:
                dst.unlink(missing_ok=True)
                return {"ok": False, "verdict": qa.verdict,
                        "reason": "; ".join(qa.issues), "qa": qa.to_dict(),
                        "stages": stages, "decision": decision,
                        "stats_before": ref.to_dict(), "notes": notes}
            prog("Dolby-off: done — QA passed", 100)
            return {"ok": True, "verdict": qa.verdict, "engine": "dolby_off",
                    "qa": qa.to_dict(), "stats": out_stats.to_dict(),
                    "stats_before": ref.to_dict(),
                    "stages": stages, "decision": decision,
                    "output": str(dst), "notes": notes}

        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    except DolbyOfflineError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail", "reason": str(exc),
                "stages": stages, "decision": decision, "notes": notes}
    except DSPError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[dolby-offline] {exc}",
                "stages": stages, "decision": decision, "notes": notes}
    except Exception as exc:  # never silently crash the pipeline
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[dolby-offline] unexpected error: {exc}",
                "stages": stages, "decision": decision, "notes": notes}
