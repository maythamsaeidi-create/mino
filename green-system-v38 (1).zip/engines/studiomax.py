"""STUDIO MAX — engine #3: the strongest-combination AI remaster (v38).

The reasoning that picked this combination (audited live against
HuggingFace / GitHub / PyPI before a single line was written):

  candidate            | size    | CPU          | verdict
  ---------------------+---------+--------------+--------------------------
  AudioSR (diffusion)  | 6.2 GB  | 60-step, very| rejected — GitHub repo
                       |         | slow         | gone, numpy<=1.23 pins
  FlashSR (one-step)   | 3.2 GB  | 1 pass but   | too heavy for small
                       |         | needs ~6 GB  | machines (future tier)
  Apollo (Tencent AI)  |  63 MB  | 1 GAN pass   | CHOSEN — music restore
  Demucs htdemucs      |  81 MB  | 0.4x RT      | CHOSEN — local AI split
  Resemble Enhance     | 713 MB  | CFM solver   | CHOSEN (already in-app)

One engine, three world-class AI specialists, each doing what it is
best at — stronger AND more robust than any single monolithic model:

  Stage 1  ANALYZE  : ebur128 + astats pre-scan
  Stage 2  SPLIT    : Demucs v4 (Meta) — LOCAL AI stem separation into
                      vocals + music bed (no cloud MVSEP needed)
  Stage 3  RESTORE  : Apollo (Tencent AI Lab, arXiv:2409.08514) —
                      generative band-sequence restoration of the music
                      bed: rebuilds the mid/high spectrum damaged by
                      codecs / old recordings. Graceful fallback:
                      harmonic exciter + spectral denoise (the engine
                      ALWAYS finishes).
  Stage 4  VOICE    : the vocals stem runs the battle-tested Mic Studio
                      engine (Resemble AI, natural profile) — voice gets
                      the voice specialist, not a music model.
  Stage 5  POLISH   : analog remaster chain in numpy/scipy — sub HPF,
                      tube warmth, air exciter, M/S width on the bed.
  Stage 6  REMIX    : vocals + bed summed at original balance
  Stage 7  SPATIAL  : Haas inter-aural depth + M/S stereo image
  Stage 8  MASTER   : loudness normalize to target + true-peak limiter,
                      48 kHz / 24-bit
  QA GATE            : the shared analysis/QA layer (every engine has it)

RAM hygiene: each AI stage runs in its OWN throwaway subprocess
(engines/studiomax_worker.py) — torch + weights are loaded, used, and
returned to the OS before the next specialist starts. The server
process itself never imports torch. This is the proven
studiomic_ai_worker pattern, applied to all three specialists.

Every stage is a tickable module (engines/catalog.py) — the user can
turn each activity on/off live and A/B it in Stem Studio.

Models auto-download from HuggingFace on first use (POST /api/model/ensure):
  apollo  -> JusperLee/Apollo            (63 MB)
  demucs  -> adefossez/HTDemucs          (81 MB)
  demucs_ft -> adefossez/HTDemucs-ft     (4x81 MB, max quality, optional)
  resemble -> ResembleAI/resemble-enhance (713 MB, existing v37 path)
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Callable

import numpy as np

from .analysis import analyze, probe, qa_gate
from .local import DSPError, _ff
from . import studiomic

# ---------------------------------------------------------------- models

_APOLLO_URL = "https://huggingface.co/JusperLee/Apollo/resolve/main/pytorch_model.bin"


def _models_root() -> Path:
    """Model root — same discovery contract as studiomic._run_dir().

    Search order:
      1. <app>/models      — app-local (fresh installs, full zip)
      2. <parent>/models   — legacy workspace layout
    First candidate that actually holds ANY known model wins; a fresh
    extraction returns the app-local path (the canonical drop point)."""
    here = Path(__file__).resolve()
    app_root = here.parents[1]
    known = ("resemble-enhance", "apollo", "demucs_hf")
    for root in (app_root / "models", app_root.parent / "models"):
        try:
            if root.exists() and any((root / k).exists() for k in known):
                return root
        except OSError:
            continue
    return app_root / "models"


MODELS_ROOT = _models_root()
APOLLO_DIR = MODELS_ROOT / "apollo"
APOLLO_CKPT = APOLLO_DIR / "pytorch_model.bin"
DEMUCS_CACHE = MODELS_ROOT / "demucs_hf"

# The huggingface_hub cache MUST be pinned before the hub is imported
# (the worker subprocess inherits the env; nothing imports the hub at
# boot in the server process).
for _k in ("HF_HUB_CACHE", "HUGGINGFACE_HUB_CACHE"):
    os.environ.setdefault(_k, str(DEMUCS_CACHE))
try:
    DEMUCS_CACHE.mkdir(parents=True, exist_ok=True)
except OSError:
    pass

_STAGE_PCT = {1: 3, 2: 6, 3: 34, 4: 60, 5: 74, 6: 80, 7: 86, 8: 93, 9: 97}


# ---------------------------------------------------------------- health

def apollo_present() -> bool:
    try:
        return APOLLO_CKPT.exists() and APOLLO_CKPT.stat().st_size > 1_000_000
    except OSError:
        return False


def _demucs_snapshot(repo_dir: str) -> list[Path]:
    hits: list[Path] = []
    try:
        for snap in (DEMUCS_CACHE / repo_dir / "snapshots").glob("*"):
            for f in snap.glob("*.safetensors"):
                try:
                    if f.stat().st_size > 10_000_000:
                        hits.append(f)
                except OSError:
                    pass
    except OSError:
        pass
    return hits


def demucs_present(variant: str = "htdemucs") -> bool:
    repo = "models--adefossez--HTDemucs" if variant == "htdemucs" \
        else "models--adefossez--HTDemucs-ft"
    return bool(_demucs_snapshot(repo))


def model_status() -> dict:
    """AI inventory for /api/dsp/health and /api/model/status."""
    try:
        import demucs  # noqa: F401
        demucs_pkg = True
    except Exception:
        demucs_pkg = False
    try:
        import torch  # noqa: F401
        torch_ok = True
    except Exception:
        torch_ok = False
    st = {
        "ok": torch_ok,
        "torch": torch_ok,
        "demucs_pkg": demucs_pkg,
        "demucs": demucs_present("htdemucs"),
        "demucs_ft": demucs_present("htdemucs_ft"),
        "apollo": apollo_present(),
        "apollo_url": _APOLLO_URL,
        "apollo_path": str(APOLLO_CKPT),
        "demucs_cache": str(DEMUCS_CACHE),
        "resemble": bool(studiomic.ai_status().get("resemble")),
    }
    return st


# ---------------------------------------------------------------- worker

def _run_worker(args: list, timeout: float,
                progress: Callable[[str, int], None] | None = None,
                pct_lo: int = 0, pct_hi: int = 100,
                on_line: Callable[[str], None] | None = None) -> bool:
    """Run one isolated AI worker; map its PROG lines onto the job range.

    Robust IO: raw fd + select with a hard deadline (a hung worker can
    never wedge a job thread), manual line reassembly, stderr untouched.
    Only stdout is consumed; everything else goes to the daemon log.
    Returns True when the worker exited 0 with an OK line."""
    import os as _os
    import select as _select
    import time as _time

    cmd = [sys.executable, "-m", "engines.studiomax_worker"] + \
        [str(a) for a in args]
    try:
        proc = subprocess.Popen(
            cmd, cwd=str(Path(__file__).resolve().parents[1]),
            stdout=subprocess.PIPE, stderr=None,
            env={**_os.environ, "PYTHONUNBUFFERED": "1"})
    except OSError as exc:
        if on_line:
            on_line(f"worker spawn failed: {exc}")
        return False

    ok = False
    timed_out = False
    try:
        fd = proc.stdout.fileno()
        deadline = _time.monotonic() + max(60.0, timeout)
        buf = ""
        while True:
            remain = deadline - _time.monotonic()
            if remain <= 0:
                timed_out = True
                break
            try:
                r, _, _ = _select.select([fd], [], [], min(1.0, remain))
            except (OSError, ValueError):
                break
            if not r:
                continue
            data = _os.read(fd, 65536)
            if not data:
                break                       # EOF — worker finished writing
            buf += data.decode("utf-8", "replace")
            while "\n" in buf:
                line, buf = buf.split("\n", 1)
                line = line.strip()
                if not line:
                    continue
                if line.startswith("PROG "):
                    rest = line[5:].split(" ", 1)
                    try:
                        pct = int(rest[0])
                    except (ValueError, IndexError):
                        continue
                    msg = rest[1] if len(rest) > 1 else ""
                    if progress:
                        progress(msg,
                                 pct_lo + int(pct * (pct_hi - pct_lo) / 100))
                else:
                    if on_line:
                        on_line(line)
                    if line.startswith("OK"):
                        ok = True
        if timed_out:
            if on_line:
                on_line(f"worker timed out after {timeout:.0f}s")
            proc.kill()
            return False
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            proc.kill()
            return False
    finally:
        try:
            proc.stdout.close()
        except Exception:
            pass
    return ok and proc.returncode == 0


def _demucs_split(wav_in: Path, workdir: Path,
                  timeout: float,
                  progress: Callable[[str, int], None] | None = None,
                  pct_lo: int = 0, pct_hi: int = 100) -> tuple[Path, Path] | None:
    """Demucs stem split in an isolated subprocess. Returns
    (bed.wav, vocals.wav) paths, or None when the model is absent /
    the worker failed (caller falls back). Uses htdemucs_ft (bag of 4,
    higher quality) when its weights are present, else htdemucs."""
    if not demucs_present():
        return None
    variant = "htdemucs_ft" if demucs_present("htdemucs_ft") else "htdemucs"
    bed = workdir / "bed_in.wav"
    voc = workdir / "voc_in.wav"
    ok = _run_worker(["split", wav_in, bed, voc, variant], timeout=timeout,
                     progress=progress, pct_lo=pct_lo, pct_hi=pct_hi,
                     on_line=lambda m: None)
    if ok and bed.exists() and voc.exists() \
            and bed.stat().st_size > 4000 and voc.stat().st_size > 4000:
        _demucs_split.variant = variant      # noqa: SLF001 — stage detail
        return bed, voc
    return None


def _apollo_restore(wav_in: Path, wav_out: Path, blend: float,
                    timeout: float,
                    progress: Callable[[str, int], None] | None = None,
                    pct_lo: int = 0, pct_hi: int = 100) -> bool:
    """Apollo music restoration in an isolated subprocess."""
    if not apollo_present():
        return False
    return _run_worker(["restore", wav_in, wav_out, round(blend, 1),
                        APOLLO_CKPT], timeout=timeout,
                       progress=progress, pct_lo=pct_lo, pct_hi=pct_hi,
                       on_line=lambda m: None) and wav_out.exists() \
        and wav_out.stat().st_size > 4000


# ---------------------------------------------------------------- DSP core

_SR = 44100        # demucs + apollo native rate
_OUT_SR = 48000    # final master rate (studio standard)


def _butter_hp(x: np.ndarray, sr: int, f: float, order: int = 2) -> np.ndarray:
    from scipy.signal import butter, sosfilt
    sos = butter(order, f, btype="highpass", fs=sr, output="sos")
    return sosfilt(sos, x, axis=0)


def _band(x: np.ndarray, sr: int, lo: float, hi: float) -> np.ndarray:
    from scipy.signal import butter, sosfilt
    sos = butter(2, [lo, hi], btype="bandpass", fs=sr, output="sos")
    return sosfilt(sos, x, axis=0)


def _ms_width(x: np.ndarray, amt: float) -> np.ndarray:
    """Mid/Side width (amt 1.0 = untouched, >1 wider)."""
    m = (x[:, 0] + x[:, 1]) * 0.5
    s = (x[:, 1] - x[:, 0]) * 0.5
    w = amt
    return np.stack([m - w * s, m + w * s], axis=1).astype(np.float32)


def _exciter(x: np.ndarray, sr: int, amt: float) -> np.ndarray:
    """Harmonic air: generate new high-frequency content (Aphex-style)."""
    hi = _band(x, sr, 4200.0, min(16000.0, sr / 2 - 500))
    shaped = np.tanh(hi * 2.2) * 0.55
    return np.clip(x + shaped * (amt / 100.0), -1.5, 1.5).astype(np.float32)


def _warmth(x: np.ndarray, sr: int, amt: float) -> np.ndarray:
    """Tube-style saturation on the low-mid band (even harmonics)."""
    lo = _band(x, sr, 120.0, 1800.0)
    shaped = np.tanh(lo * 1.6) * 0.7
    return np.clip(x + shaped * (amt / 100.0) * 0.35, -1.5, 1.5).astype(np.float32)


def _haas(x: np.ndarray, sr: int, depth: float = 0.30) -> np.ndarray:
    """Inter-aural micro-delay on the side signal (spatial depth)."""
    d = int(sr * 0.0004)                    # ~0.4 ms
    if d < 1 or x.shape[0] <= d:
        return x
    m = (x[:, 0] + x[:, 1]) * 0.5
    s = (x[:, 1] - x[:, 0]) * 0.5
    s_d = np.concatenate([np.zeros(d, np.float32), s[:-d]])
    s = (s + depth * s_d).astype(np.float32)
    return np.stack([m - s, m + s], axis=1).astype(np.float32)


def _polish_bed(x: np.ndarray, sr: int) -> np.ndarray:
    """Analog polish chain on the music bed (sub HPF + warmth + air + width)."""
    y = _butter_hp(x, sr, 26.0)
    y = _warmth(y, sr, 45.0)
    y = _exciter(y, sr, 35.0)
    y = _ms_width(y, 1.18)
    peak = float(np.max(np.abs(y))) if y.size else 0.0
    if peak > 0.99:
        y = y * (0.97 / peak)
    return y.astype(np.float32)


def _fallback_restore(x: np.ndarray, sr: int) -> tuple[np.ndarray, str]:
    """No-Apollo path: spectral denoise (if available) + harmonic exciter.
    Reconstructs a good part of the perceptual 'restored' character."""
    y = x
    how = "exciter"
    try:
        import noisereduce as nr
        y = nr.reduce_noise(y=y, sr=sr, stationary=False, prop_decrease=0.35)
        how = "noisereduce+exciter"
    except Exception:
        pass
    y = _exciter(np.asarray(y, np.float32), sr, 55.0)
    peak = float(np.max(np.abs(y))) if y.size else 0.0
    if peak > 0.99:
        y = y * (0.97 / peak)
    return np.asarray(y, np.float32), how


# ---------------------------------------------------------------- run

class StudioMaxError(DSPError):
    """Stage-tagged human-readable failure."""


def _verify(out: Path, stage_no: int, what: str) -> dict:
    p = probe(out)
    if not p.get("ok") or not p.get("duration"):
        out.unlink(missing_ok=True)
        raise StudioMaxError(f"stage {stage_no} ({what}): output is not "
                             "decodable audio — see daemon.log")
    return p


def run(path: str | Path, out_path: str | Path,
        modules: dict | None = None,
        split: bool = True, restore: float = 75, voice: float = 70,
        polish: bool = True, spatial: bool = True, master: bool = True,
        width: float = 1.35, lufs: float = -16,
        on_progress: Callable[[str, int], None] | None = None) -> dict:
    """Full Studio Max remaster — 8 stages + QA gate, studiomic contract.

    modules = {split, restore, voice, polish, spatial, master} ticks
    (the Stem Studio activity panel). Amounts: restore/voice in %,
    width in x, lufs target in LUFS.
    """
    src, dst = Path(path), Path(out_path)
    notes: list[str] = ["Studio Max — AI remaster combination engine "
                        "(Demucs split + Apollo restore + Resemble voice), "
                        "local, no keys, no cloud"]
    stages: list[dict] = []
    decision: dict = {"engine": "studiomax"}

    def stage(n, name, status, detail):
        stages.append({"n": n, "name": name, "status": status,
                       "detail": str(detail)[:200]})

    def prog(msg, pct):
        if on_progress:
            on_progress(msg, pct)

    mods = {"split": True, "restore": True, "voice": True,
            "polish": True, "spatial": True, "master": True}
    if isinstance(modules, dict):
        for k in mods:
            if k in modules:
                mods[k] = bool(modules[k])
    # legacy param-offs (module ticked off via catalog param mapping)
    mods["split"] = mods["split"] and bool(split)
    mods["restore"] = mods["restore"] and (float(restore) > 0.5)
    mods["voice"] = mods["voice"] and (float(voice) > 0.5)
    mods["polish"] = mods["polish"] and bool(polish)
    mods["spatial"] = mods["spatial"] and bool(spatial)
    mods["master"] = mods["master"] and bool(master)
    blend = max(0.0, min(100.0, float(restore)))
    voice_amt = max(0.0, min(100.0, float(voice)))
    width = max(1.0, min(1.8, float(width)))
    lufs = max(-30.0, min(-9.0, float(lufs)))

    workdir = Path(tempfile.mkdtemp(prefix="studiomax_"))
    try:
        # ============ STAGE 1 — ANALYZE ================================
        prog("Max 1/8: analyzing input", _STAGE_PCT[1])
        ref = analyze(src)
        if not ref.duration:
            return {"ok": False, "verdict": "fail",
                    "reason": "input analysis failed — unreadable audio",
                    "stages": stages, "decision": decision, "notes": notes}
        stage(1, "ANALYZE", "done",
              f"{ref.duration:.1f}s · {ref.sample_rate} Hz · "
              f"{ref.lufs if ref.lufs is not None else '?'} LUFS")
        decision.update({"duration_s": round(ref.duration, 1),
                         "modules": dict(mods),
                         "restore_blend_pct": round(blend),
                         "voice_amount_pct": round(voice_amt),
                         "width_x": round(width, 2),
                         "lufs_target": round(lufs, 1)})
        dur = float(ref.duration)

        import soundfile as sf

        # ============ STAGE 2 — AI SPLIT (Demucs, subprocess) =========
        prog("Max 2/8: AI stem split (demucs)", _STAGE_PCT[2])
        s0 = workdir / "s0_44k.wav"
        _ff(["-i", str(src), "-ar", str(_SR), "-ac", "2", "-vn",
             "-c:a", "pcm_f32le", str(s0)])
        bed_path: Path
        voc_path: Path | None = None
        demucs_used = False
        if mods["split"]:
            got = _demucs_split(s0, workdir, timeout=dur * 12 + 240,
                                progress=prog, pct_lo=_STAGE_PCT[2],
                                pct_hi=_STAGE_PCT[3] - 4)
            demucs_used = got is not None
            if got is None:
                notes.append("stage2 split: demucs model missing/failed — "
                             "treating the input as one music bed (no voice "
                             'stage; POST /api/model/ensure {"model":'
                             '"demucs"} to enable)')
                stage(2, "AI SPLIT", "skip",
                      "demucs weights not present — bed-only mode")
                mods["voice"] = False
                bed_path = s0
            else:
                bed_path, voc_path = got
                stage(2, "AI SPLIT", "done",
                      f"demucs {_demucs_split.variant} → vocals + music bed "
                      "(isolated worker)")
                notes.append(f"stage2 split: demucs "
                             f"{_demucs_split.variant} local AI separation "
                             "(vocals | bed)")
        else:
            stage(2, "AI SPLIT", "off", "module ticked off — bed-only")
            mods["voice"] = False
            bed_path = s0

        # ============ STAGE 3 — AI RESTORE (Apollo, subprocess) =======
        prog("Max 3/8: AI music restore (apollo)", _STAGE_PCT[3])
        bed_done = bed_path
        apollo_used = False
        if mods["restore"]:
            bed_out = workdir / "bed_restored.wav"
            ok = _apollo_restore(bed_path, bed_out, blend,
                                 timeout=dur * 14 + 300,
                                 progress=prog, pct_lo=_STAGE_PCT[3],
                                 pct_hi=_STAGE_PCT[4] - 4)
            if ok:
                bed_done = bed_out
                apollo_used = True
                stage(3, "AI RESTORE", "done",
                      f"apollo band-sequence restore · blend {blend:.0f}% "
                      "(isolated worker)")
                notes.append(f"stage3 restore: apollo AI restore "
                             f"(wet {blend:.0f}%)")
            else:
                x, sr = sf.read(str(bed_path), dtype="float32",
                                always_2d=True)
                y, how = _fallback_restore(np.asarray(x, np.float32), sr)
                fb = workdir / "bed_fallback.wav"
                sf.write(str(fb), y, sr, subtype="FLOAT")
                bed_done = fb
                notes.append("stage3 restore: apollo missing/failed — DSP "
                             f"fallback ({how}) used; POST /api/model/"
                             'ensure {"model":"apollo"} for the AI restore')
                stage(3, "AI RESTORE", "fallback",
                      f"apollo unavailable — {how} fallback")
        else:
            stage(3, "AI RESTORE", "off", "module ticked off")

        # ============ STAGE 4 — AI VOICE (Resemble via Mic Studio) =====
        prog("Max 4/8: AI voice studio (resemble)", _STAGE_PCT[4])
        voc_out: Path | None = None
        voc_ai_backend = None
        if mods["voice"] and voc_path is not None:
            import time as _t
            t0 = _t.time()
            v_out = workdir / "voc_out.wav"
            try:
                v_res = studiomic.run(
                    voc_path, v_out, ai_clean=voice_amt,
                    mic_profile="natural", target_lufs="auto",
                    declick=True, dehum=True)
                if v_res.get("ok") and v_out.exists():
                    voc_out = v_out
                    voc_ai_backend = (v_res.get("decision", {})
                                      .get("ai_backend"))
                    stage(4, "AI VOICE",
                          "done" if voc_ai_backend == "resemble"
                          else "fallback",
                          f"mic-studio natural · backend {voc_ai_backend} "
                          f"· ai_clean {voice_amt:.0f}% in "
                          f"{_t.time() - t0:.0f}s")
                    notes.append(f"stage4 voice: {voc_ai_backend} on the "
                                 f"vocals stem (ai_clean "
                                 f"{voice_amt:.0f}%)")
                else:
                    voc_out = voc_path
                    stage(4, "AI VOICE", "fallback",
                          "mic-studio failed — raw vocals kept")
                    notes.append("stage4 voice: studiomic failed ("
                                 + str(v_res.get("reason", ""))[:80]
                                 + ") — raw vocals kept")
            except Exception as exc:              # noqa: BLE001
                voc_out = voc_path
                stage(4, "AI VOICE", "fallback",
                      f"mic-studio crashed — raw vocals kept ({exc})")
                notes.append("stage4 voice: studiomic crashed — raw kept")
        else:
            stage(4, "AI VOICE", "off",
                  "no isolated vocals (split off/missing) or module off")

        # ============ STAGE 5 — ANALOG POLISH ==========================
        prog("Max 5/8: analog polish (bed)", _STAGE_PCT[5])
        if mods["polish"]:
            x, sr = sf.read(str(bed_done), dtype="float32", always_2d=True)
            y = _polish_bed(np.asarray(x, np.float32), sr)
            pol = workdir / "bed_polished.wav"
            sf.write(str(pol), y, sr, subtype="FLOAT")
            bed_done = pol
            stage(5, "POLISH", "done",
                  "sub HPF 26 Hz + tube warmth + air exciter + width 1.18")
            notes.append("stage5 polish: analog remaster chain on the bed")
        else:
            stage(5, "POLISH", "off", "module ticked off")

        # ============ STAGE 6 — REMIX ==================================
        prog("Max 6/8: remix (vocals + bed)", _STAGE_PCT[6])
        bed48 = workdir / "bed_48k.wav"
        _ff(["-i", str(bed_done), "-ar", str(_OUT_SR),
             "-c:a", "pcm_f32le", str(bed48)])
        if voc_out is not None:
            mixf = workdir / "remix.wav"
            _ff(["-i", str(bed48), "-i", str(voc_out),
                 "-filter_complex",
                 f"amix=inputs=2:duration=longest:normalize=0,"
                 f"aresample={_OUT_SR}",
                 "-c:a", "pcm_f32le", str(mixf)])
            stage(6, "REMIX", "done", "vocals + music bed, original balance")
        else:
            mixf = bed48
            stage(6, "REMIX", "done", "music bed only (no vocal stem)")
        notes.append("stage6 remix: " + ("vocals + bed summed"
                     if voc_out is not None else "bed passthrough"))
        _verify(mixf, 6, "remix")

        # ============ STAGE 7 — 3D SPATIAL =============================
        prog("Max 7/8: 3D spatial", _STAGE_PCT[7])
        if mods["spatial"]:
            mx, msr = sf.read(str(mixf), dtype="float32", always_2d=True)
            y = _haas(_ms_width(np.asarray(mx, np.float32), width), msr, 0.30)
            peak = float(np.max(np.abs(y))) if y.size else 0.0
            if peak > 0.99:
                y = y * (0.97 / peak)
            spat = workdir / "spatial.wav"
            sf.write(str(spat), y, msr, subtype="FLOAT")
            stage(7, "SPATIAL", "done",
                  f"M/S width {width:.2f}x + 0.4 ms Haas depth")
            notes.append(f"stage7 spatial: width {width:.2f}x + haas")
            mixf = spat
            _verify(mixf, 7, "spatial")
        else:
            stage(7, "SPATIAL", "off", "module ticked off")

        # ============ STAGE 8 — MASTER =================================
        prog("Max 8/8: loudness master", _STAGE_PCT[8])
        dst.parent.mkdir(parents=True, exist_ok=True)
        if mods["master"]:
            _ff(["-i", str(mixf), "-af",
                 f"loudnorm=I={lufs:.1f}:TP=-1.5:LRA=11,"
                 f"alimiter=limit=0.97:level=false",
                 "-ar", str(_OUT_SR), "-c:a", "pcm_s24le", str(dst)])
            stage(8, "MASTER", "done",
                  f"loudnorm {lufs:.1f} LUFS + true-peak limit −1.5 dBTP · "
                  f"{_OUT_SR // 1000} kHz / 24-bit")
            notes.append(f"stage8 master: {lufs:.1f} LUFS, TP −1.5, "
                         f"{_OUT_SR // 1000} kHz 24-bit")
        else:
            _ff(["-i", str(mixf), "-ar", str(_OUT_SR),
                 "-c:a", "pcm_s24le", str(dst)])
            stage(8, "MASTER", "off",
                  "module ticked off — level preserved (24-bit remaster)")
            notes.append("stage8 master: off — source level preserved")
        _verify(dst, 8, "master")

        # ============ STAGE 9 — QA GATE ================================
        prog("Max 9/9: QA gate", _STAGE_PCT[9])
        out_stats = analyze(dst)
        qa = qa_gate(ref, out_stats, label="studiomax")
        stage(9, "QA GATE", "done" if qa.ok else qa.verdict,
              "all gates passed — duration, aliveness, DC, level"
              if qa.ok else "; ".join(qa.issues)[:200])
        notes.extend(qa.issues)
        decision["ai_used"] = {
            "demucs": bool(demucs_used),
            "apollo": bool(apollo_used),
            "resemble": bool(mods["voice"]) and
            (voc_ai_backend == "resemble"),
        }
        if not qa.ok:
            dst.unlink(missing_ok=True)
            return {"ok": False, "verdict": qa.verdict,
                    "reason": "; ".join(qa.issues), "qa": qa.to_dict(),
                    "stages": stages, "decision": decision,
                    "stats_before": ref.to_dict(), "notes": notes}
        prog("Studio Max: done — QA passed", 100)
        return {"ok": True, "verdict": qa.verdict, "engine": "studiomax",
                "qa": qa.to_dict(), "stats": out_stats.to_dict(),
                "stats_before": ref.to_dict(),
                "stages": stages, "decision": decision,
                "output": str(dst), "notes": notes}

    except StudioMaxError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail", "reason": str(exc),
                "stages": stages, "decision": decision, "notes": notes}
    except DSPError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[studiomax] {exc}",
                "stages": stages, "decision": decision, "notes": notes}
    except Exception as exc:                     # noqa: BLE001
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[studiomax] unexpected error: {exc}",
                "stages": stages, "decision": decision, "notes": notes}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
