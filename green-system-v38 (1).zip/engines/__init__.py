"""Green System — DSP engine library (self-contained).

All engines share one result contract (see dolby_off.run / enhance.run):

    {ok: bool, verdict: 'pass'|'warn'|'fail', engine: str, qa: dict,
     stats: dict, stats_before: dict, stages: [...], output: str,
     out_id?: str, notes: [...], ...engine-specific report fields}

Modules
-------
analysis   shared analysis + QA gate layer wrapped around EVERY engine
           (ffprobe + ebur128 + astats; duration/aliveness/DC/level gates)
local      lightweight FFmpeg engines (clean/voice/music/fx/spatial/master)
           + DSPError + _ff runner + _verify
dolby_off  engine 1 — "Dolby One" OFFLINE 7-stage (analyze/repair/denoise/
           dynamics/profile-EQ/spatial/loudness-master), 100% local
studiomic  engine 2 — "Mic Studio" flagship AI voice (resemble-enhance in
           an ISOLATED subprocess + analog mic model + shared DSP helpers)
           studiomic_ai_worker.py = the isolated AI worker (never import it
           directly from the server process; it is spawned as subprocess)
enhance    engine 3 — "ENHANCE" adaptive agent (forensic → diagnose → plan →
           process+verify with keep/reduce/rollback → 10-gate QC → scores)

Legacy online engines (dolby API / mvsep / gemini / subs / stemopt /
pipeline) belong to the OLD audio-studio app and are intentionally NOT
part of this package — green-system is 100% offline, zero-key.
"""
from . import analysis, local, dolby_off, studiomic, enhance  # noqa: F401

__all__ = ["analysis", "local", "dolby_off", "studiomic", "enhance"]
