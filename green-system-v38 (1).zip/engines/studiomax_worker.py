"""Isolated AI workers for the Studio Max engine (RAM hygiene).

Why subprocesses: on a small box (2 cores / 3-4 GB) the three AI
specialists cannot coexist in one process — torch runtime (~0.5 GB) +
demucs (~0.4 GB) + apollo (~0.3 GB) + the Resemble worker (~2.5 GB) is
an OOM guarantee (measured, not guessed). Each worker below does ONE
job, streams line-based progress to stdout, then exits and the OS
reclaims every byte. The parent server never even imports torch.

CLI:
  python -m engines.studiomax_worker split   <in.wav> <bed.wav> <voc.wav>
  python -m engines.studiomax_worker restore <in.wav> <out.wav> <blend%> <ckpt>
  python -m engines.studiomax_worker fetch   <htdemucs|htdemucs_ft>

stdout protocol (one line each, flush):
  PROG <pct 0-100> <free text>
  OK [detail]
  ERR <reason>            (also exit code 1)
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]

# pin the HF hub cache to the app models dir BEFORE any hub import —
# works both when spawned by serve.py (env already set) and standalone
_models_root = None
for _root in (BASE / "models", BASE.parent / "models"):
    if _root.exists() and any((_root / k).exists() for k in
                              ("resemble-enhance", "apollo", "demucs_hf")):
        _models_root = _root
        break
_models_root = _models_root or (BASE / "models")
for _k in ("HF_HUB_CACHE", "HUGGINGFACE_HUB_CACHE"):
    os.environ.setdefault(_k, str(_models_root / "demucs_hf"))

SR = 44100


def _say(msg: str) -> None:
    print(msg, flush=True)


def _prog(pct: int, msg: str) -> None:
    _say(f"PROG {max(0, min(100, int(pct)))} {msg}")


def _load(path: str):
    import numpy as np
    import soundfile as sf
    x, sr = sf.read(path, dtype="float32", always_2d=True)
    return np.asarray(x, np.float32), int(sr)


def _save(path: str, x, sr: int) -> None:
    import soundfile as sf
    sf.write(path, x, sr, subtype="FLOAT")


# ---------------------------------------------------------------- split

def cmd_split(in_wav: str, bed_wav: str, voc_wav: str,
              variant: str = "htdemucs") -> int:
    import numpy as np
    import torch
    from demucs.apply import apply_model
    from demucs.pretrained import get_model

    _prog(4, f"worker: loading demucs {variant}")
    model = get_model(variant).to("cpu").eval()
    _prog(8, "worker: demucs loaded")

    x, sr = _load(in_wav)
    _prog(10, f"worker: separating {x.shape[0] / sr:.1f}s")
    wav = torch.from_numpy(np.ascontiguousarray(x.T))          # (2, n)
    if wav.shape[0] == 1:
        wav = wav.repeat(2, 1)
    ref = wav.mean(0)
    std = float(ref.std()) or 1.0
    wav_n = (wav - ref.mean()) / std
    t0 = time.time()
    with torch.inference_mode():
        stems = apply_model(model, wav_n[None], device="cpu",
                            split=True, overlap=0.25, progress=False,
                            segment=None)[0]
    stems = (stems * std + ref.mean()).cpu().numpy()            # (4, 2, n)
    # sources order: drums, bass, other, vocals -> (n, 2) frames-first
    bed = np.ascontiguousarray(
        (stems[0] + stems[1] + stems[2]).astype(np.float32).T)
    voc = np.ascontiguousarray(stems[3].astype(np.float32).T)
    _save(bed_wav, bed, sr)
    _save(voc_wav, voc, sr)
    _prog(100, f"worker: split done in {time.time() - t0:.0f}s")
    _say("OK split")
    return 0


# ---------------------------------------------------------------- restore

def cmd_restore(in_wav: str, out_wav: str, blend_s: str, ckpt: str) -> int:
    import numpy as np
    import torch
    from engines.apollo_model import BaseModel

    _prog(4, "worker: loading apollo")
    model = BaseModel.from_pretrain(
        str(ckpt), sr=SR, win=20, feature_dim=256, layer=6)
    model = model.to("cpu").eval()
    _prog(8, "worker: apollo loaded")

    x, sr = _load(in_wav)
    blend = max(0.0, min(100.0, float(blend_s))) / 100.0
    win = int(12.0 * SR)
    ov = int(1.5 * SR)
    n = x.shape[0]
    t0 = time.time()

    def _run(chunk: np.ndarray) -> np.ndarray:
        t = torch.from_numpy(np.ascontiguousarray(chunk.T)).unsqueeze(0)
        with torch.inference_mode():
            y = model(t).detach().squeeze(0).cpu().numpy().T
        if y.shape[0] < chunk.shape[0]:
            pad = np.zeros((chunk.shape[0] - y.shape[0], 2), np.float32)
            y = np.concatenate([y, pad])
        return y[:chunk.shape[0]].astype(np.float32)

    if n <= win:
        wet = _run(x)
        _prog(80, "worker: restored (single pass)")
    else:
        hop = win - ov
        starts = list(range(0, max(1, n - win + 1), hop))
        if not starts or starts[-1] + win < n:
            starts.append(max(0, n - win))
        out = np.zeros_like(x)
        wsum = np.zeros((n, 1), np.float32)
        for i, s in enumerate(starts):
            chunk = x[s:s + win]
            wet_c = _run(chunk)
            w = np.ones((win, 1), np.float32)
            ramp = np.linspace(0.0, 1.0, min(ov, win)).reshape(-1, 1
                                                               ).astype(np.float32)
            if i > 0:
                w[:len(ramp)] = ramp
            if i < len(starts) - 1:
                w[-len(ramp):] = ramp[::-1]
            end = min(s + win, n)
            out[s:end] += wet_c[:end - s] * w[:end - s]
            wsum[s:end] += w[:end - s]
            _prog(8 + int(72 * (i + 1) / len(starts)),
                  f"worker: chunk {i + 1}/{len(starts)}")
        wet = np.divide(out, np.maximum(wsum, 1e-8)).astype(np.float32)

    wet = wet * blend + x * (1.0 - blend)
    peak = float(np.max(np.abs(wet))) if wet.size else 0.0
    if peak > 0.99:
        wet = wet * (0.97 / peak)
    _save(out_wav, wet.astype(np.float32), sr)
    _prog(100, f"worker: restore done in {time.time() - t0:.0f}s")
    _say("OK restore")
    return 0


# ---------------------------------------------------------------- fetch

def cmd_fetch(variant: str) -> int:
    _prog(4, f"worker: fetching {variant} from huggingface")
    from demucs.pretrained import get_model
    model = get_model(variant)
    del model
    _prog(100, "worker: fetch done")
    _say(f"OK fetch {variant}")
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        _say("ERR usage: split|restore|fetch ...")
        return 1
    cmd = argv[1]
    try:
        if cmd == "split" and len(argv) >= 5:
            return cmd_split(argv[2], argv[3], argv[4],
                             argv[5] if len(argv) > 5 else "htdemucs")
        if cmd == "restore" and len(argv) >= 5:
            return cmd_restore(argv[2], argv[3], argv[4], argv[5])
        if cmd == "fetch" and len(argv) >= 3:
            return cmd_fetch(argv[2])
        _say(f"ERR bad arguments for {cmd}")
        return 1
    except Exception as exc:                      # noqa: BLE001
        _say(f"ERR {type(exc).__name__}: {exc}"[:400])
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
