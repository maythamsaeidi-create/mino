"""ENHANCE — the intelligent adaptive audio agent (v34).

Implements the AudioEngineerAgentPro blueprint (mino/1.txt) as a THIRD
engine alongside Dolby One and Mic Studio (both untouched):

  INGEST → FORENSIC ANALYSIS → PROBLEM DETECTION (severity × confidence)
  → ADAPTIVE PLAN (conditional modules, per-module budgets)
  → PROCESS (dynamic graph) → RE-MEASURE after every module
  (loudness-matched, artifact-checked) → KEEP / REDUCE / ROLLBACK
  → MASTER (profile loudness + true-peak) → MULTI-DIMENSIONAL QC
  → EXPLAINABLE REPORT

Master Quality Guard (the 20 rules, condensed into code):
  1.  never modify without a detected reason
  2.  minimum effective processing (amount scales with severity)
  3.  original preserved — the whole chain runs on temp copies
  4.  loudness-matched A/B (metrics are ratio/level-invariant)
  5.  true-peak monitored at the end
  6.  transient protection (crest-factor guard around dynamics)
  7.  dynamics protection (LRA floor 3 LU)
  8.  mono/phase safety (voice = center-locked, never widened)
  9.  low-end protection (rumble HPF only when detected)
  10. AI artifact detection (pause-region spectral flatness guard)
  11. no repeated correction of the same problem (re-measure per module)
  12. rollback on degradation
  13. per-module safety caps (mode-dependent)
  14. re-analysis after every significant process
  15. "DO NOTHING" is a valid result (intensity 0 = dry-run diagnose)
  16. never confuse louder with better
  17. low confidence → conservative processing
  18. every decision logged WHY / WHAT / HOW MUCH / RISK / RESULT
  19. all processing non-destructive
  20. final output must pass the shared QA gate before delivery

Profiles (target characteristics, per 1.txt):
  auto       → speech detected ? intimate : music
  intimate   → Premium Podcast · Intimate — close, warm, minimal room
  natural    → Premium Podcast · Natural — barely-there polish
  broadcast  → Premium Podcast · Broadcast — consistent, dense
  music      → full-mix tonal balance

Modes: SAFE (×0.7 amount, stricter) / BALANCED (default) / AGGRESSIVE.
"""
from __future__ import annotations

import math
import shutil
import tempfile
import time
from pathlib import Path
from typing import Callable

import numpy as np

from .local import DSPError, _ff
from .analysis import analyze, qa_gate
from .studiomic import (
    _biquad, _apply, _butter, _bandpass, _blocks, _rms_blocks,
    _asym_smooth, _expand, _db, _undb, _de_ess, _compress3,
    _saturate, _soft_limit, _loudness_of, _ai_stage, ai_status,
)

# ---------------------------------------------------------------- profiles

# tonal-balance reference windows: relative dB of each band vs the
# 75 Hz–16 kHz total (diagnostic "target characteristics", 1.txt §17/§22)
_VOICE_WINDOWS = {
    "rumble":   (None,  -34.0),
    "body":     (-24.0, -13.0),
    "lowmid":   (-22.0, -11.0),
    "mid":      (-16.0,  -4.0),
    "presence": (-15.0,  -3.0),
    "hi":       (-18.0,  -5.0),
    "air":      (-28.0,  -9.0),
}
_MUSIC_WINDOWS = {
    "rumble":   (None,  -18.0),
    "body":     (-20.0,  -8.0),
    "lowmid":   (-18.0,  -6.0),
    "mid":      (-14.0,  -3.0),
    "presence": (-14.0,  -2.0),
    "hi":       (-17.0,  -4.0),
    "air":      (-26.0,  -6.0),
}

PROFILES = {
    "intimate": dict(lufs=-19.0, voice=True, mono=True, warmth=32,
                     windows=_VOICE_WINDOWS, lra=(4.0, 12.0), sib_max=4.5,
                     headroom_min=15.0, roomy_max=-16.0,
                     desc="Premium Podcast · Intimate — very close, warm, "
                          "minimal room, intimate delivery"),
    "natural": dict(lufs=None, voice=True, mono=True, warmth=12,
                    windows=_VOICE_WINDOWS, lra=(5.0, 14.0), sib_max=4.5,
                    headroom_min=15.0, roomy_max=-16.0,
                    desc="Premium Podcast · Natural — source-preserving, "
                         "barely-there polish"),
    "broadcast": dict(lufs=-16.0, voice=True, mono=True, warmth=40,
                      windows=_VOICE_WINDOWS, lra=(4.0, 11.0), sib_max=4.5,
                      headroom_min=15.0, roomy_max=-16.0,
                      desc="Premium Podcast · Broadcast — consistent, dense, "
                           "loudness-managed"),
    "music": dict(lufs=-14.0, voice=False, mono=False, warmth=0,
                  windows=_MUSIC_WINDOWS, lra=(7.0, 20.0), sib_max=None,
                  headroom_min=12.0, roomy_max=-12.0,
                  desc="Music full-mix — tonal balance + dynamics window"),
}

# mode multipliers: amount scale / activation strictness / safety caps
MODES = {
    "safe":       dict(amt=0.70, thr=1.30, den=6.0,  eq=(2.5, 6.0),  rev=5.0),
    "balanced":   dict(amt=1.00, thr=1.00, den=10.0, eq=(4.0, 10.0), rev=8.0),
    "aggressive": dict(amt=1.35, thr=0.85, den=14.0, eq=(5.5, 14.0), rev=11.0),
}

# activation thresholds (severity × confidence must exceed thr × mode.thr)
_ACT = {"dc": 0.05, "declip": 0.10, "hum": 0.12, "noise": 0.15,
        "room": 0.16, "tonal": 0.12, "sib": 0.13, "dyn": 0.10,
        "level": 0.05, "breath": 0.12, "plosive": 0.10}

_BLOCK = 0.1          # envelope block, seconds
_BANDS = (("rumble", 62.0, 75.0), ("body", 75.0, 250.0),
          ("lowmid", 250.0, 500.0), ("mid", 500.0, 2000.0),
          ("presence", 2000.0, 4500.0), ("hi", 4500.0, 8000.0),
          ("air", 8000.0, 16000.0))


class EnhanceError(DSPError):
    """Raised with a human-readable, stage-tagged reason."""


def _mono(x: np.ndarray) -> np.ndarray:
    return x.mean(axis=1) if x.ndim == 2 else x


# ---------------------------------------------------------------- forensic

def _env_db(x: np.ndarray, sr: float) -> tuple[np.ndarray, int, int]:
    """100 ms block RMS envelope in dB."""
    n = max(1, int(sr * _BLOCK))
    nb = int(math.ceil(len(x) / n))
    pad = np.pad(x, (0, nb * n - len(x)))
    rms = np.sqrt(np.mean(pad.reshape(nb, n) ** 2, axis=1))
    return _db(rms), n, nb


def _activity(db: np.ndarray):
    """Floor / active level / pause-vs-active mask from the envelope."""
    floor = float(np.percentile(db, 10))
    ref = float(np.percentile(db, 90))
    thr = floor + (ref - floor) * 0.45
    thr = max(thr, floor + 6.0)
    return db > thr, thr, floor, ref


def _welch(x: np.ndarray, sr: float, nper: int):
    from scipy.signal import welch
    nper = int(min(nper, len(x)))
    if nper < 256:
        nper = min(256, len(x))
    f, p = welch(x, fs=sr, nperseg=nper, noverlap=nper // 2)
    return f, p


def _band_profile(x: np.ndarray, sr: float) -> dict:
    """Relative band energies (dB vs 75 Hz–16 kHz total) + speech-band ratio."""
    xm = _mono(x)
    if len(xm) < 2048:
        return {}
    nper = 8192 if len(xm) >= 8192 else max(256, 1 << int(math.log2(len(xm))))
    f, p = _welch(xm, sr, nper)
    out: dict = {}
    tot = 0.0
    for name, lo, hi in _BANDS:
        m = (f >= lo) & (f < hi)
        e = float(np.trapezoid(p[m], f[m])) if m.any() else 0.0
        out[name] = e
        if name != "rumble":
            tot += e
    tot = max(tot, 1e-14)
    rel = {name: 10.0 * math.log10(max(out[name], 1e-14) / tot)
           for name, _, _ in _BANDS}
    # speech-band concentration 300–3400 Hz vs 75–16 kHz
    m_v = (f >= 300) & (f < 3400)
    m_t = (f >= 75) & (f < 16000)
    pv = float(np.trapezoid(p[m_v], f[m_v])) if m_v.any() else 0.0
    pt = float(np.trapezoid(p[m_t], f[m_t])) if m_t.any() else 1e-14
    rel["voiceband_ratio"] = pv / max(pt, 1e-14)
    return rel


def _hum_lines(x: np.ndarray, sr: float) -> dict:
    """Prominence (dB over local floor) of 50/60 Hz mains families."""
    xm = _mono(x)
    if len(xm) < 4096:
        return {}
    nper = min(65536, max(4096, 1 << int(math.floor(math.log2(len(xm) // 2)))))
    from scipy.signal import welch
    f, p = welch(xm, fs=sr, nperseg=nper, noverlap=0)
    if len(f) < 128:
        return {}
    res = {}
    for base in (50.0, 60.0):
        best = -99.0
        for h in (1, 2, 3, 4):
            fh = base * h
            if fh >= sr / 2 - 30:
                break
            m1 = (f >= fh - 2.0) & (f <= fh + 2.0)
            m2 = (f >= fh - 40.0) & (f <= fh + 40.0) & ~m1
            if not m1.any() or not m2.any():
                continue
            peak = float(p[m1].max())
            flo = float(np.median(p[m2]))
            best = max(best, 10.0 * math.log10(max(peak, 1e-20) /
                                               max(flo, 1e-20)))
        res[base] = round(best, 1)
    return res


def _pause_metrics(x: np.ndarray, sr: float):
    """Metrics that need the active/pause split.

    Returns dict with: headroom_db (active-90th − floor-10th),
    speech_ratio, pause_ratio_db (pause energy under active energy),
    sib_ratio_db (5.5–9 kHz vs 300–5 kHz during ACTIVE audio),
    pause_flatness (musical-noise canary).
    """
    xm = _mono(x)
    db, n, nb = _env_db(xm, sr)
    active, thr, floor, ref = _activity(db)
    out = {"speech_ratio": float(np.mean(active)),
           "floor_db": floor, "active_db": ref,
           "headroom_db": ref - floor,
           "pause_s": float((~active).sum() * _BLOCK)}
    if ref - floor < 10.0:
        out["headroom_db"] = None       # no real pauses → can't estimate noise
        out["pause_ratio_db"] = None
        out["sib_ratio_db"] = None
        out["pause_flatness"] = None
        return out
    mask_a = np.repeat(active, n)[:len(xm)]
    mask_p = np.repeat(~active, n)[:len(xm)]
    act_rms = float(np.sqrt(np.mean(xm[mask_a] ** 2))) \
        if active.any() else 0.0
    pau_rms = float(np.sqrt(np.mean(xm[mask_p] ** 2))) \
        if (~active).any() else 0.0
    out["pause_ratio_db"] = 20.0 * math.log10(
        max(pau_rms, 1e-10) / max(act_rms, 1e-10))
    # sibilance ratio during active audio
    seg = xm[mask_a]
    if len(seg) >= sr // 2:
        f, p = _welch(seg, sr, 4096)
        ms = (f >= 5500) & (f < 9000)
        mb = (f >= 300) & (f < 5000)
        es = float(np.trapezoid(p[ms], f[ms]))
        eb = float(np.trapezoid(p[mb], f[mb]))
        out["sib_ratio_db"] = 10.0 * math.log10(max(es, 1e-14) /
                                                max(eb, 1e-14))
    else:
        out["sib_ratio_db"] = None
    # pause-region spectral flatness (artifact canary)
    segp = xm[mask_p]
    if len(segp) >= sr // 4:
        f, p = _welch(segp, sr, 2048)
        m = (f >= 200) & (f <= 12000)
        v = p[m]
        if len(v) > 8:
            g = float(np.exp(np.mean(np.log(np.maximum(v, 1e-20)))))
            a = float(np.mean(v))
            out["pause_flatness"] = g / max(a, 1e-20)
        else:
            out["pause_flatness"] = None
    else:
        out["pause_flatness"] = None
    return out


def _crest(x: np.ndarray) -> float:
    xm = _mono(x)
    if not len(xm):
        return 0.0
    pk = float(np.max(np.abs(xm)))
    rms = float(np.sqrt(np.mean(xm ** 2)))
    return 20.0 * math.log10(max(pk, 1e-10) / max(rms, 1e-10))


def _clip_stats(x: np.ndarray) -> float:
    """Fraction of samples at/above 98.5% full scale."""
    xm = _mono(x)
    if not len(xm):
        return 0.0
    return float(np.mean(np.abs(xm) >= 0.985))


def _tfmt(t: float) -> str:
    t = max(0.0, float(t))
    return f"{int(t // 60)}:{int(t % 60):02d}"


def _corr(x: np.ndarray):
    if x.ndim != 2 or x.shape[1] != 2:
        return None
    l, r = x[:, 0], x[:, 1]
    den = math.sqrt(float(np.dot(l, l)) * float(np.dot(r, r)))
    if den < 1e-12:
        return None
    return float(np.dot(l, r)) / den


def _lr_imbalance_db(x: np.ndarray):
    if x.ndim != 2 or x.shape[1] != 2:
        return None
    lr = float(np.sqrt(np.mean(x[:, 0] ** 2)))
    rr = float(np.sqrt(np.mean(x[:, 1] ** 2)))
    return abs(20.0 * math.log10(max(lr, 1e-10) / max(rr, 1e-10)))


def _st_max_db(x: np.ndarray, sr: float):
    """Approx. max short-term level (3 s RMS window) — a diagnosis hint
    for the dynamics problems (true ST is K-weighted per BS.1770; this
    RMS proxy never gates a decision, it only enriches the report)."""
    xm = _mono(x)
    n = int(sr * 3.0)
    if len(xm) <= n or n < 2:
        return None
    c = np.concatenate(([0.0], np.cumsum(xm ** 2)))
    e = (c[n:] - c[:-n]) / n
    if not len(e):
        return None
    return 20.0 * math.log10(max(float(np.sqrt(np.max(e))), 1e-10))


def _clip_spans(x: np.ndarray, sr: float) -> list:
    """Time spans of clipped samples — the waveform map (1.txt §3:
    problems must say WHEN they happen, not just that they exist)."""
    xm = _mono(x)
    idx = np.where(np.abs(xm) >= 0.985)[0]
    if not len(idx):
        return []
    gap = int(0.02 * sr)
    spans, start, prev = [], idx[0], idx[0]
    for i in idx[1:]:
        if i - prev > gap:
            spans.append((start, prev))
            start = i
        prev = i
    spans.append((start, prev))
    minlen = int(0.002 * sr)
    return [(float(a) / sr, float(b) / sr) for a, b in spans
            if (b - a) >= minlen]


def _tf_band_rel(x: np.ndarray, sr: float):
    """Time-frequency map (1.txt §3): 250 ms blocks × 7 bands, each
    block's band energy relative to the 75 Hz–16 kHz total — the same
    convention as _band_profile, so the profile windows apply per block.
    Long inputs are capped at 10 minutes of coverage (whole-file Welch
    metrics still cover everything)."""
    from scipy.signal import butter, sosfilt
    xm = _mono(x)
    capped = len(xm) > sr * 600
    if capped:
        xm = xm[:int(sr * 600)]
    n = max(1, int(sr * 0.25))
    nb = len(xm) // n
    if nb < 8:
        return None, 0.25, capped
    seg = np.ascontiguousarray(xm[:nb * n])
    tot = np.zeros(nb)
    env: dict = {}
    for name, lo, hi in _BANDS:
        f2 = min(hi, sr / 2 - 1.0)
        f1 = max(1.0, min(lo, f2 - 1.0))
        sos = butter(2, [f1, f2], btype="bandpass", fs=sr, output="sos")
        eb = np.mean(sosfilt(sos, seg).reshape(nb, n) ** 2, axis=1)
        env[name] = eb
        if name != "rumble":
            tot += eb
    rel = {name: 10.0 * np.log10(np.maximum(e, 1e-14) /
                                 np.maximum(tot, 1e-14))
           for name, e in env.items()}
    return rel, 0.25, capped


def _spans_from_rel(rel: np.ndarray, block: float, lo, hi,
                    top: int = 3) -> list:
    """Blocks outside the window → merged time spans, ranked by
    excess × duration (1.txt §3 time-frequency map)."""
    nb = len(rel)
    bad = np.zeros(nb, bool)
    exc = np.zeros(nb)
    for i in range(nb):
        if lo is not None and rel[i] < lo:
            bad[i] = True
            exc[i] = lo - rel[i]
        elif hi is not None and rel[i] > hi:
            bad[i] = True
            exc[i] = rel[i] - hi
    spans = []
    i = 0
    while i < nb:
        if bad[i]:
            last, j = i, i
            while j < nb and j - last <= 3:
                if bad[j]:
                    last = j
                j += 1
            if last - i + 1 >= 2:
                spans.append((i * block, (last + 1) * block,
                              float(np.mean(exc[i:last + 1]))))
            i = j
        else:
            i += 1
    spans.sort(key=lambda s: -(s[2] * (s[1] - s[0])))
    return spans[:top]


def _times_str(spans: list) -> str:
    if not spans:
        return ""
    return " · ".join(f"{_tfmt(s[0])}–{_tfmt(s[1])}"
                      for s in spans[:2])


def _breath_metrics(x: np.ndarray, sr: float) -> dict:
    """Breath detect → classify (Podcast §12): pause blocks above the
    noise floor, 0.18–1.6 s long, using a SPEECH threshold (speech
    lives within ~11 dB of its 90th-percentile level — loud breaths
    sit below that). Only the LOUD breaths get flagged."""
    xm = _mono(x)
    db, n, nb = _env_db(xm, sr)
    active, thr, floor, ref = _activity(db)
    out = {"count": 0, "loud": 0, "loud_frac": 0.0, "spans": [],
           "spk_thr": None}
    if ref - floor < 10.0:
        return out
    spk = max(thr, ref - 11.0)          # speech zone boundary
    out["spk_thr"] = spk
    cand = (db < spk) & (db > floor + 5.0)
    if not cand.any():
        return out
    spans = []
    i = 0
    while i < nb:
        if cand[i]:
            last, j = i, i
            while j < nb and j - last <= 3:
                if cand[j]:
                    last = j
                j += 1
            dur = (last - i + 1) * _BLOCK
            if 0.18 <= dur <= 1.6:
                spans.append((i * _BLOCK, (last + 1) * _BLOCK,
                              float(np.mean(db[i:last + 1]))))
            i = j
        else:
            i += 1
    loud_thr = floor + 13.0
    loud = [s for s in spans if s[2] > loud_thr]
    out["count"] = len(spans)
    out["loud"] = len(loud)
    out["loud_frac"] = (len(loud) / len(spans)) if spans else 0.0
    out["spans"] = loud[:6]
    return out


def _plosive_metrics(x: np.ndarray, sr: float) -> dict:
    """Plosive (P/B pop) detection (Podcast §13): a FAST rise of the
    60–150 Hz envelope (≥7 dB in 50 ms) whose energy then DECAYS
    quickly (≥5 dB within 100–150 ms) — a vowel onset rises and
    SUSTAINS, a pop rises and dies. That transient signature is what
    separates a plosive from normal speech LF."""
    from scipy.signal import butter, sosfilt
    xm = _mono(x)
    n = max(1, int(sr * 0.025))
    nb = len(xm) // n
    if nb < 20:
        return {"count": 0, "spans": [], "strength": 0.0}
    seg = np.ascontiguousarray(xm[:nb * n])
    sos = butter(4, [60.0, 150.0], btype="bandpass", fs=sr, output="sos")
    lf = sosfilt(sos, seg)
    lf_db = _db(np.sqrt(np.mean(lf.reshape(nb, n) ** 2, axis=1)))
    bb_db = _db(np.sqrt(np.mean(seg.reshape(nb, n) ** 2, axis=1)))
    floor_bb = float(np.percentile(bb_db, 25))
    hits = np.zeros(nb, bool)
    for i in range(2, nb - 7):
        if lf_db[i] - lf_db[i - 2] > 7.0 and bb_db[i] > floor_bb - 6.0:
            peak = float(np.max(lf_db[i:i + 3]))
            after = float(np.min(lf_db[i + 3:i + 7]))
            if peak - after >= 5.0:
                hits[i] = True
    spans = []
    i = 0
    while i < nb:
        if hits[i]:
            j = i
            while j < nb and hits[j]:
                j += 1
            end = min(nb, j + 4)
            pk = float(np.max(lf_db[i:end]))
            af = float(np.min(lf_db[min(end, nb - 1):min(end + 3, nb)])) \
                if end < nb else pk
            spans.append((i * 0.025, end * 0.025, max(0.0, pk - af)))
            i = end
        else:
            i += 1
    return {"count": len(spans), "spans": spans[:8],
            "strength": float(np.mean([s[2] for s in spans])) if spans
            else 0.0}


def _forensic(x: np.ndarray, sr: float, ref, prof: dict) -> dict:
    """The full forensic snapshot — one dict, every metric the
    diagnosis + verification steps need (all level-invariant)."""
    f: dict = {"bands": _band_profile(x, sr),
               "hum": _hum_lines(x, sr),
               "crest": _crest(x), "clip_pct": _clip_stats(x) * 100.0,
               "clip_spans": _clip_spans(x, sr),
               "corr": _corr(x), "lr_imb": _lr_imbalance_db(x),
               "st_max_db": _st_max_db(x, sr)}
    f.update(_pause_metrics(x, sr))
    rel, block, capped = _tf_band_rel(x, sr)
    if rel is not None:
        f["tf"] = rel
        f["tf_block"] = block
        f["tf_capped"] = capped
    if prof.get("voice"):
        f["breath"] = _breath_metrics(x, sr)
        f["plosive"] = _plosive_metrics(x, sr)
    f["lra"] = ref.lra if ref is not None else None
    f["lufs"] = ref.lufs if ref is not None else None
    f["true_peak"] = ref.true_peak if ref is not None else None
    f["dc"] = abs(ref.dc_offset) if (ref is not None and
                                     ref.dc_offset is not None) else 0.0
    return f

# ---------------------------------------------------------------- diagnosis

_PROBLEM_LABELS = {
    "dc": "DC offset", "clipping": "Clipping / clipped spans",
    "hum": "Mains hum", "noise": "Background noise",
    "rumble": "Low-frequency rumble", "thin": "Thin voice — no body",
    "boom": "Excess low body (boom)", "mud": "Low-mid mud",
    "dark": "Dark / dull — missing presence",
    "dullair": "Missing air / sheen", "harsh": "Harsh 4.5–8 kHz",
    "sibilant": "Sibilance", "roomy": "Room / reverb tails",
    "dynamic": "Uneven dynamics", "squashed": "Over-compressed",
    "level": "Loudness off target",
    "breath": "Loud breaths", "plosive": "Plosives (P/B pops)",
}


_RISK = {"dc": 0.02, "clipping": 0.08, "hum": 0.05, "noise": 0.18,
         "roomy": 0.15, "rumble": 0.10, "thin": 0.10, "boom": 0.12,
         "mud": 0.12, "dark": 0.12, "dullair": 0.10, "harsh": 0.12,
         "sibilant": 0.06, "breath": 0.10, "plosive": 0.08,
         "dynamic": 0.20, "squashed": 0.25, "level": 0.05}
_FIX = {"dc": "dc-correct", "clipping": "declick + declip",
        "hum": "dehum notches", "noise": "adaptive denoise",
        "roomy": "de-reverb (tails)", "rumble": "high-pass 75–85 Hz",
        "thin": "body low-shelf", "boom": "body low-shelf cut",
        "mud": "low-mid peaking cut", "dark": "presence peaking",
        "harsh": "hi peaking cut", "dullair": "air high-shelf",
        "sibilant": "de-esser 5.5–9 kHz",
        "breath": "breath control (loud only)",
        "plosive": "plosive dip 60–150 Hz",
        "dynamic": "3-band compressor", "squashed": "do-nothing (protect)",
        "level": "loudness master"}


def _diagnose(f: dict, prof: dict) -> list[dict]:
    """Problem Detection Engine — every problem gets severity,
    confidence, frequency region, a real TIME region from the
    time-frequency map, the recommended action and a risk estimate
    (the exact 1.txt §5 record)."""
    P: list[dict] = []

    def add(key, sev, conf, freq, region, value, window, times: str = ""):
        P.append({"problem": key, "label": _PROBLEM_LABELS.get(key, key),
                  "severity": round(float(min(1.0, max(0.0, sev))), 2),
                  "confidence": round(float(min(1.0, max(0.0, conf))), 2),
                  "freq": freq, "region": region,
                  "value": value, "window": window,
                  "risk": round(_RISK.get(key, 0.1), 2),
                  "action": _FIX.get(key, "—"),
                  "time_str": times})

    win = prof["windows"]
    bands = f.get("bands") or {}
    tf = f.get("tf")
    tf_block = f.get("tf_block", 0.25)

    if f.get("dc", 0) > 0.0015:
        add("dc", f["dc"] / 0.05, 0.98, "0 Hz", "whole file",
            f"DC {f['dc']:.4f}", "< 0.0015")
    if f.get("clip_pct", 0) > 0.004:
        csp = f.get("clip_spans") or []
        times = " · ".join(f"{_tfmt(a)}–{_tfmt(b)}"
                           for a, b in csp[:2] if b - a >= 0.05)
        add("clipping", f["clip_pct"] / 0.15, 0.95, "full band",
            "clipped spans" if csp else "clipped samples",
            f"{f['clip_pct']:.3f}% samples", "< 0.004%", times)
    hum = f.get("hum") or {}
    if hum:
        base50 = max(hum.get(50.0, -99), hum.get(100.0, -99),
                     hum.get(150.0, -99)) if 50.0 in hum else -99
        base60 = max(hum.get(60.0, -99), hum.get(120.0, -99),
                     hum.get(180.0, -99)) if 60.0 in hum else -99
        best = max(base50, base60)
        if best > 5.0:
            fam = "50 Hz family (50/100/150)" if base50 >= base60 \
                else "60 Hz family (60/120/180)"
            add("hum", (best - 4.0) / 14.0, 0.9, fam, "whole file",
                f"{fam} +{best:.1f} dB", "< +4 dB")

    h = f.get("headroom_db")
    if h is not None:
        hmin = prof["headroom_min"]
        if h < hmin:
            ps = f.get("pause_s")
            add("noise", (hmin - h) / 10.0, 0.85, "broadband floor",
                "speech pauses", f"headroom {h:.1f} dB",
                f">= {hmin:.0f} dB",
                f"in pauses · {ps:.0f}s total" if ps else "in pauses")
    ratio = f.get("pause_ratio_db")
    if ratio is not None and prof.get("roomy_max") is not None:
        rmax = prof["roomy_max"]
        if ratio > rmax:
            add("roomy", (ratio - rmax) / 12.0, 0.7, "reverb tails",
                "pauses after speech", f"pause {ratio:.0f} dB under speech",
                f"<= {abs(rmax):.0f} dB")

    def band_times(band):
        if tf is None or tf.get(band) is None:
            return ""
        lo, hi = win[band]
        spans = _spans_from_rel(np.asarray(tf[band]), tf_block, lo, hi)
        return _times_str(spans)

    def win_str(band):
        # rumble's lower bound is None (open-ended) — never format it
        lo, hi = win[band]
        lo_s = f"{lo:.0f}" if lo is not None else "−∞"
        hi_s = f"{hi:.0f}" if hi is not None else "+∞"
        return f"{lo_s}…{hi_s} dB"

    def band_pair(lo_key, hi_key, band):
        v = bands.get(band)
        if v is None:
            return
        lo, hi = win[band]
        if lo is not None and v < lo - 2.0:
            if lo_key:
                add(lo_key, (lo - v) / 9.0, 0.75, f"{band} rel",
                    "worst spans" if tf else "whole file",
                    f"{v:.1f} dB", win_str(band),
                    band_times(band))
        elif hi is not None and v > hi + 2.0:
            if hi_key:
                add(hi_key, (v - hi) / 9.0, 0.75, f"{band} rel",
                    "worst spans" if tf else "whole file",
                    f"{v:.1f} dB", win_str(band),
                    band_times(band))

    band_pair(None, "rumble", "rumble")
    band_pair("thin", "boom", "body")
    band_pair(None, "mud", "lowmid")
    band_pair("dark", None, "presence")
    band_pair(None, "harsh", "hi")
    band_pair("dullair", None, "air")

    sib = f.get("sib_ratio_db")
    if sib is not None and prof.get("sib_max") is not None:
        if sib > prof["sib_max"]:
            add("sibilant", (sib - prof["sib_max"]) / 6.0, 0.8,
                "5.5–9 kHz", "on sibilants", f"ratio {sib:.1f} dB",
                f"<= +{prof['sib_max']:.1f} dB")

    # breath + plosive — voice profiles only (Podcast §12/§13)
    if prof.get("voice"):
        br = f.get("breath") or {}
        if br.get("count", 0) >= 3 and br.get("loud_frac", 0) > 0.25:
            add("breath",
                min(1.0, br["loud_frac"] * 0.6 +
                    min(1.0, br["count"] / 12.0) * 0.4),
                0.65, "300 Hz–8 kHz (aspirated)", "between phrases",
                f"{br['loud']}/{br['count']} breaths loud",
                "natural ones kept", _times_str(br.get("spans") or []))
        pl = f.get("plosive") or {}
        if pl.get("count", 0) >= 3:
            add("plosive",
                min(1.0, 0.6 * min(1.0, pl["count"] / 12.0) +
                    0.4 * min(1.0, pl.get("strength", 0) / 12.0)),
                0.7, "60–150 Hz", "on P/B onsets",
                f"{pl['count']} pops · dom +{pl.get('strength', 0):.0f} dB",
                "adaptive dip only", _times_str(pl.get("spans") or []))

    lra = f.get("lra")
    if lra is not None:
        lo, hi = prof["lra"]
        stm = f.get("st_max_db")
        stx = f" · ST-max {stm:.0f} dB" if stm is not None else ""
        if lra > hi:
            add("dynamic", (lra - hi) / 8.0, 0.75, "dynamics",
                "whole file", f"LRA {lra:.1f} LU" + stx,
                f"{lo:.0f}–{hi:.0f} LU")
        elif lra < lo:
            add("squashed", (lo - lra) / 4.0, 0.7, "dynamics",
                "whole file", f"LRA {lra:.1f} LU",
                f"{lo:.0f}–{hi:.0f} LU (do-nothing)")

    if prof.get("lufs") is not None and f.get("lufs") is not None:
        d = abs(f["lufs"] - prof["lufs"])
        if d > 1.5:
            add("level", d / 8.0, 0.95, "loudness", "whole file",
                f"{f['lufs']:.1f} LUFS", f"target {prof['lufs']:.1f}")
    return P


# ---------------------------------------------------------------- planner

def _plan(problems: list[dict], prof: dict, mode: dict, opts: dict) -> list:
    """Adaptive Processing Brain — build the conditional module graph.

    Every entry: key, module, problem ref, planned amount (scaled by
    severity × confidence × mode × intensity) and its safety cap.
    Modules whose problem never fired are returned with act=False so the
    REPORT can explain "Ignored: K (no problem / below threshold)".
    """
    m_amt = mode["amt"]
    inten = opts["intensity"] / 100.0
    by_key = {p["problem"]: p for p in problems}
    dry = opts["intensity"] <= 0

    def sev(k):
        p = by_key.get(k)
        return (p["severity"] * p["confidence"]) if p else 0.0

    def fire(k):
        return sev(k) >= _ACT.get(k, 0.15) * mode["thr"]

    plan = []

    def entry(key, module, act, amount, cap, why):
        plan.append({"key": key, "module": module, "act": bool(act and not dry),
                     "dry": dry, "amount": amount, "cap": cap, "why": why})

    entry("dc", "dc-correct", fire("dc"),
          1.0, None, "DC offset collapses headroom and must go first")
    entry("clipping", "declick+declip", fire("clipping") or
          opts["force_declick"],
          min(1.0, 0.4 + sev("clipping")), None,
          "restore clipped spans before anything amplifies them")
    entry("hum", "dehum", fire("hum") or opts["force_dehum"],
          1.0, -10.0, "notch the detected mains family at source")
    entry("noise", "denoise", fire("noise"),
          min(mode["den"], 3.0 + 11.0 * sev("noise")), mode["den"],
          "noise floor vs speech headroom (adaptive 3–14 dB)")
    entry("roomy", "de-reverb", fire("roomy"),
          min(mode["rev"], 4.0 + 7.0 * sev("roomy")), mode["rev"],
          "pull reverb tails down in pauses, keep speech untouched")
    entry("breath", "breath-control",
          fire("breath") and bool(prof.get("voice")),
          min(0.8, 0.3 + 0.5 * sev("breath") * m_amt), 0.8,
          "level ONLY loud breaths — natural ones kept (Podcast §12)")
    entry("plosive", "plosive-control",
          fire("plosive") and bool(prof.get("voice")),
          min(0.8, 0.3 + 0.5 * sev("plosive") * m_amt), 0.8,
          "adaptive 60–150 Hz dip on P/B bursts (Podcast §13)")
    entry("tonal", "tonal-correct", fire("thin") or fire("boom") or
          fire("mud") or fire("dark") or fire("harsh") or fire("dullair")
          or fire("rumble"),
          None, mode["eq"],
          "measured band distances → corrective EQ (capped, budgeted)")
    entry("sib", "de-esser", fire("sibilant"),
          min(0.8, 0.25 + 0.55 * sev("sibilant") * m_amt), 0.8,
          "adaptive sibilance control 5.5–9 kHz")
    entry("dyn", "compressor", fire("dynamic") and not fire("squashed"),
          min(0.75, 0.25 + 0.45 * sev("dynamic") * m_amt),
          0.35 if opts["preserve_dynamics"] else 0.75,
          "level the dynamics inside the profile LRA window "
          "(transient-guarded)")
    entry("warmth", "harmonic-warmth",
          bool(prof.get("warmth")) and not opts["keep_natural"]
          and not dry and prof["voice"],
          min(45.0, prof.get("warmth", 0) * m_amt * (0.5 + 0.5 * inten)), 45.0,
          "very-low budget tube-style warmth (THD-capped)")
    entry("level", "loudness-master", True,
          None, None, "profile loudness target + true-peak ceiling")
    return plan


# ---------------------------------------------------------------- modules

def _ch_apply(x: np.ndarray, fn):
    """Apply a mono (1D->(1D,info)) module per channel — stereo-safe."""
    if x.ndim == 1:
        return fn(x)
    ys, info = [], None
    for c in range(x.shape[1]):
        y, info = fn(np.ascontiguousarray(x[:, c]))
        ys.append(y)
    return np.stack(ys, axis=1), info


def _headroom_now(x: np.ndarray, sr: float):
    xm = _mono(x)
    db, n, nb = _env_db(xm, sr)
    active, thr, floor, ref = _activity(db)
    return (ref - floor), ref


def _m_dc(x: np.ndarray):
    if x.ndim == 1:
        m = float(np.mean(x))
        return x - m, m
    m = x.mean(axis=0)
    return x - m, float(np.max(np.abs(m)))


def _m_declip(x: np.ndarray):
    """Repair flat-topped clipped spans by linear interpolation.

    Conservative by design (1.txt §12): only spans shorter than 15 ms
    whose both sides share the clip's sign are touched.
    """
    def fix(ch: np.ndarray):
        idx = np.where(np.abs(ch) >= 0.985)[0]
        n_fixed = 0
        if not len(idx):
            return ch, 0
        y = ch.copy()
        spans, start, prev = [], idx[0], idx[0]
        for i in idx[1:]:
            if i - prev > 2:
                spans.append((start, prev))
                start = i
            prev = i
        spans.append((start, prev))
        max_len = int(0.015 * 48000)
        for a, b in spans:
            if b - a < 2 or b - a > max_len:
                continue
            lo, hi = max(0, a - 1), min(len(y) - 1, b + 1)
            if hi - lo < 2:
                continue
            v0, v1 = y[lo], y[hi]
            if v0 > 0.5 and v1 > 0.5:
                seg = np.linspace(v0, v1, hi - lo + 1)
                y[lo:hi + 1] = np.clip(seg, min(v0, v1) - 0.06,
                                       max(v0, v1) + 0.06)
                n_fixed += 1
            elif v0 < -0.5 and v1 < -0.5:
                seg = np.linspace(v0, v1, hi - lo + 1)
                y[lo:hi + 1] = np.clip(seg, min(v0, v1) - 0.06,
                                       max(v0, v1) + 0.06)
                n_fixed += 1
        return y, n_fixed
    return _ch_apply(x, fix)


def _ff_roundtrip(x: np.ndarray, sr: int, filters: list[str],
                  workdir: Path, tag: str) -> np.ndarray:
    """Run an FFmpeg -af chain on the in-memory array (temp roundtrip)."""
    import soundfile as sf
    tmp_in, tmp_out = workdir / f"{tag}_in.wav", workdir / f"{tag}_out.wav"
    sf.write(str(tmp_in), x.astype(np.float32), sr, subtype="FLOAT")
    _ff(["-i", str(tmp_in), "-af", ",".join(filters),
         "-ar", str(int(sr)), str(tmp_out)])
    if not tmp_out.exists():
        raise EnhanceError(f"[enhance] ffmpeg repair pass ({tag}) failed")
    y, _ = sf.read(str(tmp_out), dtype="float64", always_2d=True)
    if x.ndim == 1:
        y = y.mean(axis=1)
    tmp_in.unlink(missing_ok=True)
    tmp_out.unlink(missing_ok=True)
    return y


def _m_denoise(x: np.ndarray, sr: int, red_db: float, use_ai: bool,
               ai_clean: float, max_quality: bool, voice: bool,
               prog, p_lo: int, p_hi: int, notes: list, workdir: Path):
    """Adaptive denoise — AI (resemble-enhance) when available & wanted,
    noisereduce spectral gating otherwise. Amount = measured need."""
    if use_ai and voice:
        xmono = _mono(x).astype(np.float64)
        return _ai_stage(xmono, sr, ai_clean, max_quality, prog,
                         p_lo, p_hi, notes, workdir) + (True,)
    pd = 1.0 - 10.0 ** (-red_db / 20.0)
    pd = min(0.92, max(0.15, pd))
    try:
        import noisereduce
        y = noisereduce.reduce_noise(y=x.astype(np.float32), sr=sr,
                                     stationary=False, prop_decrease=pd)
        return y.astype(np.float64), "noisereduce", False
    except Exception as exc:
        notes.append(f"denoise: noisereduce unavailable ({exc})")
        return x, "bypass", False


def _m_dereverb(x: np.ndarray, sr: int, red_db: float):
    """Reverb-tail suppression: progressive gain dip in pause/tail blocks
    (fast recovery on speech onsets — the tail, not the voice, drops)."""
    xm = _mono(x)
    db, n, nb = _env_db(xm, sr)
    active, thr, floor, ref = _activity(db)
    if ref - floor < 8.0:
        return x, 0.0
    depth = np.clip((thr - db) / 12.0, 0.0, 1.0)
    gain_db = -red_db * depth
    g = _undb(gain_db)
    g = _asym_smooth(g, 1.0 / _BLOCK, 0.02, 0.25)
    gg = _expand(g, n, len(xm))
    if x.ndim == 2:
        gg = gg[:, None]
    return x * gg, float(-np.max(gain_db)) if len(gain_db) else 0.0


def _level_at(x: np.ndarray, n: int, mask: np.ndarray):
    """RMS of the blocks selected by a block mask (verify helper)."""
    xm = _mono(x)
    nb = mask.shape[0]
    if not mask.any() or len(xm) < nb * n:
        return None
    seg = xm[:nb * n].reshape(nb, n)
    return float(np.sqrt(np.mean(seg[mask] ** 2)))


def _m_breath(x: np.ndarray, sr: int, amount: float):
    """Breath control (Podcast §12): dip ONLY the loud breath blocks
    (below the speech zone, above floor+13), natural ones untouched,
    feathered edges, speech never touched."""
    xm = _mono(x)
    db, n, nb = _env_db(xm, sr)
    active, thr, floor, ref = _activity(db)
    if ref - floor < 10.0 or nb < 8:
        return x, 0.0
    spk = max(thr, ref - 11.0)
    dip = 3.0 + 6.0 * min(1.0, max(0.0, amount))
    cand = (db < spk) & (db > floor + 5.0)
    loud = cand & (db > floor + 13.0)
    if not loud.any():
        return x, 0.0
    gain_db = np.zeros(nb)
    gain_db[loud] = -dip
    feather = np.convolve(loud.astype(float), [0.5, 1.0, 0.5],
                          "same") > 0.0
    gain_db[feather & ~loud] = -dip * 0.5
    g = _asym_smooth(_undb(gain_db), 1.0 / _BLOCK, 0.05, 0.12)
    gg = _expand(g, n, len(xm))
    if x.ndim == 2:
        gg = gg[:, None]
    return x * gg, float(dip)


def _m_plosive(x: np.ndarray, sr: int, amount: float):
    """Plosive control (Podcast §13): band-limited dip on detected
    60–150 Hz bursts. y = x + (g−1)·LP150(x) is an exact-reconstruction
    identity, so ONLY the low band moves — speech stays phase-intact."""
    pm = _plosive_metrics(x, sr)
    spans = pm["spans"]
    if not spans:
        return x, 0
    n = max(1, int(sr * 0.025))
    xm = _mono(x)
    nb = len(xm) // n
    if nb < 20:
        return x, 0
    dip = 4.0 + 8.0 * min(1.0, max(0.0, amount))
    gain_db = np.zeros(nb)
    for t0, t1, _ in spans:
        i0, i1 = int(t0 / 0.025), int(t1 / 0.025)
        gain_db[max(0, i0 - 1):min(nb, i1 + 1)] = -dip
    if not (gain_db < 0).any():
        return x, 0
    g = _asym_smooth(_undb(gain_db), 1.0 / 0.025, 0.01, 0.04)
    gg = _expand(g, n, len(xm))
    if x.ndim == 2:
        out = [x[:, c] + (gg - 1.0) * _butter(
            np.ascontiguousarray(x[:, c]), sr, 150.0, "lowpass", order=4)
            for c in range(x.shape[1])]
        return np.stack(out, axis=1), len(spans)
    low = _butter(x, sr, 150.0, "lowpass", order=4)
    return x + (gg - 1.0) * low, len(spans)


def _m_tonal(x: np.ndarray, sr: int, moves: list[dict]):
    def chain(ch: np.ndarray):
        y = ch
        for m in moves:
            if m["type"] == "hpf":
                y = _butter(y, sr, float(m["f"]), "highpass", order=2)
            else:
                y = _apply(y, *_biquad(m["type"], sr, float(m["f"]),
                                       float(m["gain"]), float(m["q"])))
        return y, None
    return _ch_apply(x, chain)[0]


def _band_dists(x: np.ndarray, sr: int, prof: dict) -> dict:
    bands = _band_profile(x, sr) or {}
    win = prof["windows"]
    out = {}
    for band in win:
        v = bands.get(band)
        if v is None:
            continue
        lo, hi = win[band]
        if lo is not None and v < lo:
            out[band] = round(lo - v, 2)      # below → needs boost
        elif hi is not None and v > hi:
            out[band] = round(-(v - hi), 2)   # above → needs cut
        else:
            out[band] = 0.0
    return out


def _m_deess(x: np.ndarray, sr: int, amount: float):
    return _ch_apply(x, lambda ch: _de_ess(ch, sr, amount))


def _m_compress(x: np.ndarray, sr: int, amount: float):
    return _ch_apply(x, lambda ch: _compress3(ch, sr, amount))


def _m_warmth(x: np.ndarray, sr: int, warmth: float):
    return _ch_apply(x, lambda ch: _saturate(ch, sr, warmth))


def _limit_nd(x: np.ndarray, sr: int, ceiling: float = 0.95) -> np.ndarray:
    if x.ndim == 1:
        return _soft_limit(x, sr, ceiling)
    return np.stack([_soft_limit(np.ascontiguousarray(x[:, c]), sr, ceiling)
                     for c in range(x.shape[1])], axis=1)


def _m_master(x: np.ndarray, sr: int, target: float | None,
              dst: Path, workdir: Path,
              ceil: float = 0.80) -> tuple[np.ndarray, int, float]:
    """Iterative gain (BOTH directions) → lookahead soft-limit → re-measure,
    then the final true-peak safety limiter. Loudness moves in the DYNAMICS
    stage (1.txt §11), never by slamming the final limiter. `ceil` tightens
    for the REPROCESS retry (1.txt §22)."""
    import soundfile as sf
    tmp = workdir / "pre_master.wav"
    y = x
    rounds = 0
    if target is not None:
        sf.write(str(tmp), y.astype(np.float64), sr, subtype="DOUBLE")
        cur = _loudness_of(tmp)
        while cur is not None and abs(cur - target) > 0.7 and rounds < 4:
            need = target - cur
            y = y * (10.0 ** (need / 20.0))
            if need > 0:
                y = _limit_nd(y, sr, min(0.95, ceil))  # limit when raising
            rounds += 1
            sf.write(str(tmp), y.astype(np.float64), sr, subtype="DOUBLE")
            cur = _loudness_of(tmp)
    sf.write(str(tmp), y.astype(np.float64), sr, subtype="DOUBLE")
    _ff(["-i", str(tmp), "-af",
         f"alimiter=limit={max(0.50, min(0.95, ceil)):.2f}:level=false",
         "-ar", str(int(sr)), "-c:a", "pcm_s24le", str(dst)])
    if not dst.exists():
        raise EnhanceError("[enhance] master: ffmpeg produced no output")
    final = analyze(dst)
    return y, rounds, (final.lufs if final.lufs is not None else 0.0)


# ---------------------------------------------------------------- scores

def _scores(f0: dict, f1: dict, out_stats, qa, prof: dict,
            target: float | None, thd: float, rollbacks: int) -> dict:
    """Multi-dimensional quality report (NOT one number, 1.txt §14)."""
    def clip01(v):
        return int(round(max(0.0, min(100.0, v))))

    # technical integrity
    tech = 100.0
    if f1.get("clip_pct", 0) > 0.004:
        tech -= min(30.0, f1["clip_pct"] * 200.0)
    if f1.get("dc", 0) > 0.002:
        tech -= 20.0
    if qa is not None and qa.verdict == "warn":
        tech -= 8.0
    s = {"technical": clip01(tech)}

    # restoration: how much of the REAL damage got fixed
    items = []
    h0, h1 = f0.get("headroom_db"), f1.get("headroom_db")
    had_noise = h0 is not None and h0 < prof["headroom_min"]
    if had_noise and h1 is not None:
        items.append(min(1.0, max(0.0, (h1 - h0) / max(6.0, 15.0 - h0))))
    r0, r1 = f0.get("pause_ratio_db"), f1.get("pause_ratio_db")
    if r0 is not None and r1 is not None and r0 > prof.get("roomy_max", -99):
        items.append(min(1.0, max(0.0, (r0 - r1) / 8.0)))
    c0, c1 = f0.get("clip_pct", 0), f1.get("clip_pct", 0)
    if c0 > 0.004:
        items.append(min(1.0, max(0.0, (c0 - c1) / max(c0, 1e-6))))
    hum0, hum1 = (f0.get("hum") or {}), (f1.get("hum") or {})
    b0 = max(hum0.values()) if hum0 else -99.0
    b1 = max(hum1.values()) if hum1 else -99.0
    if b0 > 4.0:
        items.append(min(1.0, max(0.0, (b0 - b1) / max(b0 - 4.0, 1.0))))
    s["restoration"] = clip01(100.0 if not items
                              else 35.0 + 65.0 * float(np.mean(items)))

    # tonal balance: distance left outside the profile windows
    d1 = _dist_penalty(f1, prof)
    d0 = _dist_penalty(f0, prof)
    s["tonal"] = clip01(100.0 - min(45.0, d1 * 4.0)
                        if d1 <= d0 else 100.0 - min(45.0, d1 * 4.0) - 5.0)

    # dynamics: LRA window + transient (crest) preservation
    dyn = 100.0
    lra1 = getattr(out_stats, "lra", None) if out_stats else None
    if lra1 is not None:
        lo, hi = prof["lra"]
        if lra1 > hi:
            dyn -= min(25.0, (lra1 - hi) * 3.0)
        elif lra1 < lo:
            dyn -= min(25.0, (lo - lra1) * 5.0)
    cd = (f0.get("crest", 0) - f1.get("crest", 0))
    if cd > 2.5:
        dyn -= min(25.0, (cd - 2.5) * 6.0)
    s["dynamics"] = clip01(dyn)

    # naturalness: over-processing canary
    nat = 100.0
    if h1 is not None and h1 > 34.0:
        nat -= min(25.0, (h1 - 34.0) * 2.0)      # over-denoised (dead room)
    if cd > 2.0:
        nat -= min(20.0, cd * 4.0)
    nat -= min(15.0, thd * 400.0)
    s["naturalness"] = clip01(nat)

    # artifacts: musical-noise canary + rollbacks
    art = 100.0
    fl0, fl1 = f0.get("pause_flatness"), f1.get("pause_flatness")
    if fl0 is not None and fl1 is not None and fl0 > 1e-4:
        drop = (fl0 - fl1) / fl0
        if drop > 0.35:
            art -= min(35.0, drop * 60.0)
    art -= min(24.0, rollbacks * 8.0)
    if cd > 4.0:
        art -= 10.0
    s["artifacts"] = clip01(art)

    # stereo / mono-phase compliance — the 8th dimension (1.txt §14)
    if prof["mono"]:
        st = 100.0
    else:
        st = 100.0
        corr = f1.get("corr")
        imb = f1.get("lr_imb")
        if corr is not None:
            if corr < 0.15:
                st -= min(40.0, (0.15 - corr) * 200.0)
            elif corr > 0.98:
                st -= 10.0
        if imb is not None and imb > 4.0:
            st -= min(20.0, (imb - 4.0) * 5.0)
    s["stereo"] = clip01(st)

    # delivery: loudness + true peak at target
    dl = 100.0
    lufs1 = getattr(out_stats, "lufs", None) if out_stats else None
    if target is not None and lufs1 is not None:
        dl -= min(30.0, abs(lufs1 - target) * 6.0)
    tp1 = getattr(out_stats, "true_peak", None) if out_stats else None
    if tp1 is not None and tp1 > -1.0:
        dl -= min(30.0, (tp1 + 1.0) * 25.0)
    s["delivery"] = clip01(dl)
    return s


def _dist_penalty(f: dict, prof: dict) -> float:
    bands = f.get("bands") or {}
    win = prof["windows"]
    tot = 0.0
    for band, (lo, hi) in win.items():
        v = bands.get(band)
        if v is None:
            continue
        if lo is not None and v < lo:
            tot += (lo - v)
        elif hi is not None and v > hi:
            tot += (v - hi)
    return tot

# ---------------------------------------------------------------- helpers

def _tri(v):
    """'auto'→None, on/true→True, off/false→False."""
    if isinstance(v, bool):
        return v
    s = str(v).lower()
    if s in ("on", "true", "1", "yes"):
        return True
    if s in ("off", "false", "0", "no"):
        return False
    return None


def _moves_from_dists(dists: dict, per_cap: float, sc: float,
                      budget: float | None) -> list[dict]:
    """Live corrective-EQ move list from CURRENT band distances.
    (re-measured right before the tonal module runs — 1.txt §24:
    already-corrected bands never get processed twice)."""
    moves: list[dict] = []

    def add(band, typ, f, gain, q=1.0):
        moves.append({"band": band, "type": typ, "f": f,
                      "gain": float(np.clip(gain, -per_cap, per_cap)),
                      "q": q})

    for band, d in (dists or {}).items():
        if abs(d) < 1.5:
            continue
        if band == "rumble" and d < 0:
            moves.append({"band": "rumble", "type": "hpf",
                          "f": 85.0 if -d > 6 else 75.0,
                          "gain": 0.0, "q": 0.0})
            continue
        g = d * sc
        if band == "body":
            add("body", "lowshelf", 170.0, g)
        elif band == "lowmid":
            add("lowmid", "peaking", 300.0, g, 1.0)
        elif band == "presence":
            add("presence", "peaking", 3100.0, g, 1.1)
            add("presence", "peaking", 4700.0, g * 0.6, 1.3)
        elif band == "hi":
            add("hi", "peaking", 6800.0, g, 1.2)
        elif band == "air":
            add("air", "highshelf", 11000.0, g, 0.707)
    if budget is not None:
        tot = sum(abs(m["gain"]) for m in moves)
        if tot > budget:
            k = budget / tot
            for m in moves:
                m["gain"] *= k
    return moves


def _dist_sum(dists: dict) -> float:
    return float(sum(abs(v) for v in (dists or {}).values()))


# ---------------------------------------------------------------- gates

def _gates(ref, out, qa, f0, f1, prof, tgt, ai_guard, sr, crest_d,
           dst) -> tuple[list[dict], str]:
    """Quality Gate — the 10 gates of 1.txt §22 (file integrity,
    technical, loudness, true peak, dynamics, phase, stereo, spectral
    artifacts, AI artifacts, delivery). Each gate returns PASS / WARN /
    FAIL; a FAIL on a fixable gate (loudness / true-peak) asks the
    caller for one REPROCESS round instead of a hard failure."""
    G: list[dict] = []

    def g(name, status, detail):
        G.append({"gate": name, "status": status,
                  "detail": str(detail)[:160]})

    okf = dst.exists() and out.duration > 0 and \
        abs(out.duration - ref.duration) < 0.25
    g("file-integrity", "pass" if okf else "fail",
      f"{out.duration:.1f}s vs {ref.duration:.1f}s · "
      f"{out.sample_rate // 1000 if out.sample_rate else '?'} kHz")

    iss = []
    if f1.get("clip_pct", 0) > 0.01:
        iss.append(f"clip {f1['clip_pct']:.2f}%")
    if f1.get("dc", 0) > 0.002:
        iss.append(f"DC {f1['dc']:.3f}")
    if qa is not None and qa.verdict == "warn":
        iss.append("qa warn")
    g("technical-integrity", "pass" if not iss else "warn",
      "; ".join(iss) or "DC · clip · silence all clean")

    if tgt is None or out.lufs is None:
        g("loudness", "pass", "no target — source level preserved")
    elif abs(out.lufs - tgt) <= 1.5:
        g("loudness", "pass", f"{out.lufs:.1f} LUFS (target {tgt:.1f})")
    elif abs(out.lufs - tgt) <= 3.0:
        g("loudness", "warn", f"{out.lufs:.1f} vs target {tgt:.1f} LUFS")
    else:
        g("loudness", "fail", f"{out.lufs:.1f} vs target {tgt:.1f} LUFS")

    if out.true_peak is None:
        g("true-peak", "pass", "not measurable")
    elif out.true_peak <= -1.5:
        g("true-peak", "pass", f"{out.true_peak:.1f} dBTP ≤ −1.5")
    else:
        g("true-peak", "fail", f"{out.true_peak:.1f} dBTP over −1.5")

    iss = []
    if out.lra is not None:
        lo, hi = prof["lra"]
        if out.lra > hi + 4:
            iss.append(f"LRA {out.lra:.1f} LU > {hi:.0f}")
        elif out.lra < lo - 2:
            iss.append(f"LRA {out.lra:.1f} LU < {lo:.0f}")
    if crest_d > 4.5:
        iss.append(f"crest Δ {crest_d:.1f} dB")
    g("dynamics", "pass" if not iss else "warn",
      "; ".join(iss) or
      f"LRA {out.lra if out.lra is not None else '—'} LU · "
      f"crest Δ {crest_d:.1f} dB")

    if prof["mono"]:
        g("phase", "pass" if out.channels == 1 else "warn",
          "center-locked mono" if out.channels == 1 else
          f"{out.channels} ch — profile expects mono")
    else:
        corr = f1.get("corr")
        if corr is None:
            g("phase", "pass", "mono source")
        elif corr >= 0.0:
            g("phase", "pass", f"correlation {corr:.2f}")
        else:
            g("phase", "fail", f"correlation {corr:.2f} — anti-phase")

    if prof["mono"]:
        g("stereo", "pass", "voice center-lock (podcast default)")
    else:
        corr, imb = f1.get("corr"), f1.get("lr_imb")
        iss = []
        if corr is not None and (corr < 0.15 or corr > 0.98):
            iss.append(f"corr {corr:.2f}")
        if imb is not None and imb > 4.0:
            iss.append(f"L/R Δ {imb:.1f} dB")
        g("stereo", "pass" if not iss else "warn",
          "; ".join(iss) or
          f"corr {corr if corr is not None else '—'} · "
          f"balance Δ {imb if imb is not None else '—'} dB")

    iss = []
    fl0, fl1 = f0.get("pause_flatness"), f1.get("pause_flatness")
    if fl0 is not None and fl1 is not None and fl0 > 1e-4 and \
            (fl0 - fl1) / fl0 > 0.35:
        iss.append("musical-noise (flatness drop)")
    b0, b1 = (f0.get("bands") or {}), (f1.get("bands") or {})
    for band in ("air", "hi"):
        v0, v1 = b0.get(band), b1.get(band)
        if v0 is not None and v1 is not None and v1 - v0 > 6.0:
            iss.append(f"artificial {band} +{v1 - v0:.1f} dB")
    g("spectral-artifacts", "pass" if not iss else "warn",
      "; ".join(iss) or "flatness & air band stable")

    g("ai-artifacts", "pass" if ai_guard.get("ok", True) else "warn",
      ai_guard.get("detail", "AI not used (DSP-only path)"))

    iss = []
    if out.sample_rate and out.sample_rate != sr:
        iss.append(f"SR {out.sample_rate} ≠ {sr}")
    if out.codec and "pcm" not in out.codec and out.codec not in ("wav",):
        iss.append(f"codec {out.codec}")
    g("delivery", "pass" if not iss else "warn",
      "; ".join(iss) or
      f"24-bit WAV · {sr // 1000} kHz · "
      f"{'mono' if prof['mono'] else 'stereo'} · ceiling −2.0 dBTP")

    if any(x["status"] == "fail" for x in G):
        fixable = any(x["status"] == "fail" and
                      x["gate"] in ("loudness", "true-peak") for x in G)
        return G, ("reprocess" if fixable else "fail")
    if any(x["status"] == "warn" for x in G):
        return G, "warn"
    return G, "pass"


# ---------------------------------------------------------------- run

def run(path: str | Path, out_path: str | Path,
        mode: str = "balanced", profile: str = "auto",
        ai_assist: float = 55.0, max_quality: bool = False,
        intensity: float = 70.0, preserve_dynamics: bool = False,
        keep_natural: bool = False, target_lufs: str | float = "auto",
        declick: str | bool = "auto", dehum: str | bool = "auto",
        on_progress: Callable[[str, int], None] | None = None) -> dict:
    """ENHANCE — diagnose, plan, process, verify, report. Same result
    contract as dolby_off / studiomic + problems/actions/scores/report."""
    src, dst = Path(path), Path(out_path)
    notes: list[str] = ["Enhance — intelligent adaptive agent (local, "
                        "no keys, no cloud) · blueprint: diagnose → plan → "
                        "process → verify → rollback"]
    stages: list[dict] = []
    actions: list[dict] = []
    problems: list[dict] = []
    scores: dict = {}
    report: dict = {}
    rollbacks = 0
    ai_guard = {"used": False, "ok": True,
                "detail": "AI not used (DSP-only path)"}
    _st = [0]

    def stage(name, status, detail):
        _st[0] += 1
        stages.append({"n": _st[0], "name": name, "status": status,
                       "detail": str(detail)[:220]})

    def prog(msg, pct):
        if on_progress:
            on_progress(msg, pct)

    def action(key, label, why, what, how, risk, result, detail=""):
        actions.append({"problem": key, "label": label, "why": why,
                        "what": what, "how_much": how, "risk": risk,
                        "result": result, "detail": str(detail)[:260]})

    try:
        # ================= 1 · INGEST + VALIDATE =====================
        prog("Enhance 1: ingest + validate", 5)
        ref = analyze(src)
        if not ref.duration:
            return {"ok": False, "verdict": "fail",
                    "reason": "input analysis failed — unreadable audio",
                    "stages": stages, "actions": actions,
                    "problems": problems, "notes": notes}
        mode_key = mode if mode in MODES else "balanced"
        md = MODES[mode_key]
        inten = max(0.0, min(100.0, float(intensity)))
        dry = inten <= 0
        declick_v, dehum_v = _tri(declick), _tri(dehum)
        ai_pct = max(0.0, min(100.0, float(ai_assist)))
        workdir = Path(tempfile.mkdtemp(prefix="enhance_"))
        try:
            import soundfile as sf
            dec = workdir / "decoded.wav"
            # f32 decode = LOSSLESS for any ≤24-bit PCM source — the
            # internal master stays pristine (1.txt §19/§20: process the
            # best source, encode once at the very end)
            _ff(["-i", str(src), "-ar", "48000", "-c:a", "pcm_f32le",
                 str(dec)])
            if not dec.exists():
                raise EnhanceError("[enhance] decode produced no output")
            y2, sr = sf.read(str(dec), dtype="float64", always_2d=True)
            if len(y2) == 0:
                raise EnhanceError("[enhance] empty decode")
            sr = int(sr)
            x_src = y2            # pristine reference (bypass truth, §23)

            # ---- profile resolution (auto → speech vs music) --------
            pmix = y2.mean(axis=1)
            probe_f = _pause_metrics(pmix, sr)
            bands0 = _band_profile(pmix, sr) or {}
            vbr = bands0.get("voiceband_ratio", 0.0)
            is_voice = (probe_f.get("speech_ratio", 0.0) > 0.22 and
                        vbr > 0.45)
            prof_key = profile if profile in PROFILES else "auto"
            if prof_key == "auto":
                prof_key = "intimate" if is_voice else "music"
            prof = PROFILES[prof_key]
            x = pmix if prof["mono"] else y2
            # predictable working level (metrics stay level-invariant)
            pk = float(np.max(np.abs(x)))
            if pk > 1e-7:
                x = x * (10.0 ** (-3.0 / 20.0) / pk)
            stage("INGEST", "done",
                  f"{ref.duration:.1f}s · {sr} Hz · {y2.shape[1]} ch → "
                  f"{'mono' if prof['mono'] else 'stereo'} · profile="
                  f"{prof_key} ({'speech detected' if is_voice else 'music'})")
            notes.append(f"ingest: {ref.duration:.1f}s, profile auto-resolve "
                         f"→ {prof_key}")

            # ================= 2 · FORENSIC + DIAGNOSE =================
            prog("Enhance 2: forensic analysis + problem detection", 10)
            f0 = _forensic(x, sr, ref, prof)
            problems = _diagnose(f0, prof)
            stage("DIAGNOSE", "done" if problems else "skipped",
                  f"{len(problems)} problem(s) detected · "
                  + ("; ".join(f"{p['label']} sev {p['severity']:.2f}"
                               for p in problems[:5]) if problems
                     else "clean source — nothing to fix"))
            for p in problems:
                notes.append(f"problem: {p['problem']} sev={p['severity']} "
                             f"conf={p['confidence']} ({p['value']})")

            # ================= 3 · ADAPTIVE PLAN =======================
            prog("Enhance 3: build the adaptive processing plan", 14)
            opts = dict(intensity=inten, preserve_dynamics=preserve_dynamics,
                        keep_natural=keep_natural,
                        force_declick=declick_v is True,
                        force_dehum=dehum_v is True)
            plan = _plan(problems, prof, md, opts)
            by_key = {e["key"]: e for e in plan}
            n_act = sum(1 for e in plan if e["act"] and e["key"] != "level")
            stage("PLAN", "done",
                  f"{n_act} module(s) activated of {len(plan) - 1} "
                  f"conditional · mode={mode_key} · intensity={inten:.0f}%"
                  + (" · DRY-RUN (intensity 0 — diagnose only)" if dry else ""))
            notes.append(f"plan: {n_act} modules activated "
                         f"({', '.join(e['module'] for e in plan if e['act'])})")

            # target loudness (user > profile > preserve-source)
            tgt = None
            if isinstance(target_lufs, (int, float)):
                tgt = max(-30.0, min(-9.0, float(target_lufs)))
            elif prof.get("lufs") is not None:
                tgt = prof["lufs"]
            elif ref.lufs is not None:
                tgt = max(-35.0, min(-16.0, float(ref.lufs)))

            # ================= MODULES (verify each) ===================
            # ---- DC ------------------------------------------------
            e = by_key["dc"]
            if e["act"]:
                x, dcm = _m_dc(x)
                action("dc", "DC offset", "DC collapses headroom",
                       "dc-correct", f"mean {dcm:.4f} removed", "none",
                       "kept" if not dry else "dry-run")
                stage("DC CORRECT", "done", f"mean {dcm:.4f} removed")
            else:
                action("dc", "DC offset", "—", "dc-correct", "—", "none",
                       "no-problem", "DC within tolerance")

            # ---- REPAIR (ffmpeg: declick + dehum notches) -----------
            rep: list[str] = []
            e_click, e_hum = by_key["clipping"], by_key["hum"]
            hum0v = max((f0.get("hum") or {}).values(), default=-99.0)
            if e_hum["act"] or e_click["act"]:
                if e_hum["act"]:
                    humd = f0.get("hum") or {}
                    best50 = max(humd.get(50.0, -99), humd.get(100.0, -99),
                                 humd.get(150.0, -99))
                    best60 = max(humd.get(60.0, -99), humd.get(120.0, -99),
                                 humd.get(180.0, -99))
                    base = 50.0 if best50 >= best60 else 60.0
                    for h in (1, 2, 3):
                        rep.append(f"equalizer=f={base * h}:width_type=h:"
                                   f"width=1.2:g=-10")
                if e_click["act"]:
                    rep.append("adeclick=window=55:overlap=75:arorder=4")
            if rep and not dry:
                prog("Enhance: repair pass (declick / dehum notches)", 26)
                x = _ff_roundtrip(x, sr, rep, workdir, "repair")
                hum1v = max((_hum_lines(x, sr) or {}).values(), default=-99.0)
                if e_hum["act"]:
                    action("hum", "Mains hum",
                           f"hum lines +{hum0v:.1f} dB over floor",
                           "dehum notches",
                           f"{hum0v:.1f} → {hum1v:.1f} dB", "low", "kept")
                    stage("DEHUM", "done",
                          f"mains family notched: {hum0v:.1f} → "
                          f"{hum1v:.1f} dB prominence")
                if e_click["act"]:
                    action("clipping", "Clicks / clipped spans",
                           "impulsive damage detected",
                           "adeclick + declip", "ffmpeg adeclip pass", "low",
                           "kept")
                    stage("DECLICK", "done", "ffmpeg adeclick applied")
            else:
                for k, lbl in (("hum", "Mains hum"), ("clipping", "Clicks")):
                    action(k, lbl, "—", "repair", "—", "low",
                           "no-problem" if not (by_key[k]["act"]) else
                           ("dry-run" if dry else "no-problem"),
                           "below activation threshold or clean")

            # ---- numpy declip if clipping persists -------------------
            if by_key["clipping"]["act"] and not dry:
                cp = _clip_stats(x) * 100.0
                if cp > 0.004:
                    x, nfix = _m_declip(x)
                    cp2 = _clip_stats(x) * 100.0
                    action("clipping", "Clipped spans",
                           f"{cp:.3f}% samples at ceiling",
                           "declip (interpolation)", f"{nfix} span(s)",
                           "low", "kept" if cp2 < cp else "kept (partial)",
                           f"{cp:.3f}% → {cp2:.3f}%")
                    stage("DECLIP", "done",
                          f"{nfix} span(s) repaired · {cp:.3f}% → "
                          f"{cp2:.3f}%")

            # ---- DENOISE --------------------------------------------
            e = by_key["noise"]
            if e["act"] and not dry:
                red = float(e["amount"])
                h_b, act_b = _headroom_now(x, sr)
                pm_b = _pause_metrics(x, sr)
                fl_b = pm_b.get("pause_flatness")
                ai_ok = ai_pct > 0 and prof["voice"] and \
                    ai_status().get("resemble")
                sev_noise = next((p["severity"] * p["confidence"]
                                   for p in problems
                                   if p["problem"] == "noise"), 0.5)
                ai_clean = min(100.0, ai_pct * (0.45 + 0.55 * sev_noise))
                use_ai = bool(ai_ok)
                prog("Enhance: denoise " +
                     ("(AI studio backend)" if use_ai else
                      "(spectral gating)"), 36)
                x2, backend, _ = _m_denoise(
                    x, sr, red, use_ai, ai_clean, max_quality, prof["voice"],
                    prog, 36, 44, notes, workdir)
                h_a, act_a = _headroom_now(x2, sr)
                pm_a = _pause_metrics(x2, sr)
                fl_a = pm_a.get("pause_flatness")
                need = red * 0.45
                act_tol = 2.5 if backend in ("resemble",) else 2.0
                why: list[str] = []
                ok = (h_a is not None and h_b is not None and
                      h_a >= h_b + need)
                if ok and act_b is not None and act_a is not None:
                    ok = (act_b - act_a) <= act_tol
                if ok and fl_b is not None and fl_a is not None:
                    ok = fl_a >= 0.45 * fl_b
                if ok:
                    # artificial-brightness guard (1.txt §20 'excessive
                    # brightness'): AI must not invent hi/air content
                    bands_b = _band_profile(x, sr) or {}
                    bands_a = _band_profile(x2, sr) or {}
                    for band in ("hi", "air"):
                        vb, va = bands_b.get(band), bands_a.get(band)
                        if vb is not None and va is not None and \
                                va - vb > 6.0:
                            ok = False
                            why.append(f"artificial {band} "
                                       f"(+{va - vb:.1f} dB)")
                            notes.append(f"denoise guard: artificial "
                                         f"{band} +{va - vb:.1f} dB")
                if ok:
                    x = x2
                    if backend in ("resemble",):
                        ai_guard.update(
                            used=True, ok=True,
                            detail="AI guards passed — speech level, "
                                   "pause flatness, no artificial "
                                   "hi/air")
                    action("noise", "Background noise",
                           f"headroom {h_b:.1f} dB (target >= "
                           f"{prof['headroom_min']:.0f})",
                           f"denoise ({backend})",
                           f"≈ {red:.0f} dB target", "medium",
                           "kept",
                           f"headroom {h_b:.1f} → {h_a:.1f} dB · speech "
                           f"level Δ {act_a - act_b:+.1f} dB")
                    stage("DENOISE", "done",
                          f"{backend}: headroom {h_b:.1f} → {h_a:.1f} dB "
                          f"(target ≈ {red:.0f} dB)")
                else:
                    rollbacks += 1
                    if backend in ("resemble",):
                        ai_guard.update(
                            used=True, ok=True,
                            detail="AI output REJECTED by the artifact "
                                   "guard — original kept (" +
                                   "; ".join(why) + ")")
                    if h_a is not None and h_b is not None and \
                            h_a < h_b + need:
                        why.append(f"headroom gain < {need:.1f} dB")
                    if act_b is not None and act_a is not None and \
                            (act_b - act_a) > act_tol:
                        why.append("speech level eaten")
                    if fl_b is not None and fl_a is not None and \
                            fl_a < 0.45 * fl_b:
                        why.append("musical-noise artifact (flatness)")
                    action("noise", "Background noise",
                           f"headroom {h_b:.1f} dB",
                           f"denoise ({backend})", f"≈ {red:.0f} dB",
                           "medium", "rolled-back",
                           "reason: " + "; ".join(why))
                    stage("DENOISE", "skipped",
                          "rolled back — " + "; ".join(why))
                    notes.append("denoise rolled back: " + "; ".join(why))
            else:
                action("noise", "Background noise", "—", "denoise", "—",
                       "medium", "no-problem" if not e["act"] else
                       ("dry-run" if dry else "no-problem"),
                       "headroom within target or not measurable")

            # ---- DE-REVERB -------------------------------------------
            e = by_key["roomy"]
            if e["act"] and not dry:
                red = float(e["amount"])
                pm_b = _pause_metrics(x, sr)
                r_b = pm_b.get("pause_ratio_db")
                act_b = pm_b.get("active_db")
                x2, applied = _m_dereverb(x, sr, red)
                pm_a = _pause_metrics(x2, sr)
                r_a = pm_a.get("pause_ratio_db")
                act_a = pm_a.get("active_db")
                ok = (r_b is not None and r_a is not None and
                      (r_b - r_a) >= 2.0)
                if ok and act_b is not None and act_a is not None:
                    ok = (act_b - act_a) <= 1.5
                if ok:
                    x = x2
                    action("roomy", "Room / reverb tails",
                           f"pause energy {r_b:.0f} dB under speech "
                           f"(target <= {abs(prof['roomy_max']):.0f})",
                           "de-reverb (tail suppression)",
                           f"−{applied:.0f} dB on tails", "medium", "kept",
                           f"pause ratio {r_b:.1f} → {r_a:.1f} dB")
                    stage("DE-REVERB", "done",
                          f"tails −{applied:.0f} dB · pause {r_b:.1f} → "
                          f"{r_a:.1f} dB under speech")
                else:
                    rollbacks += 1
                    action("roomy", "Room / reverb tails",
                           f"pause energy {r_b} dB under speech",
                           "de-reverb", f"−{red:.0f} dB", "medium",
                           "rolled-back", "not enough improvement")
                    stage("DE-REVERB", "skipped",
                          "rolled back — tail energy did not drop enough")
            else:
                action("roomy", "Room / reverb tails", "—", "de-reverb", "—",
                       "medium", "no-problem", "tails within target")

            # ---- BREATH CONTROL (loud only — Podcast §12) ---------
            e = by_key["breath"]
            if e["act"] and not dry:
                amt = float(e["amount"])
                dbb, n, nb = _env_db(_mono(x), sr)
                active, thr, floor, refx = _activity(dbb)
                spk = max(thr, refx - 11.0)   # speech zone boundary
                loud_idx = (dbb < spk) & (dbb > floor + 13.0)
                lvl_b = _level_at(x, n, loud_idx)
                h_b, act_b = _headroom_now(x, sr)
                x2, dip = _m_breath(x, sr, amt)
                lvl_a = _level_at(x2, n, loud_idx)
                h_a, act_a = _headroom_now(x2, sr)
                drop = None
                if lvl_b is not None and lvl_a is not None:
                    drop = 20.0 * math.log10(max(lvl_b, 1e-10) /
                                             max(lvl_a, 1e-10))
                ok = drop is not None and drop >= 2.0
                if ok and act_b is not None and act_a is not None:
                    ok = abs(act_a - act_b) <= 1.0
                if ok:
                    x = x2
                    dsfx = (f" · speech Δ {act_a - act_b:+.1f} dB"
                            if act_a is not None and act_b is not None
                            else "")
                    action("breath", "Loud breaths",
                           "breaths far above the noise floor",
                           "breath control (loud only)",
                           f"−{dip:.1f} dB on loud breaths", "low",
                           "kept",
                           f"breath level −{drop:.1f} dB" + dsfx)
                    stage("BREATH", "done",
                          f"loud breaths dipped {dip:.1f} dB · natural "
                          f"ones kept")
                else:
                    rollbacks += 1
                    action("breath", "Loud breaths", "—", "breath control",
                           "—", "low", "rolled-back",
                           "insufficient gain or speech moved — original "
                           "kept")
                    stage("BREATH", "skipped", "rolled back")
            else:
                action("breath", "Loud breaths", "—", "breath control", "—",
                       "low", "no-problem" if not e["act"] else
                       ("dry-run" if dry else "no-problem"),
                       "no loud breaths (or music profile)")

            # ---- PLOSIVE CONTROL (60–150 Hz dips — §13) ------------
            e = by_key["plosive"]
            if e["act"] and not dry:
                amt = float(e["amount"])
                pl_b = _plosive_metrics(x, sr)
                h_b, act_b = _headroom_now(x, sr)
                x2, nfix = _m_plosive(x, sr, amt)
                pl_a = _plosive_metrics(x2, sr)
                h_a, act_a = _headroom_now(x2, sr)
                ok = nfix > 0 and pl_a["count"] <= pl_b["count"] * 0.7
                if ok and act_b is not None and act_a is not None:
                    ok = abs(act_a - act_b) <= 1.0
                if ok:
                    x = x2
                    action("plosive", "Plosives (P/B pops)",
                           "LF-dominant bursts on consonant onsets",
                           "plosive dip 60–150 Hz",
                           f"{nfix} span(s) dipped", "low", "kept",
                           f"LF bursts {pl_b['count']} → {pl_a['count']}")
                    stage("PLOSIVE", "done",
                          f"{nfix} burst(s) dipped · LF pops "
                          f"{pl_b['count']} → {pl_a['count']}")
                else:
                    rollbacks += 1
                    action("plosive", "Plosives (P/B pops)", "—",
                           "plosive dip", "—", "low", "rolled-back",
                           "burst reduction or speech level failed guard")
                    stage("PLOSIVE", "skipped", "rolled back")
            else:
                action("plosive", "Plosives (P/B pops)", "—", "plosive dip",
                       "—", "low", "no-problem" if not e["act"] else
                       ("dry-run" if dry else "no-problem"),
                       "no pops detected (or music profile)")

            # ---- TONAL (2-pass, self-correcting) ----------------------
            e = by_key["tonal"]
            per_cap, budget = md["eq"][0], md["eq"][1]
            sc = 0.5 * md["amt"] * (0.4 + 0.6 * inten / 100.0)
            if e["act"] and not dry:
                d_start = _band_dists(x, sr, prof)
                pen0 = _dist_sum(d_start)
                moves1 = _moves_from_dists(d_start, per_cap, sc, budget)
                x1 = _m_tonal(x, sr, moves1) if moves1 else x
                d1 = _band_dists(x1, sr, prof)
                moves2 = _moves_from_dists(d1, per_cap, sc * 0.8, budget)
                if moves2:                       # fine-correction pass
                    x2 = _m_tonal(x1, sr, moves2)
                    d2 = _band_dists(x2, sr, prof)
                    if _dist_sum(d2) <= _dist_sum(d1):
                        x1, d1 = x2, d2
                pen1 = _dist_sum(d1)
                if pen1 > pen0 + 0.8:            # overshoot → conservative retry
                    rollbacks += 1
                    xh = _m_tonal(x, sr, [{**m, "gain": m["gain"] * 0.5}
                                          for m in moves1])
                    if _dist_sum(_band_dists(xh, sr, prof)) < pen1:
                        x1, d1, pen1 = xh, _band_dists(xh, sr, prof), pen0
                        action("tonal", "Tonal balance",
                               "overshoot detected on first pass",
                               "tonal-correct", "halved", "low",
                               "kept-reduced", "fine pass corrected the "
                               "overshoot")
                x = x1
                moved = ", ".join(f"{m['type']} {m['f']:.0f} Hz "
                                  f"{m['gain']:+.1f} dB"
                                  for m in moves1 + moves2
                                  if m["type"] != "hpf") or "HPF only"
                action("tonal", "Tonal balance",
                       "band(s) outside the profile window",
                       "tonal-correct (2-pass)", moved, "low", "kept",
                       f"window distance {pen0:.1f} → {pen1:.1f} dB")
                stage("TONAL", "done",
                      f"2-pass corrective EQ · window distance {pen0:.1f} "
                      f"→ {pen1:.1f} dB")
                notes.append(f"tonal: {moved}")
            else:
                action("tonal", "Tonal balance", "—", "tonal-correct", "—",
                       "low", "no-problem", "all bands inside the windows")

            # ---- DE-ESS -----------------------------------------------
            e = by_key["sib"]
            if e["act"] and not dry:
                amt = float(e["amount"])
                sib_b = (_pause_metrics(x, sr).get("sib_ratio_db"))
                x2, dess_db = _m_deess(x, sr, amt)
                sib_a = (_pause_metrics(x2, sr).get("sib_ratio_db"))
                ok = (sib_b is not None and sib_a is not None and
                      (sib_b - sib_a) >= 1.2)
                if ok:
                    x = x2
                    action("sibilant", "Sibilance",
                           f"ratio {sib_b:.1f} dB over speech band",
                           "de-esser 5.5–9 kHz",
                           f"max −{dess_db:.1f} dB", "low", "kept",
                           f"ratio {sib_b:.1f} → {sib_a:.1f} dB")
                    stage("DE-ESS", "done",
                          f"adaptive de-esser · max −{dess_db:.1f} dB · "
                          f"ratio {sib_b:.1f} → {sib_a:.1f} dB")
                else:
                    rollbacks += 1
                    action("sibilant", "Sibilance", f"ratio {sib_b}",
                           "de-esser", f"{amt:.2f}", "low", "rolled-back",
                           "insufficient improvement — original kept")
                    stage("DE-ESS", "skipped", "rolled back")
            else:
                action("sibilant", "Sibilance", "—", "de-esser", "—", "low",
                       "no-problem", "sibilance within target")

            # ---- COMPRESSOR (transient-guarded) -----------------------
            e = by_key["dyn"]
            if e["act"] and not dry:
                amt = float(e["amount"])
                crest_b = _crest(x)
                x2, cinfo = _m_compress(x, sr, amt)
                crest_a = _crest(x2)
                if crest_b - crest_a > 3.5:       # transient damage guard
                    x2, cinfo = _m_compress(x, sr, amt * 0.5)
                    crest_a = _crest(x2)
                if crest_b - crest_a <= 4.5:
                    x = x2
                    action("dynamic", "Uneven dynamics",
                           f"LRA {f0.get('lra')} LU outside window",
                           "3-band compressor",
                           f"ratio {cinfo['ratio']}:1 · GR "
                           f"{cinfo['gr_db']:.1f} dB", "medium",
                           "kept" if crest_b - crest_a <= 3.5
                           else "kept-reduced",
                           f"crest {crest_b:.1f} → {crest_a:.1f} dB "
                           "(transient protected)")
                    stage("COMPRESS", "done",
                          f"3-band comp · GR {cinfo['gr_db']:.1f} dB · "
                          f"crest {crest_b:.1f} → {crest_a:.1f} dB")
                else:
                    rollbacks += 1
                    action("dynamic", "Uneven dynamics", "—", "compressor",
                           "—", "medium", "rolled-back",
                           "transient guard tripped — dynamics untouched")
                    stage("COMPRESS", "skipped", "rolled back (transient)")
            else:
                action("dynamic", "Uneven dynamics", "—", "compressor", "—",
                       "medium", "no-problem", "LRA inside the profile "
                       "window")

            # ---- WARMTH (THD-budgeted, reduce-then-rollback) --------
            e = by_key["warmth"]
            thd = 0.0
            if e["act"] and not dry:
                w = float(e["amount"])
                x2, thd = _m_warmth(x, sr, w)
                reduced = False
                if thd > 0.025:                    # reduce first (1.txt §2)
                    x2, thd = _m_warmth(x, sr, w * 0.4)
                    reduced = True
                if thd <= 0.025:
                    x = x2
                    action("warmth", "Tone color",
                           "profile asks for preamp-style warmth",
                           "harmonic saturation", f"warmth {w:.0f}% · "
                           f"THD {thd * 100:.2f}%", "low",
                           "kept-reduced" if reduced else "kept",
                           "distortion budget respected")
                    stage("WARMTH", "done",
                          f"tube-style saturation {w:.0f}% · THD "
                          f"{thd * 100:.2f}% (budget 2.5%)"
                          + (" · reduced to fit budget" if reduced else ""))
                else:
                    rollbacks += 1
                    action("warmth", "Tone color", "—", "saturation", "—",
                           "low", "rolled-back",
                           f"THD {thd * 100:.2f}% over budget even reduced")
                    stage("WARMTH", "skipped", "rolled back (THD budget)")
            else:
                action("warmth", "Tone color", "—", "warmth", "—", "low",
                       "no-problem", "keep-natural / not in profile")

            # ---- MASTER -----------------------------------------------
            if dry:
                prog("Enhance: dry-run passthrough encode", 84)
                # Bypass Truth Test (§23): intensity 0 must provably
                # change NOTHING — the pristine decode is the output.
                sf.write(str(dst), x_src.astype(np.float64), sr,
                         subtype="PCM_24")
                x = x_src
                rounds, lufs_out = 0, None
                stage("MASTER", "skipped",
                      "dry-run — audio untouched (diagnose only)")
            else:
                prog("Enhance: master — loudness to profile target", 84)
                lufs_pre = None
                x, rounds, lufs_out = _m_master(x, sr, tgt, dst, workdir)
                action("level", "Loudness off target",
                       f"{ref.lufs if ref.lufs is not None else '?'} LUFS vs "
                       f"target {tgt}",
                       "loudness-master (iterative gain + TP limiter)",
                       f"→ {lufs_out:.1f} LUFS in {rounds} round(s)", "low",
                       "kept",
                       f"true-peak ceiling −2.0 dBTP · alimiter 0.80")
                stage("MASTER", "done",
                      f"{tgt if tgt is not None else 'preserve'} LUFS in "
                      f"{rounds} gain+limit round(s) · true-peak ceiling "
                      f"−1.5 dBTP")
            notes.append(f"master: target={tgt}, rounds={rounds}")

            # ================= QC + SCORES + REPORT ====================
            prog("Enhance: 10-gate QC + multi-dimensional scoring", 92)
            out_stats = analyze(dst)
            qa = qa_gate(ref, out_stats, label="enhance")
            f1 = _forensic(x, sr, out_stats, prof)
            crest_d = (f0.get("crest", 0.0) - f1.get("crest", 0.0))
            gates, g_overall = _gates(ref, out_stats, qa, f0, f1, prof,
                                      None if dry else tgt, ai_guard, sr,
                                      crest_d, dst)
            reprocess = 0
            if g_overall == "reprocess" and not dry:
                # 1.txt §22 — REPROCESS verdict: one supervised re-master
                reprocess = 1
                stage("QC GATE", "warn",
                      "REPROCESS — loudness/true-peak gate failed → one "
                      "conservative re-master (ceiling −3.1 dBTP)")
                x, rounds, lufs_out = _m_master(x, sr, tgt, dst, workdir,
                                                ceil=0.70)
                out_stats = analyze(dst)
                qa = qa_gate(ref, out_stats, label="enhance")
                f1 = _forensic(x, sr, out_stats, prof)
                crest_d = (f0.get("crest", 0.0) - f1.get("crest", 0.0))
                gates, g_overall = _gates(ref, out_stats, qa, f0, f1, prof,
                                          tgt, ai_guard, sr, crest_d, dst)
                notes.append("reprocess: one re-master round executed "
                             "(tighter true-peak ceiling)")
            scores = _scores(f0, f1, out_stats, qa, prof, tgt, thd, rollbacks)
            corrected = sum(1 for a in actions if a["result"].startswith("kept"))
            rolled = sum(1 for a in actions if a["result"] == "rolled-back")
            gates_pass = sum(1 for g_ in gates if g_["status"] == "pass")
            report = {"detected": len(problems), "corrected": corrected,
                      "rolled_back": rolled,
                      "ignored": max(0, len(problems) - corrected - rolled),
                      "mode": mode_key, "profile": prof_key,
                      "profile_desc": prof["desc"], "intensity": inten,
                      "dry_run": dry, "gates_pass": gates_pass,
                      "gates_total": len(gates), "reprocess": reprocess}
            stage("QC GATE", "done" if qa.ok and g_overall == "pass"
                  else ("warn" if qa.ok and g_overall in
                        ("warn", "reprocess") else qa.verdict),
                  f"{gates_pass}/{len(gates)} gates pass · overall "
                  f"{g_overall.upper()}"
                  + ("" if qa.ok else " · " + "; ".join(qa.issues)[:140]))
            notes.extend(qa.issues)
            if not qa.ok or g_overall == "fail":
                reason = "; ".join(qa.issues) if not qa.ok else \
                    "; ".join(f"{g_['gate']}: {g_['detail']}"
                              for g_ in gates if g_["status"] == "fail")
                dst.unlink(missing_ok=True)
                return {"ok": False, "verdict": "fail", "reason": reason,
                        "qa": qa.to_dict(),
                        "stages": stages, "actions": actions,
                        "problems": problems, "scores": scores,
                        "gates": gates, "report": report,
                        "stats_before": ref.to_dict(),
                        "notes": notes}
            prog("Enhance: done — report ready", 100)
            decision = {
                "engine": "enhance", "mode": mode_key, "profile": prof_key,
                "profile_desc": prof["desc"], "intensity": round(inten),
                "ai_assist": round(ai_pct), "ai_backend": "resemble-enhance"
                " (conditional)" if ai_pct > 0 else "DSP-only",
                "modules_activated": n_act,
                "gates": f"{gates_pass}/{len(gates)} pass · overall "
                         f"{g_overall}",
                "reprocess_rounds": reprocess,
                "deterministic": ai_pct <= 0,
                "detected": len(problems), "corrected": corrected,
                "rolled_back": rolled,
                "loudness_target": tgt if tgt is not None else "preserve",
                "loudness_rule": ("user target" if isinstance(
                    target_lufs, (int, float)) else
                    (f"profile {prof_key}" if prof.get("lufs") is not None
                     else "source-preserved, clamped [-35, -16]")),
                "true_peak_ceiling": -2.0,
                "output_format": f"{sr // 1000} kHz · 24-bit WAV · "
                                 f"{'mono voice' if prof['mono'] else 'stereo'}",
            }
            stage("REPORT", "done",
                  f"detected {report['detected']} · corrected "
                  f"{corrected} · ignored {report['ignored']} · rolled back "
                  f"{rolled} — scores: " +
                  " ".join(f"{k} {v}" for k, v in scores.items()))
            verdict = "pass" if (qa.verdict == "pass" and
                                 g_overall == "pass") else "warn"
            return {"ok": True, "verdict": verdict, "engine": "enhance",
                    "qa": qa.to_dict(), "stats": out_stats.to_dict(),
                    "stats_before": ref.to_dict(), "stages": stages,
                    "decision": decision, "problems": problems,
                    "actions": actions, "scores": scores, "report": report,
                    "gates": gates, "gates_overall": g_overall,
                    "output": str(dst), "notes": notes}
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    except EnhanceError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail", "reason": str(exc),
                "stages": stages, "actions": actions, "problems": problems,
                "notes": notes}
    except DSPError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[enhance] {exc}", "stages": stages,
                "actions": actions, "problems": problems, "notes": notes}
    except Exception as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[enhance] unexpected: {exc}", "stages": stages,
                "actions": actions, "problems": problems, "notes": notes}
