"""Engine module catalog — the single source of truth for per-activity
toggles exposed to the UI.

Every engine declares its activities ("modules"). A module is either
  - a LOCAL module  -> passed as modules{key:bool} to engines/local.py
  - a PARAM module  -> maps onto an existing engine kwarg; "off" sets the
                       kwarg to the module's off_value.

The frontend fetches this via GET /api/dsp/engine_catalog and renders a
checkbox (+ optional amount slider) per module, per stem, so the user can
tick every single activity of every engine on/off, preview live (A/B),
and finally remix.

Shape:
  CATALOG[engine] = {
    "name":   "Display name",
    "heavy":  bool  (True -> AI/dolby class, warns about cost in UI),
    "modules":[
      {"key": str, "label": str, "desc": str,
       "default": bool,                  # checkbox default
       "amount": {key,label,min,max,step,default,unit} | None
       "param": str | None,              # PARAM module: params key
       "off":   value                    # PARAM module: value when OFF
      }, ...
    ]
  }
"""

CATALOG: dict = {
    # ------------------------------------------------------------ local
    "clean": {
        "name": "Clean (full mix)",
        "heavy": False,
        "modules": [
            {"key": "dehum", "label": "Hum notch", "desc": "cut mains hum at 50/60/100 Hz",
             "default": True, "param": "dehum", "off": False},
            {"key": "hp", "label": "Rumble filter", "desc": "high-pass at 35 Hz",
             "default": True, "amount": None},
            {"key": "declick", "label": "Declick", "desc": "remove clicks & crackle",
             "default": True, "param": "declick", "off": False},
            {"key": "denoise", "label": "FFT denoise", "desc": "spectral noise cut (afftdn)",
             "default": True, "param": "denoise", "off": 0,
             "amount": {"key": "denoise", "label": "strength dB", "min": 0,
                        "max": 24, "step": 1, "default": 18, "unit": "dB"}},
        ],
    },
    "voice": {
        "name": "Voice Enhance",
        "heavy": False,
        "modules": [
            {"key": "band", "label": "Voice band", "desc": "HP 75 Hz + LP 14 kHz",
             "default": True, "amount": None},
            {"key": "denoise", "label": "FFT denoise", "desc": "spectral noise cut (afftdn)",
             "default": True, "param": "denoise", "off": 0,
             "amount": {"key": "denoise", "label": "strength dB", "min": 0,
                        "max": 30, "step": 1, "default": 14, "unit": "dB"}},
            {"key": "declick", "label": "Declick", "desc": "remove clicks & crackle",
             "default": True, "amount": None},
            {"key": "eq", "label": "Presence EQ", "desc": "mud cut + presence + air",
             "default": True, "amount": None},
            {"key": "comp", "label": "Level compression", "desc": "gentle 2.2:1 control",
             "default": True, "amount": None},
            {"key": "limiter", "label": "Safety limiter", "desc": "-0.5 dBFS ceiling",
             "default": True, "amount": None},
        ],
    },
    "music": {
        "name": "Music Enhance",
        "heavy": False,
        "modules": [
            {"key": "hp", "label": "Subsonic filter", "desc": "high-pass at 28 Hz",
             "default": True, "amount": None},
            {"key": "denoise", "label": "Mild denoise", "desc": "anlmdn musical denoise",
             "default": True, "amount": None},
            {"key": "eq", "label": "Tone EQ", "desc": "bass body + sheen",
             "default": True, "amount": None},
            {"key": "crystal", "label": "Harmonic lift", "desc": "crystalizer detail",
             "default": True, "param": "crystal", "off": 0,
             "amount": {"key": "crystal", "label": "amount", "min": 0,
                        "max": 4, "step": 0.1, "default": 2.0, "unit": ""}},
            {"key": "widen", "label": "Stereo widening", "desc": "extrastereo image",
             "default": True, "param": "widen", "off": 1.0,
             "amount": {"key": "widen", "label": "width", "min": 1.0,
                        "max": 1.6, "step": 0.05, "default": 1.25, "unit": "×"}},
            {"key": "comp", "label": "Glue compression", "desc": "1.8:1 mix glue",
             "default": True, "amount": None},
            {"key": "limiter", "label": "Safety limiter", "desc": "-0.5 dBFS ceiling",
             "default": True, "amount": None},
        ],
    },
    "fx": {
        "name": "FX Enhance",
        "heavy": False,
        "modules": [
            {"key": "hp", "label": "Subsonic filter", "desc": "high-pass at 22 Hz",
             "default": True, "amount": None},
            {"key": "decrackle", "label": "De-crackle", "desc": "light click removal",
             "default": True, "amount": None},
            {"key": "crystal", "label": "Transient restore", "desc": "crystalizer punch",
             "default": True, "param": "crystal", "off": 0,
             "amount": {"key": "crystal", "label": "amount", "min": 0,
                        "max": 3, "step": 0.1, "default": 1.5, "unit": ""}},
            {"key": "limiter", "label": "Safety limiter", "desc": "-0.4 dBFS ceiling",
             "default": True, "amount": None},
        ],
    },
    "spatial": {
        "name": "3D Spatial",
        "heavy": False,
        "modules": [
            {"key": "widen", "label": "Stereo widening", "desc": "extrastereo image",
             "default": True, "param": "width", "off": 1.0,
             "amount": {"key": "width", "label": "width", "min": 1.0,
                        "max": 1.8, "step": 0.05, "default": 1.4, "unit": "×"}},
            {"key": "haas", "label": "Haas depth", "desc": "0.4 ms inter-aural delay",
             "default": True, "amount": None},
            {"key": "ambience", "label": "Micro ambience", "desc": "30/45 ms diffuse tail",
             "default": True, "amount": None},
            {"key": "crystal", "label": "Air & detail", "desc": "crystalizer lift",
             "default": True, "param": "crystal", "off": 0,
             "amount": {"key": "crystal", "label": "amount", "min": 0,
                        "max": 3, "step": 0.1, "default": 1.2, "unit": ""}},
            {"key": "limiter", "label": "Safety limiter", "desc": "-0.5 dBFS ceiling",
             "default": True, "amount": None},
        ],
    },
    "master": {
        "name": "Master",
        "heavy": False,
        "modules": [
            {"key": "loudnorm", "label": "Loudness normalize", "desc": "broadcast LUFS target",
             "default": True, "param": "lufs", "off": None,
             "amount": {"key": "lufs", "label": "target", "min": -30,
                        "max": -9, "step": 1, "default": -16, "unit": "LUFS"}},
            {"key": "limiter", "label": "True-peak limit", "desc": "dBTP safety ceiling",
             "default": True, "param": "tp", "off": -0.5,
             "amount": {"key": "tp", "label": "ceiling", "min": -3,
                        "max": -0.5, "step": 0.5, "default": -1.5, "unit": "dBTP"}},
        ],
    },
    # ------------------------------------------------------------ heavy
    "studiomax": {
        "name": "Studio Max AI",
        "heavy": True,
        "modules": [
            {"key": "split", "label": "AI stem split", "desc": "Demucs local separation: vocals + music bed",
             "default": True, "param": "split", "off": False},
            {"key": "restore", "label": "AI music restore", "desc": "Apollo rebuilds damaged mids/highs (music bed)",
             "default": True, "param": "restore", "off": 0,
             "amount": {"key": "restore", "label": "blend", "min": 0,
                        "max": 100, "step": 5, "default": 75, "unit": "%"}},
            {"key": "voice", "label": "AI voice studio", "desc": "Resemble AI treatment on the vocals stem",
             "default": True, "param": "voice", "off": 0,
             "amount": {"key": "voice", "label": "amount", "min": 0,
                        "max": 100, "step": 5, "default": 70, "unit": "%"}},
            {"key": "polish", "label": "Analog polish", "desc": "sub HPF + tube warmth + air exciter (bed)",
             "default": True, "param": "polish", "off": False},
            {"key": "spatial", "label": "3D spatial", "desc": "Haas depth + M/S stereo image on the remix",
             "default": True, "param": "spatial", "off": False,
             "amount": {"key": "width", "label": "width", "min": 1.0,
                        "max": 1.8, "step": 0.05, "default": 1.35, "unit": "×"}},
            {"key": "master", "label": "Master", "desc": "loudness normalize + true-peak limit",
             "default": True, "param": "master", "off": False,
             "amount": {"key": "lufs", "label": "target", "min": -30,
                        "max": -9, "step": 1, "default": -16, "unit": "LUFS"}},
        ],
    },
    "studiomic": {
        "name": "Mic Studio AI",
        "heavy": True,
        "modules": [
            {"key": "ai", "label": "Resemble AI clean", "desc": "deep denoise + generative restore",
             "default": True, "param": "ai_clean", "off": 0,
             "amount": {"key": "ai_clean", "label": "amount", "min": 0,
                        "max": 100, "step": 5, "default": 70, "unit": "%"}},
            {"key": "mic", "label": "Analog mic model", "desc": "profile EQ + character",
             "default": True, "param": "mic_profile", "off": "natural",
             "amount": None},
            {"key": "declick", "label": "Declick", "desc": "click & crackle removal",
             "default": True, "param": "declick", "off": False},
            {"key": "dehum", "label": "Dehum", "desc": "mains hum notch",
             "default": True, "param": "dehum", "off": False},
        ],
    },
    "dolby_off": {
        "name": "Dolby OFFLINE",
        "heavy": True,
        "modules": [
            {"key": "denoise", "label": "Noise reduction", "desc": "stage 3 denoise gate",
             "default": True, "param": "noise_strength", "off": 0,
             "amount": {"key": "noise_strength", "label": "strength", "min": 0,
                        "max": 60, "step": 5, "default": 20, "unit": ""}},
            {"key": "spatial", "label": "Spatial stage", "desc": "stage 6 spatial",
             "default": True, "param": "spatial", "off": False},
            {"key": "declick", "label": "Declick", "desc": "repair stage declick",
             "default": True, "param": "declick", "off": False},
            {"key": "dehum", "label": "Dehum", "desc": "hum removal",
             "default": True, "param": "dehum", "off": False},
        ],
    },
    "enhance": {
        "name": "Enhance Agent",
        "heavy": True,
        "modules": [
            {"key": "ai", "label": "AI assist", "desc": "AI problem detection weight",
             "default": True, "param": "ai_assist", "off": 0,
             "amount": {"key": "ai_assist", "label": "weight", "min": 0,
                        "max": 100, "step": 5, "default": 55, "unit": "%"}},
            {"key": "budget", "label": "Fix budget", "desc": "how much the agent may change",
             "default": True, "param": "intensity", "off": 0,
             "amount": {"key": "intensity", "label": "budget", "min": 0,
                        "max": 100, "step": 5, "default": 70, "unit": "%"}},
            {"key": "declick", "label": "Declick fixes", "desc": "auto / on / off",
             "default": True, "param": "declick", "off": "off"},
            {"key": "dehum", "label": "Dehum fixes", "desc": "auto / on / off",
             "default": True, "param": "dehum", "off": "off"},
        ],
    },
}

# param keys each engine accepts for _sanitize (amount + param modules)
def param_keys(engine: str) -> set:
    out = set()
    for m in CATALOG.get(engine, {}).get("modules", []):
        if m.get("amount"):
            out.add(m["amount"]["key"])
        if m.get("param"):
            out.add(m["param"])
    return out


def defaults(engine: str) -> dict:
    """Checkbox defaults + amount defaults for an engine (UI seed)."""
    mods, amounts = {}, {}
    for m in CATALOG.get(engine, {}).get("modules", []):
        mods[m["key"]] = bool(m.get("default", True))
        a = m.get("amount")
        if a:
            amounts[a["key"]] = a["default"]
    return {"modules": mods, **amounts}


def catalog_json() -> dict:
    return {"ok": True, "engines": CATALOG}
