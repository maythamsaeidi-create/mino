"""Local FFmpeg DSP engines — fully offline, no API keys required.

Engines:
  clean          : full-mix cleanup (denoise + declick + optional dehum)
  voice_enhance  : speech chain for separated voice stems
  music_enhance  : music chain for separated music stems
  fx_enhance     : effects chain (transient-preserving)
  spatialize     : 3D spatial widening for a single file
  master         : final loudness normalization + safety limiter

Every step is verified with ffprobe after writing (no silent failures).
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Callable

from .analysis import analyze, probe, qa_gate

FFMPEG = "ffmpeg"
ProgressFn = Callable[[str, int], None]


class DSPError(Exception):
    pass


def _ff(args: list[str], timeout: int = 1800) -> None:
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y"] + args
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise DSPError(f"ffmpeg failed: {p.stderr.strip()[-500:]}")


def _verify(out: Path) -> dict:
    p = probe(out)
    if not p.get("ok") or not p.get("duration"):
        out.unlink(missing_ok=True)
        raise DSPError(f"ffmpeg produced invalid output: {p.get('error', 'empty')}")
    return p


def _std_io(src: Path, dst: Path) -> list[str]:
    return ["-i", str(src), str(dst)]


# ------------------------------------------------------------------ clean

def _mods(modules: dict | None, keys: list[str]) -> dict:
    """Normalize a module-toggle dict: unknown keys dropped, missing = ON.
    modules=None -> everything ON (legacy callers: identical behavior)."""
    out = {k: True for k in keys}
    if isinstance(modules, dict):
        for k in keys:
            v = modules.get(k)
            if v is not None:
                out[k] = bool(v)
    return out


def _modnote(m: dict) -> str:
    off = [k for k, v in m.items() if not v]
    return "modules off: " + (",".join(off) if off else "none")


def clean(src: str | Path, dst: str | Path, denoise: int = 18,
          declick: bool = True, dehum: bool = True,
          modules: dict | None = None,
          on_progress: ProgressFn | None = None) -> dict:
    """Full-mix cleanup — deliberately conservative (the anti-'killer' chain).

    denoise strength maps to afftdn nr, capped at 24 dB so music and
    ambience survive. Strong FFT denoising on mixed content is exactly
    what makes output sound dead/blinded, so we stay mild here and do the
    aggressive cleaning per-stem in the offline section instead.
    modules: {dehum, hp, declick, denoise} — each tickable on/off.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: full-mix cleanup", 10)
    m = _mods(modules, ["dehum", "hp", "declick", "denoise"])
    nr = max(0, min(24, int(denoise))) if m["denoise"] else 0
    chain: list[str] = []
    if m["dehum"] and dehum:
        # notch mains hum fundamentals before anything else
        chain += [
            "equalizer=f=50:width_type=h:width=1.2:g=-10",
            "equalizer=f=60:width_type=h:width=1.2:g=-10",
            "equalizer=f=100:width_type=h:width=1.2:g=-8",
        ]
    if m["hp"]:
        chain += ["highpass=f=35"]
    if m["declick"] and declick:
        chain += ["adeclick=window=55:overlap=75:arorder=4"]
    if nr > 0:
        chain += [f"afftdn=nr={nr}:nf=-45:tn=1"]
    _ff(["-i", str(src), "-af", ",".join(chain),
         "-ar", "48000", str(dst)])
    info = _verify(dst)
    if on_progress:
        on_progress("DSP: cleanup done", 90)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "notes": [f"afftdn nr={nr}dB, declick={m['declick'] and declick}, "
                      f"dehum={m['dehum'] and dehum}", _modnote(m)]}


# ------------------------------------------------------------- voice stem

def voice_enhance(src: str | Path, dst: str | Path, denoise: int = 14,
                  modules: dict | None = None,
                  on_progress: ProgressFn | None = None) -> dict:
    """Speech chain: clean presence, controlled sibilance, gentle compression.

    Voice stems are already isolated, so we can denoise harder than on a
    full mix (default 14 dB, cap 30) without touching music.
    modules: {band, denoise, declick, eq, comp, limiter}.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: voice stem", 10)
    m = _mods(modules, ["band", "denoise", "declick", "eq", "comp", "limiter"])
    nr = max(0, min(30, int(denoise))) if m["denoise"] else 0
    chain: list[str] = []
    if m["band"]:
        chain += ["highpass=f=75", "lowpass=f=14000"]
    if nr > 0:
        chain += [f"afftdn=nr={nr}:nf=-50:tn=1"]
    if m["declick"]:
        chain += ["adeclick=window=55:overlap=75:arorder=4"]
    if m["eq"]:
        # presence & clarity
        chain += [
            "equalizer=f=240:width_type=o:width=0.8:g=-1.5",   # mud cut
            "equalizer=f=2800:width_type=o:width=1.2:g=2.5",    # presence
            "equalizer=f=6800:width_type=o:width=0.8:g=-2",     # harshness
            "equalizer=f=10500:width_type=o:width=1.0:g=1.5",   # air
        ]
    if m["comp"]:
        # gentle level control
        chain += ["acompressor=threshold=-21dB:ratio=2.2:attack=12:release=180:makeup=2"]
    if m["limiter"]:
        chain += ["alimiter=limit=0.95:level=false"]
    _ff(["-i", str(src), "-af", ",".join(chain), "-ar", "48000", str(dst)])
    info = _verify(dst)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "notes": [f"voice chain: afftdn nr={nr}, EQ, comp 2.2:1", _modnote(m)]}


# ------------------------------------------------------------- music stem

def music_enhance(src: str | Path, dst: str | Path, widen: float = 1.25,
                  crystal: float = 2.0,
                  modules: dict | None = None,
                  on_progress: ProgressFn | None = None) -> dict:
    """Music chain: protect the mix, widen the image, mild harmonic lift.
    modules: {hp, denoise, eq, crystal, widen, comp, limiter}.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: music stem", 10)
    m = _mods(modules, ["hp", "denoise", "eq", "crystal",
                        "widen", "comp", "limiter"])
    widen = max(1.0, min(1.6, float(widen)))
    crystal = max(0.0, min(4.0, float(crystal)))
    chain: list[str] = []
    if m["hp"]:
        chain += ["highpass=f=28"]
    if m["denoise"]:
        chain += ["anlmdn=s=0.00003"]   # very mild musical denoise
    if m["eq"]:
        chain += [
            "equalizer=f=55:width_type=q:width=0.9:g=1.5",     # bass body
            "equalizer=f=12000:width_type=q:width=0.8:g=1.0",  # sheen
        ]
    if m["crystal"] and crystal > 0:
        chain += [f"crystalizer={crystal:.2f}"]  # transient/harmonic lift
    if m["widen"]:
        chain += [f"extrastereo=m={widen}:c=true"]   # stereo widening
    if m["comp"]:
        chain += ["acompressor=threshold=-19dB:ratio=1.8:attack=25:release=320:makeup=1.5"]
    if m["limiter"]:
        chain += ["alimiter=limit=0.97:level=false"]
    _ff(["-i", str(src), "-af", ",".join(chain), "-ar", "48000", str(dst)])
    info = _verify(dst)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "notes": [f"music chain: widen x{widen}, crystalizer {crystal}, "
                      f"glue comp", _modnote(m)]}


# ---------------------------------------------------------------- fx stem

def fx_enhance(src: str | Path, dst: str | Path, crystal: float = 1.5,
               modules: dict | None = None,
               on_progress: ProgressFn | None = None) -> dict:
    """Effects chain: keep dynamics & transients intact, just clean edges.
    modules: {hp, decrackle, crystal, limiter}.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: fx stem", 10)
    m = _mods(modules, ["hp", "decrackle", "crystal", "limiter"])
    crystal = max(0.0, min(3.0, float(crystal)))
    chain: list[str] = []
    if m["hp"]:
        chain += ["highpass=f=22"]
    if m["decrackle"]:
        chain += ["adeclick=window=35:overlap=75:arorder=2"]  # de-crackle only
    if m["crystal"] and crystal > 0:
        chain += [f"crystalizer={crystal:.2f}"]
    if m["limiter"]:
        chain += ["alimiter=limit=0.98:level=false"]
    _ff(["-i", str(src), "-af", ",".join(chain), "-ar", "48000", str(dst)])
    info = _verify(dst)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "notes": ["fx chain: transient-safe, declick, crystalizer", _modnote(m)]}


# ---------------------------------------------------------------- spatial

def spatialize(src: str | Path, dst: str | Path, width: float = 1.4,
               crystal: float = 1.2,
               modules: dict | None = None,
               on_progress: ProgressFn | None = None) -> dict:
    """3D spatial widening for a single stereo file (Haas + width + air).

    Headphone-friendly: short inter-aural delay + widened image + a touch
    of ambience gives an out-of-head, enveloping presentation.
    modules: {widen, haas, ambience, crystal, limiter}.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: 3D spatializer", 10)
    m = _mods(modules, ["widen", "haas", "ambience", "crystal", "limiter"])
    width = max(1.0, min(1.8, float(width)))
    crystal = max(0.0, min(3.0, float(crystal)))
    chain: list[str] = [
        "stereotools=slev=1.0:sbal=0:mlev=1.0",
    ]
    if m["widen"]:
        chain += [f"extrastereo=m={width}:c=true"]
    if m["haas"]:
        # Haas-style micro delay (~0.4 ms) for depth cues
        chain += ["adelay=0.4:0:all=1"]
    if m["ambience"]:
        # tiny diffuse ambience tail (30/45 ms, very low)
        chain += ["aecho=0.7:0.75:30|45:0.08|0.06"]
    if m["crystal"] and crystal > 0:
        chain += [f"crystalizer={crystal:.2f}"]
    if m["limiter"]:
        chain += ["alimiter=limit=0.97:level=false"]
    _ff(["-i", str(src), "-af", ",".join(chain), "-ar", "48000", str(dst)])
    info = _verify(dst)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "notes": [f"spatial: width x{width}, haas 0.4ms, micro-ambience", _modnote(m)]}


# ----------------------------------------------------------------- master

def master(src: str | Path, dst: str | Path, lufs: float = -16.0,
           tp: float = -1.5, mp3: bool = False,
           modules: dict | None = None,
           on_progress: ProgressFn | None = None) -> dict:
    """Final master: loudnorm to broadcast target + true-peak safety.
    modules: {loudnorm, limiter} — tick each master activity on/off.
    """
    src, dst = Path(src), Path(dst)
    if on_progress:
        on_progress("DSP: mastering", 20)
    m = _mods(modules, ["loudnorm", "limiter"])
    lufs = max(-30.0, min(-9.0, float(lufs)))
    tp = max(-3.0, min(-0.5, float(tp)))
    chain: list[str] = []
    if m["loudnorm"]:
        chain += [f"loudnorm=I={lufs}:TP={tp if m['limiter'] else -0.5}:LRA=11"]
    if m["limiter"]:
        chain += [f"alimiter=limit={min(0.98, 10 ** (tp / 20)):.4f}:level=false"]
    args = ["-i", str(src)]
    if chain:
        args += ["-af", ",".join(chain)]
    args += ["-ar", "48000"]
    if mp3:
        _ff(args + ["-c:a", "libmp3lame", "-b:a", "320k", str(dst)])
    else:
        _ff(args + ["-c:a", "pcm_s24le", str(dst)])
    info = _verify(dst)
    out = analyze(dst)
    if on_progress:
        on_progress("DSP: master done", 90)
    return {"ok": True, "output": str(dst), "duration": info["duration"],
            "lufs": out.lufs, "true_peak": out.true_peak,
            "notes": [f"mastered to {lufs if m['loudnorm'] else 'source'} LUFS / "
                      f"{tp if m['limiter'] else 'unlimited'} dBTP", _modnote(m)]}


# ------------------------------------------------------------- local full

def local_clean_fallback(src: str | Path, dst: str | Path,
                         denoise: int = 18,
                         on_progress: ProgressFn | None = None) -> dict:
    """Local fallback for the online section: clean + QA gate.

    Runs when Dolby is unavailable/rejected, or when the user picks the
    local engine directly. Returns the same shape as dolby.run() so the
    pipeline can treat both engines identically.
    """
    src, dst = Path(src), Path(dst)
    notes = ["using LOCAL engine (offline, no API keys)"]
    ref = analyze(src)
    if on_progress:
        on_progress("LOCAL: analyzing input", 5)
    res = clean(src, dst, denoise=denoise, on_progress=on_progress)
    notes.extend(res.get("notes", []))
    out_stats = analyze(dst)
    qa = qa_gate(ref, out_stats, label="local")
    notes.extend(qa.issues)
    if not qa.ok:
        dst.unlink(missing_ok=True)
        return {"ok": False, "verdict": qa.verdict,
                "reason": "; ".join(qa.issues), "qa": qa.to_dict(),
                "notes": notes}
    return {"ok": True, "verdict": qa.verdict, "qa": qa.to_dict(),
            "stats": out_stats.to_dict(), "output": str(dst),
            "notes": notes}
