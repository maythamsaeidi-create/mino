"""Analysis & QA layer — runs around EVERY engine, no exceptions.

Pre-analysis  : ffprobe container facts + ebur128 loudness + astats signal health
Post-QA gate  : duration match, aliveness, level sanity, clipping, DC offset
                -> verdict PASS / WARN / FAIL drives automatic fallback.
"""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

FFPROBE = "ffprobe"
FFMPEG = "ffmpeg"


def _run(cmd: list[str], timeout: int = 300) -> str:
    p = subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout
    )
    return p.stdout + p.stderr


# ---------------------------------------------------------------- container

def probe(path: str | Path) -> dict:
    """Container/stream facts via ffprobe."""
    out = _run([
        FFPROBE, "-v", "quiet", "-print_format", "json",
        "-show_format", "-show_streams", str(path),
    ])
    try:
        data = json.loads(out)
    except Exception:
        return {"ok": False, "error": "ffprobe returned non-JSON", "raw": out[:400]}
    streams = [s for s in data.get("streams", []) if s.get("codec_type") == "audio"]
    if not streams:
        return {"ok": False, "error": "no audio stream found"}
    s = streams[0]
    fmt = data.get("format", {})
    dur = 0.0
    for key in ("duration",):
        try:
            dur = float(s.get(key) or fmt.get(key) or 0.0)
        except (TypeError, ValueError):
            dur = 0.0
    if not dur:
        try:
            dur = float(fmt.get("duration", 0.0))
        except (TypeError, ValueError):
            dur = 0.0
    return {
        "ok": True,
        "duration": round(dur, 3),
        "sample_rate": int(s.get("sample_rate", 0) or 0),
        "channels": int(s.get("channels", 0) or 0),
        "codec": s.get("codec_name", ""),
        "bitrate": int(fmt.get("bit_rate", 0) or 0),
        "size": int(fmt.get("size", 0) or 0),
    }


# ---------------------------------------------------------------- loudness

_LUFS_RE = re.compile(r"I:\s*(-?\d+\.?\d*)\s*LUFS")
_TP_RE = re.compile(r"Peak:\s*(-?\d+\.?\d*)\s*dBFS")
_LRA_RE = re.compile(r"LRA:\s*(-?\d+\.?\d*)")


def _ebur128(path: str | Path) -> dict:
    out = _run([
        FFMPEG, "-hide_banner", "-nostats", "-i", str(path),
        "-af", "ebur128=peak=true", "-f", "null", "-",
    ], timeout=600)
    tail = out[-4000:]
    # ebur128 prints a LIVE table every 100 ms (each line has its own
    # running "I: … LUFS") and only the FINAL summary is authoritative.
    # For SHORT files the early ungated live lines (I: -70.0) land inside
    # the tail and re.search() picked THOSE — a -8.6 LUFS file measured
    # as -70 "inaudible" and the QA gate rejected perfectly loud audio.
    # findall() + LAST match = always the summary values.
    lufs = _LUFS_RE.findall(tail)
    tp = _TP_RE.findall(tail)
    lra = _LRA_RE.findall(tail)
    return {
        "lufs": float(lufs[-1]) if lufs else None,
        "true_peak": float(tp[-1]) if tp else None,
        "lra": float(lra[-1]) if lra else None,
    }


# ---------------------------------------------------------------- astats

_RMS_RE = re.compile(r"RMS level dB:\s*(-?\d+\.?\d*|inf|-inf)")
_DC_RE = re.compile(r"DC offset:\s*(-?\d+\.?\d*e?-?\d*)")
_CLIP_RE = re.compile(r"Number of Clipped samples:\s*(\d+)")
_MINRMS_RE = re.compile(r"Minimum level dB:\s*(-?\d+\.?\d*|inf|-inf)")
_MAXRMS_RE = re.compile(r"Maximum level dB:\s*(-?\d+\.?\d*|inf|-inf)")


def _astats(path: str | Path) -> dict:
    out = _run([
        FFMPEG, "-hide_banner", "-nostats", "-i", str(path),
        "-af", "astats=metadata=1:reset=0", "-f", "null", "-",
    ], timeout=600)
    tail = out[-6000:]
    # last "Overall" block values
    rms = _RMS_RE.findall(tail)
    dc = _DC_RE.findall(tail)
    clip = _CLIP_RE.findall(tail)
    minlvl = _MINRMS_RE.findall(tail)
    maxlvl = _MAXRMS_RE.findall(tail)

    def _f(v, default=None):
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    return {
        "rms_db": _f(rms[-1]) if rms else None,
        "dc_offset": _f(dc[-1]) if dc else None,
        "clipped_samples": int(clip[-1]) if clip else None,
        "min_level_db": _f(minlvl[-1]) if minlvl else None,
        "max_level_db": _f(maxlvl[-1]) if maxlvl else None,
    }


# ---------------------------------------------------------------- combined

@dataclass
class AudioStats:
    duration: float = 0.0
    sample_rate: int = 0
    channels: int = 0
    codec: str = ""
    size: int = 0
    lufs: float | None = None
    true_peak: float | None = None
    lra: float | None = None
    rms_db: float | None = None
    dc_offset: float | None = None
    clipped_samples: int = 0
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "duration": self.duration, "sample_rate": self.sample_rate,
            "channels": self.channels, "codec": self.codec, "size": self.size,
            "lufs": self.lufs, "true_peak": self.true_peak, "lra": self.lra,
            "rms_db": self.rms_db, "dc_offset": self.dc_offset,
            "clipped_samples": self.clipped_samples,
        }


def analyze(path: str | Path) -> AudioStats:
    """Full pre-analysis of one audio file (container + loudness + signal)."""
    p = probe(path)
    st = AudioStats(
        duration=p.get("duration", 0.0),
        sample_rate=p.get("sample_rate", 0),
        channels=p.get("channels", 0),
        codec=p.get("codec", ""),
        size=p.get("size", 0),
    )
    if not p.get("ok"):
        st.extra["probe_error"] = p.get("error", "")
        return st
    try:
        e = _ebur128(path)
        st.lufs, st.true_peak, st.lra = e["lufs"], e["true_peak"], e["lra"]
    except Exception as exc:  # analysis must never crash the pipeline
        st.extra["ebur128_error"] = str(exc)
    try:
        a = _astats(path)
        st.rms_db = a["rms_db"]
        st.dc_offset = a["dc_offset"]
        st.clipped_samples = a["clipped_samples"] or 0
        st.min_level_db = a.get("min_level_db")
        st.max_level_db = a.get("max_level_db")
    except Exception as exc:
        st.extra["astats_error"] = str(exc)
    return st


# ---------------------------------------------------------------- QA gate

@dataclass
class QAResult:
    verdict: str = "pass"          # pass | warn | fail
    issues: list = field(default_factory=list)
    metrics: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.verdict != "fail"

    def to_dict(self) -> dict:
        return {"verdict": self.verdict, "issues": self.issues, "metrics": self.metrics}


def qa_gate(ref: AudioStats, out: AudioStats, label: str = "engine") -> QAResult:
    """Post-QA validation — decides whether an engine's output is shippable.

    The gates that historically let Dolby destroy audio:
      1. duration mismatch (truncated / padded output)     -> FAIL
      2. output silent or near-silent ("blinded" audio)   -> FAIL
      3. output collapsed to DC                           -> FAIL
      4. extreme level change (> 12 LU vs reference)      -> WARN/FAIL
      5. severe clipping (clipped samples > 0.5% duration) -> WARN
    """
    issues: list[str] = []
    verdict = "pass"
    metrics: dict = {
        "ref_duration": ref.duration, "out_duration": out.duration,
        "ref_lufs": ref.lufs, "out_lufs": out.lufs,
        "out_rms_db": out.rms_db, "out_true_peak": out.true_peak,
        "label": label,
    }

    # 1) duration gate (tolerance: 0.6 s or 0.75 %, whichever is larger)
    tol = max(0.6, ref.duration * 0.0075)
    ddur = abs(out.duration - ref.duration)
    metrics["duration_delta"] = round(ddur, 3)
    if out.duration <= 0:
        issues.append(f"[{label}] output has zero/negative duration")
        verdict = "fail"
    elif ddur > tol:
        issues.append(
            f"[{label}] duration mismatch: output {out.duration:.2f}s vs input "
            f"{ref.duration:.2f}s (Δ {ddur:.2f}s) — truncated or padded, rejected"
        )
        verdict = "fail"

    # 2) aliveness — "killed/blinded" audio detection
    if out.rms_db is not None and out.rms_db < -55.0:
        issues.append(
            f"[{label}] output RMS {out.rms_db:.1f} dB — near-silent, "
            f"engine destroyed the audio, rejected"
        )
        verdict = "fail"
    if out.lufs is not None and out.lufs < -50.0 and verdict != "fail":
        issues.append(f"[{label}] output loudness {out.lufs:.1f} LUFS — inaudible")
        verdict = "fail"

    # 3) DC collapse
    if out.dc_offset is not None and abs(out.dc_offset) > 0.05:
        issues.append(f"[{label}] DC offset {out.dc_offset:.3f} — collapsed signal")
        verdict = "fail"

    # 4) extreme level shift
    if ref.lufs is not None and out.lufs is not None:
        dlu = out.lufs - ref.lufs
        metrics["lufs_delta"] = round(dlu, 2)
        if abs(dlu) > 18 and verdict == "pass":
            issues.append(
                f"[{label}] loudness jumped {dlu:+.1f} LU vs input — "
                f"unnatural level change"
            )
            verdict = "warn"

    # 5) clipping
    if out.clipped_samples and out.duration > 0 and out.sample_rate:
        pct = out.clipped_samples / max(1.0, out.duration * out.sample_rate) * 100.0
        metrics["clipped_pct"] = round(pct, 4)
        if pct > 0.5 and verdict == "pass":
            issues.append(f"[{label}] {pct:.2f}% clipped samples — limiter stress")
            verdict = "warn"

    if verdict == "pass":
        issues.append(f"[{label}] QA passed — duration, level and aliveness OK")
    return QAResult(verdict=verdict, issues=issues, metrics=metrics)
