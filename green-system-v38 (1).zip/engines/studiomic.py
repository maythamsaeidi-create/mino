"""STUDIO MIC — world-class voice enhancement engine (v32 flagship).

Goal: make ANY voice recording sound like it was captured on an
expensive studio microphone very close to the speaker — intimate,
dense, present, with the 'expensive preamp' polish.

Research-backed pipeline (GitHub / 2025 SOTA, all local, no API keys):

  Stage 1  ANALYZE    : ebur128 + astats pre-scan (LUFS / TP / channels)
  Stage 2  REPAIR     : declick + mains-hum notches + rumble HPF (FFmpeg)
  Stage 3  AI STUDIO  : Resemble-Enhance (github.com/resemble-ai/
                        resemble-enhance, MIT) — deep denoise + generative
                        restoration through a CFM solver + UnivNet vocoder
                        @ 44.1 kHz. This is the stage that actually REBUILDS
                        the speech spectrum into 'studio' quality.
                        Graceful fallback if the model is unavailable:
                        noisereduce (spectral gating) -> FFmpeg afftdn —
                        the engine ALWAYS runs, only the AI part degrades.
  Stage 4  MIC MODEL  : the 'expensive microphone' analog chain, hand-built
                        in numpy/scipy at 48 kHz — the broadcast chain used
                        on SM7B / U87 voice tracks:
                        HPF 75 Hz -> proximity shelf (cardioid close-talk)
                        -> mud dip -> presence bell -> air shelf ->
                        dynamic de-esser -> 3-band compressor ->
                        tanh saturation with oversampling (preamp warmth)
  Stage 5  MASTER     : loudnorm (source-preserved target) + true-peak
                        safety limiter, 48 kHz / 24-bit
  Stage 6  QA GATE    : the shared analysis/QA layer — same rules as every
                        other engine (duration / aliveness / DC / level)

Mic profiles (the character of the chain):
  studio    : large-diaphragm condenser (U87-like) — silky, airy, detailed
  broadcast : dynamic broadcast mic (SM7B-like) — thick, punchy, controlled
  podcast   : warm intimate close-up — the podcast 'golden voice' sound
  vintage   : tube / ribbon character — rounded, even-harmonic warmth
  natural   : barely-there polish — minimal color

Result contract identical to dolby_off.run(): {ok, verdict, engine, qa,
stats, stats_before, stages, decision, output, notes} so the existing
UI cards render it unchanged.
"""

from __future__ import annotations

import math
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable

import numpy as np

from .analysis import analyze, probe, qa_gate
from .local import DSPError, _ff

_STAGE_PCT = {1: 4, 2: 12, 3: 62, 4: 78, 5: 90, 6: 96}

def _run_dir() -> Path:
    """Model location lookup (self-contained app).

    Search order:
      1. <app>/models/resemble-enhance      — app-local (fresh installs)
      2. <parent-of-app>/models/resemble-enhance — legacy workspace layout
    The first candidate that actually contains the weights wins; if none
    does, the app-local path is returned so a fresh extraction has one
    canonical place to drop the model into.
    """
    here = Path(__file__).resolve()
    app_root = here.parents[1]          # green-system/
    candidates = [app_root / "models" / "resemble-enhance",
                  app_root.parent / "models" / "resemble-enhance"]
    for c in candidates:
        if (c / "ds" / "G" / "default" / "mp_rank_00_model_states.pt").exists():
            return c
    return candidates[0]


RUN_DIR = _run_dir()

# profile      prox  pres  air  warm  comp
_MICS = {
    "studio":     (4.0,  4.0, 5.0,  35,  45),
    "broadcast":  (6.0,  5.0, 2.5,  45,  60),
    "podcast":    (7.0,  3.5,  3.0,  55,  55),
    "vintage":    (5.0,  2.0,  1.5,  70,  40),
    "natural":    (2.0,  2.0,  2.0,  15,  25),
}

# one AI inference at a time (2-core box, ~2 GB model in RAM)
_AI_LOCK = threading.Lock()
_ENHANCER = {"loaded": False, "err": None}


class StudioMicError(DSPError):
    """Raised with a human-readable, stage-tagged reason."""


# ---------------------------------------------------------------- health

def _model_files() -> Path | None:
    p = RUN_DIR / "ds" / "G" / "default" / "mp_rank_00_model_states.pt"
    try:
        if p.exists() and p.stat().st_size > 1_000_000:
            return p
    except OSError:
        pass
    return None


def ai_status() -> dict:
    """Engine availability probe — used by /api/dsp/health and the UI."""
    st = {"resemble": bool(_model_files()), "noisereduce": False}
    try:
        import noisereduce  # noqa: F401
        st["noisereduce"] = True
    except Exception:
        pass
    if _ENHANCER["loaded"]:
        st["resemble"] = True
        st["resemble_err"] = None
    elif _ENHANCER["err"]:
        st["resemble"] = False
        st["resemble_err"] = _ENHANCER["err"]
    st["ok"] = bool(st["resemble"] or st["noisereduce"])
    return st


def _verify(out: Path, stage: int, what: str) -> dict:
    p = probe(out)
    if not p.get("ok") or not p.get("duration"):
        out.unlink(missing_ok=True)
        raise StudioMicError(
            f"[studiomic stage {stage} ({what})] ffmpeg produced invalid "
            f"output: {p.get('error', 'empty file')}")
    return p


# ---------------------------------------------------------------- dsp atoms

def _biquad(kind: str, sr: float, f0: float, gain_db: float, q: float):
    """RBJ audio-EQ-cookbook biquad coefficients (float64)."""
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * np.pi * f0 / sr
    cw, sw = np.cos(w0), np.sin(w0)
    al = sw / (2.0 * q)
    if kind == "lowshelf":
        b = [A * ((A + 1) - (A - 1) * cw + 2 * np.sqrt(A) * al),
             2 * A * ((A - 1) - (A + 1) * cw),
             A * ((A + 1) - (A - 1) * cw - 2 * np.sqrt(A) * al)]
        a = [(A + 1) + (A - 1) * cw + 2 * np.sqrt(A) * al,
             2 * ((A - 1) + (A + 1) * cw),
             (A + 1) + (A - 1) * cw - 2 * np.sqrt(A) * al]
    elif kind == "highshelf":
        b = [A * ((A + 1) + (A - 1) * cw + 2 * np.sqrt(A) * al),
             -2 * A * ((A - 1) + (A + 1) * cw),
             A * ((A + 1) + (A - 1) * cw - 2 * np.sqrt(A) * al)]
        a = [(A + 1) - (A - 1) * cw + 2 * np.sqrt(A) * al,
             -2 * ((A - 1) - (A + 1) * cw),
             (A + 1) - (A - 1) * cw - 2 * np.sqrt(A) * al]
    else:  # peaking
        b = [1 + al * A, -2 * cw, 1 - al * A]
        a = [1 + al / A, -2 * cw, 1 - al / A]
    return np.array(b), np.array(a)


def _apply(x: np.ndarray, b: np.ndarray, a: np.ndarray) -> np.ndarray:
    from scipy.signal import lfilter
    return lfilter(b, a, x)


def _butter(x: np.ndarray, sr: float, f: float, kind: str, order: int = 2) -> np.ndarray:
    from scipy.signal import butter, sosfiltfilt
    sos = butter(order, f, btype=kind, fs=sr, output="sos")
    return sosfiltfilt(sos, x)


def _bandpass(x: np.ndarray, sr: float, lo: float, hi: float) -> np.ndarray:
    from scipy.signal import butter, sosfiltfilt
    sos = butter(2, [lo, hi], btype="bandpass", fs=sr, output="sos")
    return sosfiltfilt(sos, x)


# ----------------------------------------------------- block envelope tools

def _blocks(x: np.ndarray, n: int) -> np.ndarray:
    nb = int(math.ceil(len(x) / n))
    pad = np.pad(x, (0, nb * n - len(x)))
    return pad.reshape(nb, n)


def _rms_blocks(x: np.ndarray, n: int) -> np.ndarray:
    return np.sqrt(np.mean(_blocks(x, n) ** 2, axis=1))


def _asym_smooth(y: np.ndarray, rate: float, atk_s: float, rel_s: float) -> np.ndarray:
    """Exact one-pole attack/release smoother on a block-rate series."""
    atk = math.exp(-1.0 / (atk_s * rate))
    rel = math.exp(-1.0 / (rel_s * rate))
    out = np.empty_like(y)
    cur = 0.0
    for i, v in enumerate(y):
        r = atk if v > cur else rel
        cur = r * cur + (1 - r) * v
        out[i] = cur
    return out


def _expand(env_blocks: np.ndarray, n: int, total: int) -> np.ndarray:
    """Interpolate a block-rate envelope back to sample rate."""
    pos = np.arange(total, dtype=np.float64) / n
    return np.interp(pos, np.arange(len(env_blocks)), env_blocks)


def _db(x: np.ndarray) -> np.ndarray:
    return 20.0 * np.log10(np.maximum(x, 1e-10))


def _undb(x: np.ndarray) -> np.ndarray:
    return 10.0 ** (x / 20.0)


# ------------------------------------------------------------- de-esser

def _de_ess(x: np.ndarray, sr: float, amount: float) -> tuple[np.ndarray, float]:
    """Dynamic sibilance control on 5.5–9 kHz, adaptive threshold.

    amount 0..1 maps to ratio 1.5:1..4:1 and max 2..7 dB reduction.
    Threshold adapts to the band's own 92nd percentile so it only
    catches true sibilant peaks on any source level.
    """
    if amount <= 0:
        return x, 0.0
    n = max(1, int(sr * 0.003))                     # 3 ms blocks
    band = _bandpass(x, sr, 5500.0, 9000.0)
    env = _rms_blocks(band, n)
    thr = np.percentile(env, 92)
    if thr <= 1e-6:
        return x, 0.0
    ratio = 1.5 + 2.5 * amount
    red_max = 2.0 + 5.0 * amount                    # dB
    over = _db(env) - _db(np.full_like(env, thr))
    gr_db = np.where(over > 0, -np.minimum(over * (1 - 1 / ratio), red_max), 0.0)
    gr = _expand(_asym_smooth(_undb(gr_db), 1 / 0.003, 0.001, 0.030), n, len(x))
    applied = float(-gr.min()) if len(gr) else 0.0
    return x - band * (1.0 - np.minimum(1.0, gr)), applied


# ------------------------------------------------------- 3-band compressor

def _compress3(x: np.ndarray, sr: float, amount: float) -> tuple[np.ndarray, dict]:
    """Gentle broadcast leveling across 3 bands (LR-style crossovers)."""
    if amount <= 0:
        return x, {"ratio": 1.0, "gr_db": 0.0}
    low = _butter(x, sr, 250.0, "lowpass")
    high = _butter(x, sr, 4000.0, "highpass")
    mid = x - low - high
    ratio = 1.5 + 1.3 * amount                       # 1.5:1 .. 2.8:1
    n = max(1, int(sr * 0.003))
    out = np.zeros_like(x)
    worst = 0.0
    for name, band, atk, rel in (("low", low, 0.020, 0.250),
                                 ("mid", mid, 0.010, 0.120),
                                 ("high", high, 0.006, 0.080)):
        env = _rms_blocks(band, n)
        thr_db = np.percentile(_db(env), 70) - 6.0   # sit just under speech
        over = _db(env) - thr_db
        gr_db = np.where(over > 0, -over * (1 - 1 / ratio), 0.0)
        smooth = _asym_smooth(_undb(gr_db), 1 / 0.003, atk, rel)
        worst = min(worst, 20.0 * np.log10(max(1e-9, float(smooth.min()) if len(smooth) else 1.0)))
        g = _expand(smooth, n, len(band))
        out += band * np.minimum(1.0, g)
    return out, {"ratio": round(ratio, 2), "gr_db": round(worst, 2)}


# ----------------------------------------------------------- saturation

def _saturate(x: np.ndarray, sr: float, warmth: float) -> tuple[np.ndarray, float]:
    """Oversampled tanh preamp saturation, RMS level-matched.

    warmth 0..100 -> drive 1..7, mix 0..0.75. Adds the odd+even harmonic
    'analog density' of a high-end preamp without changing loudness.
    """
    if warmth <= 0:
        return x, 0.0
    from scipy.signal import resample_poly
    drive = 1.0 + 6.0 * (warmth / 100.0)
    mix = 0.75 * (warmth / 100.0)
    up = resample_poly(x, 2, 1)                       # 2x oversample
    sat = np.tanh(drive * up) / math.tanh(drive)
    rms_in = math.sqrt(float(np.mean(up ** 2)) + 1e-12)
    rms_out = math.sqrt(float(np.mean(sat ** 2)) + 1e-12)
    sat *= rms_in / rms_out                           # level match
    y = (1 - mix) * up + mix * sat
    thd = float(np.sqrt(np.mean((y - up) ** 2)) / (rms_in + 1e-12))
    out = resample_poly(y, 1, 2)
    if len(out) > len(x):
        out = out[:len(x)]
    elif len(out) < len(x):
        out = np.pad(out, (0, len(x) - len(out)))
    return out, thd


# ------------------------------------------------------------- AI stage

def _ai_stage(x48: np.ndarray, sr: int, ai_clean: float, max_quality: bool,
              prog: Callable[[str, int], None], p_lo: int, p_hi: int,
              notes: list, workdir: Path) -> tuple[np.ndarray, str]:
    """Run Resemble-Enhance (or fallback). x48 mono float64 @ sr.

    The AI runs in an ISOLATED SUBPROCESS: the model peaks at ~2.5 GB
    RAM and would risk OOM-killing the Flask server if it lived inside
    it. The worker streams 'CHUNK k n' progress lines on stdout; when
    it exits the OS reclaims every byte — the server stays lean.

    Returns (wav48, backend_used).
    """
    import soundfile as sf
    span = p_hi - p_lo
    model = _model_files()
    if model is None:
        # ---- fallback 1: noisereduce spectral gating -------------------
        try:
            import noisereduce
            prog("AI: fallback — noisereduce spectral gating", p_lo)
            xnr = noisereduce.reduce_noise(
                y=x48.astype(np.float32), sr=sr,
                stationary=False, prop_decrease=min(0.95, 0.3 + 0.6 * ai_clean))
            notes.append("AI stage: noisereduce fallback (spectral gating) — "
                         "Resemble model not installed")
            return xnr.astype(np.float64), "noisereduce"
        except Exception as exc:
            notes.append(f"AI stage: noisereduce unavailable ({exc}) — "
                         "FFmpeg afftdn fallback")
            return x48, "bypass"
        # (if both AI paths missing, caller falls to ffmpeg afftdn)

    # ---- flagship: resemble-enhance in an isolated worker ------------
    import subprocess as _sp
    import sys as _sys
    worker = Path(__file__).parent / "studiomic_ai_worker.py"
    in_w = workdir / "ai_in.wav"
    out_w = workdir / "ai_out.wav"
    sf.write(str(in_w), x48.astype(np.float32), sr, subtype="FLOAT")
    lambd = max(0.0, min(1.0, ai_clean / 100.0))
    nfe = 64 if max_quality else 16
    timeout = max(600, int(len(x48) / sr * 14) + 400)   # RTF ~6 + margin
    t0 = time.time()
    cmd = [_sys.executable, str(worker), str(in_w), str(out_w),
           f"{ai_clean:.1f}", "1" if max_quality else "0"]
    prog(f"AI studio: resemble-enhance (lambd {lambd:.2f}, nfe {nfe}) "
         "— isolated worker", p_lo + 2)
    try:
        with _AI_LOCK:
            p = _sp.Popen(cmd, stdout=_sp.PIPE, stderr=_sp.PIPE,
                          text=True, bufsize=1)
            for line in p.stdout:
                line = line.strip()
                if line.startswith("CHUNK"):
                    try:
                        k, n = line.split()[1:3]
                        prog(f"AI studio — chunk {k}/{n}",
                             p_lo + int(span * int(k) / max(1, int(n))))
                    except Exception:
                        pass
            p.wait(timeout=timeout)
            if p.returncode != 0 or not out_w.exists():
                err = (p.stderr.read() if p.stderr else "")[:200]
                raise RuntimeError(f"worker exit {p.returncode}: {err}")
            _ENHANCER["loaded"] = True
            _ENHANCER["err"] = None
    except Exception as exc:
        _ENHANCER["err"] = str(exc)[:200]
        notes.append(f"AI stage: resemble-enhance failed ({str(exc)[:120]}) — "
                     "falling back to noisereduce")
        try:
            p.kill()
        except Exception:
            pass
        try:
            import noisereduce
            xnr = noisereduce.reduce_noise(
                y=x48.astype(np.float32), sr=sr,
                stationary=False, prop_decrease=min(0.95, 0.3 + 0.6 * ai_clean))
            return xnr.astype(np.float64), "noisereduce"
        except Exception:
            return x48, "bypass"

    dt = time.time() - t0
    out48, _osr = sf.read(str(out_w), dtype="float64", always_2d=True)
    out48 = out48.mean(axis=1)
    in_w.unlink(missing_ok=True)
    out_w.unlink(missing_ok=True)
    notes.append(f"AI stage: resemble-enhance done in {dt:.0f}s "
                 f"({len(x48) / sr / max(dt, .01):.2f}x realtime on CPU) — "
                 f"denoise+generative restore @ 44.1 kHz, nfe {nfe}")
    return out48, "resemble"


# ---------------------------------------------------------------- master

def _loudness_of(path: Path) -> float | None:
    st = analyze(path)
    return st.lufs


def _soft_limit(x: np.ndarray, sr: float, ceiling: float = 0.95) -> np.ndarray:
    """Lookahead soft limiter: 5 ms block peaks, fast-down/slow-up gain,
    hard-clip safety. The gain series is shifted one block early so the
    reduction is already active when the peak arrives."""
    n = max(1, int(sr * 0.005))
    nb = int(math.ceil(len(x) / n))
    pad = np.pad(np.abs(x), (0, nb * n - len(x)))
    peaks = pad.reshape(nb, n).max(axis=1)
    gain = np.minimum(1.0, ceiling / np.maximum(peaks, 1e-9))
    gain = np.concatenate([[1.0], gain[:-1]])          # 1-block lookahead
    rate = sr / n
    gain = _asym_smooth(gain, rate, 0.030, 0.001)       # slow up, fast down
    g = _expand(gain, n, len(x))
    y = x * g
    np.clip(y, -1.0, 1.0, out=y)
    return y


# ---------------------------------------------------------------- run
# ---------------------------------------------------------------- run

def run(path: str | Path, out_path: str | Path,
        ai_clean: float = 70, max_quality: bool = False,
        mic_profile: str = "studio", proximity: float = 60,
        presence: float = 60, air: float = 60, warmth: float = 60,
        compression: float = 60, target_lufs: str | float = "auto",
        declick: bool = True, dehum: bool = True,
        on_progress: Callable[[str, int], None] | None = None) -> dict:
    """Full Studio Mic enhance — 6 stages + QA gate, dolby_off contract."""
    src, dst = Path(path), Path(out_path)
    notes: list[str] = ["Studio Mic — AI + analog mic-model engine (local, "
                        "no keys, no cloud)"]
    stages: list[dict] = []
    decision: dict = {}

    def stage(n, name, status, detail):
        stages.append({"n": n, "name": name, "status": status, "detail": detail})

    def prog(msg, pct):
        if on_progress:
            on_progress(msg, pct)

    try:
        # ============ STAGE 1 — ANALYZE ================================
        prog("Mic 1/6: analyzing input", _STAGE_PCT[1])
        ref = analyze(src)
        if not ref.duration:
            return {"ok": False, "verdict": "fail",
                    "reason": "input analysis failed — unreadable audio",
                    "stages": stages, "decision": decision, "notes": notes}
        mic_profile = mic_profile if mic_profile in _MICS else "studio"
        dprox, dpres, dair, dwarm, dcomp = _MICS[mic_profile]
        # axis scalars 0..100 -> profile default is 60 on that axis
        prox = dprox * (0.35 + 0.012 * proximity)          # 60 -> 1.07x
        pres = dpres * (0.35 + 0.012 * presence)
        air = dair * (0.35 + 0.012 * air)
        warm = min(100.0, dwarm * (0.35 + 0.012 * warmth))
        comp = min(100.0, dcomp * (0.35 + 0.012 * compression))
        ai_clean = max(0.0, min(100.0, float(ai_clean)))

        target = None
        if isinstance(target_lufs, (int, float)):
            target = max(-30.0, min(-9.0, float(target_lufs)))
        elif ref.lufs is not None:
            # voice-appropriate window: preserve the source level, but a
            # voice never needs to be hotter than −16 LUFS (podcast std)
            target = max(-35.0, min(-16.0, float(ref.lufs)))

        decision.update({
            "engine": "studiomic",
            "ai_clean": round(ai_clean),
            "ai_quality": "max (nfe 64, rk4)" if max_quality else "fast (nfe 16)",
            "mic_profile": mic_profile,
            "mic_profile_desc": {
                "studio": "large-diaphragm condenser — silky, airy, detailed",
                "broadcast": "dynamic broadcast mic — thick, punchy, controlled",
                "podcast": "warm intimate close-up — podcast golden voice",
                "vintage": "tube / ribbon — rounded, even-harmonic warmth",
                "natural": "minimal color — barely-there polish",
            }[mic_profile],
            "proximity_db": round(prox, 1),
            "presence_db": round(pres, 1),
            "air_db": round(air, 1),
            "warmth_pct": round(warm),
            "compression_pct": round(comp),
            "declick": bool(declick),
            "dehum": bool(dehum),
            "loudness_target": round(target, 1) if target is not None else -16.0,
            "loudness_rule": ("user target" if isinstance(target_lufs, (int, float))
                              else "source LUFS preserved, clamped [-35, -9]"),
            "true_peak_ceiling": -1.5,
            "output_format": "48 kHz · 24-bit WAV · mono voice focus",
        })
        stage(1, "ANALYZE", "done",
              f"{ref.duration:.1f}s · {ref.sample_rate} Hz · {ref.channels} ch · "
              f"{ref.lufs if ref.lufs is not None else '?'} LUFS · profile={mic_profile}")
        notes.append(f"stage1 analyze: {ref.duration:.1f}s, "
                     f"{ref.lufs if ref.lufs is not None else '?'} LUFS, "
                     f"mic profile={mic_profile}")

        workdir = Path(tempfile.mkdtemp(prefix="studiomic_"))
        try:
            # ============ STAGE 2 — REPAIR =============================
            prog("Mic 2/6: repair (declick / dehum / rumble)", _STAGE_PCT[2])
            chain: list[str] = []
            if dehum:
                chain += [
                    "equalizer=f=50:width_type=h:width=1.2:g=-10",
                    "equalizer=f=60:width_type=h:width=1.2:g=-10",
                    "equalizer=f=100:width_type=h:width=1.2:g=-8",
                ]
            chain += ["highpass=f=35"]
            if declick:
                chain += ["adeclick=window=55:overlap=75:arorder=4"]
            s2 = workdir / "s2.wav"
            _ff(["-i", str(src), "-af", ",".join(chain),
                 "-ac", "1", "-ar", "48000", str(s2)])
            _verify(s2, 2, "repair")
            stage(2, "REPAIR", "done",
                  f"declick={'on' if declick else 'off'} · dehum 50/60/100 Hz "
                  f"{'on' if dehum else 'off'} · rumble HPF 35 Hz · mono 48 kHz")
            notes.append("stage2 repair: declick/dehum/rumble + mono 48k decode")

            # ============ STAGE 3 — AI STUDIO ==========================
            import soundfile as sf
            x48, sr = sf.read(str(s2), dtype="float64", always_2d=True)
            x48 = x48.mean(axis=1)
            if len(x48) == 0:
                raise StudioMicError("[studiomic stage 3] empty decode")

            backend = None
            if ai_clean > 0:
                x48, backend = _ai_stage(
                    x48, sr, ai_clean, max_quality, prog,
                    _STAGE_PCT[2] + 2, _STAGE_PCT[3] - 2, notes, workdir)
            else:
                backend = "bypass"
                notes.append("AI stage: skipped (AI clean = 0)")

            if backend == "bypass":
                # last-resort denoise inside the mic chain via ffmpeg
                s3 = workdir / "s3.wav"
                _ff(["-i", str(s2), "-af", "afftdn=nr=22:nf=-50:tn=1",
                     "-ar", "48000", str(s3)])
                _verify(s3, 3, "denoise-fallback")
                x48, sr = sf.read(str(s3), dtype="float64", always_2d=True)
                x48 = x48.mean(axis=1)
                backend = "afftdn"
                notes.append("AI stage: FFmpeg afftdn fallback applied")

            _ENH = {"resemble": "Resemble-Enhance — deep denoise + generative "
                                "restore (CFM solver + UnivNet vocoder)",
                    "noisereduce": "noisereduce — spectral gating fallback",
                    "afftdn": "FFmpeg afftdn — spectral subtraction fallback"}
            decision["ai_backend"] = backend
            decision["ai_backend_desc"] = _ENH.get(backend, backend)
            stage(3, "AI STUDIO", "done", _ENH.get(backend, backend))

            # ============ STAGE 4 — MIC MODEL ==========================
            prog("Mic 4/6: mic model — the expensive-microphone chain",
                 _STAGE_PCT[4])
            # working normalization: predictable thresholds, RMS-matched
            peak = float(np.max(np.abs(x48))) if len(x48) else 0.0
            if peak > 1e-7:
                x48 = x48 * (10.0 ** (-3.0 / 20.0) / peak)

            x = _butter(x48, sr, 75.0, "highpass")            # rumble
            x = _apply(x, *_biquad("lowshelf", sr, 170.0, prox, 0.707))
            x = _apply(x, *_biquad("peaking", sr, 300.0, -1.5, 1.0))  # mud dip
            x = _apply(x, *_biquad("peaking", sr, 3100.0, pres, 1.1))
            x = _apply(x, *_biquad("peaking", sr, 4700.0, pres * 0.6, 1.3))
            x = _apply(x, *_biquad("highshelf", sr, 11000.0, air, 0.707))
            x, dess_db = _de_ess(x, sr, 0.6)
            x, compinfo = _compress3(x, sr, comp / 100.0)
            x, thd = _saturate(x, sr, warm)

            # safety: never clip before master
            peak2 = float(np.max(np.abs(x))) if len(x) else 0.0
            if peak2 > 0.98:
                x = x * (0.98 / peak2)

            decision["mic_chain"] = (
                f"HPF 75 Hz → proximity low-shelf +{prox:.1f} dB @ 170 Hz → "
                f"mud dip −1.5 dB @ 300 Hz → presence +{pres:.1f} dB @ 3.1 kHz → "
                f"clarity +{pres * 0.6:.1f} dB @ 4.7 kHz → air +{air:.1f} dB "
                f"@ 11 kHz → de-esser 5.5–9 kHz (max −{dess_db:.1f} dB) → "
                f"3-band comp {compinfo['ratio']}:1 (GR {compinfo['gr_db']:.1f} dB) → "
                f"saturated preamp {warm:.0f}% (THD {thd * 100:.1f}%)")
            stage(4, "MIC MODEL", "done", decision["mic_chain"])
            notes.append("stage4 mic model: " + decision["mic_chain"][:180])

            s4 = workdir / "s4.wav"
            sf.write(str(s4), x.astype(np.float64), sr, subtype="DOUBLE")
            _verify(s4, 4, "mic-model")

            # ============ STAGE 5 — MASTER =============================
            # iterative gain -> lookahead soft-limit -> re-measure until the
            # loudness target is reached (a real mastering chain — pure
            # linear loudnorm cannot reach the target on high-crest audio)
            prog("Mic 5/6: loudness master (iterate to target)", _STAGE_PCT[5])
            tl = target if target is not None else -16.0
            rounds = 0
            for _ in range(4):
                sf.write(str(s4), x.astype(np.float64), sr, subtype="DOUBLE")
                cur_i = _loudness_of(s4)
                if cur_i is None or cur_i >= tl - 0.7:
                    break
                need = tl - cur_i
                x = x * (10.0 ** (need / 20.0))
                x = _soft_limit(x, sr)
                rounds += 1
            dst.parent.mkdir(parents=True, exist_ok=True)
            _ff(["-i", str(s4), "-af",
                 "alimiter=limit=0.97:level=false",
                 "-ar", "48000", "-c:a", "pcm_s24le", str(dst)])
            _verify(dst, 5, "master")
            stage(5, "MASTER", "done",
                  f"loudness {tl:.1f} LUFS in {rounds} gain+limit round(s) · "
                  "true-peak safety limiter 0.97")
            notes.append(f"stage5 master: iterative gain+lookahead-limit "
                         f"({rounds} round(s)) to {tl:.1f} LUFS + final "
                         "alimiter 0.97")

            # ============ STAGE 6 — QA GATE ============================
            prog("Mic 6/6: QA gate", _STAGE_PCT[6])
            out_stats = analyze(dst)
            qa = qa_gate(ref, out_stats, label="studiomic")
            stage(6, "QA GATE", "done" if qa.ok else qa.verdict,
                  ("all gates passed — duration, aliveness, DC, level, clip"
                   if qa.ok else "; ".join(qa.issues)[:200]))
            notes.extend(qa.issues)
            if not qa.ok:
                dst.unlink(missing_ok=True)
                return {"ok": False, "verdict": qa.verdict,
                        "reason": "; ".join(qa.issues), "qa": qa.to_dict(),
                        "stages": stages, "decision": decision,
                        "stats_before": ref.to_dict(), "notes": notes}
            prog("Mic Studio: done — QA passed", 100)
            return {"ok": True, "verdict": qa.verdict, "engine": "studiomic",
                    "qa": qa.to_dict(), "stats": out_stats.to_dict(),
                    "stats_before": ref.to_dict(),
                    "stages": stages, "decision": decision,
                    "output": str(dst), "notes": notes}

        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    except StudioMicError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail", "reason": str(exc),
                "stages": stages, "decision": decision, "notes": notes}
    except DSPError as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[studiomic] {exc}",
                "stages": stages, "decision": decision, "notes": notes}
    except Exception as exc:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": False, "verdict": "fail",
                "reason": f"[studiomic] unexpected error: {exc}",
                "stages": stages, "decision": decision, "notes": notes}
