"""Upstream: JusperLee/Apollo look2hear/models/base_model.py (trimmed).

Only from_pretrain() is kept (checkpoint = {model_name, state_dict}); the
huggingface_hub mixin is removed so this module imports with torch only.
"""
import torch
import torch.nn as nn


class BaseModel(nn.Module):
    def __init__(self, sample_rate, in_chan=1):
        super().__init__()
        self._sample_rate = sample_rate
        self._in_chan = in_chan

    def forward(self, *args, **kwargs):
        raise NotImplementedError

    def sample_rate(self):
        return self._sample_rate

    @staticmethod
    def load_state_dict_in_audio(model, pretrained_dict):
        model_dict = model.state_dict()
        update_dict = {}
        for k, v in pretrained_dict.items():
            if "audio_model" in k:
                update_dict[k[12:]] = v
        model_dict.update(update_dict)
        model.load_state_dict(model_dict)
        return model

    @staticmethod
    def from_pretrain(pretrained_model_conf_or_path, *args, **kwargs):
        from . import Apollo as _Fallback  # noqa: F401  (keeps import alive)
        from .apollo import Apollo

        conf = torch.load(
            pretrained_model_conf_or_path, map_location="cpu",
            weights_only=False,
        )
        name = str(conf.get("model_name", "Apollo")).lower()
        # registry: this vendored package contains exactly one model
        model_class = Apollo
        model = model_class(*args, **kwargs)
        model.load_state_dict(conf["state_dict"])
        return model
