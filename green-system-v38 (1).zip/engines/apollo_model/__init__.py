"""Vendored Apollo audio-restoration model code (minimum inference core).

Source: github.com/JusperLee/Apollo (Kai Li, Yi Luo — Tsinghua University /
Tencent AI Lab, arXiv:2409.08514, "Apollo: Band-sequence Modeling for
High-Quality Audio Restoration"). Weights: huggingface.co/JusperLee/Apollo
(CC BY-SA 4.0 — see LICENSE-APOLLO.txt in this folder).

Only the inference path is vendored (model definition + loader). The
PyTorchModelHubMixin of the upstream base class is stripped — we fetch the
checkpoint file ourselves (engines/studiomax.py auto-download) and never
touch the HF hub from here.

The rest of the app treats this folder as read-only third-party code.
"""
from .base_model import BaseModel
from .apollo import Apollo

__all__ = ["BaseModel", "Apollo"]
