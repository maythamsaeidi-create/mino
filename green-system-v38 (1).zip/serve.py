#!/usr/bin/env python3
"""Green System — the ORIGINAL 'Vocal Music Speaker Splitter' app (green)
served byte-for-byte at /, PLUS a 100% LOCAL DSP engine API so the first
page can run the battle-tested FFmpeg engines.

API (all JSON, no silent failures — every error returns {ok:false, reason}):
  GET  /healthz                     liveness
  GET  /api/dsp/health              engine availability
  POST /api/dsp/upload              upload a source file (multipart)
  GET  /api/dsp/sources             registry (uploads + stems + engine outputs)
  POST /api/dsp/run                 start engine job {src_id, engine, params}
  GET  /api/dsp/job/<id>            job progress/result (polled)
  GET  /api/dsp/download/<id>       result file (attachment)
  GET  /api/dsp/file/<id>           result file (inline, for playback)
  POST /api/dsp/workshop_run        per-stem scan & fix (engine chains)
  POST /api/dsp/workshop_mix        final mix + broadcast master + QA

Engines (self-contained package ./engines — all local, all QA-gated):
  local: clean | voice | music | fx | spatial | master   (FFmpeg, offline)
  dolby_off: OFFLINE 7-stage Dolby-style engine — analyze/repair/denoise/
         dynamics/profile-EQ/spatial/loudness-master. No API, no keys,
         no upload, no cloud. Same safety rules + QA gate as before.
  studiomic: "Mic Studio" flagship AI voice (resemble-enhance in an
         isolated subprocess + analog mic model).
  enhance: "ENHANCE" adaptive agent — forensic → diagnose → plan →
         process+verify (keep/reduce/rollback) → 10-gate QC → scores.
Every engine runs inside the shared analysis/QA layer: pre-analysis
(ebur128+astats) and post-QA gates (duration / aliveness / DC / level).
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import uuid
from pathlib import Path

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from flask import Flask, jsonify, request, send_file  # noqa: E402

from engines import (analysis, catalog, dolby_off, local,  # noqa: E402
                     studiomic, enhance, studiomax)  # noqa: E402  (local engine package)
from engines.local import DSPError, _ff  # noqa: E402

DATA = BASE / "data"
UPLOADS = DATA / "uploads"
OUTPUTS = DATA / "outputs"
for d in (UPLOADS, OUTPUTS):
    d.mkdir(parents=True, exist_ok=True)

ALLOWED_EXT = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus",
               ".wma", ".aiff", ".aif", ".mp4", ".mkv", ".webm"}
ENGINE_NAMES = {
    "enhance": "Enhance — intelligent adaptive agent",
    "studiomic": "Mic Studio — AI studio voice",
    "studiomax": "Studio Max — AI remaster (Demucs+Apollo+Resemble)",
    "dolby_off": "Dolby OFFLINE (7-stage)",
    "clean": "Clean (full-mix)", "voice": "Voice enhance",
    "music": "Music enhance", "fx": "FX enhance",
    "spatial": "3D Spatial", "master": "Master",
}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024  # 2 GB


@app.after_request
def _no_cache(resp):
    """HTML and /static/* must ALWAYS revalidate.

    Heuristic caching (or max-age) on JS kept serving OLD code after an
    update while the HTML was new — a half-updated app with ghost bugs
    that no restart could fix. ETag/304 makes revalidation cheap, so
    every deploy reaches every user immediately.  (The ?v= bump stays
    as a belt-and-suspenders cache buster.)"""
    ct = (resp.headers.get("Content-Type") or "")
    if ("text/html" in ct or request.path.startswith("/static/")) \
            and resp.status_code in (200, 304):
        resp.headers["Cache-Control"] = "no-cache, must-revalidate"
    return resp

# JSON contract: EVERY error on EVERY path/method is JSON — the client must
# never receive an HTML error page (the root cause of "Unexpected token '<'").


def _wants_html(path: str) -> bool:
    return not path.startswith("api/")


@app.errorhandler(404)
def _e404(e):
    p = request.path.lstrip("/")
    if request.method == "GET" and _wants_html(p):
        return send_file(BASE / "index.html")  # SPA fallback
    return jsonify({"ok": False, "reason": "not found", "path": p}), 404


@app.errorhandler(Exception)
def _e_any(e):
    """Safety net: ANY unhandled error is JSON, never an HTML page."""
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        p = request.path.lstrip("/")
        if request.method == "GET" and _wants_html(p) and e.code == 404:
            return send_file(BASE / "index.html")
        return jsonify({"ok": False, "reason": e.name.lower(), "path": p}), e.code
    return jsonify({"ok": False, "reason": "server error",
                    "detail": str(e)[:300]}), 500


# 100% offline: no server-side keys/tokens of any kind — the only settings
# (MVSEP token / Gemini key / Worker URL+key) live client-side in the browser.
SOURCES: dict[str, dict] = {}      # id -> {id, path, name, kind, engine, stats}
JOBS: dict[str, "Job"] = {}
_JOBS_LOCK = threading.RLock()


# ---------------------------------------------------------------- jobs

class Job:
    def __init__(self, kind: str, label: str = ""):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind
        self.label = label
        self.state = "running"          # running | done | error
        self.stage = "queued"
        self.progress = 0
        self.started = time.time()
        self.logs: list[str] = []
        self.result: dict = {}

    def to_dict(self) -> dict:
        return {"id": self.id, "kind": self.kind, "label": self.label,
                "state": self.state, "stage": self.stage,
                "progress": self.progress,
                "elapsed": round(time.time() - self.started, 1),
                "logs": self.logs, "result": self.result}

    def log(self, msg: str) -> None:
        self.logs.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
        if len(self.logs) > 300:
            del self.logs[:150]

    def prog(self, stage: str, pct: int) -> None:
        self.stage = stage
        self.progress = max(0, min(100, int(pct)))
        self.log(stage)


def start_job(kind: str, fn, label: str = "") -> str:
    job = Job(kind, label=label)
    with _JOBS_LOCK:
        JOBS[job.id] = job

    def wrapper():
        try:
            result = fn(job) or {}
            job.result = result
            job.state = "done" if result.get("ok", True) else "error"
            job.progress = 100
            job.log(f"JOB {job.state.upper()}")
        except Exception as exc:
            job.state = "error"
            job.result = {"ok": False, "reason": f"crash: {exc}",
                          "detail": traceback.format_exc()[-800:]}
            job.log(f"CRASH: {exc}")

    threading.Thread(target=wrapper, daemon=True).start()
    return job.id


def _clamp(v, lo, hi, dflt):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return dflt


# ---------------------------------------------------------------- engines

def _prog(job):
    def cb(stage: str, pct: int) -> None:
        job.prog(stage, pct)
    return cb


def _run_local(engine: str, src: Path, dst: Path, params: dict, job: Job) -> dict:
    job.prog("LOCAL: analyzing input", 5)
    ref = analysis.analyze(src)
    if not ref.duration:
        return {"ok": False, "reason": "input is not decodable audio", "notes": []}
    modules = params.get("modules") if isinstance(params.get("modules"), dict) else None
    try:
        if engine == "clean":
            res = local.clean(src, dst,
                              denoise=int(_clamp(params.get("denoise", 18), 0, 24, 18)),
                              declick=bool(params.get("declick", True)),
                              dehum=bool(params.get("dehum", True)),
                              modules=modules,
                              on_progress=_prog(job))
        elif engine == "voice":
            res = local.voice_enhance(src, dst,
                                      denoise=int(_clamp(params.get("denoise", 14), 0, 30, 14)),
                                      modules=modules,
                                      on_progress=_prog(job))
        elif engine == "music":
            res = local.music_enhance(src, dst,
                                      widen=_clamp(params.get("widen", 1.25), 1.0, 1.6, 1.25),
                                      crystal=_clamp(params.get("crystal", 2.0), 0.0, 4.0, 2.0),
                                      modules=modules,
                                      on_progress=_prog(job))
        elif engine == "fx":
            res = local.fx_enhance(src, dst,
                                   crystal=_clamp(params.get("crystal", 1.5), 0.0, 3.0, 1.5),
                                   modules=modules,
                                   on_progress=_prog(job))
        elif engine == "spatial":
            res = local.spatialize(src, dst,
                                   width=_clamp(params.get("width", 1.4), 1.0, 1.8, 1.4),
                                   crystal=_clamp(params.get("crystal", 1.2), 0.0, 3.0, 1.2),
                                   modules=modules,
                                   on_progress=_prog(job))
        elif engine == "master":
            res = local.master(src, dst,
                               lufs=_clamp(params.get("lufs", -16), -30, -9, -16),
                               tp=_clamp(params.get("tp", -1.5), -3, -0.5, -1.5),
                               mp3=bool(params.get("mp3", False)),
                               modules=modules,
                               on_progress=_prog(job))
        else:
            return {"ok": False, "reason": f"unknown engine {engine}", "notes": []}
    except local.DSPError as exc:
        return {"ok": False, "reason": str(exc), "notes": [f"[{engine}] ffmpeg error"]}

    # shared QA layer around every engine
    job.prog("LOCAL: QA gate", 92)
    out_stats = analysis.analyze(dst)
    qa = analysis.qa_gate(ref, out_stats, label=engine)
    res["qa"] = qa.to_dict()
    res["stats"] = out_stats.to_dict()
    res["verdict"] = qa.verdict
    res.setdefault("notes", []).extend(qa.issues)
    if not qa.ok:
        dst.unlink(missing_ok=True)
        res["ok"] = False
        res["reason"] = "; ".join(qa.issues)
    return res


def _run_dolby_off(src: Path, dst: Path, params: dict, job: Job) -> dict:
    """OFFLINE Dolby engine — no keys, no network, 7 verified stages."""
    noise = int(_clamp(params.get("noise_strength", 20), 0, 45, 20))
    profile = "voice" if str(params.get("profile", "music")) == "voice" else "music"
    spatial = bool(params.get("spatial", True))
    declick = bool(params.get("declick", True))
    dehum = bool(params.get("dehum", True))
    try:
        return dolby_off.run(
            src, dst, noise_strength=noise, profile=profile,
            spatial=spatial, declick=declick, dehum=dehum,
            on_progress=_prog(job))
    except Exception as exc:  # dolby_off already catches internally; belt+braces
        return {"ok": False, "reason": f"dolby_off crashed: {exc}", "notes": []}


def _run_enhance(src: Path, dst: Path, params: dict, job: Job) -> dict:
    """ENHANCE — the intelligent adaptive agent (diagnose → plan →
    process → verify → rollback → report). Third engine; Dolby One and
    Mic Studio stay untouched."""
    tl = params.get("target_lufs", "auto")
    if isinstance(tl, str):
        tl = tl.strip()
        tl = float(tl) if tl and tl not in ("auto", "") else "auto"
    try:
        return enhance.run(
            src, dst,
            mode=str(params.get("mode", "balanced")),
            profile=str(params.get("profile", "auto")),
            ai_assist=_clamp(params.get("ai_assist", 55), 0, 100, 55),
            max_quality=bool(params.get("max_quality", False)),
            intensity=_clamp(params.get("intensity", 70), 0, 100, 70),
            preserve_dynamics=bool(params.get("preserve_dynamics", False)),
            keep_natural=bool(params.get("keep_natural", False)),
            target_lufs=tl,
            declick=params.get("declick", "auto"),
            dehum=params.get("dehum", "auto"),
            on_progress=_prog(job))
    except Exception as exc:  # enhance catches internally; belt+braces
        return {"ok": False, "reason": f"enhance crashed: {exc}", "notes": []}


def _run_studiomic(src: Path, dst: Path, params: dict, job: Job) -> dict:
    """STUDIO MIC — the flagship AI voice engine (resemble-enhance +
    analog mic model). Same result contract as dolby_off."""
    mic = str(params.get("mic_profile", "studio"))
    tl = params.get("target_lufs", "auto")
    try:
        if isinstance(tl, str):
            tl = tl.strip()
            tl = float(tl) if tl and tl not in ("auto", "") else "auto"
        return studiomic.run(
            src, dst,
            ai_clean=_clamp(params.get("ai_clean", 70), 0, 100, 70),
            max_quality=bool(params.get("max_quality", False)),
            mic_profile=mic if mic in ("studio", "broadcast", "podcast",
                                       "vintage", "natural") else "studio",
            proximity=_clamp(params.get("proximity", 60), 0, 100, 60),
            presence=_clamp(params.get("presence", 60), 0, 100, 60),
            air=_clamp(params.get("air", 60), 0, 100, 60),
            warmth=_clamp(params.get("warmth", 60), 0, 100, 60),
            compression=_clamp(params.get("compression", 60), 0, 100, 60),
            target_lufs=tl,
            declick=bool(params.get("declick", True)),
            dehum=bool(params.get("dehum", True)),
            on_progress=_prog(job))
    except Exception as exc:  # studiomic catches internally; belt+braces
        return {"ok": False, "reason": f"studiomic crashed: {exc}", "notes": []}


def _run_studiomax(src: Path, dst: Path, params: dict, job: Job) -> dict:
    """STUDIO MAX — engine #3: the strongest-combination AI remaster
    (Demucs split + Apollo restore + Resemble voice). Same contract as
    studiomic/dolby_off: stages, notes, QA gate, graceful fallback."""
    tl = params.get("lufs", -16)
    if isinstance(tl, str):
        tl = tl.strip()
        tl = float(tl) if tl and tl not in ("auto", "") else -16
    try:
        return studiomax.run(
            src, dst,
            modules=params.get("modules") if isinstance(
                params.get("modules"), dict) else None,
            split=bool(params.get("split", True)),
            restore=_clamp(params.get("restore", 75), 0, 100, 75),
            voice=_clamp(params.get("voice", 70), 0, 100, 70),
            polish=bool(params.get("polish", True)),
            spatial=bool(params.get("spatial", True)),
            master=bool(params.get("master", True)),
            width=_clamp(params.get("width", 1.35), 1.0, 1.8, 1.35),
            lufs=_clamp(tl, -30, -9, -16),
            on_progress=_prog(job))
    except Exception as exc:  # studiomax catches internally; belt+braces
        return {"ok": False, "reason": f"studiomax crashed: {exc}", "notes": []}


# ---------------------------------------------------------------- registry

def _register(path: Path, name: str, kind: str, engine: str = "",
              stats: dict | None = None) -> dict:
    sid = path.stem
    entry = {"id": sid, "path": str(path), "name": name, "kind": kind,
             "engine": engine,
             "stats": stats or analysis.analyze(path).to_dict()}
    SOURCES[sid] = entry
    return entry


def _entry(sid: str):
    """Registry lookup WITH disk recovery.

    Every registered id IS a filename stem inside data/outputs (engine
    results, wsh_*, mix_*) or data/uploads (user files). The registry
    is in-memory, so after a server restart (or in a long-open browser
    tab from before the restart) ids go 'missing' and Final Mix failed
    with a cryptic 400 'no stems — process and tick stems first', even
    though the files were still on disk. Re-registering from disk makes
    every stale id work again — the mix, downloads and playback."""
    sid = str(sid or "").strip()
    if not sid or "/" in sid or "\\" in sid or ".." in sid:
        return None            # path traversal guard
    entry = SOURCES.get(sid)
    if entry and Path(entry["path"]).exists():
        return entry
    for d in (OUTPUTS, UPLOADS):
        for ext in (".wav", ".mp3", ".flac", ".m4a", ".aac", ".ogg",
                    ".opus", ".aiff"):
            p = d / f"{sid}{ext}"
            if p.exists():
                kind = "upload" if d is UPLOADS else "output"
                try:
                    return _register(p, p.stem, kind=kind)
                except Exception:
                    return None
    return None


# ---------------------------------------------------------------- workshop

WORKSHOP_KINDS = ("voice", "music", "fx", "clean")
CHAIN_ENGINES = ("enhance", "studiomic", "studiomax", "clean", "voice",
                 "music", "fx", "spatial", "master", "dolby_off")
DEFAULT_CHAIN = {"voice": ["studiomic"], "music": ["music"],
                 "fx": ["fx"], "clean": ["clean"]}


def _kind_for_name(name: str, kind: str) -> str:
    """Refine the client-supplied kind by stem name (safety net).

    NOTE: 'No Vocals' / 'instrumental' / 'other' are the MUSIC bed,
    not voice — checked first so the vocal guard never misfires.
    """
    n = (name or "").lower()
    if any(w in n for w in ("no vocal", "no_vocal", "novocal", "instrumental",
                            "backing", "karaoke", "accompaniment")):
        return "music"
    if n.strip() in ("other", "others", "accompaniment"):
        return "music"
    if "speaker" in n or n.startswith("spk"):
        return "voice"
    if any(w in n for w in ("vocal", "voice", "acap", "speech")):
        return "voice"
    if any(w in n for w in ("fx", "effect", "sfx")):
        return "fx"
    if "original" in n or "full mix" in n or n.strip() == "mix":
        return "clean"
    return kind if kind in WORKSHOP_KINDS else "music"


def _sanitize_engine_params(engine: str, raw) -> dict:
    """Keep only catalog-known keys, coerced to sane types.

    The UI sends, per engine: {modules:{key:bool}, ...amount keys} — the
    module checkbox OFF maps to the module's param-off value (or just
    modules[key]=false for local engines). Unknown junk is dropped so a
    hostile/buggy client can never smuggle arbitrary kwargs into an
    engine call.
    """
    if not isinstance(raw, dict):
        return {}
    allowed = catalog.param_keys(engine)
    out: dict = {}
    for k in allowed:
        if k in raw:
            out[k] = raw[k]
    mods = raw.get("modules")
    if isinstance(mods, dict):
        keys = {m["key"] for m in catalog.CATALOG.get(engine, {}).get("modules", [])}
        clean = {k: bool(v) for k, v in mods.items() if k in keys}
        if clean:
            out["modules"] = clean
    return out


def _chain_params(engine: str, kind: str, user: dict | None = None) -> dict:
    """Kind-aware default params for an engine inside a per-stem chain,
    MERGED with the user's per-engine module settings (tick on/off +
    amount sliders). User values are sanitized against the catalog."""
    if engine == "enhance":
        base = {"mode": "balanced", "profile": "auto", "ai_assist": 55,
                "max_quality": False, "intensity": 70,
                "preserve_dynamics": False, "keep_natural": False,
                "target_lufs": "auto", "declick": "auto", "dehum": "auto"}
    elif engine == "studiomic":
        base = {"ai_clean": 70, "max_quality": False,
                "mic_profile": "studio",
                "proximity": 60, "presence": 60, "air": 60,
                "warmth": 60, "compression": 60,
                "target_lufs": "auto", "declick": True, "dehum": True}
    elif engine == "studiomax":
        base = {"split": True, "restore": 75, "voice": 70,
                "polish": True, "spatial": True, "master": True,
                "width": 1.35, "lufs": -16}
    elif engine == "dolby_off":
        base = {"noise_strength": 20,
                "profile": "voice" if kind == "voice" else "music",
                "spatial": True, "declick": True, "dehum": True}
    else:
        base = {}          # every other engine uses its own safe defaults
    if user:
        base.update(_sanitize_engine_params(engine, user))
    return base


def _run_engine_one(engine: str, src: Path, dst: Path, kind: str,
                    job: Job, user: dict | None = None) -> dict:
    """Run ONE engine of a per-stem chain (same runners as /api/dsp/run).
    user = the per-engine module settings from the stem row (optional)."""
    params = _chain_params(engine, kind, user)
    if engine == "enhance":
        return _run_enhance(src, dst, params, job)
    if engine == "studiomic":
        return _run_studiomic(src, dst, params, job)
    if engine == "studiomax":
        return _run_studiomax(src, dst, params, job)
    if engine == "dolby_off":
        return _run_dolby_off(src, dst, params, job)
    return _run_local(engine, src, dst, params, job)


def _parse_engines(raw, kind: str) -> list:
    """Validate the per-stem engine chain.

    list            -> user selection (order kept, dupes/bogus dropped)
                      empty list = NO engine (pass-through the original)
    missing/None    -> default chain for the stem kind (legacy clients)
    """
    if isinstance(raw, list):
        out = []
        for e in raw:
            e = str(e)
            if e in CHAIN_ENGINES and e not in out:
                out.append(e)
        return out
    return list(DEFAULT_CHAIN.get(kind, ["clean"]))


def _workshop_run_item(kind: str, src: Path, dst: Path, job,
                       i: int, n: int, name: str, engines: list,
                       src_id: str, eparams: dict | None = None) -> dict:
    """Scan + fix ONE stem with the USER-SELECTED engine chain.

    engines == []  -> pass-through: the original goes to the final mix
                       untouched (out_id = the uploaded source id).
    engines == [a, b, ...] -> chained a -> b -> ... (each step runs the
    same battle-tested runner used by /api/dsp/run, QA-gated).
    eparams = {engine: {modules:{...}, amount keys}} — per-engine activity
    ticks from the stem row (every module of every engine on/off).
    """
    base = 5 + 88 * (i - 1) / max(1, n)
    span = 88 / max(1, n)
    label = f"stem {i}/{n}: {name}"
    job.prog(f"{label} — scan", int(base + 1))
    ref = analysis.analyze(src)
    before = ref.to_dict()
    if not ref.duration:
        return {"ok": False, "name": name, "kind": kind,
                "reason": "unreadable audio", "stats_before": before,
                "engines_used": []}

    if not engines:
        job.prog(f"{label} — pass-through (original)", int(base + span))
        return {"ok": True, "passthrough": True, "name": name, "kind": kind,
                "engines_used": [], "out_id": src_id,
                "stats": before, "stats_before": before, "verdict": "pass",
                "notes": ["pass-through — the original goes to the mix unchanged"]}

    workdir = Path(tempfile.mkdtemp(prefix="wshchain_"))
    notes: list = []
    cur = src
    m = len(engines)
    try:
        for j, eng in enumerate(engines, 1):
            job.prog(f"{label} — engine {j}/{m}: {ENGINE_NAMES[eng]}",
                     int(base + span * (0.15 + 0.65 * (j - 1) / m)))
            step = dst if j == m else workdir / f"step{j:02d}.wav"
            try:
                res = _run_engine_one(eng, cur, step, kind, job,
                                      (eparams or {}).get(eng))
            except DSPError as exc:
                return {"ok": False, "name": name, "kind": kind,
                        "reason": f"[{eng}] {exc}", "stats_before": before,
                        "engines_used": engines[:j - 1], "notes": notes}
            if not res.get("ok"):
                reason = str(res.get("reason", "engine failed"))
                return {"ok": False, "name": name, "kind": kind,
                        "reason": reason, "stats_before": before,
                        "engines_used": engines[:j - 1], "notes": notes}
            notes.extend(str(x) for x in res.get("notes", [])[:3])
            cur = step

        # whole-chain QA vs the ORIGINAL scan of the stem
        job.prog(f"{label} — QA", int(base + span * 0.92))
        out_stats = analysis.analyze(dst)
        qa = analysis.qa_gate(ref, out_stats, label="workshop_" + kind)
        notes.extend(qa.issues)
        ok = bool(qa.ok)
        if not ok:
            dst.unlink(missing_ok=True)
        return {"ok": ok, "name": name, "kind": kind,
                "engines_used": engines, "qa": qa.to_dict(),
                "stats": out_stats.to_dict(), "stats_before": before,
                "verdict": qa.verdict, "notes": notes[-12:],
                "reason": "" if ok else "; ".join(qa.issues)}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


@app.post("/api/dsp/workshop_run")
def dsp_workshop_run():
    """Batch stem workshop: every stem runs its OWN engine chain.

    body: {items: [{src_id, kind, name, engines: [...], params: {...}}]}
      engines        ordered chain — several engines run back-to-back
      engines: []    no engine: the ORIGINAL passes to the final mix
      engines omit   default chain for the stem kind
      params         {engineKey: {modules:{key:bool}, ...amounts}} —
                     per-engine activity ticks (live A/B in the UI)
    """
    body = request.get_json(silent=True) or {}
    raw_items = body.get("items") or []
    if not isinstance(raw_items, list) or not raw_items:
        return jsonify({"ok": False, "reason": "no items"}), 400
    items = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        entry = _entry(str(it.get("src_id", "")))
        if not entry:
            continue
        name = str(it.get("name") or entry.get("name") or "stem")
        # classify on BOTH names (display name + stored name) — safety net
        kind = _kind_for_name(
            f"{name} {entry.get('name', '')}",
            str(it.get("kind") or "music"))
        engines = _parse_engines(it.get("engines"), kind)
        raw_params = it.get("params") if isinstance(it.get("params"), dict) else {}
        eparams = {e: p for e, p in raw_params.items()
                   if e in CHAIN_ENGINES and isinstance(p, dict)}
        items.append((entry, kind, name, engines, eparams))
    if not items:
        return jsonify({"ok": False, "reason": "no valid stems — upload first"}), 400
    batch_id = uuid.uuid4().hex[:8]

    def fn(job: Job):
        results = []
        for i, (entry, kind, name, engines, eparams) in enumerate(items, 1):
            src = Path(entry["path"])
            dst = OUTPUTS / f"wsh_{kind}_{batch_id}_{i}.wav"
            res = _workshop_run_item(kind, src, dst, job, i, len(items),
                                     name, engines, entry["id"], eparams)
            res["name"] = name
            res["kind"] = kind
            res["src_id"] = entry["id"]
            res.setdefault("engines_used", engines)
            if res.get("ok") and not res.get("passthrough") and dst.exists():
                reg = _register(dst, f"{name} — fixed ({kind})",
                                kind="output", engine="workshop_" + kind,
                                stats=res.get("stats"))
                res["out_id"] = reg["id"]
            results.append(res)
        ok = any(r.get("ok") for r in results)
        reason = "" if ok else "; ".join(
            f"{r.get('name')}: {r.get('reason', '')}" for r in results
            if not r.get("ok"))[:600]
        return {"ok": ok, "stems": results, "reason": reason}

    jid = start_job("workshop", fn, label=f"Stem Studio — {len(items)} stems")
    return jsonify({"ok": True, "job_id": jid})


def _workshop_mix(items: list, dst: Path, lufs: float, tp: float,
                  job: Job) -> dict:
    """Final mix: sum the ticked processed stems (original balance kept),
    then broadcast master (loudnorm + true-peak limiter), QA-gated."""
    notes = [f"final mix of {len(items)} ticked stem(s) — balance preserved"]
    job.prog("Mix: preparing", 5)
    workdir = Path(tempfile.mkdtemp(prefix="wshmix_"))
    try:
        stems = []
        for entry, _orig_lufs in items:
            ref = analysis.analyze(Path(entry["path"]))
            if not ref.duration:
                return {"ok": False,
                        "reason": f"stem {entry['name']} unreadable"}
            stems.append((Path(entry["path"]), ref))
        ref_long = max(stems, key=lambda t: t[1].duration)[1]  # QA reference
        for s, r in stems:
            notes.append(f"stem {entry_name(s)}: {r.duration:.1f}s, "
                         f"{r.lufs if r.lufs is not None else '?'} LUFS")

        # ---- sum (amix keeps each stem at its own level) ---------------
        job.prog("Mix: summing stems", 55)
        if len(stems) > 1:
            mixf = workdir / "mixsum.wav"
            args: list = []
            for s, _ in stems:
                args += ["-i", str(s)]
            args += ["-filter_complex",
                     f"amix=inputs={len(stems)}:duration=longest:normalize=0",
                     str(mixf)]
            _ff(args)
        else:
            mixf = stems[0][0]

        # ---- master --------------------------------------------------
        job.prog("Mix: final master", 72)
        dst.parent.mkdir(parents=True, exist_ok=True)
        _ff(["-i", str(mixf), "-af",
             f"loudnorm=I={lufs:.1f}:TP={tp:.1f}:LRA=11,"
             f"alimiter=limit=0.97:level=false",
             "-ar", "48000", "-c:a", "pcm_s24le", str(dst)])
        p = local._verify(dst)

        job.prog("Mix: QA gate", 90)
        out_stats = analysis.analyze(dst)
        qa = analysis.qa_gate(ref_long, out_stats, label="workshop_mix")
        notes.extend(qa.issues)
        if not qa.ok:
            dst.unlink(missing_ok=True)
            return {"ok": False, "reason": "; ".join(qa.issues),
                    "qa": qa.to_dict(), "notes": notes}
        reg = _register(dst, f"Final Mix ({len(items)} stems)",
                        kind="output", engine="workshop_mix",
                        stats=out_stats.to_dict())
        job.prog("Mix complete — QA pass", 100)
        return {"ok": True, "verdict": qa.verdict, "engine": "workshop_mix",
                "qa": qa.to_dict(), "stats": out_stats.to_dict(),
                "output": str(dst), "out_id": reg["id"], "notes": notes,
                "stems_used": len(items), "duration": p.get("duration")}
    except DSPError as exc:
        dst.unlink(missing_ok=True)
        return {"ok": False, "reason": f"[mix] {exc}", "notes": notes}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def entry_name(path: Path) -> str:
    return path.stem


@app.post("/api/dsp/workshop_mix")
def dsp_workshop_mix():
    """Final mix of the ticked (final) stems — processed outputs OR
    originals (pass-through: engines = none).

    body: {items: [{out_id | src_id, orig_lufs}], lufs, tp}
    """
    body = request.get_json(silent=True) or {}
    raw = body.get("items") or []
    items = []
    for it in raw:
        if not isinstance(it, dict):
            continue
        sid = str(it.get("out_id") or it.get("src_id") or "")
        entry = _entry(sid)
        if not entry:
            continue
        items.append((entry, it.get("orig_lufs")))
    if not items:
        return jsonify({"ok": False,
                        "reason": "no usable stems — reload the page (F5) and "
                                  "re-scan: the server restarted and this "
                                  "tab's old ids are being recovered from "
                                  "disk"}), 400
    lufs = _clamp(body.get("lufs", -16), -30, -9, -16)
    tp = _clamp(body.get("tp", -1.5), -3, -0.5, -1.5)
    out_id = uuid.uuid4().hex[:10]
    dst = OUTPUTS / f"mix_{out_id}.wav"

    def fn(job: Job):
        return _workshop_mix(items, dst, lufs, tp, job)

    jid = start_job("workshop_mix", fn,
                    label=f"Final Mix — {len(items)} stems")
    return jsonify({"ok": True, "job_id": jid, "out_id": out_id})


# ---------------------------------------------------------------- routes

@app.get("/")
def index():
    return send_file(BASE / "index.html")


@app.get("/healthz")
def healthz():
    return jsonify({"status": "green-system+dsp",
                    "app": "vocal-music-speaker-splitter"})


@app.get("/api/dsp/health")
def dsp_health():
    try:
        ai = studiomic.ai_status()
    except Exception as exc:
        ai = {"ok": False, "resemble": False, "noisereduce": False,
              "resemble_err": str(exc)[:120]}
    try:
        smax = studiomax.model_status()
    except Exception as exc:
        smax = {"ok": False, "demucs": False, "apollo": False,
                "studiomax_err": str(exc)[:120]}
    return jsonify({"ok": True,
                    "engines": {"local": True, "dolby_off": True,
                                "studiomic": True, "enhance": True,
                                "studiomax": True},
                    "studiomic_ai": ai,
                    "studiomax_ai": smax})


@app.get("/api/dsp/engine_catalog")
def dsp_engine_catalog():
    """Per-engine activity catalog — the UI renders a checkbox (and an
    optional amount slider) per module so every single activity of every
    engine can be ticked on/off per stem, previewed live, then remixed."""
    return jsonify(catalog.catalog_json())


# ------------------------------------------------- AI model auto-download
# The clean zip ships WITHOUT the 713 MB Resemble-Enhance weights. This
# endpoint pair lets the app pull them straight from HuggingFace on
# demand (job with live progress) so a fresh extraction reaches full AI
# power with one click — no manual git/lfs, no restart.

MODEL_REPO = "ResembleAI/resemble-enhance"
MODEL_BASE = f"https://huggingface.co/{MODEL_REPO}/resolve/main/"
# (local rel path under the model dir, repo path)
MODEL_FILES = [
    ("hparams.yaml", "enhancer_stage2/hparams.yaml"),
    ("ds/G/latest", "enhancer_stage2/ds/G/latest"),
    ("ds/G/default/mp_rank_00_model_states.pt",
     "enhancer_stage2/ds/G/default/mp_rank_00_model_states.pt"),
]
_MODEL_DL_LOCK = threading.Lock()


def _model_dir() -> Path:
    """Target dir = studiomic's resolved RUN_DIR (app-local first)."""
    try:
        return Path(studiomic.RUN_DIR)
    except Exception:
        return BASE / "models" / "resemble-enhance"


def _model_present() -> bool:
    try:
        return bool(studiomic.ai_status().get("resemble"))
    except Exception:
        p = _model_dir() / MODEL_FILES[2][0]
        return p.exists() and p.stat().st_size > 1_000_000


@app.get("/api/model/status")
def model_status():
    """AI model inventory (v38: multi-model registry).

    Legacy fields (present/path/size_mb/...) describe the Resemble voice
    model — the v37 Mic Studio button still reads them. The new
    'models' dict covers every auto-downloadable model:
    resemble (voice) · apollo (music restore) · demucs (stem split)
    · demucs_ft (max-quality split)."""
    d = _model_dir()
    present = _model_present()
    weights = d / MODEL_FILES[2][0]
    size_mb = round(weights.stat().st_size / 1e6, 1) if weights.exists() else 0
    try:
        smax = studiomax.model_status()
    except Exception:
        smax = {}
    models = {
        "resemble": {
            "label": "Resemble Enhance — voice AI (Mic Studio)",
            "present": present, "size_mb": 713,
            "url": f"https://huggingface.co/{MODEL_REPO}",
            "downloading": _RUNNING.get("resemble") is not None},
        "apollo": {
            "label": "Apollo — music restoration AI (Studio Max)",
            "present": bool(smax.get("apollo")), "size_mb": 63,
            "url": smax.get("apollo_url", studiomax._APOLLO_URL),
            "downloading": _RUNNING.get("apollo") is not None},
        "demucs": {
            "label": "Demucs htdemucs — local AI stem split (Studio Max)",
            "present": bool(smax.get("demucs")), "size_mb": 81,
            "url": "https://huggingface.co/adefossez/HTDemucs",
            "downloading": _RUNNING.get("demucs") is not None},
        "demucs_ft": {
            "label": "Demucs htdemucs_ft — max-quality split (optional)",
            "present": bool(smax.get("demucs_ft")), "size_mb": 324,
            "url": "https://huggingface.co/adefossez/HTDemucs-ft",
            "downloading": _RUNNING.get("demucs_ft") is not None},
    }
    return jsonify({"ok": True, "present": present, "path": str(weights),
                    "size_mb": size_mb, "repo": MODEL_REPO,
                    "url": f"https://huggingface.co/{MODEL_REPO}",
                    "downloading": any(m["downloading"] for m in
                                       models.values()),
                    "models": models,
                    "files": [{"local": rel, "url": MODEL_BASE + repo}
                              for rel, repo in MODEL_FILES]})


# per-model in-flight download job ids: model key -> job id
_RUNNING: dict[str, str | None] = {k: None for k in
                                   ("resemble", "apollo", "demucs",
                                    "demucs_ft")}


def _dl_files(job: Job, files: list, target: Path, total_hint: int) -> dict:
    """Stream a list of (rel, url) files to *target* with live progress."""
    job.prog("model: connecting to huggingface", 1)
    got = 0
    for rel, url in files:
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        part = dst.with_suffix(dst.suffix + ".part")
        if dst.exists() and dst.stat().st_size > 1_000_000:
            got += dst.stat().st_size
            continue
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "green-system/1.0"})
            with urllib.request.urlopen(req, timeout=60) as r, \
                    open(part, "wb") as out:
                total = int(r.headers.get("Content-Length") or 0)
                job.prog(f"model: fetching {rel} ({total / 1e6:.0f} MB)", 2)
                last = -1
                while True:
                    chunk = r.read(1 << 20)   # 1 MB
                    if not chunk:
                        break
                    out.write(chunk)
                    got += len(chunk)
                    pct = 2 + int(93 * got / max(total, total_hint))
                    if pct != last and pct % 5 < 2:
                        job.prog(f"model: {got / 1e6:.0f} MB / "
                                 f"{max(total, total_hint) / 1e6:.0f} MB",
                                 pct)
                        last = pct
            part.replace(dst)
        except Exception as exc:
            part.unlink(missing_ok=True)
            return {"ok": False,
                    "reason": f"download failed ({rel}): {exc}"[:300]}
    return {"ok": True, "got": got}


def _dl_demucs(job: Job, variant: str) -> dict:
    """Demucs via an isolated worker subprocess (the server itself never
    imports torch). Progress = HF cache growth, watched live."""
    import threading as _th

    job.prog(f"model: fetching demucs {variant} from huggingface", 2)
    stop = _th.Event()
    cache_root = Path(studiomax.DEMUCS_CACHE)
    expect = 340_000_000 if variant == "htdemucs_ft" else 86_000_000

    def watch():
        while not stop.wait(1.0):
            try:
                size = sum(f.stat().st_size for f in cache_root.rglob("*")
                           if f.is_file() and not f.name.endswith(".lock"))
                pct = 2 + int(93 * min(size, expect) / expect)
                job.prog(f"model: {size / 1e6:.0f} MB / "
                         f"{expect / 1e6:.0f} MB", pct)
            except OSError:
                pass

    watcher = _th.Thread(target=watch, daemon=True)
    watcher.start()
    try:
        ok = studiomax._run_worker(["fetch", variant], timeout=1800,
                                   on_line=lambda m: job.log("worker: " + m))
        if ok and studiomax.demucs_present(variant):
            job.prog("model: demucs ready — Studio Max split at full power",
                     100)
            return {"ok": True, "present": True, "model": variant}
        return {"ok": False,
                "reason": "demucs weights missing after download"}
    except Exception as exc:
        return {"ok": False, "reason": f"demucs download failed: {exc}"[:300]}
    finally:
        stop.set()


@app.post("/api/model/ensure")
def model_ensure():
    """Download ANY AI model from HuggingFace (job + live progress).

    body {model: "resemble"|"apollo"|"demucs"|"demucs_ft"}
    (missing/empty -> "resemble": v37 clients posted {} for the 713 MB
    voice model and keep working untouched).

    present        -> {ok, already: true}  (fast no-op)
    already going  -> {ok, job_id}         (join the running download)
    else           -> start a model_dl job; the engine flips on without
                      any restart (presence is probed from disk).
    """
    body = request.get_json(silent=True) or {}
    key = str(body.get("model") or "resemble")
    if key not in _RUNNING:
        return jsonify({"ok": False, "reason": f"unknown model: {key}"}), 400

    def _present() -> bool:
        if key == "resemble":
            return _model_present()
        if key == "apollo":
            return studiomax.apollo_present()
        return studiomax.demucs_present(
            "htdemucs_ft" if key == "demucs_ft" else "htdemucs")

    if _present():
        return jsonify({"ok": True, "already": True, "present": True,
                        "model": key})
    with _MODEL_DL_LOCK:
        if _RUNNING.get(key):
            return jsonify({"ok": True, "job_id": _RUNNING[key],
                            "already": True, "model": key,
                            "note": "download already running"})
        label = {"resemble": "Resemble voice AI (713 MB)",
                 "apollo": "Apollo music-restore AI (63 MB)",
                 "demucs": "Demucs stem-split AI (81 MB)",
                 "demucs_ft": "Demucs max-quality split (324 MB)"}[key]

        def _dl(job: Job):
            if key == "resemble":
                res = _dl_files(job, MODEL_FILES, _model_dir(),
                                713_000_000)
                if not res.get("ok"):
                    return res
                weights = _model_dir() / MODEL_FILES[2][0]
                if not (weights.exists() and
                        weights.stat().st_size > 1_000_000):
                    return {"ok": False,
                            "reason": "weights missing after download"}
                job.prog("model: verifying availability", 97)
                job.prog("model ready — AI engine at full power", 100)
                return {"ok": True, "present": True, "model": key,
                        "path": str(weights)}
            if key == "apollo":
                res = _dl_files(
                    job, [("pytorch_model.bin", studiomax._APOLLO_URL)],
                    studiomax.APOLLO_DIR, 63_000_000)
                if not res.get("ok"):
                    return res
                job.prog("model ready — Studio Max music restore armed",
                         100)
                return {"ok": True, "present": True, "model": key}
            res = _dl_demucs(job, "htdemucs_ft" if key == "demucs_ft"
                             else "htdemucs")
            return res

        def fn(job: Job):
            _RUNNING[key] = job.id      # set INSIDE the thread — no race
            try:
                return _dl(job)
            finally:
                _RUNNING[key] = None

        jid = start_job("model_dl", fn, label=f"AI model — {label}")
        return jsonify({"ok": True, "job_id": jid, "model": key})


@app.post("/api/dsp/upload")
def dsp_upload():
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "reason": "no file part"}), 400
    name = re.sub(r"[^\w\-. ]", "_", f.filename or "audio")
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXT:
        return jsonify({"ok": False, "reason": f"unsupported format: {ext}"}), 400
    sid = uuid.uuid4().hex[:12]
    path = UPLOADS / f"{sid}{ext}"
    f.save(path)
    entry = _register(path, name, kind="upload")
    if not entry["stats"].get("duration"):
        path.unlink(missing_ok=True)
        SOURCES.pop(sid, None)
        return jsonify({"ok": False,
                        "reason": "file is not decodable audio"}), 400
    return jsonify({"ok": True, "id": sid, "name": name,
                    "stats": entry["stats"]})


@app.get("/api/dsp/sources")
def dsp_sources():
    items = [e for e in SOURCES.values() if Path(e["path"]).exists()]
    return jsonify({"ok": True, "sources": items})


@app.post("/api/dsp/run")
def dsp_run():
    body = request.get_json(silent=True) or {}
    src_id = str(body.get("src_id", ""))
    entry = _entry(src_id)
    if not entry:
        return jsonify({"ok": False,
                        "reason": "source not found — re-upload or pick it "
                                  "again (the server may have restarted)"}), 400
    engine = str(body.get("engine", "clean"))
    if engine not in ENGINE_NAMES:
        return jsonify({"ok": False, "reason": f"unknown engine: {engine}"}), 400
    params = body.get("params") or {}
    out_id = uuid.uuid4().hex[:10]
    ext = ".mp3" if (engine == "master" and params.get("mp3")) else ".wav"
    dst = OUTPUTS / f"{engine}_{out_id}{ext}"
    label = f"{ENGINE_NAMES[engine]} — {entry['name']}"

    def fn(job: Job):
        src = Path(entry["path"])
        if engine == "enhance":
            res = _run_enhance(src, dst, params, job)
        elif engine == "studiomic":
            res = _run_studiomic(src, dst, params, job)
        elif engine == "studiomax":
            res = _run_studiomax(src, dst, params, job)
        elif engine == "dolby_off":
            res = _run_dolby_off(src, dst, params, job)
        else:
            res = _run_local(engine, src, dst, params, job)
        if res.get("ok") and Path(res.get("output", str(dst))).exists():
            reg = _register(Path(res["output"]),
                            f"{ENGINE_NAMES[engine]} → {entry['name']}",
                            kind="output", engine=engine,
                            stats=res.get("stats"))
            res["out_id"] = reg["id"]
        return res

    jid = start_job(engine, fn, label=label)
    return jsonify({"ok": True, "job_id": jid, "out_id": out_id})


@app.get("/api/dsp/job/<jid>")
def dsp_job(jid: str):
    job = JOBS.get(jid)
    if not job:
        return jsonify({"ok": False, "reason": "job not found"}), 404
    return jsonify({"ok": True, "job": job.to_dict()})


@app.get("/api/dsp/download/<sid>")
def dsp_download(sid: str):
    entry = _entry(sid)
    if not entry:
        return jsonify({"ok": False, "reason": "file not found"}), 404
    return send_file(entry["path"], as_attachment=True,
                     download_name=Path(entry["name"]).name or f"{sid}.wav")


@app.get("/api/dsp/file/<sid>")
def dsp_file(sid: str):
    entry = _entry(sid)
    if not entry:
        return jsonify({"ok": False, "reason": "file not found"}), 404
    return send_file(entry["path"])


# ----------------------------------------------------------- timeline markers
# Windowed signal analysis -> waveform MARKERS (silence / quiet / loud /
# clipping segments). Pure local FFmpeg decode + numpy; honest thresholds,
# same classification for every file. Drives the marker layer of the
# timeline player (lab output cards: A = original, B = enhanced).

_MARK_WIN = 0.5          # seconds per analysis window
_MARK_SR = 16000         # mono analysis decode rate (fast, enough for RMS)


def _timeline_markers(path: Path) -> dict:
    p = subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error",
         "-i", str(path), "-ac", "1", "-ar", str(_MARK_SR),
         "-f", "s16le", "-"],
        capture_output=True, timeout=600)
    if p.returncode != 0:
        return {"ok": False, "reason": "decode failed"}
    import numpy as np
    a = np.frombuffer(p.stdout, dtype=np.int16).astype(np.float32) / 32768.0
    if not len(a):
        return {"ok": False, "reason": "empty decode"}
    win = int(_MARK_WIN * _MARK_SR)
    nwin = len(a) // win
    if nwin < 1:
        return {"ok": False, "reason": "too short"}
    segs = []           # merged consecutive same-kind segments
    for i in range(nwin):
        w = a[i * win:(i + 1) * win]
        rms = float(np.sqrt(np.mean(w * w)))
        peak = float(np.max(np.abs(w)))
        rms_db = 20.0 * np.log10(max(rms, 1e-9))
        if peak >= 0.985:
            kind = "clip"
        elif rms_db < -55.0:
            kind = "silence"
        elif rms_db < -40.0:
            kind = "quiet"
        elif rms_db > -12.0:
            kind = "loud"
        else:
            continue                      # 'ok' windows are not markers
        t0 = i * _MARK_WIN
        if segs and segs[-1]["kind"] == kind and \
                abs(segs[-1]["t1"] - t0) < 0.01:
            segs[-1]["t1"] = t0 + _MARK_WIN
        else:
            segs.append({"t0": round(t0, 2), "t1": round(t0 + _MARK_WIN, 2),
                         "kind": kind})
    labels = {"silence": "Silence", "quiet": "Quiet section",
              "loud": "Loud section", "clip": "Clipping"}
    for s in segs:
        s["label"] = labels[s["kind"]]
    summary = {k: len([s for s in segs if s["kind"] == k])
               for k in ("silence", "quiet", "loud", "clip")}
    return {"ok": True, "duration": round(len(a) / _MARK_SR, 3),
            "window": _MARK_WIN, "markers": segs[:400], "summary": summary}


@app.get("/api/dsp/analyze/<sid>")
def dsp_analyze(sid: str):
    """Timeline analysis for ONE file: markers + loudness stats."""
    entry = _entry(sid)
    if not entry:
        return jsonify({"ok": False, "reason": "file not found"}), 404
    try:
        res = _timeline_markers(Path(entry["path"]))
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "reason": "decode timed out"}), 504
    except Exception as exc:
        return jsonify({"ok": False, "reason": f"analyze failed: {exc}"}), 500
    if not res.get("ok"):
        return jsonify(res), 422
    res["id"] = sid
    res["name"] = entry.get("name")
    res["stats"] = entry.get("stats")
    return jsonify(res)


@app.errorhandler(405)
def _e405(_e):
    # wrong method on an API path must be JSON, never an HTML error page
    return jsonify({"ok": False, "reason": "method not allowed",
                    "path": request.path.lstrip("/")}), 405


@app.errorhandler(413)
def _e413(_e):
    return jsonify({"ok": False, "reason": "upload too large (limit 2 GB)"}), 413


@app.errorhandler(500)
def _e500(e):
    return jsonify({"ok": False, "reason": "server error",
                    "detail": str(e)[:300]}), 500


if __name__ == "__main__":
    print(f"Green System + DSP engines on http://0.0.0.0:3000/", flush=True)
    print(f"  app file : {BASE / 'index.html'}", flush=True)
    print(f"  engines  : local FFmpeg + Dolby OFFLINE (7-stage) — "
          f"100% local, no keys, no cloud", flush=True)
    app.run(host="0.0.0.0", port=3000, threaded=True)
