# Audio Studio — green-system (self-contained final)

Professional audio separation / repair / subtitle / mix platform —
100% offline, zero server-side keys, everything in ONE folder.

Audio engines (all QA-gated, JSON result contract):

| Engine | What it is |
|---|---|
| **Dolby One** (`dolby_off`) | 7-stage offline chain: analyze → repair → denoise → dynamics → profile-EQ → spatial → loudness master |
| **Mic Studio** (`studiomic`) | AI voice: Resemble-Enhance deep denoise + generative restore (isolated subprocess) + analog mic model + master |
| **Enhance** (`enhance`) | Adaptive agent: forensic → diagnose (17 problem types) → minimum-effective plan → process+verify with keep/reduce/rollback → 10-gate QC → 8-dimension scores |
| **Studio Max** (`studiomax`) | Engine 4 — the strongest AI remaster COMBINATION: Demucs v4 local stem split + Apollo music restoration + Resemble voice + remaster/spatial/master chain. Six tickable activities: AI stem split · AI music restore · AI voice studio · Analog polish · 3D spatial · Master |
| local six-pack (`clean/voice/music/fx/spatial/master`) | FFmpeg engines with 40 tickable activities (v37 catalog) |

## Run

```bash
pip install -r requirements.txt   # + ffmpeg/ffprobe on PATH
./start.sh start                  # daemon on http://127.0.0.1:3000/
./start.sh status · restart · stop
```

Health after start (all JSON):

```bash
curl -s http://127.0.0.1:3000/healthz
curl -s http://127.0.0.1:3000/api/dsp/health
```

## Structure (50 files — no dead code, no legacy app)

```
serve.py               Flask server: 11 JSON endpoints, job system,
                      disk-recovery, workshop (stem chains + final mix),
                      timeline markers. Every error on every path is JSON.
engines/               SELF-CONTAINED DSP engine package:
  analysis.py            shared analysis + QA gate (ffprobe+ebur128+astats)
  local.py               FFmpeg engines (clean/voice/music/fx/spatial/master)
  dolby_off.py           engine 1 — Dolby One (7-stage)
  studiomic.py           engine 2 — Mic Studio (AI + analog mic model)
  studiomic_ai_worker.py isolated AI subprocess (RAM guard, ~2.5GB model)
  enhance.py             engine 3 — ENHANCE adaptive agent (2076 lines)
  studiomax.py           engine 4 — Studio Max AI remaster (orchestrator)
  studiomax_worker.py   isolated split/restore/fetch workers (RAM guard)
  apollo_model/          vendored Apollo model code (Tencent AI Lab,
                        CC BY-SA 4.0 — weights auto-download from HF)
  catalog.py             activity catalog — 46 tickable modules / 10 engines
index.html             SPA shell (2 tabs, 5 modals, all engine cards)
static/js/             core·player·options·msep·studio·subs·mixer·app
static/js/viz/         subtitle stage + FX STUDIO (3D/fx/canvas/gl/export)
static/vendor/three/   three.js r169 + addons (bundled, no CDN)
skills/                TWO complete SKILL.md files for AI hand-off:
  green-system-structure  full code map, zero to hero (what is where)
  green-system-control    full operational control (run/test/debug/change)
data/                  uploads/ + outputs/ (runtime, auto-created)
start.sh               daemon start/stop/restart/status
```

## Optional: AI model weights (auto-download from HuggingFace)

The clean package ships without weights; every model below downloads
with ONE click (live progress, no restart) from the **AI models** row
of the Mic Studio card, or via CLI:

```bash
curl -X POST http://127.0.0.1:3000/api/model/ensure \
     -H 'Content-Type: application/json' -d '{"model":"apollo"}'
# models: resemble · apollo · demucs · demucs_ft   ({} = resemble)
curl -s http://127.0.0.1:3000/api/model/status      # full registry
```

| Model | Size | Source | Powers |
|---|---|---|---|
| Resemble Enhance | 713 MB | `huggingface.co/ResembleAI/resemble-enhance` (MIT) | Mic Studio / Enhance voice AI |
| **Apollo** | 63 MB | `huggingface.co/JusperLee/Apollo` (CC BY-SA 4.0) | **Studio Max — AI music restoration** |
| **Demucs htdemucs** | 81 MB | `huggingface.co/adefossez/HTDemucs` (MIT) | **Studio Max — local AI stem split** |
| Demucs htdemucs_ft | 324 MB | `huggingface.co/adefossez/HTDemucs-ft` | optional max-quality split (bag of 4) |

Manual drop also works (auto-detected, no config needed):

```
models/resemble-enhance/ds/G/default/mp_rank_00_model_states.pt
models/apollo/pytorch_model.bin
models/demucs_hf/            (huggingface_hub cache layout)
```

Without any weights everything still runs — every AI stage falls back
gracefully (noisereduce → FFmpeg afftdn, harmonic exciter) and
`/api/dsp/health` reports what is missing (`studiomax_ai` block).

## Workflow

1. **Studio** — Choose Audio → Start (MVSEP separation + speakers) — or
   upload straight into any engine card (Mic Studio / ENHANCE)
2. **Stem Studio** — per-stem engine chains → A/B compare → tick Final
3. **Final Mix** — server-side broadcast master (LUFS + TP, QA)
4. **Mixer** — timeline deck, M/S/volume per track, WAV/MP3/ZIP
5. **Subtitles** — any source → Gemini → broadcast cues → 16:9 stage
   with FX STUDIO (10 themes, 3D, word pool, one-line, HTML export)

## Guarantees

- Every error is JSON `{ok:false, reason}` — never an HTML error page
- A/B compare flips at the EXACT same sample position
- Original files are never overwritten; every output is QA-gated
- AI model never lives inside the server process (subprocess guard)
- The two SKILL.md files under `skills/` are the complete map for any
  AI (or human) taking over this project — read them first.

## Theme

Swap the `:root { … }` block in `static/css/studio.css` — layout,
components and player colors follow the variables automatically.
