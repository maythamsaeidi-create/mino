---
name: green-system-structure
description: نقشهٔ کامل ساختار کد پروژهٔ Audio Studio (green-system) از صفر تا صد — معماری کلان، همهٔ فایل‌ها و نقش هر کدام، همهٔ توابع کلیدی، همهٔ APIها و قراردادهای JSON، قرارداد نتیجهٔ موتورها، زیرسیستم VFX زیرنویس، جریان‌های داده و اینوارینت‌های ساختاری. هر هوش مصنوعی که این اسکیل را بخواند دقیقاً می‌داند «چه خبره»: هر قطعهٔ کد کجاست، چه کاری می‌کند و با چه چیزی صحبت می‌کند. برای اجرا/تغییر/تست، بعد از این فایل SKILL «green-system-control» را بخوان.
language: fa
---

# 🗺️ ساختار کامل green-system — صفر تا صد

> **این فایل چیست؟** نقشهٔ مطلق کد. وقتی به هر هوش مصنوعی این پروژه داده شود، با خواندن همین یک فایل باید کل سیستم را بشناسد — بدون نیاز به حدس زدن. همهٔ مسیرها نسبت به ریشهٔ پروژه نوشته شده‌اند.

---

## ۰. شناسنامهٔ پروژه

| مورد | مقدار |
|---|---|
| نام محصول | **Audio Studio — Separate · Fix · Subtitle · Mix** |
| نام سیستم/کد | **green-system** (برگشت به اپ سبز اصلی «Vocal Music Speaker Splitter») |
| نوع | SPA تک‌صفحه‌ای + بک‌اند Flask (همان سرور، همان پورت) |
| آدرس اجرا | `http://127.0.0.1:3000/` (فلورک استاندارد) |
| زبان‌های اصلی | Python 3 (بک‌اند) · JavaScript بدون فریمورک (فرانت) · GLSL (شیدرهای 3D) |
| وابستگی‌های سنگین | FFmpeg/ffprobe (پردازش صدا) · resemble-enhance (AI صدا، فقط در venv) · three.js r169 (لودال، در vendor) |
| کلید/توکن روی سرور | **هیچ** — ۱۰۰٪ آفلاین؛ MVSEP/Gemini/Worker keys فقط سمت کلاینت (options.js) |
| نسخهٔ فعلی UI | `?v=37` (کش‌باست) — هر تغییر UI باید بامپ شود |
| فایل راه‌انداز | `green-system/start.sh` (دایمن با PID/LOG) |
| استقلال | **v37: خودکفا + مدل خودکار** — پکیج `engines/` داخل پروژه؛ مدل AI از HuggingFace با یک کلیک دانلود می‌شود (`POST /api/model/ensure`) |

**یک اپ واحد و خودکفا:**

```
green-system/   ← کل پروژه در همین یک پوشه (50 فایل) — استخراج zip در هر جا کار می‌کند
```

- موتورها از `engines/` **محلی** import می‌شوند: `from engines import analysis, dolby_off, local, studiomic, enhance` (serve.py خودش BASE را به sys.path اضافه می‌کند).
- مدل AI (اختیاری، ~713MB) در `models/resemble-enhance/` داخل همان پوشه — یا fallback خودکار به `<parent>/models/` (چیدمان legacy).

---

## ۱. معماری کلان

```
                    ┌────────────────────────── BROWSER (SPA) ──────────────────────────┐
                    │  index.html (ساختار) + studio.css + viz.css (?v=34)               │
                    │                                                                    │
                    │  core.js → player.js → options.js → msep.js → studio.js →          │
                    │  subs.js → mixer.js → app.js        (کلاسیک، order-sensitive)      │
                    │  viz/boot.js (ES module) → core/dom/canvas/fx/fxpanel/fxexport/ui  │
                    │                                        + gl.js lazy → fx3d.js 3D   │
                    │  namespace مشترک: window.S  ·  زیرنویس: window.VIZ                │
                    └───────────────┬────────────────────────────────────────────────────┘
                                    │  fetch / JSON contract (S.api → S.jpost/S.jget/S.upl)
                                    │  هر پاسخ غیر-JSON = خطای ساختاریافته (richErr)
                    ┌───────────────▼────────────────────────────────────────────────────┐
                    │  green-system/serve.py  (Flask, port 3000, threaded)               │
                    │  · Job system (SOURCES / JOBS / start_job / Thread)                │
                    │  · upload/run/poll/download + workshop_run + workshop_mix          │
                    │  · timeline markers (نumpy روی decode 16k)                          │
                    │  · disk-recovery برای idهای کهنه (_entry)                           │
                    └───────────────┬────────────────────────────────────────────────────┘
                                    │  import (sys.path → BASE خودِ پروژه)
                    ┌───────────────▼────────────────────────────────────────────────────┐
                    │  green-system/engines/  ← پکیج موتورهای محلی (خودکفا)              │
                    │  analysis.py  (AudioStats/QA — دور هر موتور)                        │
                    │  local.py     (۶ موتور FFmpeg سبک)                                  │
                    │  dolby_off.py (موتور ۱: Dolby One ۷-مرحله‌ای)                       │
                    │  studiomic.py (موتور ۲: Mic Studio AI + آنالوگ)                     │
                    │  enhance.py   (موتور ۳: عامل تطبیقی — ۱۰ گیت، ۸ امتیاز)             │
                    │  studiomic_ai_worker.py (subprocess ایزوله برای resemble RAM-safe)  │
                    └────────────────────────────────────────────────────────────────────┘
```

**سه مسیر اصلی داده:**

1. **جداسازی (Separation):** کلاینت → MVSEP (worker خارجی با توکن کلاینت) → استم‌ها به `S.state.stems` → آپلود به سرور → Stem Studio → Final Mix.
2. **موتورهای DSP:** کلاینت → `POST /api/dsp/run` → Job → موتور → خروجی در `data/outputs/` → پخش A/B در کلاینت.
3. **زیرنویس:** کلاینت → Gemini (پروکسی + کلید کلاینت) → کلمات `{speaker, startSec, endSec, text}` → cueها → VIZ stage → خروجی SRT/VTT/TXT/HTML.

---

## ۲. نقشهٔ دایرکتوری کامل

```
green-system/                ← کل پروژه: یک پوشهٔ خودکفا (۵۰ فایل)
├── serve.py                 سرور Flask (~۸۹۰ خط) — توضیح کامل §۳
├── start.sh                 دایمن start/stop/restart/status (daemon.pid/daemon.log runtime)
├── requirements.txt         وابستگی‌های python (flask/numpy/scipy/soundfile + optional AI)
├── index.html               کل SPA (۷۹۶ خط) — §۷
├── README.md
├── engines/                 ← پکیج موتورها — §۵ (v36: داخل پروژه، مستقل)
│   ├── __init__.py          فقط ۵ ماژول زنده را import می‌کند (اسلیم)
│   ├── analysis.py          probe/ebur128/astats → AudioStats + qa_gate — §۵.۱
│   ├── local.py             DSPError/_ff + ۶ موتور FFmpeg سبک — §۵.۲
│   ├── dolby_off.py         موتور ۱: Dolby One (۷ استیج) — §۵.۳
│   ├── studiomic.py         موتور ۲: Mic Studio + هِلپرهای DSP مشترک — §۵.۴
│   ├── studiomic_ai_worker.py  ورکر subprocess برای resemble (جدا از RAM سرور)
│   └── enhance.py           موتور ۳: ENHANCE عامل تطبیقی v34 (۲۰۷۶ خط) — §۵.۵
├── skills/
│   ├── green-system-structure/SKILL.md   ← همین فایل
│   └── green-system-control/SKILL.md      ← اسکیل کنترل مطلق (اجرا/تست/تغییر)
├── models/                  (اختیاری، خارج از zip) resemble-enhance/ds/G/default/…pt ~713MB
│                            مسیر در studiomic.py:_run_dir() خودکار پیدا می‌شود
├── data/
│   ├── uploads/             فایل‌های کاربر: {uuid12}.{ext} — id = نام فایل بدون پسوند
│   └── outputs/             خروجی موتورها: {engine}_{id10}.wav · wsh_{kind}_{batch}_{i}.wav · mix_{id10}.wav
├── static/
│   ├── css/
│   │   ├── studio.css       استایل اصلی + بلاک‌های نسخه‌دار (v32 mic/enhbar… v33 enh…)
│   │   └── viz.css          استایل VIZ stage + FX STUDIO
│   ├── js/                  (order لود در index.html، همه ?v=34)
│   │   ├── core.js          پایه: S, utils, API, خطاها, diag, heartbeat — §۶.۱
│   │   ├── player.js        پلیر تایم‌لاین A/B — §۶.۲
│   │   ├── options.js       مدال Separation & Services + کلیدها — §۶.۳
│   │   ├── msep.js          لود سورس + پایپ‌لاین MVSEP — §۶.۴
│   │   ├── studio.js        Stem Studio (Scan&Fix + Final Mix) — §۶.۵
│   │   ├── subs.js          زیرنویس: سورس‌پیکر + Gemini + cueها — §۶.۶
│   │   ├── mixer.js         Final Mixer (M/S/vol) — §۶.۷
│   │   ├── app.js           تب‌ها + MIC STUDIO + ENHANCE + کارت‌های خروجی — §۶.۸
│   │   └── viz/             زیرسیستم زیرنویس/FX — §۸
│   │       ├── boot.js      نقطهٔ ورود ES-module + لود lazy ش GL
│   │       ├── core.js      VIZ namespace + مدل + rAF + registry
│   │       ├── dom.js       مدیریت DOM استیج
│   │       ├── canvas.js    رندرر Canvas2D (سیستم‌های کلاسیک)
│   │       ├── gl.js        رندرر WebGL (پریست‌های ۱۶گانه Systems)
│   │       ├── fx.js        FX STUDIO: تم‌ها + FXCSS (منبع export) + ورودها
│   │       ├── fx3d.js      موتور 3D واقعی three.js + GLSL + Word Pool
│   │       ├── fxpanel.js   پنل کنترل FX (چیپ‌ها/جهت/پرچم‌ها)
│   │       ├── fxexport.js  خروجی HTML مستقل (MP3 data-URI + رانتایم)
│   │       └── ui.js        پنل Systems + snapshot PNG
│   └── vendor/three/        three.module.js r169 + addons (postprocessing/loaders/…) + fonts
```

> **v36 — خودکفا:** پوشهٔ `docs/` (اسکرین‌شات‌های قدیمی + بکاپ) و وابستگی به `audio-studio/` حذف شدند؛ موتورها به `engines/` داخل همان پوشه منتقل شدند. daemon.pid/daemon.log فقط runtime هستند (بعد از start ساخته می‌شوند).

---

## ۳. سرور — `green-system/serve.py` (۸۸۹ خط)

### ۳.۱ راه‌اندازی و ثابت‌ها

- `BASE` = پوشهٔ green-system و خودش به `sys.path` اضافه می‌شود؛ موتورها از پکیج محلی `engines` import می‌شوند: `from engines import analysis, dolby_off, local, studiomic, enhance` + `from engines.local import DSPError, _ff`.
- `UPLOADS = data/uploads`، `OUTPUTS = data/outputs` (می‌سازد اگر نباشد).
- `ALLOWED_EXT` = mp3, wav, flac, m4a, aac, ogg, opus, wma, aiff, aif, mp4, mkv, webm.
- `ENGINE_NAMES` = `enhance` «Enhance — intelligent adaptive agent» · `studiomic` «Mic Studio — AI studio voice» · `dolby_off` «Dolby OFFLINE (7-stage)» · `clean` · `voice` · `music` · `fx` · `spatial` · `master`.
- `MAX_CONTENT_LENGTH` = ۲GB.
- **no-cache:** بعد از هر response برای HTML و `/static/*` هدر `Cache-Control: no-cache, must-revalidate` (ETag/304 ارزان) — به‌علاوهٔ `?v=` در URLها. هر تغییر استاتیک **باید** v بامپ شود.
- **قرارداد JSON:** هر خطا در هر مسیر JSON است (`{ok:false, reason, path}`) — کلاینت هرگز صفحهٔ HTML خطا نمی‌بیند («Unexpected token '<'» ممنوع). errorhandlerهای 404/405/413/500 + Exception عمومی. 404 برای مسیر غیر-API → SPA fallback به `index.html`.

### ۳.۲ سیستم Job (قلب async)

```python
SOURCES: dict[str, dict] = {}   # id → {id, path, name, kind, engine, stats}
JOBS: dict[str, Job] = {}       # job_id → Job
class Job:  # id=uuid12, kind, label, state=running|done|error,
           # stage, progress(0..100), started, logs(≤300), result
def start_job(kind, fn, label)  # Thread(daemon) اجرا می‌کند؛ fn(job)→dict(result)
                                # state=done اگر result.ok!==False وگرنه error
```
- `_prog(job)` → callback `(stage, pct)` برای موتورها → `job.prog`.
- `Job.log` هر استیج را با timestamp ذخیره می‌کند (S: `job.logs` در پاسخ poll).

### ۳.۳ رجیستری و disk-recovery

- `_register(path, name, kind, engine, stats)` → id = `path.stem` (نام فایل بدون پسوند = id).
- `_entry(sid)` — **نکتهٔ حیاتی:** رجیستری in-memory است؛ بعد از restart سرور، idهای قدیمی از دیسک (`OUTPUTS` سپس `UPLOADS` با همهٔ پسوندها) **بازیابی و re-register می‌شوند**. گارد path-traversal (`/`, `..`). این مکانیزم باعث می‌شود تب‌های قدیمی بعد از restart هنوز دانلود/پخش/mix کار کنند.

### ۳.۴ رانرهای موتور (همه قرارداد یکسان نتیجه)

| تابع | موتور | نکتهٔ کلیدی |
|---|---|---|
| `_run_local(engine,…)` | clean/voice/music/fx/spatial/master | پارامترها clamp می‌شوند؛ دور موتور لایهٔ QA مشترک: `analysis.analyze(dst)` + `qa_gate(ref,out)`؛ QA fail → خروجی حذف + `ok:false` |
| `_run_dolby_off(…)` | dolby_off | noise ∈ [0,45] · profile voice\|music · spatial/declick/dehum bool |
| `_run_studiomic(…)` | studiomic | clamp همه: ai_clean∈[0,100] · mic_profile∈{studio,broadcast,podcast,vintage,natural} · prox/pres/air/warm/comp∈[0,100] · target_lufs str\|float («auto»→auto) |
| `_run_enhance(…)` | enhance | mode·profile·ai_assist∈[0,100]·intensity∈[0,100]·preserve_dynamics·keep_natural·target_lufs·declick/dehum ∈ «auto\|on\|off» |

### ۳.۵ Workshop (Stem Studio + Final Mix)

- `WORKSHOP_KINDS` = voice, music, fx, clean.
- `CHAIN_ENGINES` = enhance, studiomic, clean, voice, music, fx, spatial, master, dolby_off.
- `DEFAULT_CHAIN`: voice→[studiomic]، music→[music]، fx→[fx]، clean→[clean].
- `_kind_for_name(name, kind)` — طبقه‌بندی ایمن: «no vocal/instrumental/other»→music (اول چک می‌شود تا گارد vocal خط نخورد)، «speaker/spk»→voice، «vocal/voice/acap/speech»→voice، «fx/sfx»→fx، «original/full mix/mix»→clean.
- `_parse_engines(raw, kind)` — لیست = انتخاب کاربر (ترتیب حفظ، تکراری/نامعتبر حذف)؛ **لیست خالی = pass-through (اصل بدون تغییر به mix می‌رود، out_id=src_id)**؛ غایب = زنجیرهٔ پیش‌فرض kind.
- `_workshop_run_item` — هر استم: scan → زنجیرهٔ موتورها (هر گام خروجی QA-gated، گام آخر → dst) → QA کل-زنجیره نسبت به scan اولیه؛ workdir تمپ `wshchain_` در finally حذف.
- `_workshop_mix` — استم‌های تیک‌خورده با `amix=duration=longest:normalize=0` (سطح هر استم حفظ) → `loudnorm=I={lufs}:TP={tp}:LRA=11, alimiter=0.97` → `48kHz pcm_s24le` → QA → ثبت `mix_{id10}.wav`.
- خروجی استم: `wsh_{kind}_{batch8}_{i}.wav` با نام نمایشی «{name} — fixed ({kind})».

### ۳.۶ Timeline Markers (تحلیل پنجره‌ای)

- `_timeline_markers(path)`: decode مونو 16kHz با FFmpeg → پنجره‌های ۰.۵s → RMS/peak → دسته‌ها: `clip` (peak≥0.985)، `silence` (RMS<−55dB)، `quiet` (RMS<−40dB)، `loud` (RMS>−12dB)، بقیه بدون marker؛ merge پنجره‌های پیوسته؛ خروجی `{ok, duration, window, markers[≤400], summary}`. هر marker: `{t0,t1,kind,label}`.
- `GET /api/dsp/analyze/{id}` = markers + stats — درایور لایهٔ marker کارت‌های A/B (کلیک روی marker → seek).

---

## ۴. قرارداد API کامل (۱۴ مسیر)

همهٔ پاسخ‌ها JSON. موفق: `ok:true` + داده. خطا: `ok:false, reason` (+ `detail` اختیاری).

| مسیر | متد | ورودی | خروجی کلیدی |
|---|---|---|---|
| `/healthz` | GET | — | `{status:"green-system+dsp", app}` — لایو (heartbeat ۷s کلاینت) |
| `/api/dsp/health` | GET | — | `{engines:{local,dolby_off,studiomic,enhance:true}, studiomic_ai:{ok,resemble,noisereduce,…}}` |
| `/api/dsp/upload` | POST multipart `file` | فایل ≤۲GB با پسوند مجاز | `{ok,id,name,stats}` — id=uuid12؛ decode ناموفق → 400 «file is not decodable audio» + فایل حذف |
| `/api/dsp/sources` | GET | — | `{sources:[…]}` فقط مواردی که فایلشان روی دیسک هست |
| `/api/dsp/run` | POST JSON `{src_id, engine, params}` | engine∈ENGINE_NAMES | `{ok, job_id, out_id}` — نتیجهٔ واقعی از poll می‌آید |
| `/api/dsp/job/{id}` | GET | — | `{job:{state,stage,progress,elapsed,logs,result}}` — state=running\|done\|error |
| `/api/dsp/download/{id}` | GET | — | فایل attachment (نام اصلی) |
| `/api/dsp/file/{id}` | GET | — | فایل inline (پخش `<audio>`) |
| `/api/dsp/analyze/{id}` | GET | — | markers + stats (§۳.۶) — 422 اگر decode نشد |
| `/api/dsp/engine_catalog` | GET | — | `{ok,engines:{…}}` — کاتالوگ ماژول‌های هر ۹ موتور (کلید/برچسب/پیش‌فرض/رنج) برای رندر تیک‌های فعالیت |
| `/api/model/status` | GET | — | `{ok,present,path,size_mb,repo,files:[{local,url}]}` — وضعیت وزن‌های ۷۱۳MB |
| `/api/model/ensure` | POST | — | اگر مدل هست: `{ok,already:true}`؛ وگرنه job با پیشرفت زنده → دانلود از HF → `resemble:true` بدون restart |
| `/api/dsp/workshop_run` | POST `{items:[{src_id,kind,name,engines,params}]}` | `params={engineKey:{modules:{key:bool},…amounts}}` | `{ok, job_id}` → result: `{stems:[{ok,name,kind,engines_used,out_id,passthrough,qa,stats,stats_before,verdict,notes,reason}]}` |
| `/api/dsp/workshop_mix` | POST `{items:[{out_id|src_id,orig_lufs}], lufs, tp}` | — | `{ok, job_id, out_id}` → result: mix + qa + stats + stems_used |

**الگوی کلاینت (همیشه):** upload/run → poll `job/{id}` هر ۱.۵s → `state==='done'` → `job.result` → رندر کارت. خطای شبکه ۳ بار پشت‌سرهم = رد. (آپلود ۳.۵MB ≈ ۳ ثانیه؛ timeoutها را سخاوتمندانه بگذار — polling تا ≥۳۰s.)

---

## ۵. کتابخانهٔ موتورها — `green-system/engines/` (خودکفا)

### ۵.۰ `catalog.py` — کاتالوگ ماژول‌های موتورها (v37)

منبع حقیقتِ «فعالیت‌های قابل تیک» هر ۹ موتور: `CATALOG[engine] = {name, heavy, modules:[{key,label,desc,default,amount?,param?,off?}]}`. موتورهای سبک از `modules{key:bool}` مستقیم می‌خوانند؛ موتورهای سنگین (studiomic/dolby_off/enhance) با `param`+`off` روی kwarg موجود خود map می‌شوند (تیک خاموش = مقدار off در params). `param_keys()` کلیدهای مجاز sanitize و `defaults()` seed اولیهٔ UI است.

### ۵.۱ `analysis.py` — لایهٔ تحلیل/QA مشترک (دور **هر** موتور)

- `probe(path)` — فکت‌های کانتینر (ffprobe JSON).
- `_ebur128(path)` — LUFS integrated/LRA/TruePeak (ffmpeg ebur128).
- `_astats(path)` — RMS/clip/DC و … .
- `@dataclass AudioStats` — `to_dict()`؛ فیلدها: duration, sample_rate, channels, lufs, true_peak, lra, rms_db, clipped_samples و … .
- `analyze(path) → AudioStats` (تجمیع probe+ebur128+astats).
- `qa_gate(ref: AudioStats, out: AudioStats, label) → QAResult` — دروازه‌های: تطابق مدت، زنده‌بودن (نه سکوت)، sanity سطح، clipping، DC. `QAResult.verdict` = pass|warn|fail + `issues[]`. **نکته:** `ref.duration==0` یعنی ورودی decode نمی‌شود.

### ۵.۲ `local.py` — موتورهای FFmpeg سبک

> **v37 — سیستم ماژول‌ها:** هر ۶ موتور این فایل آرگومان `modules` دارند (dict از
> `{کلید:bool}`). `modules=None` = همه فعال (رفتار legacy). کلیدها در `catalog.py`
> تعریف شده‌اند؛ notes خروجی همیشه `modules off: a,b` را گزارش می‌کند.

- `DSPError` (اکسپشن پایه) و `_ff(args, timeout=1800)` (اجرای FFmpeg با خطای ساختاریافته) و `_verify(out)`.
- توابع: `clean(denoise,declick,dehum,modules)` · `voice_enhance(denoise,modules)` · `music_enhance(widen,crystal,modules)` · `fx_enhance(crystal,modules)` · `spatialize(width,crystal,modules)` · `master(lufs,tp,mp3,modules)` · `local_clean_fallback`.
- خروجی پیش‌فرض 48kHz/24bit (master می‌تواند mp3 بدهد).

### ۵.۳ `dolby_off.py` — موتور ۱: «Dolby One» (۷ استیج)

```
run(path, out_path, noise_strength=20, profile="music"|"voice", spatial=True,
    declick=True, dehum=True, on_progress=…) → dict قرارداد مشترک
```
استیج‌ها: ۱ ANALYZE → ۲ REPAIR (declick + ناچ ۵۰/۶۰/۱۰۰Hz + HPF 35Hz) → ۳ DENOISE (afftdn، کِپ ۴۵dB) → ۴ DYNAMICS (leveling ملایم بدون pumping) → ۵ PROFILE EQ (کانتور music/voice) → ۶ SPATIAL (widening+Haas فقط stereo؛ **مونو هرگز fake-stereo نمی‌شود**) → ۷ MASTER (loudnorm با LUFS منبع clamp در [−35,−9] + limiter) → QA. هر استیج ffprobe-verify.

### ۵.۴ `studiomic.py` — موتور ۲: «Mic Studio» (۶ استیج، فلگ‌شیپ صدا)

```
run(path, out_path, ai_clean=70, max_quality=False, mic_profile="studio",
    proximity=60, presence=60, air=60, warmth=60, compression=60,
    target_lufs="auto"|float, declick=True, dehum=True, on_progress=…) → dict
ai_status() → {ok, resemble, noisereduce, …}   # سلامت بک‌اند AI
```
- استیج‌ها: ۱ ANALYZE → ۲ REPAIR → ۳ **AI STUDIO** (resemble-enhance: denoise عمیق + بازسازی generative CFM @44.1kHz، چانک ۳۰s در **subprocess ایزوله** = RAM سرور امن؛ fallback: noisereduce → afftdn — موتور هرگز کامل نمی‌میرد) → ۴ **MIC MODEL** (HPF 75Hz → proximity shelf → mud dip → presence bell → air shelf → de-esser داینامیک → کمپرسور ۳-باند → saturation tanh oversampled) → ۵ MASTER (گین تکراری + lookahead limiter) → ۶ QA.
- پروفایل‌های میک: studio/broadcast/podcast/vintage/natural.
- **مسیر مدل AI (v36):** `_run_dir()` — اول `green-system/models/resemble-enhance` (چیدمان خودکفا) بعد `<parent>/models/resemble-enhance` (چیدمان legacy)؛ اولین مسیری که فایل `ds/G/default/mp_rank_00_model_states.pt` (~713MB) را داشته باشد برنده. بدون مدل → fallback زنجیره‌ای (noisereduce → afftdn) و `health → resemble:false`. worker هم همین lookup را دارد (باید آینه باشند).
- **هِلپرهای DSP مشترک که enhance.py هم import می‌کند:** `_biquad _apply _butter _bandpass _blocks _rms_blocks _asym_smooth _expand _db _undb _de_ess _compress3 _saturate _soft_limit _loudness_of _ai_stage` — اینها مال این فایل‌اند؛ تغییرشان هر دو موتور را تحت تأثیر قرار می‌دهد.

### ۵.۵ `enhance.py` — موتور ۳: «ENHANCE» عامل تطبیقی v34 (۲۰۷۶ خط)

```
run(path, out_path, mode="safe"|"balanced"|"aggressive", profile="auto"|"intimate"|
    "natural"|"broadcast"|"music", ai_assist=0..100, max_quality=bool,
    intensity=0..100 (۰=dry-run تشخیص‌محض), preserve_dynamics=bool,
    keep_natural=bool, target_lufs="auto"|float, declick="auto"|"on"|"off",
    dehum="auto"|"on"|"off", on_progress=…) → dict + problems/actions/scores/gates/report
```

**زنجیرهٔ داخلی:** INGEST/VALIDATE → FORENSIC → DIAGNOSE → ADAPTIVE PLAN (ماژول‌های شرطی) → PROCESS با **re-measure بعد از هر ماژول** → KEEP/REDUCE/ROLLBACK → MASTER → ۱۰-GATE QC (+REPROCESS قابل‌اصلاح) → ۸-امتیاز → گزارش قابل‌تفسیر.

- **FORENSIC** (`_forensic` + هِلپرها): باندهای طیفی نسبی welch (rumble/body/mud/presence/air…)، headroom نویز (پاور ۱۰/۹۰ انولوپ)، خطوط هام ۵۰/۶۰ (`_hum_lines`)، sibilance فعال، roominess (انرژی pause/active)، flatness پاز (قناری musical-noise)، crest/clip/DC/LRA/LUFS، `_tf_band_rel` نقشهٔ زمان-فرکانس (بلوک ۲۵۰ms، سقف ۱۰ دقیقه) + `_spans_from_rel` → بازه‌های زمانی واقعی هر مسئله، `_breath_metrics` (نفس‌های بلند)، `_plosive_metrics` (امضای p/b pop)، `_corr` همبستگی استریو، `_st_max_db` (پنجرهٔ ۳s).
- **DIAGNOSE** (`_diagnose`) → رکوردهای ۱۷-نوع مسئله: `{problem,label,severity,confidence,freq,window,value,time_str,risk,action}` (پنجره‌های مرجع voice/music جدا). `_RISK` و `_FIX` مقدار ریسک و اقدام پیشنهادی هر مسئله را می‌دهند.
- **PLAN** (`_plan`) → ماژول‌های شرطی؛ فعال‌سازی فقط وقتی `severity×confidence ≥ آستانهٔ mode`؛ مقدار = شدت اندازه‌گیری‌شده (Minimum Effective Processing). ترتیب: dc → declick+dehum → denoise → de-reverb → tonal (2-pass) → de-ess → compressor → warmth → master؛ + breath/plosive در مسیر restore.
- **PROCESS + VERIFY** (ماژول‌های `_m_*`): هر ماژول قبل/بعد سنجیده می‌شود — denoise (AI resemble وقتی نویز واقعی + گارد speech-level + گارد flatness + گارد روشنی مصنوعی hi/air ≤ +6dB)، de-reverb (گارد انرژی فعال)، tonal (overshoot retry + بودجه EQ)، compressor (گارد transient: افت crest ≤ 3.5dB با retry نصف شدت)، warmth (بودجه THD 2.5%)، master (گین دوطرفه تکراری + alimiter). تخریب → **rollback** (اورجینال برمی‌گردد) و در گزارش ثبت می‌شود.
- **SCORES** (`_scores`) — ۸ بُعد: technical, restoration, tonal, dynamics, naturalness, artifacts, stereo, delivery (نه یک عدد واحد).
- **GATES** (`_gates`) — ۱۰ دروازه: file-integrity / technical / loudness / true-peak / dynamics / phase / stereo / spectral-artifacts / ai-artifacts / delivery → هرکدام PASS/WARN/FAIL + overall؛ FAIL قابل‌اصلاح (loudness/TP) → «reprocess» (یک re-master با ceiling −3.1dBTP و باز-سنجی).
- **قوانین Master Quality Guard** (۲۰ قانون) در docstring فایل — «DO NOTHING نتیجهٔ معتبر است»؛ dry-run (intensity=0) خروجی = عین منبع (Bypass Truth Test)؛ ai_assist=0 → deterministic.
- **قرارداد نتیجه** (فراتر از قرارداد مشترک): `problems[] actions[] scores{} gates[] report{detected,corrected,ignored,rolled_back,profile,profile_desc} stages[] qa stats stats_before verdict notes output out_id`.

### ۵.۶ `studiomic_ai_worker.py`

ورکر subprocess برای resemble-enhance — مدل سنگین در **پروسهٔ جدا** لود می‌شود (پیک ~۲.۲GB anon) و بعد از اتمام کاملاً آزاد می‌شود؛ سرور (۳۲۵MB) هرگز مدل را resident نگه نمی‌دارد. حکم: OOM-killer نگیریم.

---

## ۶. فرانت‌اند — ماژول‌های JS (به ترتیب لود)

هر ماژول IIFE است و روی `window.S` (namespace استودیو) سوار می‌شود. `$` = `getElementById`، `S.el(tag,cls,txt)`، `S.esc` (HTML-escape — همیشه برای متن کاربر)، `S.toast`، `S.err/richErr` (جعبهٔ خطا + hint)، `S.diag` (لاگ ۳۰۰تایی پایین صفحه با شمارندهٔ logs).

### ۶.۱ `core.js` (۱۷۴ خط) — پایه

`S.$ / S.el / S.state{lf,sab,stems,spkTrk,finalMode,serverUp} / S.esc / S.fb (fmt بایت) / S.fps=25 / S.tcSMPTE (HH:MM:SS:FF) / S.tcSRT (HH:MM:SS,mmm) / S.fd / S.ctx (AudioContext اشتراکی) / S.decode / S.api (قرارداد JSON سخت‌گیر) / S.jpost / S.jget / S.upl (XHR با progress) / S.richErr / S.err / S.diag / S.toast (fade ۳.2s) / heartbeat هر ۷s → hb chip online/offline / window error+unhandledrejection → S.err`.

### ۶.۲ `player.js` (۳۳۰ خط) — پلیر تایم‌لاین

`S.Player(host, {dual,labels,mini,onTick})` → `{setUrl, setBlob, setBuffer, play, stop, seek, playing, setMarkers, destroy}`. موج canvas با peaks (DPR-aware)، playhead، کلیک-to-seek، SMPTE، **dual A/B**: فلیپ سمت A⇄B موقعیت پخش sample-exact حفظ می‌شود (مقایسهٔ صادق A=اصل / B=پردازش‌شده). رجیستری `PLAYERS` — فقط یکی همزمان پخش می‌شود (`S.stopAllPlayers`).

### ۶.۳ `options.js` (۲۰۳ خط) — تنظیمات سرویس‌ها

- IDها: `workerUrl workerKey mvsepToken geminiKey geminiModel model opt1 opt2 fmt spk subsSpk` — persistence: `localStorage['studio22_opts']`؛ خالی → DEFAULTS بعد از reload.
- **DEFAULTS داخل کد** (سمت کلاینت): آدرس worker MVSEP + کلید worker + توکن MVSEP + کلید Gemini (gemini-3.5-transcribe) + model=40/opt1=81/opt2=2/fmt=0/spk=-1. **این تنها مکان کلیدهاست — سرور zero-key.**
- `S.wu() S.mvsep() S.authV() S.authH() S.mvTok()` — سازندهٔ endpoint/هدرها.
- `S.GEMINI_PROXY = 'https://gemini-proxy.maytham-saeidi.workers.dev'` (خط ۱۲۳).
- `save/load/saveOpts/mirrorToSubs` (آینه‌سازی subsSpk به مدال زیرنویس) + health-check worker (whDot + whDotMini) + verify MVSEP + `S.dlSpk`? (خیر — در msep).
- UI: `optModal` (مدال modal-lg) باز با `optBtn`؛ Esc/بک‌دراپ/Save&Close/Reset (الگوی مدال استاندارد §۹).

### ۶.۴ `msep.js` (۴۲۶ خط) — سورس + جداسازی

- `S.pn` (نام سورس برای نام فایل خروجی‌ها)؛ هِلپرهای بافر: `S.sliceAB / S.ab2wav / S.ab2mp3 (lamejs) / S.concatAB / S.cleanStemName` (تمیزکردن نام استم‌های MVSEP: حذف پیشوندهای مدل، مپ vocals→Vocals و…).
- فلو: `chooseBtn→fileInput` → **خواندن کامل explicit** (فایل قفل/cloud-placeholder اینجا خطای دقیق می‌دهد) → `S.state.sab=decode` (گارد ۹۰s) → `startBtn` فعال → upload (با fallback bytes) → MVSEP job (چانک‌بندی هوشمند ۵۴۰s با cut در نقاط ساکت، retry، polling) → دانلود استم‌ها → decode → merge → `S.state.stems` + **سپیکرها**: vocal → Gemini diarization → `S.state.spkTrk` → `S.onSeparationDone()` (mixer) و ردیف‌های Stem Studio ساخته می‌شوند.
- `S.setStat` (خط ۱۳۳) — ستون ستetusِ کارت Source.
- Cancel با AbortController؛ خطاها همیشه richErr + hint.

### ۶.۵ `studio.js` (۳۰۰ خط) — Stem Studio

- `ENGINES` (۹ موتور با نام/توضیح) + `CHAIN` + `DEFAULT_ENG`.
- ردیف‌ها: `ensureRow(key,name,kind,blob,duration,isSpk,buffer)` — key = `spk:{id}` یا `stem:{id}`؛ setInterval ۲.۵s از `S.state` خودکار populate می‌کند؛ **سپیکرها vocal عادی را جایگزین می‌کنند** (جلوگیری از دوبرابر شدن وکال در mix).
- هر ردیف: هدر (tag SPK/VOC/MUS/FX/MIX + نام + متا LUFS before→after + زنجیرهٔ موتورها) + چک‌باکس **Final ✓** + دکمهٔ WAV + بادی collapsible = پلیر dual A/B + پنل انتخاب زنجیرهٔ موتورها (چک‌باکسها به ترتیب CHAIN).
- `S.resetStudio()` — جداسازی جدید = پاک کامل ردیف‌ها (tickهای کهنه هرگز به mix نمی‌ریزند).
- `wshRun` → آپلود استم‌های بی‌سرور → `POST /api/dsp/workshop_run` → `pollJob` (۱.۵s؛ ۳ خطای شبکه = reject؛ hint مخصوص «job not found» بعد از restart) → `applyResults` (out_id/passthrough/verdict/stats به ردیف‌ها) → re-render.
- `wshMix` → آیتم‌های تیک‌خورده (`out_id` ترجیح، وگرنه `src_id`) → `POST /api/dsp/workshop_mix {items,lufs:-16,tp:-1.5}` → `S.onFinalMixDone`.
- `busyScan/busyMix` — فقط یک scan یا mix همزمان.
- خروجی‌های عمومی: `S.ensureWRow S.wshRows S.resetStudio`.

### ۶.۶ `subs.js` (۵۴۰ خط) — زیرنویس

- استانداردهای broadcast: `SUB = {MAX_LINE:42, MAX_CHARS:84, MAX_CPS:21, MIN_DUR:0.9, MAX_DUR:7.0, GAP:0.08}` (Netflix TTSG/EBU-inspired).
- **سورس‌پیکر (v29):** `subsLocalBtn` → file picker مستقیم (بدون لیست) · `subsChooseBtn` → منوی گروه‌بندی‌شده: «Separated — this session» (سورس استودیو + Final Mix + استم‌ها با **vocal اول** + سپیکرها) و «Server — uploads & engine outputs» (`/api/dsp/sources` + `S.dspOutputs()`) — **dedupe با seen{}**؛ rebuild منو **keys-guarded** (فقط وقتی محتوا/انتخاب واقعاً عوض شود — کلیک هرگز توسط re-render پس گرفته نمی‌شود). سرور-فایل: fetch → decode محلی. `userPicked` — انتخاب خودکار سورس استودیو فقط تا اولین انتخاب دستی کاربر.
- `S.geminiSend(b64,mime,numSpk)` — دو مسیر: مدل `gemini-3.5-transcribe` (native word timestamps + diarization) یا مدل‌های عمومی (prompt JSON word-array + responseSchema). خطاها: کلید نامعتبر/404 مدل/429 rate با hint دقیق. پاسخ → `normSpk` (A,B,C…) → `{speaker,startSec,endSec,text}[]`.
- `S.applySubs(ws)` → `groupCues` (شکست: تغییر گوینده/وقفه>1s/۱۴ کلمه/نقطه‌گذاری/۸۴ کاراکتر) → `normCues` (CPS/MIN/MAX/GAP) → رندر cue list + karaoke → **`VIZ.setWords(segs, name, duration)`** (اگر VIZ هنوز لود نشده: `window.__VIZ_PEND_*`) → `primeCuePlayer`.
- پلیر استیج: `S._cueP = S.Player($('subPlayerHost'),{mini,onTick:cueTick})` — Play = کل زیرنویس از موقعیت فعلی؛ `cueTick` → هایلایت ردیف cue + `karaokeTick` (کلمهٔ فعال). `OFF` = آفست همگام‌سازی کلمات (اسلایدر advanced، `S._cueOffset` — VIZ هم همین را می‌خواند).
- صادرات: `srtTxt` (۲-خطی + [Speaker]) · `vttTxt` (`<v A>`) · `txtTxt` (ترن‌های گوینده با [HH:MM:SS]) · Copy. نام فایل: `Subtitles_{S.pn بدون پسوند}.srt`.
- `subsSetModal` (مدال sm): مدل Gemini + تعداد سپیکر + کلید (آینه با Options) + اسلایدر آفست ±0.5s زنده در استیج.
- `S.fxSrcInfo()` — سورس فعلی برای export HTML (§۸).

### ۶.۷ `mixer.js` (۱۷۷ خط) — Final Mixer

`S.onSeparationDone` → حالت خاموش: `mixWait` (Locked until Final Mix + آمار + Stems ZIP/Speakers ZIP) · `S.onFinalMixDone(res)` → `mixCard` فعال: deck پخش mix + ردیف‌های per-track (پلیر تایم‌لاین / M / S / volume / WAV / MP3 با `S.ab2mp3`) + Download All ZIP (JSZip). گراف چند-ترک Web Audio: `nodes/gains/mute/solo/vol`.

### ۶.۸ `app.js` (۷۶۹ خط) — تب‌ها + کارت‌های موتور

- `TABS=['main','subs']` + `S.switchTab` — دکمه‌های `tabBtnMain/tabBtnSubs` + badge تعداد cue.
- **`OUTS`** — رجیستری خروجی‌های موتور این session `{id,label}` → `S.dspOutputs()` (منبع «engine outputs» در منوی زیرنویس) + `_labRefresh` ترکیبی (lab + enhance هر دو refresh).
- **LAB_ENGINES** (دراپ‌داون `labEngine`، پیش‌فرض studiomic): studiomic, dolby_off, clean, voice, music, fx, spatial, master. `syncMicBar`: label دکمه run (Enhance ▶ / Run Engine ▶) و دکمهٔ ⚙ (Settings/Dolby Settings/مخفی برای بقیه) با موتور عوض می‌شود.
- **labParams()** (Dolby: noise/profile/spatial/declick/dehum) · **micParams()** (۱۲ پارامتر) · **enhParams()** (۱۲ پارامتر) — هرکدام `S._labParams/S._micParams/S._enhParams` صادر می‌شوند.
- **پریست‌ها:** Dolby `PRESETS{music,voice,rescue,maxclean,raw}` · Mic `MIC_PRESETS{podcast,broadcast,intimate,natural,maxclean}` · Enhance `ENH_PRESETS{adaptive,deep,gentle,bcast,music,dry}` — دکمه‌های `data-preset` داخل مدال.
- **Persistence:** `localStorage['studio32_mic']` و `localStorage['studio33_enh']` (JSON کامل پارامترها؛ load → applyPreset با DEFAULTS merge).
- **Run handler** (`labRunBtn`): params بر اساس موتور → `POST /api/dsp/run` → poll ۱.۵s (status در `micStatus` + progress `labBar`) → نتیجه → OUTS push + buildEngineCard (Mic Studio) / buildDolbyCard (Dolby) / پلیر ساده (بقیه).
- **enhRunBtn** — مسیر موازی مخصوص Enhance: upload اختصاصی (`enhFile`→`enhUpBtn`)، status زندهٔ عامل در `enhStatus`، بعد از اتمام → `buildEnhanceCard(res, srcSid)`.
- **کارت سازها:** `buildEngineCard(res,srcSid,title,fname)` — caption (QA chip + Download WAV) + پلیر dual A/B + markerBar (fetch `/api/dsp/analyze` → legend + آیتم‌های کلیک‌پذیر → seek) + پنل: statBox(قبل/بعد) + qaBox + beforeAfter + decisionTable|micDecisionTable + stageList. `buildEnhanceCard` — فراتر: problemsTable (sevbar رنگی + conf + risk + window + fix + time_str) + actionsTable (WHY/WHAT/HOW MUCH/RESULT + chip kept/kept-reduced/rolled-back/no-problem) + scoresPanel (۸ بُعد sc-grid) + gatesTable (۱۰ دروازه PASS/WARN/FAIL) + stageList + statBoxes.
- کلید `Space` روی body فقط preventDefault (پلیرها کل خودشان را دارند).

---

## ۷. `index.html` (۷۹۶ خط) — ساختار SPA

سلسله‌مراتب و **همهٔ IDهای مهم**:

```
topbar:  brand · tabBtnMain · tabBtnSubs(+tabSubsBadge) · hb/hbTxt (heartbeat) · diagBtn/diagCount
tabMain:
  Source card:            chooseBtn startBtn cancelBtn fileInput srcPlayer fileInfo fileMeta filePlan status bar
  optbar-card:            optBtn (⚙ Separation & Services) + whDotMini
  micbar-card (MIC STUDIO): labEngine (select موتور) · micAiChip · labSource · labUpBtn ·
                           micSrcName · micSetBtn (⚙) · labRunBtn (Enhance ▶) · micStatus ·
                           labBar · labOuts · labFile (input hidden)
  enhbar-card (ENHANCE):  enhAiChip · enhSource · enhUpBtn · enhSrcName · enhSetBtn ·
                           enhRunBtn · enhStatus · enhBar · enhOuts · enhFile
  wshSection (Stem Studio): wshCount wshList wshRun (Scan & Fix All) wshMix (Final Mix) wshBar wshError
  results:                mixWait (wshGoStem dlStems dlSpk mixWaitStats) · mixCard (trackCount
                          mixPlayAll mixStopAll dlAll mixDeck mixRows)
tabSubs:
  subbar:                 subsLocalBtn · subsChooseBtn (Separated ▾) · subsSrcName · subsGemBtn ·
                          subsAdvBtn (⚙ Advanced) · subsSrcMenu (absolute) · subsGemStatus ·
                          subsGemBar · subsFileInput
  subSection (stagecard): vizWrap → vizStage (viz-hud: vhName vhFam · viz-tools: vizShot vizFull) +
                          subPlayerHost
  fxstudio card:          fxTabF/fxTabS (تب FX Themes/Systems) → fxPanel:
                          fxThemes · fxEngine (css|3d) · fxGlow · fxChips (entrance) · fxDir ·
                          fxSpeed · fxWmode (word|line) · fxOneline · fxPos (bottom|center) ·
                          fxDepth · fxSize (S/M/L/XL) · fxPoolIn/fxPoolAdd/fxPoolClear/fxPoolCount ·
                          fxEmph (burst|pulse|glow|flip) · fxEmphI · fxPoolChips
                          sysPanel (مخفی): vizRail vizPdots vizScale vizMotion vizFx vizReact
  listcard:               vwCue/vwKar (تب) · subCount · copySub dlHtml dlSrt dlVtt dlTxt ·
                          subList · karaokeBox
جعبه‌ها:                   errBox (errTitle errMsg errHint errClose) · diagPanel (diagLive diagBody
                          diagClear diagClose) · toast · liveCap
مدال‌ها (§۹):             optModal · micSetModal · enhSetModal · setModal (Dolby One) · subsSetModal
اسکریپت‌ها (?v=34):       core → player → options → msep → studio → subs → mixer → app →
                          viz/boot.js (type=module)
```

---

## ۸. زیرسیستم VIZ — استیج زیرنویس + FX STUDIO

- **ورود:** `viz/boot.js` (ES module) — `core → dom → canvas → fx → fxpanel → fxexport → ui` و `gl.js` **lazy** (پس‌زمینه؛ اگر GL نبود فقط Systems-WebGL خاموش می‌شود).
- **`window.VIZ`** (core.js): registry رندررها با اینترفیس یکسان `mount/setModel/applyParams/frame/resize/snapshot/dispose` · مدل کلمات با progress پیوسته ۰..۱ · motion tokens (`VIZ.MO`) · `VIZ.setWords(segs,name,dur)` · `VIZ.setEngine('fx'|'3d'|…)` · prefers-reduced-motion رعایت می‌شود · DPR کپ · رندر فقط وقتی visible.
- **فلسفه:** caption باید اول «خوانا» باشد (contrast gate، سقف وزن) بعد جذاب.
- **سیستم‌ها (تب Systems، ۱۶ پریست آرت‌دایرکت‌شده):** Canvas2D: Clean Karaoke (Mint/Amber/Ice) · Short-form Social (Lemon/Mint/Coral) · Technical HUD (Phosphor/Amber/Cyan) · Experimental 3D (Ivory/Ice/Clay) — WebGL (gl.js): Metal (Chrome/Gold/Obsidian) · Particles Words · Holo و … .
- **FX Themes (fx.js — ۱۰ تم مدرن):** Viral Bold · Neon Cyber · Chrome 3D · Fire · Candy Pop · Box Caption · Hacker · Y2K Holo · VHS Tape · Aurora Glass. `FXCSS` صادرشده = منبع واحد استایل استیج **و** خروجی HTML.
- **Entrance FX:** pop · slide · zoom · flip · spin · blur · type · wave · cut + **Direction پد ۸-جهته** (nw/n/ne/w/c/e/sw/s/se) + Speed.
- **Modeها:** Word/Line · **One-line** (تک‌خطی auto-fit پایین صفحه — کل‌صفحه‌ی جایگزین) · Position bottom/center · 3D depth اسلایدر · Size S/M/L/XL · **Word Pool** (کلمات خاص → افکت ویژه لحظهٔ گفته‌شدن) · Emphasis (burst/pulse/glow/flip) + Intensity.
- **fx3d.js (موتور 3D واقعی):** three.js r169 + شیدرهای سفارشی GLSL (fill sweep کلمه، gradient lit، ember flicker، chroma fringe، scanlines) + **اگزتروشن واقعی** (عمق stack پلین‌ها) + UnrealBloomPass per-theme + ورود در فضای 3D (slide 8-way/flip/spin/zoom/wave/type) + **Word Pool: pop به سمت دوربین + طلایی + انفجار پارتیکل GPU** + RTL آینه‌ای (فارسی) + یک‌خطی + پس‌زمینهٔ گرادیان GLSL + DPR کپ ۱.۷۵ + dispose کامل.
- **fxexport.js:** خروجی **HTML مستقل** — MP3 data-URI + کلمات JSON + همان FXCSS + رانتایم فشرده → دابل‌کلیک = پخش با کارائوکه در هر مرورگری.
- **viz/ui.js:** snapshot PNG استیج (`vizShot`).

---

## ۹. الگوی مدال استاندارد (۵ مدال، الگوی واحد — قانون پروژه)

```
HTML: <div id="xModal" class="modal hidden"> <div class="modal-bg"></div>
      <div class="modal-card [modal-lg|modal-sm]"> modal-head(+xModalClose ×)
      modal-body (بخش‌ها: lset-head + labset/preset-row/mic-profiles/lset-specs)
      modal-foot (xLive + xReset + xApply) </div></div>
JS:   open  → classList.remove('hidden') + sync مقادیر
      close → classList.add('hidden') + toast('applied — '+خلاصه)
      بک‌دراپ → listener: e.target===modal || e.target.classList.contains('modal-bg') → close
                (⚠️ فقط e.target===modal بدون چک modal-bg → کلیک داخل کارت بسته می‌شود — باگ تاریخی)
      Esc → keydown listener (شرط !hidden)
      Apply/Reset/Close هرکدام onclick جدا
      هر کنترل: input+change → updVals()+save() (live + persistence)
```

مدال‌های فعلی: `optModal` (سرویس‌ها/کلیدها/الگوریتم MVSEP) · `micSetModal` (۵ پریست + AI + میک‌مدل ۵ اسلایدر + LUFS + declick/dehum + ۸ spec) · `enhSetModal` (۶ پریست + mode + profile + AI/intensity + constraints + LUFS + declick/dehum سه‌حالته + ۱۴ چیپ گارد) · `setModal` (Dolby: ۵ پریست + ۵ پارامتر + ۹ spec) · `subsSetModel→subsSetModal` (مدل/سپیکر/کلید/آفست).

---

## ۱۰. داده‌ها، وضعیت و persistence

| مخزن | کلید/پattern | محتوا | ماندگاری |
|---|---|---|---|
| localStorage | `studio22_opts` | کلیدها+تنظیمات سرویس‌ها | مرورگر، همیشگی |
| localStorage | `studio32_mic` | پارامترهای کامل Mic Studio | مرورگر |
| localStorage | `studio33_enh` | پارامترهای کامل Enhance | مرورگر |
| سرور in-mem | `SOURCES` | id→{path,name,kind,engine,stats} | تا restart (بعدش disk-recovery §۳.۳) |
| سرور in-mem | `JOBS` | job_id→Job (state/progress/logs/result) | تا restart |
| دیسک | `data/uploads/{uuid12}{ext}` | فایل کاربر | ماندگار |
| دیسک | `data/outputs/{engine}_{id10}.wav · wsh_… · mix_…` | خروجی‌ها | ماندگار |
| کلاینت in-mem | `OUTS` (app.js) | {id,label} خروجی‌های session → منوی زیرنویس | تا reload (بعدش از /sources می‌آید) |
| کلاینت in-mem | `S.state.{lf,sab,stems,spkTrk}` | سورس + استم‌های decode شده | تا reload |

---

## ۱۱. اینوارینت‌های ساختاری (هرگز نشکن)

1. **قرارداد JSON مطلق:** هیچ endpointی هرگز HTML برنمی‌گرداند؛ هر خطا `{ok:false, reason}`.
2. **قرارداد نتیجهٔ موتور:** `{ok, verdict, engine, qa, stats, stats_before, stages, decision?, output, out_id?, notes, problems?/actions?/scores?/gates?/report?}` — UI کارت‌سازها به این تکیه می‌کنند.
3. **اصل فایل هرگز overwrite نمی‌شود** — همهٔ موتورها روی کپی تمپ می‌کارند؛ خروجی فایل جدید است.
4. **QA gate دور هر موتور** (`analysis.qa_gate`) — fail → خروجی حذف + ok:false.
5. **دو موتور Dolby One و Mic Studio + جداسازی/Gemini** — طبق تأیید صریح کاربر «دست نزن»؛ Enhance موتور سوم **اضافه** شده، جایگزین نیست.
6. **مونو هرگز fake-stereo نمی‌شود**؛ voice center-lock.
7. **کلاینت-only keys:** سرور هیچ کلیدی ندارد؛ MVSEP/Gemini/Worker فقط در options.js + localStorage.
8. **بامپ `?v=`** بعد از هر تغییر استاتیک (فعلاً ۳۴؛ ۱۱ جا: ۲ css + ۹ اسکریپت) — وگرنه کش کهنه.
9. **Load order اسکریپت‌ها** (core→player→options→msep→studio→subs→mixer→app→viz/boot module) — وابستگی‌های S.* به این ترتیب حساس‌اند.
10. **بک‌دراپ مدال** باید شامل چک `modal-bg` باشد (§۹).
11. **Polling ۱.۵s** با ۳-خطای-شبکه tolerance؛ آپلود/پردازش طولانی → timeout سخاوتمندانه.
12. **Stem Studio: جداسازی جدید → resetStudio()** (ردیف‌های کهنه هرگز به mix نمی‌ریزند).
13. **sephخاتم لود VIZ:** subs.js قبل از VIZ ممکن است آماده شود → پل `__VIZ_PEND_*` باید حفظ شود.
14. **سپیکرها vocal ساده را در Stem Studio جایگزین می‌کنند** (mix دوبرابر ممنوع).
15. **AI در subprocess ایزوله** (studiomic_ai_worker) — مدل هرگز در RAM سرور resident نمی‌شود.

---

## ۱۲. واژه‌نامهٔ سریع

- **استم (stem):** خروجی جداسازی (Vocals/No Vocals/Drums/Bass/…) — `S.state.stems`
- **سپیکر-ترک:** خروجی diarization گوینده‌ها — `S.state.spkTrk`
- **pass-through:** استم بدون موتور — اصل مستقیم به mix می‌رود (`out_id=src_id`)
- **A/B:** پلیر دو-سورسی با حفظ sample-exact موقعیت — مقایسهٔ صادق قبل/بعد
- **dry-run:** `intensity=0` در Enhance = فقط تشخیص، خروجی عین منبع
- **rollback:** ماژول نتایج را خراب کرد → خروجی ماژول دور ریخته، اصل برمی‌گردد، در گزارش ثبت می‌شود
- **gates / scores:** ۱۰ دروازهٔ QC و ۸ بُعد امتیاز — فقط Enhance
- **marker:** ناحیهٔ silence/quiet/loud/clip روی تایم‌لاین (`/api/dsp/analyze`)
- **Word Pool:** کلمات خاص کاربر → افکت ویژه (طلایی+پارتیکل) لحظهٔ گفته‌شدن در FX 3D

---

*این فایل با نسخهٔ v36 (خودکفا: engines/ داخل پروژه، بدون audio-studio/docs) همگام است. بعد از هر تغییر ساختاری (فایل جدید/endpoint جدید/ID جدید) این نقشه و SKILL کنترل را هم به‌روز کنید — قانون worklog همین است.*

---

## 🆕 v38 — موتور چهارم: Studio Max (ترکیب قوی‌ترین AIها)

| فایل | نقش |
|---|---|
| `engines/studiomax.py` | ارکستراتور موتور ۴ — زنجیرهٔ ۸+۱ مرحله‌ای: ANALYZE → **AI SPLIT** (Demucs زیرپروسه) → **AI RESTORE** (Apollo زیرپروسه، chunk با overlap-add) → **AI VOICE** (فراخوانی `studiomic.run` روی استم وکال، پروفایل natural) → POLISH (HPF/warmth/exciter/width در numpy) → REMIX (amix) → SPATIAL (Haas+M/S) → MASTER (loudnorm+alimiter، 48k/24bit) → QA GATE. ماژول‌های تیک‌پذیر: `split/restore/voice/polish/spatial/master` + مقادیر `restore%`, `voice%`, `width×`, `lufs`. |
| `engines/studiomax_worker.py` | زیرپروسه‌های ایزولهٔ AI برای بهداشت RAM: `split` (Demucs، variant خودکار htdemucs_ft اگر باشد)، `restore` (Apollo با پیشرفت خطی PROG)، `fetch` (دانلود از HF داخل کش اپ). سرور هرگز torch را import نمی‌کند. |
| `engines/apollo_model/` | کد وندور مدل Apollo (Kai Li, Yi Luo — Tsinghua/Tencent AI Lab، arXiv:2409.08514، CC BY-SA 4.0): `apollo.py` (تعریف مدل)، `base_model.py` (from_pretrain بدون hub-mixin)، `LICENSE-APOLLO.txt`. فقط-خواندنی. |
| `engines/catalog.py` | +۱ موتور → ۱۰ موتور / ۴۶ ماژول تیک‌پذیر: `studiomax` با ۶ فعالیت. |

**endpointهای جدید/تغییر یافته (v38):**
- `GET /api/model/status` — فیلد `models` جدید: dict چهار مدل `{resemble, apollo, demucs, demucs_ft}` با `present/size_mb/url/downloading`؛ فیلدهای قدیمی (present/size_mb برای resemble) حفظ شدند (سازگاری v37).
- `POST /api/model/ensure` — body `{model: "resemble"|"apollo"|"demucs"|"demucs_ft"}`؛ خالی/جاافتاده = resemble (سازگاری v37). apollo/resemble با urllib مستقیم؛ demucs با worker `fetch` + پیشرفت از رشد کش.
- `GET /api/dsp/health` — بلوک `studiomax_ai` جدید (torch/demucs_pkg/demucs/demucs_ft/apollo/resemble).
- `studiomax` در `ENGINE_NAMES`، `CHAIN_ENGINES` (زنجیرهٔ workshop) و dispatchهای `dsp_run`/`_run_engine_one`.

**UI (v38):** ردیف «AI models — auto-download from HuggingFace» در کارت Mic (`#aiModelsRow`): دکمهٔ هر مدل فقط وقتی غایب است + chip سبز «Studio Max AI ready» وقتی هر سه هست؛ studio.js: `studiomax` در ENGINES/CHAIN (پنل ۶-ماژولی از کاتالوگ خودکار رندر می‌شود)؛ app.js: ماژول `modelPanel`. همهٔ تگ‌ها `?v=38`.

**مدل‌ها و discovery:** `models/` (اپ-محلی، داخل بستهٔ full) اول، `../models/` دوم — `HF_HUB_CACHE` به `models/demucs_hf` پین می‌شود قبل از هر import هاب (در studiomax و studiomax_worker هر دو).

*این نقشه با v38 همگام است. قانون آخر: هر تغییر ساختاری → هر دو اسکیل به‌روز شوند.*
