---
name: green-system-control
description: راهنمای کنترل مطلق پروژهٔ Audio Studio (green-system) از صفر تا صد — اجرا/توقف/ریستارت سرور، سلامت‌سنجی، دیباگ، تست کامل (engine/e2e/UI/VLM)، دستورالعمل‌های گام‌به‌گام برای هر نوع تغییر (موتور جدید، پارامتر، مدال، پریست، endpoint، تم FX)، اینوارینت‌هایی که هرگز نباید شکست، مدیریت RAM، چک‌لیست انتشار و همهٔ دام‌های شناخته‌شدهٔ تاریخی. هر هوش مصنوعی که این اسکیل را بخواند می‌تواند پروژه را کامل اجرا، عیب‌یابی، توسعه و منتشر کند. پیش‌نیاز فهم ساختار: SKILL «green-system-structure».
language: fa
---

# 🎛️ کنترل مطلق green-system — صفر تا صد

> **این فایل چیست؟** کتاب عملیاتی. با SKILL ساختار (green-system-structure) که بدانی «چه خبره»، این فایل بهت قدرتِ «هر کاری که بخواهی» را می‌دهد: اجرا، تست، دیباگ، تغییر، توسعه، انتشار. همهٔ دستورها آزموده و از تاریخ واقعی پروژه آمده‌اند.

---

## ۱. مرجع سریع فرمان‌ها (کپی-پیست)

```bash
# سرور
cd /home/z/my-project/green-system
./start.sh status                # آیا زنده است؟ (pid از daemon.pid)
./start.sh start                 # دایمن nohup → daemon.log
./start.sh stop                  # kill + حذف pid
./start.sh restart               # stop + 1s + start (بعد از هر تغییر بک‌اند/استاتیک)

# سلامت (بعد از استارت همیشه این ۳ تا)
curl -s http://127.0.0.1:3000/healthz                 # {"status":"green-system+dsp"}
curl -s http://127.0.0.1:3000/api/dsp/health          # engines همه true + studiomic_ai
tail -20 daemon.log                                   # بدون traceback

# لاگ زنده
tail -f green-system/daemon.log

# python درست (مهم!) — سرور باید با همین اجرا شود (start.sh خودش انتخاب می‌کند)
~/.venv/bin/python3    # venv با flask+numpy+scipy+noisereduce+resemble_enhance
python3                # فقط flask/numpy/scipy/noisereduce (بدون resemble)

# تست‌ها (همه از /home/z/my-project)
python3 scripts/v34_engine_test.py       # ۲۸ تست هستهٔ Enhance مستقیم (بدون سرور)
python3 scripts/v34_e2e_test.py          # ۱۹ تست E2E روی سرور زنده
python3 scripts/v34_ui_test.py           # ۱۸ تست Playwright UI (سرور باید زنده باشد)
node scripts/vlm_v34.js                  # چشمی VLM glm-4.5v (اسکرین‌شات → قضاوت)
```

---

## ۲. محیط اجرا — فکت‌ها

| جزء | مقدار/مسیر | نکته |
|---|---|---|
| venv | `~/.venv` (python3) | flask≥3.0 · requests · numpy==2.1.3 · scipy · noisereduce · **resemble_enhance** |
| FFmpeg/ffprobe | سیستم PATH | بدون آن هیچ موتوری کار نمی‌کند |
| Node | برای Playwright + اسکریپت‌های VLM | `scripts/node_modules` آماده است |
| Playwright | browser نصب‌شده | تست UI با `chromium` |
| VLM | `z-ai-web-dev-sdk` با `createVision()` | ⚠️ `create` نیست — `createVision` (خطای تاریخی) |
| مدل resemble | `green-system/models/resemble-enhance/` (خودکار؛ fallback: `<parent>/models/` legacy) | فایل `ds/G/default/mp_rank_00_model_states.pt` (~713MB)؛ `_run_dir()` پیدایش می‌کند؛ worker جدا |
| پورت | 3000 | کلاینت + همهٔ تست‌ها همین را صدا می‌زنند |
| RAM سرور | ~۳۲۵MB پایدار | مدل AI هرگز resident نمی‌شود (subprocess)؛ پیک worker ~۲.۲GB |

**قانون اجرای بک‌اند:** `start.sh` اول `~/.venv/bin/python3` را امتحان می‌کند بعد `python3`. اگر venv خراب شد، resemble (Mic Studio/Enhance-AI) سالم fallback می‌کند (noisereduce→afftdn) — یعنی همه‌چیز می‌ماند «کار می‌کند» ولی کیفیت AI کم می‌شود؛ `/api/dsp/health` → `studiomic_ai.resemble:false` را نشان می‌دهد.

---

## ۳. Runbook — اجرا و تأیید

```
۱. cd green-system && ./start.sh restart
۲. sleep 2 && curl /healthz          → status ok
۳. curl /api/dsp/health              → engines: local/dolby_off/studiomic/enhance=true
۴. مرورگر: http://127.0.0.1:3000/    → هدر «server online» + console بدون خطا
۵. tail -30 daemon.log               → فقط request 200ها
```

**اگر بالا نیامد:**
```
tail -40 daemon.log        # traceback آخر را بخوان — معمولاً ImportError یا پورت اشغال
ss -ltnp | grep 3000       # پورت آزاد است؟
kill -9 $(cat daemon.pid)  # اگر پروسهٔ زامبی مانده؛ بعد ./start.sh start
```

---

## ۴. Playbook تست — سه لایه + چشمی

### ۴.۱ لایهٔ موتور (بدون سرور — سریع‌ترین)
مستقیم `engines/enhance.run(...)` را روی فایل سینتتیک صدا می‌زند و قرارداد نتیجه را می‌سنجد (از داخل پوشهٔ green-system import کن: `from engines import enhance`).
- نمونه‌های موجود: `scripts/v34_engine_test.py` (۲۸/۲۸) · `scripts/test_enh_engine.py` · `scripts/test_studiomic.py` · `scripts/test_dolby_off.py` · `scripts/gen_enh_test.py` (سازندهٔ فایل سینتتیک: نویز+هام+boom/mud/dark+کلیپ).
- **الگو:** بساز ورودی بد → run → assert روی `problems/actions/scores/gates/report/verdict` → assert بypass-truth (dry-run = byte-identical) → assert determinism (دو dry-run یکسان).

### ۴.۲ لایهٔ E2E (سرور زنده — HTTP خالص)
آپلود واقعی → run → poll → نتیجه → دانلود. `scripts/v34_e2e_test.py` (۱۹/۱۹) الگوست:
```python
r=requests.post(URL+'/api/dsp/upload',files={'file':open(wav,'rb')}).json()
j=requests.post(URL+'/api/dsp/run',json={'src_id':r['id'],'engine':'enhance','params':{...}}).json()
for _ in range(60):                     # polling تا ~۹۰s (نویز سنگین/فایل بلند بیشتر)
    job=requests.get(URL+'/api/dsp/job/'+j['job_id']).json()['job']
    if job['state'] in ('done','error'): break
    time.sleep(1.5)
assert job['state']=='done' and job['result']['ok']
```
**قانون:** فایل ~۳.۵MB آپلودش ~۳s طول می‌کشد؛ polling را حداقل تا ۳۰s ادامه بده؛ هرگز timeout کوتاه نگذار.

### ۴.۳ لایهٔ UI (Playwright — سرور زنده)
`scripts/v34_ui_test.py` (۱۸/۱۸) الگوست:
```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))   # صفر خطای JS الزامی
    pg.goto('http://127.0.0.1:3000/')
    pg.click('#enhSetBtn'); pg.wait_for_selector('#enhSetModal:not(.hidden)')
    pg.click('[data-preset="deep"]'); ... assert ...
    pg.screenshot(path='shot.png')                             # بعدش VLM
    assert not errs
```
- تست‌های حساس: باز/بستن هر ۵ مدال (Esc + بک‌دراپ)، پریست‌ها، persistence (reload بعد از set → مقادیر مانده)، اجرای واقعی موتور با polling، **موبایل ۳90×844 بدون overflow افقی**، دست‌نخوردگی دو موتور دیگر.

### ۴.۴ لایهٔ چشمی (VLM)
`scripts/vlm_v34.js` — اسکرین‌شات → `createVision()` (glm-4.5v) → prompt: «آیا X دیده می‌شود؟ عیب بصری؟» → PASS/FAIL. برای: مدال‌ها، کارت گزارش، گرید امتیاز، موبایل. خروجی PNG در `download/`.

### ۴.۵ قانون طلایی تست
هیچ تغییری بدون تست همان لایهٔ مرتبط commit/بسته نمی‌شود:
- فقط بک‌اند → لایهٔ ۱+۲ · UI یا JS → لایهٔ ۳ (+۴ برای چیدمان) · قرارداد API → همه.

---

## ۵. Playbook دیباگ

### ۵.۱ ابزارها (همیشه در دسترس)
1. **جعبهٔ خطای UI** (`errBox`) + `S.err` — هر خطای ساختاریافته با `hint` دقیق. متن hint دقیقاً می‌گوید چه شود.
2. **Diagnostic Log** — دکمهٔ «N logs» پایین هدر: هر fetch با status/duration/بادی ۲۲۰ کاراکتری. **اولین جای نگاه** وقتی چیزی کار نمی‌کند.
3. **daemon.log** — هر request + traceback کامل کریشهای Thread (crash: … + آخرین ۸۰۰ کاراکتر).
4. **Console مرورگر** — `[studio vNN]` پیام بوت + خطاهای JS (window error hook خودشان را به errBox می‌آورند).
5. **`job.logs`** — در پاسخ poll: استیج‌های واقعی موتور با timestamp.

### ۵.۲ جدول علائم (تاریخ واقعی)

| علامت | علت رایج | درمان |
|---|---|---|
| «server offline» در هدر | serve.py مرده/پورت | `./start.sh restart` → لاگ |
| «Unexpected token '<'» | endpoint خطای HTML داده | غیرممکن در کد سالم — یعنی errorhandler دور زده شده؛ مسیر API را چک کن |
| «source not found» در run | سرور restart شده، id کهنه | خودکار درمان می‌شود (disk-recovery)؛ اگر نشد F5 + انتخاب دوباره |
| «no stems — process and tick» | تب قدیمی post-restart | F5 → re-scan؛ _entry از دیسک برمی‌گرداند |
| Enhance/Mic خیلی کند (۹۰s+) | resemble با nfe64 (max_quality) یا فایل بلند | طبیعی است؛ status زنده stage را نشان می‌دهد؛ nfe16 = ۴× سریع‌تر |
| worker AI کشته شد (OOM) | فایل خیلی بلند | خودکار fallback noisereduce؛ چانک ۴s/۸s در worker؛ اگر تکرار شد فایل را ببُر |
| `resemble:false` در health | venv/مدل خراب | `~/.venv/bin/pip install resemble-enhance` → restart |
| مدال با کلیک داخل کارت بسته می‌شود | چک backdrop ناقص | باید: `e.target===modal \|\| e.target.classList.contains('modal-bg')` |
| JS کهنه بعد از تغییر | کش مرورگر | `?v=` بامپ (§۶-R5) — no-cache کمک می‌کند ولی v الزامی است |
| کرش فقط با ورودی خاص (rumble زیاد…) | `None` در f-string | الگوی v34: `win_str` با −∞ برای None — هر جا فیلد اختیاری fmt می‌شود گارد بگذار |
| خطای شبکه در poll | restart حین job | poll ۳ خطا = رد؛ UI hint «job lost» می‌دهد |

### ۵.۳ دیباگ بک‌اند سریع
```bash
# اجرای مستقیم با لاگ روی ترمینال (بدون دایمن)
cd green-system && ~/.venv/bin/python3 serve.py
# تست تک-ماژول
~/.venv/bin/python3 -c "import sys; sys.path.insert(0,'.'); from engines import enhance; print(enhance.run('a.wav','b.wav',intensity=0)['report'])"
```

---

## ۶. دستورالعمل‌های تغییر (Recipes) — قلب کنترل

> قبل از هر Recipe: فایل هدف را کامل بخوان، بعد SKILL ساختار §مرتبط، بعد تغییر، بعد تست همان لایه، بعد §۸ انتشار.

### R1 — افزودن موتور جدید (کامل، ۷ گام)
۱. **هسته:** `engines/motor_jadid.py` — قرارداد `run(path, out_path, ..., on_progress)→dict` (قرارداد §۵ SKILL ساختار). الگو: `dolby_off.py` (ساده) یا `studiomic.py` (با AI worker). **مقدارها را خودت clamp کن**؛ QA با `analysis.qa_gate`؛ استیجها `on_progress("NAME: …", pct)`؛ خطاها هرگز raise خام — `{ok:false, reason}`. ماژول را در `engines/__init__.py` هم ثبت کن.
۲. **serve.py:** import بالای فایل + `ENGINE_NAMES["motor_jadid"]="…"` + تابع `_run_motor_jadid` (با `_clamp`) + دو شاخه در `dsp_run.fn` و `_run_engine_one` + (اختیاری) `_chain_params` + `CHAIN_ENGINES` + health.
۳. **index.html:** کارت جدید الگوی `enhbar-card` (select سورس + Upload + name + ⚙ + Run + status + progress + outputs + input hidden) یا افزودن به `LAB_ENGINES` در app.js اگر ساده است. مدال تنظیمات اگر پارامتر دارد (R4).
۴. **app.js:** wiring — selector refresh مشترک `OUTS` (`S._labRefresh` را wrap کن مثل v33: `_origLabRefresh` الگو)، `params()` + `S._xParams`، پریست‌ها، persistence `localStorage['studioXX_x']`، run handler با polling، کارت نتیجه (`buildEngineCard` یا سازندهٔ اختصاصی مثل `buildEnhanceCard`).
۵. **studio.js:** اگر در زنجیره Stem Studio می‌آید → `ENGINES` + `CHAIN` (+`DEFAULT_ENG`).
۶. **CSS:** بلاک نسخه‌دار جدید در studio.css (کلاس‌های `xbar-card` …) — بکگراند/استایل کلی دست‌نخورده.
۷. **تست + انتشار:** سه لایه §۴ + §۸.
⚠️ قانون پروژه: **موتورهای موجود Dolby One / Mic Studio / جداسازی / Gemini دست نمی‌خورند** — موتور جدید «اضافه» است.

### R2 — افزودن پارامتر به موتور موجود
مسیر کامل: هسته (امضا+clamp+استفاده) → serve.py (`_run_x` آن را بخوان و clamp کند) → index.html (کنترل در مدال مربوط با id یکتا) → app.js (`xParams()` + `xUpdVals` + persistence شامل کلید جدید + `xApplyPreset` مقدارش را بدهد) → تست: مقدار غیرپیش‌فرض → نتیجه فرق کند → persistence بعد reload.

### R3 — افزودن پریست
app.js: به `ENH_PRESETS/MIC_PRESETS/PRESETS` کلید+مقادیر کامل اضافه کن → index.html: `<button data-preset="key">` در `#enhPresets/#micPresets/#setPresets` → تست کلیک پریست → خلاصهٔ زنده (`xSetLive`) درست شود → reload → پریست اثرش مانده (تست لایه ۳).

### R4 — ساخت/تغییر مدال (الگوی مقدس — از آن منحرف نشو)
همان §۹ SKILL ساختار: HTML سه‌لایه (modal/modal-bg/modal-card[+modal-lg]) + head(+`xClose ×`)/body/foot(`xLive`+`xReset`+`xApply`)؛ JS: open/close/Esc/**چک بک‌دراپ با هر دو شرط**/هر input+change→save. تست: باز، کلیک داخل کارت (نباید بسته شود)، کلیک بک‌دراپ (باید بسته شود)، Esc، Apply→toast، مقادیر→موتور، reload→مانده.
⚠️ تنظیمات اینلاین در کارت ممنوع — همیشه ⚙ + مدال (تصمیم v28/v32).

### R5 — بامپ نسخه (بعد از هر تغییر استاتیک)
index.html — همهٔ ۱۱ جا: `studio.css?v=NN` · `viz.css?v=NN` · ۸ اسکریپت کلاسیک + `viz/boot.js?v=NN`. NN = نسخهٔ قبل + ۱ (فعلاً ۳۵ بعدی). کنسول پیام `[studio vNN]` در app.js آخر فایل هم آپدیت شود. بدون این، کاربر کد کهنه می‌بیند.

### R6 — endpoint جدید در serve.py
```
@app.post("/api/dsp/…")  def dsp_…():
    body=request.get_json(silent=True) or {}      # هرگز بدون silent نیست
    …validate + _entry() با گارد traversal…
    jid=start_job("kind", fn, label=…)            # سنگین؟ حتماً Job
    return jsonify({"ok":True,"job_id":jid})
```
خطا: `jsonify({"ok":False,"reason":…}),400` — هرگز string خام. تست لایهٔ ۲ (چک ok/reason/هر دو مسیر خروج).

### R7 — افزودن تم/FX به VIZ
- تم CSS جدید: fx.js → به لیست تم‌ها `{id,name,family,engine:'fx',…}` + استایل در `FXCSS` (چون export همین را می‌سازد) → fxpanel خودش چیپ می‌سازد.
- افکت ورود جدید: `ENTRANCES` در fxpanel.js + پیاده‌سازی در fx.js (CSS) و در صورت 3D در fx3d.js (three.js).
- سیستم Canvas/GL جدید: canvas.js یا gl.js با اینترفیس ۸تایی `mount/setModel/applyParams/frame/resize/snapshot/dispose` + ثبت در registry core.js.
- تست: لایه ۳ (چیپ کلیک → stage تغییر) + VLM اسکرین‌شات + export HTML باز شود و همان تم را بدهد.

### R8 — تغییر عامل Enhance (مسئله/ماژول/گیت جدید)
- **نوع مسئلهٔ جدید:** `_diagnose` رکورد کامل `{problem,label,severity,confidence,freq,window,value,time_str,risk,action}` + مقدار `_RISK/_FIX` → (اگر قابل‌اصلاح) ماژول `_m_x` با verify → `_plan` شرط فعال‌سازی → تست سینتتیک مخصوص (gen مثل `_breath_metrics`/`_plosive_metrics`).
- **گیت جدید:** `_gates` لیست + منطق PASS/WARN/FAIL (+ «reprocess» اگر قابل‌اصلاح) → UI در `gatesTable` خودش رندر می‌شود.
- **امتیاز جدید:** `_scores` (حالا ۸ بُعد) + NAMES در `scoresPanel` (app.js).
- ⚠️ هر ماژول جدید **حتماً verify + rollback path** داشته باشد — این هویت موتور است (۱.txt).

### R9 — تغییر CSS
بلاک جدید با کامنت نسخه (مثل `/* v33 enhance */`) در **انتهای** studio.css/viz.css — بکگراند و استایل‌های کلی دست‌نخورده (تصمیم صریح کاربر). بعد: R5. تست: VLM + موبایل overflow.

### R10 — تست جدید نوشتن
از نزدیک‌ترین اسکریپت موجود **کپی** کن (v34_* جدیدترین الگوها): سرآیند `#!/usr/bin/env python3`، شمارندهٔ PASS/FAIL، exit code، خروجی واضح. برای UI: الگوی `sync_playwright` + pageerror-collector + polling ≥۳۰s + assert نرم (پیام، نه snapshot سخت).

---

## ۷. اینوارینت‌هایی که هرگز نمی‌شکنند (حین تغییر)

۱. قرارداد JSON و قرارداد نتیجهٔ موتور (SKILL ساختار §۱۱) — UI/تست‌ها/زنجیره‌ها همه به آن قفل‌اند.
۲. Dolby One + Mic Studio + Separation/Gemini **دست‌نخورده** (تأیید صریح کاربر، چندباره).
۳. بکگراند و استایل کلی صفحهٔ اصلی **تغییر نمی‌کند** — فقط بلاک‌های نسخه‌دار اضافه.
۴. اصل صوتی هرگز overwrite نمی‌شود؛ output همیشه QA-gated؛ مونو fake-stereo ممنوع.
۵. سرور zero-key می‌ماند — کلید فقط کلاینت (options.js).
۶. Load order + `?v=` + چک بک‌دراپ + persistence pattern.
۷. AI فقط در subprocess؛ گارد RAM سرور.
۸. «DO NOTHING معتبر است» — هیچ موتوری «چون هست» پردازش نمی‌کند (فلسفهٔ Enhance از 1.txt).
۹. هر تغییر → worklog.md (فقط append با الگوی Task ID/Agent/Work Log/Stage Summary) → بستهٔ zip در download/.
۱۰. **فایل‌ها فقط زیر /home/z/my-project** ساخته می‌شوند؛ اسکریپت‌ها در scripts/، خروجی نهایی در download/.

---

## ۸. چک‌لیست انتشار (Release)

```
□ ۱. تغییرها کامل + بدون TODO/کد مرده/چند-خط کامنت‌های بی‌ربط
□ ۲. ./start.sh restart + /healthz + /api/dsp/health سبز
□ ۳. لایهٔ تست مرتبط(ها) سبز (engine/e2e/ui — شماره‌ها گزارش شوند)
□ ۴. VLM: مدال/کارت/موبایل PASS (اگر UI تغییر کرده)
□ ۵. موبایل 390×844 بدون overflow + صفر pageerror
□ ۶. رگرسیون: Dolby One و Mic Studio و Studio/Subtitles دست‌نخورده باقی (تست صریح)
□ ۷. ?v= بامپ + پیام کنسول [studio vNN]
□ ۸. این ۲ اسکیل را اگر ساختار عوض شده به‌روز کن
□ ۹. worklog.md سکشن جدید (الگوی Task ID/Agent/…)
□ ۱۰. zip: cd green-system && zip -r ../download/green-system-vNN.zip . -x "data/*" "daemon.*" "models/*" "engines/__pycache__/*" "__pycache__/*"
       (خودکفا: engines/ داخل zip است؛ models/data/pycache مستثنی) + اسکرین‌شات‌های vNN-*.png کنار zip
```

---

## ۹. دام‌های شناخته‌شدهٔ تاریخی (تکرار ممنوع)

| # | دام | درس |
|---|---|---|
| 1 | بک‌دراپ مدال با `e.target===modal` فقط | حتماً `modal-bg` هم چک شود |
| 2 | آپلود ۳.۵MB ~۳s، تست‌ها زود timeout | polling ≥۳۰s |
| 3 | VLM با `create()` | همیشه `createVision()` |
| 4 | تنظیمات اینلاین در کارت | ⚙ + مدال (الگوی R4) |
| 5 | کش استاتیک بعد از آپدیت | `?v=` بامپ + no-cache هدر (هست) |
| 6 | `filtfilt` با sos دوبعدی | `sosfiltfilt` (scipy) |
| 7 | subtype float64 در encode | `pcm_f32le`/`pcm_s24le`/`DOUBLE` درست |
| 8 | loudnorm خطی به هدف نمی‌رسد (crest بالا) | master تکراری (iterate) |
| 9 | OOM با مدل در پروسهٔ سرور | subprocess + چانک (۴s/۸s) + fallback |
| 10 | mask بولی IndexError در numpy | ماسک را قبل از ایندکس کامل بساز (باگ v33 `_pause_metrics`) |
| 11 | KeyError پارامترهای اختیاری در `_plan` | `.get()` با پیش‌فرض |
| 12 | رندر منو حین باز بودن، کلیک را می‌بلعد | keys-guarded rebuild (subs.js الگو) |
| 13 | فایل قفل/cloud در decode → «network error» قیافه | خواندن explicit اول + پیام دقیق (msep.js الگو) |
| 14 | `const c=cs` به‌جای `cs[i]` در normCues | آرایه/عضو — باگ خاموش یک‌روزه |
| 15 | ردیف‌های استم کهنه بعد از جداسازی جدید | resetStudio اجباری |
| 16 | دو vocal (سپیکر+استم) در mix | جایگزینی ردیف vocal با سپیکرها |
| 17 | idهای post-restart گم | _entry disk-recovery — این مکانیزم را حذف نکن |
| 18 | فیلد Optional (None) در f-string → کرش فقط با ورودی خاص | گارد −∞/'' — همیشه مسیر «بدون مشکل» را هم تست کن |

---

## ۱۰. «برای فلان کار، فلان فایل» — ایندکس برخورد

| می‌خواهم… | فایل(ها) اصلی | Recipe |
|---|---|---|
| موتور صوتی جدید | engines/… + serve.py + app.js + index.html | R1 |
| پارامتر موتور | هسته + _run_x + مدال + xParams | R2 |
| پریست | app.js + index.html | R3 |
| مدال/کنترل UI | index.html + app.js | R4 |
| endpoint | serve.py | R6 |
| تم زیرنویس/FX | viz/fx.js (+fx3d.js) + fxpanel | R7 |
| مسئله/گیت Enhance | engines/enhance.py (+ app.js اگر UI) | R8 |
| استایل | studio.css/viz.css | R9 |
| فیکس باگ | جدول §۵.۲ → لاگ → تست | §۵ |
| تست | scripts/ | R10/§۴ |
| انتشار | worklog + zip | §۸ |

---

## ۱۱. جریان‌های کاربر آماده (برای اثباتِ «همه‌چیز کار می‌کند»)

۱. **میکروفن گرون:** استودیو → MIC STUDIO → فایل ⚙ (پریست Podcast Gold) → Enhance ▶ → A/B + جدول تصمیم + دانلود.
۲. **عامل تشخیص‌محور:** استودیو → ENHANCE → فایل ⚙ (Diagnose Only) → Enhance ▶ → فقط گزارش؛ بعد Adaptive Gold → اجرای واقعی + ۱۰ گیت + ۸ امتیاز.
۳. **جداسازی کامل:** Source → Choose → Start → (MVSEP+Gemini) → Stem Studio → Scan&Fix → Final ✓ → Final Mix → Mixer/ZIP.
۴. **زیرنویس مدرن:** Subtitles → Local File/Separated ▾ → Generate → استیج 16:9 + FX Themes (تم + ورود + جهت + Word/Line + One-line + 3D + Word Pool) → HTML/SRT/VTT/TXT.
۵. **زنجیره استم با عامل:** Stem Studio → ردیف باز → Enhance Agent + Mic Studio هر دو تیک → Scan → زنجیره enhances→studiomic با QA هر گام.

---

*این اسکیل با v37 همگام است (خودکفا: engines/ داخل پروژه). شمای کامل ساختار در SKILL «green-system-structure». قانون آخر: هر تغییر ساختاری → هر دو اسکیل به‌روز شوند.*

---

## 🆕 v37 — موتورها به‌عنوان فعالیت‌های تیک‌پذیر + دانلود خودکار مدل

```bash
# کاتالوگ ماژول‌های هر ۹ موتور (چه چیزی قابل تیک است)
curl -s http://127.0.0.1:3000/api/dsp/engine_catalog | python3 -m json.tool | head -40

# وضعیت مدل AI (۷۱۳MB)
curl -s http://127.0.0.1:3000/api/model/status

# دانلود خودکار از HuggingFace (job با پیشرفت؛ fast-path اگر موجود)
curl -s -X POST http://127.0.0.1:3000/api/model/ensure
curl -s http://127.0.0.1:3000/api/dsp/job/<job_id>   # پیشرفت زنده

# اجرای موتور با تیک ماژول‌ها (denoise خاموش، بقیه فعال)
curl -s -X POST http://127.0.0.1:3000/api/dsp/run -H 'Content-Type: application/json' \
  -d '{"src_id":"<id>","engine":"voice","params":{"modules":{"denoise":false},"denoise":20}}'

# workshop تک-stem با params هر موتور (همان چیزی که Preview UI می‌فرستد)
curl -s -X POST http://127.0.0.1:3000/api/dsp/workshop_run -H 'Content-Type: application/json' \
  -d '{"items":[{"src_id":"<id>","kind":"voice","name":"vocals","engines":["voice"],
        "params":{"voice":{"modules":{"eq":false},"denoise":10}}}]}'
```

**علامت → درمان (v37):**

| علامت | علاج |
|---|---|
| `model status present:false` + دکمهٔ «AI model» در کارت Mic | `POST /api/model/ensure` → poll job → بعد از `done` بدون restart `resemble:true` |
| ماژول تیک‌خورده اثر نکرد | notes خروجی را ببین (`modules off: …`)؛ موتورهای سنگین از param/off استفاده می‌کنند نه modules |
| پنل ماژول در UI خالی | کاتالوگ لود نشده — Network را چک کن؛ fallback: موتورها بدون کاتالوگ هم تیک‌پذیرند ولی پنل رندر نمی‌شود |

**اینوارینت جدید:** هر تغییر در `engines/catalog.py` باید هم‌زمان با کلیدهای واقعی موتور در
`engines/local.py` (و paramهای سنگین‌ها) هم‌خوان باشد — sanitize کلیدهای ناشناس را حذف می‌کند
و سکوت = تیک بی‌اثر.


---

## 🆕 v38 — موتور چهارم «Studio Max» (قوی‌ترین ترکیب AI) + رجیستری چند-مدلی

موتور سوم/چهارم بعد از استدلال زنده روی کاندیداها (AudioSR رد شد: ۶.۲GB + مخزن GitHub حذف‌شده + قفل numpy≤1.23؛ FlashSR رد شد: ۳.۲GB و حتی در سندباکس تست ۳GB RAM جا نمی‌شود):
**Demucs htdemucs(_ft) جداسازی AI محلی + Apollo بازسازی موسیقی (Tencent AI Lab, arXiv:2409.08514) + Resemble وکال** — هر سه در زیرپروسهٔ ایزوله، پشت همان قرارداد QA.

```bash
# سلامت موتور + موجودی هر ۴ مدل
curl -s http://127.0.0.1:3000/api/dsp/health | python3 -c "import json,sys;print(json.load(sys.stdin)['studiomax_ai'])"

# رجیستری مدل‌ها (resemble/apollo/demucs/demucs_ft)
curl -s http://127.0.0.1:3000/api/model/status | python3 -m json.tool | head -30

# دانلود هر مدل از HuggingFace (job با پیشرفت؛ {} = resemble برای سازگاری v37)
curl -s -X POST http://127.0.0.1:3000/api/model/ensure -H 'Content-Type: application/json' \
     -d '{"model":"apollo"}'      # یا demucs / demucs_ft / resemble

# اجرای Studio Max — زنجیرهٔ کامل: split→restore→voice→polish→remix→spatial→master
curl -s -X POST http://127.0.0.1:3000/api/dsp/run -H 'Content-Type: application/json' \
  -d '{"src_id":"<id>","engine":"studiomax","params":{"restore":75,"voice":70,"width":1.35,"lufs":-16}}'

# فقط دو فعالیت مشخص (تیک ماژول‌ها مثل بقیهٔ موتورها)
curl -s -X POST http://127.0.0.1:3000/api/dsp/run -H 'Content-Type: application/json' \
  -d '{"src_id":"<id>","engine":"studiomax","params":{"modules":{"split":false,"voice":false,"restore":true,"polish":true,"spatial":false,"master":true}}}'

# در زنجیرهٔ Stem Studio (workshop) هم مثل هر موتور دیگر
curl -s -X POST http://127.0.0.1:3000/api/dsp/workshop_run -H 'Content-Type: application/json' \
  -d '{"items":[{"src_id":"<id>","kind":"music","name":"mix","engines":["studiomax"],"params":{"studiomax":{"restore":50}}}]}'
```

**علامت → درمان (v38):**

| علامت | علاج |
|---|---|
| `studiomax_ai.demucs:false` | `POST /api/model/ensure {"model":"demucs"}` → بدون restart روشن می‌شود |
| `ai_used.resemble:false` در decision ولی stage 4 «fallback» | worker resemble با OOM کشته شده — دموکز/آپولو قبل از stage 4 در زیرپروسه بودند؟ (باید باشند)؛ dmesg را ببین |
| `stage3 fallback` در حالی که Apollo هست | worker: `python -m engines.studiomax_worker restore in.wav out.wav 75 <ckpt>` را دستی اجرا کن؛ ERR را ببین |
| پردازش طولانی/کند (CPU) | طبیعی است: demucs ≈۰.۴×RT و apollo ≈۰.۱۲×RT روی ۲ هسته — job پیشرفت chunk دارد؛ preview با split/voice خاموش سریع است |

**اینوارینت‌های v38 (هرگز نشکنند):**
1. هر سه AI فقط در `engines/studiomax_worker.py` (زیرپروسه) اجرا می‌شوند — سرور هرگز torch را import نمی‌کند (به‌جز `_dl_demucs` که خودش worker می‌زند).
2. پیام‌های worker از stdout خط‌به‌خط (`PROG <pct> <msg>` / `OK` / `ERR`)؛ خواندن با select + deadline سخت — worker هنگ‌کرده هرگز job را گیر نمی‌اندازد.
3. `engines/apollo_model/` کد وندور شخص ثالث است (CC BY-SA 4.0) — فقط خوانده می‌شود؛ باگ = در studiomax_worker دورش بزن، نه داخلش.
4. discovery مدل‌ها: `models/` داخل اپ اول، `../models/` (layout قدیمی) دوم — همان قرارداد `studiomic._run_dir`.
5. مثل همیشه: نبودِ مدل = fallback نرم (exciter/noiseredude/afftdn) — job همیشه تمام می‌شود؛ QA gate همیشه فعال.
